package com.anz.mdm.ocv.api.util;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.text.translate.CharSequenceTranslator;
import org.apache.commons.text.translate.LookupTranslator;

/**
 * Provides util method for specific string escape functions not readily
 * available in commons-text StringEscaperUtils.
 *
 * @author palanisk
 *
 */
public final class StringEscaper {

    private StringEscaper() {

    }

    private static final CharSequenceTranslator ESCAPE_XML_JSON;

    static {
        final Map<CharSequence, CharSequence> escapeJsonMap = new HashMap<CharSequence, CharSequence>();
        escapeJsonMap.put("&quot;", "\\&quot;");
        escapeJsonMap.put("\\", "\\\\");
        ESCAPE_XML_JSON = new LookupTranslator(Collections.unmodifiableMap(escapeJsonMap));
    }

    /**
     * Escape the single quote and double quote characters in the attribute values.
     * This method is inspired from StringEscapeUtils (commons-text) and uses the
     * same construct
     * 
     * @param input
     *            xml string
     * @return Treated XML which is escaped for Double-Quote and Single Quote
     *         characters
     */
    public static String escapeXMLForJSON(String input) {
        return ESCAPE_XML_JSON.translate(input);
    }
}