package com.anz.mdm.ocv.api.mapper.cap;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;


import com.anz.mdm.ocv.api.dto.CapProfileDTO;
import com.anz.mdm.ocv.api.util.CapTransformerUtil;
import com.anz.mdm.ocv.cap.v1.CapProfile;

@Mapper(imports = { CapTransformerUtil.class, CapProfileDTO.class }, 
        uses = { com.anz.mdm.ocv.cap.v1.ObjectFactory.class })
public interface CapProfileMapValueSetter extends CapProfileMapper {
    @Mappings({
            @Mapping(target = "name", expression = "java(capDTO.getName())"),
            @Mapping(target = "title", expression = "java(capDTO.getTitle())"),
            @Mapping(target = "salutation", expression = "java(capDTO.getSalutation())"),
            @Mapping(target = "birthDate", expression = "java(capDTO.getBirthDate())"),
            @Mapping(target = "gender", expression = "java(capDTO.getGender())"),
            @Mapping(target = "maritalStatus", expression = "java(capDTO.getMaritalStatus())"),
            @Mapping(target = "emailAddress.email", expression = "java(capDTO.getEmail())"),
            @Mapping(target = "addresses", expression = "java(CapTransformerUtil.getAddress(capDTO))"),
            @Mapping(target = "employment.employmentType", expression = "java(capDTO.getEmploymentType())"),
            @Mapping(target = "employment.employer", expression = "java(capDTO.getEmployer())"),
            @Mapping(target = "employment.employerType", expression = "java(capDTO.getEmployerType())"),
            @Mapping(target = "employment.occupationCode", expression = "java(capDTO.getOccupationCode())"),
            @Mapping(target = "employment.countryExempt", expression = "java(capDTO.getCountryExempt())"),
            @Mapping(target = "employment.ssnTaxId", expression = "java(capDTO.getSsnTaxId())"),
            @Mapping(target = "isANZEmployee", expression = "java(capDTO.isANZEmployee())"),
            @Mapping(target = "customerType", expression = "java(capDTO.getCustomerType())"),
            @Mapping(target = "customerStatus", expression = "java(capDTO.getCustomerStatus())"),
            @Mapping(target = "openedDate", expression = "java(capDTO.getOpenedDate())"),
            @Mapping(target = "securityCode", expression = "java(capDTO.getSecurityCode())"),
            @Mapping(target = "bankruptDate", expression = "java(capDTO.getBankruptDate())"),
            @Mapping(target = "operatorLastMaintained", 
                    expression = "java(capDTO.getOperatorLastMaintained())"),
            @Mapping(target = "lastContact", expression = "java(capDTO.getLastContact())"),
            @Mapping(target = "additionalDetails.companyId", expression = "java(capDTO.getCompanyId())"),
            @Mapping(target = "additionalDetails.acceptsAdvertisements",    
                    expression = "java(capDTO.isAcceptsAdvertisements())"),
            @Mapping(target = "additionalDetails.agreeToDisclosure", expression = "java(capDTO.isAgreeToDisclosure())"),
            @Mapping(target = "additionalDetails.selfCertIndicator", 
                    expression = "java(capDTO.getSelfCertIndicator())"),
            @Mapping(target = "additionalDetails.branch", expression = "java(capDTO.getBranch())"),
            @Mapping(target = "additionalDetails.dateBusinessEstablished", 
                    expression = "java(capDTO.getDateBusinessEstablished())"),
            @Mapping(target = "additionalDetails.sicCode", expression = "java(capDTO.getSicCode())"),
            @Mapping(target = "additionalDetails.govtRefType", expression = "java(capDTO.getGovtRefType())"),
            @Mapping(target = "additionalDetails.govtRefNumber", expression = "java(capDTO.getGovtRefNumber())"),
            @Mapping(target = "additionalDetails.securityIndicator", 
                    expression = "java(capDTO.getSecurityIndicator())"),
            @Mapping(target = "additionalDetails.orgContactPhone", expression = "java(capDTO.getOrgContactPhone())"),
            @Mapping(target = "additionalDetails.orgContactFaxNumber",
                    expression = "java(capDTO.getOrgContactFaxNumber())"),
            @Mapping(target = "additionalDetails.orgContactName", expression = "java(capDTO.getOrgContactName())"),
            @Mapping(target = "additionalDetails.orgContactTitle", expression = "java(capDTO.getOrgContactTitle())"),
            @Mapping(target = "additionalDetails.orgContactMobile", expression = "java(capDTO.getOrgContactMobile())"),
            @Mapping(target = "additionalDetails.contactPreferredIndicator", 
                    expression = "java(capDTO.getContactPreferredIndicator())"),
            @Mapping(target = "additionalDetails.dateSelfCertification", 
                    expression = "java(capDTO.getDateSelfCertification())"),
            @Mapping(target = "additionalDetails.controllingPostId", 
                    expression = "java(capDTO.getControllingPostId())"),
            @Mapping(target = "additionalDetails.controllingPostId2", 
                    expression = "java(capDTO.getControllingPostId2())"),
        })
        CapProfile map(CapProfileDTO capDTO);

}
