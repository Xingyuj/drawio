package com.anz.mdm.ocv.api.util;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
@Setter
public class VaultUtil {

    @Value("${tokenise.identifierUsageType}")
    private String identifiers;

    public Boolean isIdentifiersExists(List<String> configIdentifiers, String inputStr) {
        String tempInputStr = inputStr.replaceAll("\\s","");
        return configIdentifiers.stream().anyMatch(tempInputStr::equals);
    }

    public List<String> getIdentifiers() {
        if (!StringUtils.isEmpty(identifiers)) {
            return Stream.of(identifiers.split(",")).map(String::trim)
                    .collect(Collectors.toCollection(ArrayList::new));
        }
        return new ArrayList<>();
    }

}
