package com.anz.mdm.ocv.api;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.jwt.util.LogUtil;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Setter
@Getter
@Configuration
@ConfigurationProperties(prefix = "")
public class UAMAccessConfiguration {

    private Map<String, Object> ocv = new HashMap<String, Object>();

    @SuppressWarnings("unchecked")
    public Map getAccessMap(String claimName) {
        Map<String, Object> accessObject = (Map<String, Object>) ocv.get(claimName);
        if (accessObject != null) {
            Map<String, String> accessList = (Map<String, String>) accessObject.get(OCVConstants.UAM_ACCESS_LIST_NAME);
            return accessList;
        }
        return null;
    }
    
    /* included as part of JWT 17031 feature */
    
    public Map getIssuer(String type, String listName) {
        LogUtil.debug(log, "UAMAccessConfiguration::getIssuer", "", "ConfigMap lookup in UAMAccessConfiguration");
        Map<String, Object> accessObject = (Map<String, Object>) ocv.get(type);
        if (accessObject != null) {
            Map<String, String> accessList = (Map<String, String>) accessObject.get(listName);
            return accessList;
        }
        return null;
    }
}