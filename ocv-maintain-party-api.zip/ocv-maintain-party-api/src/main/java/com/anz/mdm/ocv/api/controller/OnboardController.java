package com.anz.mdm.ocv.api.controller;


import static com.anz.mdm.ocv.api.util.LogUtil.printObjectAsString;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.downsteamservices.OnboardService;
import com.anz.mdm.ocv.api.dto.APIResponse;
import com.anz.mdm.ocv.api.exception.JwtValidationException;
import com.anz.mdm.ocv.api.interceptor.JWTInterceptor;
import com.anz.mdm.ocv.api.util.APIServiceUtil;
import com.anz.mdm.ocv.api.util.IdempotencyConfigUtil;
import com.anz.mdm.ocv.api.util.LogRequestModel;
import com.anz.mdm.ocv.api.util.LogUtil;
import com.anz.mdm.ocv.api.validator.APIRequest;
import com.anz.mdm.ocv.common.v1.Identifier;
import com.anz.mdm.ocv.party.v1.Party;

import lombok.extern.slf4j.Slf4j;


/**
 * Onboard processing Controller
 *
 * @author Ethan Ji
 */
@Slf4j
@RestController
public class OnboardController {

    private final LogRequestModel logAttributes;

    private final JWTInterceptor jwtInterceptor;

    private final OnboardService onboardService;

    private final IdempotencyConfigUtil idempotencyUtil;

    @Autowired
    public OnboardController(LogRequestModel logAttributes,
                             JWTInterceptor jwtInterceptor,
                             OnboardService onboardService,
                             IdempotencyConfigUtil idempotencyUtil) {
        this.logAttributes = logAttributes;
        this.jwtInterceptor = jwtInterceptor;
        this.onboardService = onboardService;
        this.idempotencyUtil = idempotencyUtil;
    }

    public void populateLogAttributes(APIRequest<Party> apiRequest) {
        logAttributes.setChannel(apiRequest.getChannel());
        logAttributes.setTraceId(apiRequest.getTraceId());
        logAttributes.setPartyType(apiRequest.getRequestBody().getPartyType());
    }

    @RequestMapping(method = RequestMethod.POST, value = "v3/parties", consumes = {MediaType.APPLICATION_JSON_VALUE},
            produces = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseBody
    public ResponseEntity<Object> maintainPartyV3(@RequestHeader Map<String, String> headers,
                                                  @RequestParam Map<String, String> queryParameters,
                                                  @RequestBody Party party) throws Exception {
        long startTime = System.currentTimeMillis();
        String traceId = headers.get(OCVConstants.TRACE_ID_HEADER);
        APIRequest<Party> apiRequest = new APIRequest<>(headers, queryParameters, party);
        logAttributes.setServiceName(OCVConstants.MAINTAINPARTY_SERVICE);
        populateLogAttributes(apiRequest);

        boolean signatureValidationStatus = jwtInterceptor.validateJWT(apiRequest);
        if (!signatureValidationStatus) {
            LogUtil.debug(log, "maintainParty Api", traceId,
                    "Header and Signature tampered causing signature validation failure. "
                            + "Pls try with a valid JWT", System.currentTimeMillis() - startTime);
            throw new JwtValidationException(OCVConstants.INVALID_JWT_CODE, OCVConstants.INVALID_JWT);
        }

        APIRequest<Party> validatedRequest = onboardService.getPartyAPIRequestWithValidatedParty(headers,
                queryParameters,
                apiRequest, startTime);

        idempotencyUtil.validate(validatedRequest, apiRequest, logAttributes.getTraceId());

        // create prospect profile
        log.info("Missing OCV id or profile id, going to create Prospect profile first in MDM");
        APIResponse responseCreateProfileInMDM = onboardService.createOrUpdateProspectParty(
                apiRequest, traceId, null, false);

        if (responseCreateProfileInMDM.getResponseFromIdempotency() != null
                && responseCreateProfileInMDM.getResponseFromIdempotency()) {
            responseCreateProfileInMDM.setResponseFromIdempotency(null);
            return new ResponseEntity<>(responseCreateProfileInMDM, new APIServiceUtil().setHeaders(traceId),
                    HttpStatus.ACCEPTED);
        }

        APIResponse responseUpdateParty = attachCapCisIdAndProfileId(traceId, apiRequest, validatedRequest,
                responseCreateProfileInMDM);

        return new ResponseEntity<>(responseUpdateParty, new APIServiceUtil().setHeaders(traceId), HttpStatus.OK);
    }

    private APIResponse attachCapCisIdAndProfileId(String traceId, APIRequest<Party> apiRequest,
                                                   APIRequest<Party> validatedRequest,
                                                   APIResponse responseCreateProfileInMDM) throws Exception {
        // Attach by retrieving or generating cap cis id
        Identifier identifierOCVID = new Identifier();
        identifierOCVID.setIdentifier(responseCreateProfileInMDM.getOcvId());
        identifierOCVID.setIdentifierUsageType(OCVConstants.OCV_ID_IDENTIFIER_TYPE);
        validatedRequest.getRequestBody().getIdentifiers().add(identifierOCVID);

        Identifier identifierProfileID = new Identifier();
        identifierProfileID.setIdentifier(responseCreateProfileInMDM.getProfileIds().get(0));
        identifierProfileID.setIdentifierUsageType(OCVConstants.OCV_PROFILE_ID_TYPE);
        validatedRequest.getRequestBody().getIdentifiers().add(identifierProfileID);

        // retrieved returns false, generated new one returns true
        Boolean createCustomerModeWithCAPCISID = onboardService.retrieveOrGenerateCapCisId(apiRequest, validatedRequest,
                traceId);
        APIResponse responseUpdateParty = onboardService.createOrUpdateProspectParty(
                apiRequest, traceId, createCustomerModeWithCAPCISID, true);
        log.debug("create or update prospect party response: " + printObjectAsString(responseUpdateParty));
        if (responseUpdateParty.getProfileIds() == null || responseUpdateParty.getProfileIds().size() < 1) {
            responseUpdateParty.setProfileIds(responseCreateProfileInMDM.getProfileIds());
        }
        // AND MDM should return same details to return to CRM
        responseUpdateParty.setResponseFromIdempotency(null);
        return responseUpdateParty;
    }
}