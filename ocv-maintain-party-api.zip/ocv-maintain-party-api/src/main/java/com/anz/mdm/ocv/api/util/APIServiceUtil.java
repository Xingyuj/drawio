package com.anz.mdm.ocv.api.util;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.springframework.http.HttpHeaders;
import org.springframework.util.CollectionUtils;

import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.downsteamservices.ValidatedParty;
import com.anz.mdm.ocv.api.dto.APIResponse;
import com.anz.mdm.ocv.api.model.CAPParty;
import com.anz.mdm.ocv.api.validator.APIRequest;
import com.anz.mdm.ocv.common.v1.CommercialContacts;
import com.anz.mdm.ocv.common.v1.Fax;
import com.anz.mdm.ocv.common.v1.Identifier;
import com.anz.mdm.ocv.common.v1.Phone;
import com.anz.mdm.ocv.common.v1.PrivacyPreference;
import com.anz.mdm.ocv.party.v1.Party;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class APIServiceUtil {

    public HttpHeaders setHeaders(String traceId) {
        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.set("x-b3-traceid", traceId);
        responseHeaders.set(HttpHeaders.CACHE_CONTROL, "no-cache, no-store");
        responseHeaders.set("Content-Security-Policy",
                "default-src 'none'; img-src 'self'; " + "script-src 'self'; style-src 'self'; https:");
        responseHeaders.set(HttpHeaders.PRAGMA, "no-cache");
        responseHeaders.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains;");

        return responseHeaders;
    }

    public String printPartyRequest(final Party partyRequest) {
        String json = "";
        ObjectMapper mapper = new ObjectMapper();
        try {
            json = mapper.writeValueAsString(partyRequest);
        } catch (JsonProcessingException e) {
            LogUtil.error(log, "printPartyRequest", "JsonProcessingException: ", e.getLocalizedMessage());
        }
        // LogUtil.info(log, "partyRequest is", json, "JSON String",
        // System.currentTimeMillis(), null, null, "APIConroller");
        return json;
    }
    
    /**
     * logging for V2 API - Moved here as method block allows only 50 lines of code.
     */
    public void captureLogs(Logger log, String traceId, Map<String, String> headers, Party party) {
        LogUtil.debug(log, "maintainParty", traceId, "Entering: maintainParty method in APIController");
        LogUtil.debug(log, "maintainParty", traceId, "Headers: " + headers);
        LogUtil.debug(log, "partyRequest for ANZx:", printPartyRequest(party), "maintainPartyAPI");
    }

    public static void removeOcvId(APIRequest<Party> validatedApiRequest) {
        List<Identifier> identifiers = validatedApiRequest.getRequestBody().getIdentifiers();
        if (!CollectionUtils.isEmpty(identifiers)) {
            for (Iterator<Identifier> iterator = identifiers.iterator(); iterator.hasNext();) {
                Identifier identifier = iterator.next();
                if (OCVConstants.ONE_CUSTOMER_ID.equalsIgnoreCase(identifier.getIdentifierUsageType())) {
                    iterator.remove();
                }
            }
        }
    }
    
    public void populateLatestOCVIdInRequest(APIResponse response, APIRequest<Party> validatedApiRequest) {
        if (null != response) {
            Identifier ocvIdIndentifier = validatedApiRequest
                    .getRequestBody()
                    .getIdentifiers()
                    .stream()
                    .filter(iden -> OCVConstants.OCV_ID_IDENTIFIER_TYPE.equalsIgnoreCase(iden.getIdentifierUsageType()))
                    .findAny().orElse(null);
            if (null != response.getOcvId() && null != ocvIdIndentifier.getIdentifier()
                    && !response.getOcvId().equalsIgnoreCase(ocvIdIndentifier.getIdentifier())) {
                // Update Only when they are not the same
                validatedApiRequest.getRequestBody().setOcvId(response.getOcvId());
                ocvIdIndentifier.setIdentifier(response.getOcvId());
            }
        }
    }
 
    
    /**
     * Added for https://jira.service.anz/browse/OCT-25769
     * This method maps commercial contacts and checks if Phone exists in requests.
     */
    public boolean isPhoneExists(ValidatedParty validatedPartyParam) throws Exception {
        this.constructPhoneWithCommerContact(validatedPartyParam.getParty());
        if (!CollectionUtils.isEmpty(validatedPartyParam.getParty().getPhones())
                && validatedPartyParam.getParty().getPhones().size() > 0) {
            return true;
        }
        return false;
    }

    /**
     * Added for https://jira.service.anz/browse/OCT-25769
     * This method populates Phone and fax from Commercial contacts
     */
    private void constructPhoneWithCommerContact(Party party) throws Exception {
        List<CommercialContacts> commercialContacts = party.getCommercialContacts();
        if (!CollectionUtils.isEmpty(commercialContacts) && commercialContacts.size() > 0) {
            List<Phone> phones = party.getPhones();
            List<Fax> faxes = party.getFaxes();
            for (CommercialContacts commercialContact : commercialContacts) {
                if (StringUtils.isNoneBlank(commercialContact.getMobile())) {
                    Phone commPhone = new Phone();
                    commPhone.setPhoneUsageType(OCVConstants.COMMERCIAL_MOBILE);
                    commPhone.setPhone(commercialContact.getMobile());
                    commPhone.setContactPreferredInd(commercialContact.getPreferred());
                    commPhone.setSequence(commercialContact.getSequence());
                    commPhone.setContactName(commercialContact.getName());
                    commPhone.setContactTitle(commercialContact.getTitle());
                    commPhone.setSource(party.getSource());
                    commPhone.setStartDate(commercialContact.getStartDate());
                    commPhone.setEndDate(commercialContact.getEndDate());
                    phones.add(commPhone);
                }
                if (StringUtils.isNoneBlank(commercialContact.getPhone())) {
                    Phone commPhone = new Phone();
                    commPhone.setPhoneUsageType(OCVConstants.COMMERCIAL_PHONE);
                    commPhone.setPhone(commercialContact.getPhone());
                    commPhone.setContactPreferredInd(commercialContact.getPreferred());
                    commPhone.setSequence(commercialContact.getSequence());
                    commPhone.setContactName(commercialContact.getName());
                    commPhone.setContactTitle(commercialContact.getTitle());
                    commPhone.setSource(party.getSource());
                    commPhone.setStartDate(commercialContact.getStartDate());
                    commPhone.setEndDate(commercialContact.getEndDate());
                    phones.add(commPhone);
                }
                if (StringUtils.isNoneBlank(commercialContact.getFax())) {
                    Fax fax = new Fax();
                    fax.setFaxUsageType(OCVConstants.COMMERCIAL_FAX);
                    fax.setFax(commercialContact.getFax());
                    fax.setContactPreferredInd(commercialContact.getPreferred());
                    fax.setSequence(commercialContact.getSequence());
                    fax.setContactName(commercialContact.getName());
                    fax.setContactTitle(commercialContact.getTitle());
                    fax.setSource(party.getSource());
                    fax.setStartDate(commercialContact.getStartDate());
                    faxes.add(fax);
                }
            }
            party.getCommercialContacts().clear();
        }
    }
    
    public void populatePrivacyPreference(CAPParty capCreateResponse) {
        PrivacyPreference privacyPreferenceAdvInd = new PrivacyPreference();
        privacyPreferenceAdvInd.setPreferenceType(OCVConstants.ADVERTISING_IND);
        privacyPreferenceAdvInd.setPreferenceValue(OCVConstants.ADVERTISING_DISC_IND_NO);
        privacyPreferenceAdvInd.setPreferenceReason(OCVConstants.ADVERTISING_DISC_NOT_ALLOWED);
        privacyPreferenceAdvInd.setSource(capCreateResponse.getPartyApiReq().getChannel());
        privacyPreferenceAdvInd.setStartDate(OCVConstants.LOW_END_DATE);
        capCreateResponse.getPartyApiReq().getRequestBody().getPreferences().add(privacyPreferenceAdvInd);
        
        PrivacyPreference privacyPreferenceDiscInd = new PrivacyPreference();
        privacyPreferenceDiscInd.setPreferenceType(OCVConstants.DISCLOSURE_IND);
        privacyPreferenceDiscInd.setPreferenceValue(OCVConstants.ADVERTISING_DISC_IND_NO);
        privacyPreferenceDiscInd.setPreferenceReason(OCVConstants.ADVERTISING_DISC_NOT_ALLOWED);
        privacyPreferenceDiscInd.setSource(capCreateResponse.getPartyApiReq().getChannel());
        privacyPreferenceDiscInd.setStartDate(OCVConstants.LOW_END_DATE);
        capCreateResponse.getPartyApiReq().getRequestBody().getPreferences().add(privacyPreferenceDiscInd);
    }
}