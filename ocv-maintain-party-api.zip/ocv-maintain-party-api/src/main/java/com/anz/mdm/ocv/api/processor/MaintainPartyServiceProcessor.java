package com.anz.mdm.ocv.api.processor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;

import com.anz.mdm.ocv.api.constants.MDMRequestTemplates;
import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.util.IdempotencyConfigUtil;
import com.anz.mdm.ocv.api.util.LogUtil;
import com.anz.mdm.ocv.api.util.MaintainPartyAdditionalAttributes;
import com.anz.mdm.ocv.api.util.MaintainPartyIndBankingRelationship;
import com.anz.mdm.ocv.api.util.MaintainPartyIndBankingServices;
import com.anz.mdm.ocv.api.util.MaintainPartyOrgBankingRelationship;
import com.anz.mdm.ocv.api.util.MaintainPartyOrgBankingServices;
import com.anz.mdm.ocv.api.util.MaintainPartyPrepareJurisdiction;
import com.anz.mdm.ocv.api.util.RequestTransfomerUtil;
import com.anz.mdm.ocv.api.util.StreetSuffixConfig;
import com.anz.mdm.ocv.api.validator.APIRequest;
import com.anz.mdm.ocv.common.v1.Address;
import com.anz.mdm.ocv.common.v1.AnzsicDetail;
import com.anz.mdm.ocv.common.v1.BankingRelationships;
import com.anz.mdm.ocv.common.v1.BankingService;
import com.anz.mdm.ocv.common.v1.CommercialContacts;
import com.anz.mdm.ocv.common.v1.Consent;
import com.anz.mdm.ocv.common.v1.EVMatchStatus;
import com.anz.mdm.ocv.common.v1.Email;
import com.anz.mdm.ocv.common.v1.Fax;
import com.anz.mdm.ocv.common.v1.Identifier;
import com.anz.mdm.ocv.common.v1.JurisdictionDetail;
import com.anz.mdm.ocv.common.v1.KYCVerification;
import com.anz.mdm.ocv.common.v1.KYCVerificationDocRef;
import com.anz.mdm.ocv.common.v1.KycVerificationMethods;
import com.anz.mdm.ocv.common.v1.Name;
import com.anz.mdm.ocv.common.v1.NoTaxReason;
import com.anz.mdm.ocv.common.v1.PartyMacroRole;
import com.anz.mdm.ocv.common.v1.Phone;
import com.anz.mdm.ocv.common.v1.PrivacyPreference;
import com.anz.mdm.ocv.common.v1.SocialMedia;
import com.anz.mdm.ocv.common.v1.SourceSystem;
import com.anz.mdm.ocv.common.v1.TaxCountry;
import com.anz.mdm.ocv.party.v1.Party;

import io.micrometer.core.instrument.util.StringUtils;
import lombok.extern.slf4j.Slf4j;

/**
 * Serves as a processor to transform the JSON request to MDM specific request
 */
@Slf4j
public class MaintainPartyServiceProcessor {

    private Random random = new Random();

    public StringBuilder prepareOrgReq(StringBuilder request, Party party, String traceId, Map<String, String> headers,
                                       String anzxAddressChannel, StreetSuffixConfig streetSuffixCfg) {
        LogUtil.debug(log, "prepareOrgRequest", traceId,
                "Entering: prepareOrgRequest method in MaintainPartyServiceProcessor");
        String channel = headers.get(OCVConstants.CHANNEL);
        PartyInternalObjectsProcessor childObjProcessor = new PartyInternalObjectsProcessor();
        MaintainPartyPrepareJurisdiction jurisdictionObjProcessor = new MaintainPartyPrepareJurisdiction();
        MaintainPartyOrgBankingServices bankingServicesORG = new MaintainPartyOrgBankingServices();
        MaintainPartyOrgBankingRelationship bankingRelationshipsORG = new MaintainPartyOrgBankingRelationship();
        MaintainPartyAdditionalAttributes additionalAttributes = new MaintainPartyAdditionalAttributes();
        prepareOrgDetails(request, party, traceId);
        List<Name> orgNameList = party.getNames();
        List<Address> addressList = party.getAddresses();
        List<Phone> phones = party.getPhones();
        List<Email> emails = party.getEmails();
        List<Identifier> identifiers = party.getIdentifiers();
        List<Fax> faxes = party.getFaxes();
        List<SocialMedia> socialMedia = party.getSocialMedia();
        List<SourceSystem> sourceSystems = party.getSourceSystems();
        List<PrivacyPreference> privacyPreference = party.getPreferences();
        List<CommercialContacts> commercialContacts = party.getCommercialContacts();
        List<BankingService> bankingService = party.getBankingServices();
        List<BankingRelationships> bankingRelationShip = party.getBankingRelationships();
        List<JurisdictionDetail> jurisdictionDetails = party.getJurisdictionDetails();
        List<PartyMacroRole> partyMacroRoles = party.getPartyMacroRoles();
        List<AnzsicDetail> anzsicDetails = party.getAnzsicDetails();
        prepareOrgName(request, orgNameList, traceId);
        childObjProcessor.preparePartyAddress(request, addressList, traceId, channel, anzxAddressChannel,
                streetSuffixCfg);
        childObjProcessor.prepareContactMethods(request, phones, emails, faxes, socialMedia, traceId, null);
        childObjProcessor.prepareIdentifiers(request, identifiers, traceId, null);
        childObjProcessor.prepareContEquivs(request, sourceSystems, party.getPartyType(), traceId);
        childObjProcessor.preparePreferences(request, privacyPreference, party.getPartyType(), traceId);
        prepareCommercialContacts(request, commercialContacts, traceId);
        prepareJurisdictionForCAPSource(request, jurisdictionDetails, sourceSystems, traceId);
        jurisdictionObjProcessor.prepareJurisdictionKeyValueObjects(request, jurisdictionDetails, traceId);
        bankingServicesORG.prepareKeyValueforBankingServicesObjects(request, bankingService, traceId);
        bankingRelationshipsORG.prepareBankingRelationShipKeyValueObjects(request, bankingRelationShip, traceId);
        additionalAttributes.preparePartyMacroRoles(request, partyMacroRoles, traceId);
        additionalAttributes.prepareAnzsicDetails(request, anzsicDetails, traceId);
        populateTaxCountries(request, party.getTaxCountries(), childObjProcessor, traceId);
        childObjProcessor.prepareCitizenship(request, party.getCitizenship(), traceId);
        // This Below method has to stay at last to clear all unused validation
        // and verification
        removeValidationAndVerification(request, traceId);
        LogUtil.debug(log, "prepareOrgRequest", traceId,
                "Exiting: prepareOrgRequest in " + "MaintainPartyServiceProcessor");
        return request;
    }

    public void prepareOrgDetails(StringBuilder request, Party party, String traceId) {
        RequestTransfomerUtil.modifyTemplate(request, "@ClientStatusValue@", party.getStatus(), traceId);
        // BVD changes OCT-10973
        RequestTransfomerUtil.modifyTemplate(request, "@EntityStatusValue@", party.getEntityStatus(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@SourceIdentifierValue@", party.getSource(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@OrganizationValue@", party.getOrganisationType(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@EstablishedDate@", party.getEstablishmentDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@SinceDate@", party.getSourceEstablishedDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@LeftDate@", party.getSourceClosedDate(), traceId);
        if (null != party.getIndustry()) {
            RequestTransfomerUtil.modifyTemplate(request, "@IndustryValue@", party.getIndustry().getCode(), traceId);
        } else {
            RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@IndustryValue@", traceId);
        }
        if (null != party.getKycDetails()) {
            RequestTransfomerUtil.modifyTemplate(request, "@XKycVerificationLevelValue@",
                    party.getKycDetails().getVerificationLevel(), traceId);
            RequestTransfomerUtil.modifyTemplate(request, "@XKycStatusValue@", party.getKycDetails().getStatus(),
                    traceId);
        } else {
            RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@XKycVerificationLevelValue@", traceId);
            RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@XKycStatusValue@", traceId);
        }
        RequestTransfomerUtil.modifyTemplate(request, "@XBankruptDate@", party.getBankruptDate(), traceId);
    }

    public void prepareOrgName(StringBuilder request, List<Name> orgNameList, String traceId) {
        LogUtil.debug(log, "prepareOrgName", traceId,
                "Entering: prepareOrgName method in MaintainPartyServiceProcessor");
        int namesCount = 0;
        for (Name orgName : orgNameList) {
            if (namesCount == 0) {

                modifytemplateForOrgNames(request, orgName, traceId);
                namesCount++;
            } else {
                createAndModifyTemplateForOrgNames(request, orgName, traceId);
            }
        }
        RequestTransfomerUtil.removeObjectFromTemplate(request, "<TCRMOrganizationNameBObj>",
                "</TCRMOrganizationNameBObj>", namesCount, traceId);
        LogUtil.debug(log, "prepareOrgName", traceId, "Exit: prepareOrgName method in MaintainPartyServiceProcessor");

    }

    public void modifytemplateForOrgNames(StringBuilder request, Name orgName, String traceId) {
        LogUtil.debug(log, "modifytemplateForOrgNames", traceId,
                "Entering: modifytemplateForOrgNames method in MaintainPartyServiceProcessor");
        RequestTransfomerUtil.modifyTemplate(request, "@OrganizationName@", orgName.getName(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@OrgNameUsageValue@", orgName.getNameUsageType(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@OrgNameStartDate@", orgName.getStartDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@OrgNameEndDate@", orgName.getFirstName(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@OrgNameSourceIdentifierValue@", orgName.getSource(), traceId);
        LogUtil.debug(log, "modifytemplateForOrgNames", traceId,
                "Exit: modifytemplateForOrgNames method in MaintainPartyServiceProcessor");
    }

    public void createAndModifyTemplateForOrgNames(StringBuilder request, Name orgName, String traceId) {
        LogUtil.debug(log, "createAndModifyTemplateForOrgNames", traceId,
                "Entering: createAndModifyTemplateForOrgNames method in MaintainPartyServiceProcessor");
        String orgNameRequest = MDMRequestTemplates.MAINTAIN_PARTY_ORGNAME_REQUEST;
        request.insert(request.indexOf("<TCRMPartyAddressBObj>"), orgNameRequest);
        modifytemplateForOrgNames(request, orgName, traceId);
        LogUtil.debug(log, "createAndModifyTemplateForOrgNames", traceId,
                "Exit: createAndModifyTemplateForOrgNames method in MaintainPartyServiceProcessor");

    }

    private void prepareCommercialContacts(StringBuilder request, List<CommercialContacts> commercialContacts,
                                           String traceId) {
        LogUtil.debug(log, "prepareCommercialContacts", traceId,
                "Entering: prepareCommercialContacts method in MaintainPartyServiceProcessor");
        int commercialCount = 0;
        for (CommercialContacts commercialContact : commercialContacts) {
            if (commercialCount == 0) {
                modifytemplateForCommercialContacts(request, commercialContact, traceId, commercialCount);
                commercialCount++;
            } else {
                createAndModifyTemplateForCommercialContacts(request, commercialContact, traceId, commercialCount);
            }

        }
        RequestTransfomerUtil.removeObjectFromTemplate(request, "<TCRMPartyDemographicsBObj>",
                "</TCRMPartyDemographicsBObj>", commercialCount, traceId);
        LogUtil.debug(log, "prepareCommercialContacts", traceId,
                "Exit: prepareCommercialContacts method in MaintainPartyServiceProcessor");

    }

    private void createAndModifyTemplateForCommercialContacts(StringBuilder request,
                                                              CommercialContacts commercialContact, String traceId,
                                                              int commercialCount) {
        LogUtil.debug(log, "createAndModifyTemplateForCommercialContacts", traceId,
                "Entering: createAndModifyTemplateForCommercialContacts method in MaintainPartyServiceProcessor");
        String commercialContactRequest = MDMRequestTemplates.MAINTAIN_PARTY_COMMERCIALCONTACTS_REQUEST;
        request.insert(request.indexOf("</CommercialContact:CommercialContactList>"), commercialContactRequest);
        modifytemplateForCommercialContacts(request, commercialContact, traceId, commercialCount);
        LogUtil.debug(log, "createAndModifyTemplateForCommercialContacts", traceId,
                "Exit: createAndModifyTemplateForCommercialContacts method in MaintainPartyServiceProcessor");
    }

    private void modifytemplateForCommercialContacts(StringBuilder request, CommercialContacts commercialContact,
                                                     String traceId, int commercialCount) {
        LogUtil.debug(log, "modifytemplateForCommercialContacts", traceId,
                "Entering: modifytemplateForCommercialContacts method in MaintainPartyServiceProcessor");
        if (commercialCount == 0) {
            RequestTransfomerUtil.modifyTemplate(request, "@PartyDemographicsStartDate@",
                    commercialContact.getStartDate(), traceId);
        }
        RequestTransfomerUtil.modifyTemplate(request, "@CommercialContactName@", commercialContact.getName(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@CommercialContactTitle@", commercialContact.getTitle(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@CommercialContactMobile@", commercialContact.getMobile(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@CommercialContactPreferredIndicator@",
                commercialContact.getPreferred(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@CommercialContactPhone@", commercialContact.getPhone(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@CommercialContactFax@", commercialContact.getFax(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@CommercialContactOccurrence@", commercialContact.getSequence(),
                traceId);
        LogUtil.debug(log, "modifytemplateForCommercialContacts", traceId,
                "Exit: modifytemplateForCommercialContacts method in MaintainPartyServiceProcessor");
    }

    public void prepareControlObject(StringBuilder request, Party party, String requestTime, String traceId,
                                     String channel, String userId, String requestMode) {
        LogUtil.debug(log, "prepareControlObject", traceId,
                "Entering: prepareControlObject method in MaintainPartyServiceProcessor");
        Long startTime = System.currentTimeMillis();
        String requestIdValue = Long.toString(startTime);
        RequestTransfomerUtil.modifyTemplate(request, "@requesterName@", userId, traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@requestID@", requestIdValue, traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@transactionCorrelatorId@", traceId, traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@requestTime@", requestTime, traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@clientSystemName@", channel, traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@requestMode@", requestMode, traceId);
        LogUtil.debug(log, "prepareControlObject", traceId,
                "Exit: prepareControlObject method in MaintainPartyServiceProcessor");
    }

    public void prepareIdemptotencyControlObj(StringBuilder request, String idempotencyKey, String idempotencyFirstSent,
                                              String persistsResponse, String traceId) {
        LogUtil.debug(log, "prepareIdemptotencyControlObj", traceId,
                "Entering: prepareIdemptotencyControlObj method in MaintainPartyServiceProcessor");

        RequestTransfomerUtil.modifyTemplate(request, "@idempotencyKey@", idempotencyKey, traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@idempotencyFirstSent@", idempotencyFirstSent, traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@persistInIdempotency@", persistsResponse, traceId);
        LogUtil.debug(log, "prepareIdemptotencyControlObj", traceId,
                "Exit: prepareIdemptotencyControlObj method in MaintainPartyServiceProcessor");
    }

    public void prepareControlObjectExt(StringBuilder request, String traceId, String fenergoSourceId) {
        LogUtil.debug(log, "prepareControlObjectExt", traceId,
                "Entering: prepareControlObjectExt method in MaintainPartyServiceProcessor");

        if (fenergoSourceId != null) {
            RequestTransfomerUtil.modifyTemplate(request, "@fenergoSourceId@", fenergoSourceId, traceId);
        } else {
            RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@fenergoSourceId@", traceId);
        }
        LogUtil.debug(log, "prepareControlObjectExt", traceId,
                "Exit: prepareControlObjectExt method in MaintainPartyServiceProcessor");
    }

    public StringBuilder preparePersonRequest(StringBuilder request, Party party, Map<String, String> headers,
                                              String traceId, String anzxAddressChannel,
                                              StreetSuffixConfig stSuffixCfg) {
        String channel = headers.get(OCVConstants.CHANNEL);
        PartyInternalObjectsProcessor childObjProcessor = new PartyInternalObjectsProcessor();
        MaintainPartyPrepareJurisdiction jurisdictionObjProcessor = new MaintainPartyPrepareJurisdiction();
        MaintainPartyIndBankingServices bankingServicesIND = new MaintainPartyIndBankingServices();
        MaintainPartyIndBankingRelationship bankingRelationshipIND = new MaintainPartyIndBankingRelationship();
        MaintainPartyAdditionalAttributes additionalAttributes = new MaintainPartyAdditionalAttributes();
        prepareKycDetails(party, request, traceId);
        prepareOccupationDetails(party, request, traceId);
        prepareTaxDetails(party, request, traceId);
        preparePersonDetails(party, request, traceId);
        List<KYCVerification> kycVerifications = party.getKycVerifications();

        List<Consent> consents = party.getConsents();
        prepareConsentDetails(childObjProcessor, consents, request, traceId);
        List<Name> personNameList = party.getNames();
        List<Address> addressList = party.getAddresses();
        List<Phone> phones = party.getPhones();
        List<Email> emails = party.getEmails();
        List<SocialMedia> socialMedia = party.getSocialMedia();
        List<Identifier> identifiers = party.getIdentifiers();
        List<Fax> faxes = party.getFaxes();
        List<SourceSystem> sourceSystems = party.getSourceSystems();
        List<PrivacyPreference> privacyPreference = party.getPreferences();
        List<BankingService> bankingServices = party.getBankingServices();
        List<BankingRelationships> bankingRelationShip = party.getBankingRelationships();
        List<JurisdictionDetail> jurisdictionDetails = party.getJurisdictionDetails();
        List<PartyMacroRole> partyMacroRoles = party.getPartyMacroRoles();
        childObjProcessor.preparePartyAddress(request, addressList, traceId, channel, anzxAddressChannel, stSuffixCfg);
        childObjProcessor.prepareContactMethods(request, phones, emails, faxes, socialMedia, traceId, channel);
        Map<String, String> objRefNumMap = populateIdentifiers(request, party, traceId, channel, childObjProcessor,
                identifiers);
        childObjProcessor.prepareContEquivs(request, sourceSystems, party.getPartyType(), traceId);
        preparePersonNames(request, personNameList, traceId);
        childObjProcessor.preparePreferences(request, privacyPreference, party.getPartyType(), traceId);
        childObjProcessor.prepareDocumentReferences(party, request, traceId);
        prepareJurisdictionForCAPSource(request, jurisdictionDetails, sourceSystems, traceId);
        jurisdictionObjProcessor.prepareJurisdictionKeyValueObjects(request, jurisdictionDetails, traceId);
        bankingServicesIND.prepareKeyValueforBankingServicesObjects(request, bankingServices, traceId);
        bankingRelationshipIND.prepareBankingRelationShipKeyValueObjects(request, bankingRelationShip, traceId);
        prepareKYCVerificationDetails(childObjProcessor, kycVerifications, request, objRefNumMap, traceId); // Beta
        additionalAttributes.preparePartyMacroRoles(request, partyMacroRoles, traceId);
        populateTaxCountries(request, party.getTaxCountries(), childObjProcessor, traceId);
        childObjProcessor.prepareCitizenship(request, party.getCitizenship(), traceId);
        // This Below method has to stay at last to clear all unused validation
        // and
        // verification
        removeValidationAndVerification(request, traceId);
        return request;
    }

    private void populateTaxCountries(StringBuilder request, List<TaxCountry> taxCountries,
                                      PartyInternalObjectsProcessor childObjProcessor, String traceId) {

        LogUtil.debug(log, "populateTaxCountries", traceId,
                "Entering: populateTaxCountries method in MaintainPartyServiceProcessor");
        int taxCountryCount = 0;

        for (TaxCountry taxCountry : taxCountries) {
            String objectReferenceId = null;
            if (!taxCountry.getNoTaxReasons().isEmpty()) {
                objectReferenceId = generateObjectReferenceId();
            }
            if (taxCountryCount == 0) {
                modifyTemplateForTaxCountries(request, taxCountry, childObjProcessor, objectReferenceId, traceId);
                taxCountryCount++;
            } else {
                createAndModifyTemplateForTaxCountries(request, taxCountry, childObjProcessor, objectReferenceId,
                        traceId);
            }

        }
        RequestTransfomerUtil.removeObjectFromTemplate(request, "<XContTaxCountryBObj>", "</XContTaxCountryBObj>",
                taxCountryCount, traceId);
        LogUtil.debug(log, "populateTaxCountries", traceId,
                "Exit: populateTaxCountries method in MaintainPartyServiceProcessor");
    }

    private void createAndModifyTemplateForTaxCountries(StringBuilder request, TaxCountry taxCountry,
                                                        PartyInternalObjectsProcessor childObjProcessor,
                                                        String objectReferenceId, String traceId) {
        LogUtil.debug(log, "createAndModifytemplateForTaxCountries", traceId,
                "Entering: createAndModifytemplateForTaxCountries method in MaintainPartyServiceProcessor");
        String taxCountriesRequest = MDMRequestTemplates.MAINTAIN_PARTY_XCONT_TAX_COUNTRY_REQUEST;
        request.insert(request.indexOf("<XContTaxCountryBObj>"), taxCountriesRequest);
        modifyTemplateForTaxCountries(request, taxCountry, childObjProcessor, objectReferenceId, traceId);
        LogUtil.debug(log, "createAndModifyTemplateForNoTaxReasons", traceId,
                "Exit: createAndModifytemplateForTaxCountries method in MaintainPartyServiceProcessor");
    }

    private void modifyTemplateForTaxCountries(StringBuilder request, TaxCountry taxCountry,
                                               PartyInternalObjectsProcessor childObjProcessor,
                                               String objectReferenceId, String traceId) {

        LogUtil.debug(log, "modifytemplateForTaxCountries", traceId,
                "Entering: modifytemplateForTaxCountries method in MaintainPartyServiceProcessor");

        RequestTransfomerUtil.modifyTemplate(request, "@TaxCountryObjectReferenceId@", objectReferenceId, traceId);

        RequestTransfomerUtil.modifyTemplate(request, "@TaxCountryValue@", taxCountry.getCountryType(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@TaxCountryResidentFromDt@", taxCountry.getResidentFromDate(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@TaxCountryResidentToDt@", taxCountry.getResidentToDate(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@TaxCountryStartDate@", taxCountry.getStartDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@TaxCountryEndDate@", taxCountry.getEndDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@TaxCountrySourceIdentifierValue@", taxCountry.getSource(),
                traceId);
        List<NoTaxReason> taxReasons = CollectionUtils.isNotEmpty(taxCountry.getNoTaxReasons())
                ? taxCountry.getNoTaxReasons() : Collections.<NoTaxReason>emptyList();
        childObjProcessor.prepareNoTaxReasons(request, taxReasons, objectReferenceId, traceId);
        LogUtil.debug(log, "modifytemplateForPhones", traceId,
                "Exit: modifytemplateForPhones method in PartyInternalObjectsProcessor");
    }

    private void removeValidationAndVerification(StringBuilder request, String traceId) {
        if (-1 != request.indexOf("<ObjectReferenceId>@VerificationObjectReferenceId@</ObjectReferenceId>")) {
            RequestTransfomerUtil.removeObjectFromTemplate(request, "<XAttrVerificationBObj>",
                    "</XAttrVerificationBObj>", 0, traceId);
        }

        if (-1 != request.indexOf("<ObjectReferenceId>@ValidationObjectReferenceId@</ObjectReferenceId>")) {
            RequestTransfomerUtil.removeObjectFromTemplate(request, "<XAttrValidationBObj>", "</XAttrValidationBObj>",
                    0, traceId);
        }
    }

    private Map<String, String> populateIdentifiers(StringBuilder request, Party party, String traceId, String channel,
                                                    PartyInternalObjectsProcessor childObjProcessor,
                                                    List<Identifier> identifiers) {
        LogUtil.debug(log, "Enter populateIdentifiers method", traceId);
        if (ObjectUtils.isNotEmpty(party.getKycVerifications())
                && OCVConstants.FENERGOANZX_CHANNEL.equalsIgnoreCase(channel)) {
            List<KycVerificationMethods> kycMethods = getKYCMethods(party.getKycVerifications());
            List<String> kycDocs = getKYCDocList(kycMethods);
            LogUtil.debug(log, "kycMethods size in populateIdentifiers", traceId + " " + kycMethods.size(),
                    "kycMethods");
            LogUtil.debug(log, "kycDocs size in populateIdentifiers", traceId + " " + kycDocs.size());
            LogUtil.debug(log, "identifiers size in populateIdentifiers", traceId + " " + identifiers.size());
            return childObjProcessor.prepareIdentifiers(request, identifiers, traceId, kycDocs);
        } else {
            return childObjProcessor.prepareIdentifiers(request, identifiers, traceId, null);
        }
    }

    private List<KycVerificationMethods> getKYCMethods(List<KYCVerification> kycVerifications) {
        LogUtil.debug(log, "getKYCMethods", String.valueOf(kycVerifications.size()),
                "Entering: getKYCMethods method in MaintainPartyServiceProcessor");
        List<KycVerificationMethods> kycVerificationMethods = new ArrayList<>();
        for (KYCVerification kycVerification : kycVerifications) {
            for (KycVerificationMethods method : kycVerification.getKycVerificationMethods()) {
                kycVerificationMethods.add(method);
            }
        }
        return kycVerificationMethods;
    }

    private List<String> getKYCDocList(List<KycVerificationMethods> kycVerificationMethods) {
        LogUtil.debug(log, "getKYCDocList", String.valueOf(kycVerificationMethods.size()),
                "Entering: getKYCDocList method in MaintainPartyServiceProcessor");
        List<String> allKycDocsList = new ArrayList<>();
        for (KycVerificationMethods method : kycVerificationMethods) {
            List<KYCVerificationDocRef> kycVerificationDocRefs = method.getKycVerificationDocRef();
            List<String> kycDocs = kycVerificationDocRefs.stream().map(KYCVerificationDocRef::getIdentifierType)
                    .collect(Collectors.toCollection(ArrayList::new));
            allKycDocsList.addAll(kycDocs);
        }
        return allKycDocsList;
    }

    private void prepareKYCVerificationDetails(PartyInternalObjectsProcessor childObjProcessor,
                                               List<KYCVerification> kycVerifications, StringBuilder request,
                                               Map<String, String> objRefNumMap,
                                               String traceId) {
        LogUtil.debug(log, "prepareKYCVerificationDetails", traceId,
                "Entering: prepareKYCVerificationDetails method in MaintainPartyServiceProcessor");
        int kycVerCount = 0;
        for (KYCVerification kycVerification : kycVerifications) {
            if (kycVerCount == 0) {
                modifytemplateForKycVerification(request, kycVerification, traceId, childObjProcessor, objRefNumMap);
                kycVerCount++;
            } else {
                createAndModifyTemplateForKycVerification(request, kycVerification, traceId, childObjProcessor,
                        objRefNumMap);
            }
        }
        RequestTransfomerUtil.removeObjectFromTemplate(request, "<XKycVerificationBObj>", "</XKycVerificationBObj>",
                kycVerCount, traceId);
        LogUtil.debug(log, "preparePersonNames", traceId,
                "Exit: preparePersonNames method in MaintainPartyServiceProcessor");
    }

    private void prepareJurisdictionForCAPSource(StringBuilder request, List<JurisdictionDetail> jurisdictionDetails,
                                                 List<SourceSystem> sourceSystems, String traceId) {
        LogUtil.debug(log, "prepareJurisdictionForCAPSource", traceId,
                "Entering: prepareJurisdictionForCAPSource method in MaintainPartyServiceProcessor");
        for (SourceSystem sourceSystem : sourceSystems) {
            if (null != jurisdictionDetails && jurisdictionDetails.isEmpty()
                    && null != sourceSystem.getSourceSystemName()
                    && sourceSystem.getSourceSystemName().equalsIgnoreCase(OCVConstants.CAP_CIS_SOURCE)) {
                JurisdictionDetail jurisdictionDetail = new JurisdictionDetail();
                jurisdictionDetail.setKey(OCVConstants.AU_JURISDICTION);
                jurisdictionDetails.add(jurisdictionDetail);
            }
        }
        LogUtil.debug(log, "prepareJurisdictionForCAPSource", traceId,
                "Exit: prepareJurisdictionForCAPSource method in MaintainPartyServiceProcessor");
    }

    private void prepareConsentDetails(PartyInternalObjectsProcessor childObjProcessor, List<Consent> consents,
                                       StringBuilder request, String traceId) {
        LogUtil.debug(log, "prepareConsentDetails", traceId,
                "Entering: prepareConsentDetails method in MaintainPartyServiceProcessor");
        int consentCount = 0;
        for (Consent consent : consents) {
            String objectReferenceId = generateObjectReferenceId();
            if (consentCount == 0) {
                modifytemplateForConsent(request, consent, traceId, childObjProcessor, objectReferenceId);
                consentCount++;
            } else {
                createAndModifyTemplateForConsent(request, consent, traceId, childObjProcessor, objectReferenceId);
            }
        }
        RequestTransfomerUtil.removeObjectFromTemplate(request, "<ConsentBObj>", "</ConsentBObj>", consentCount,
                traceId);
        LogUtil.debug(log, "prepareConsentDetails", traceId,
                "Exit: prepareConsentDetails method in MaintainPartyServiceProcessor");
    }

    private void modifytemplateForConsent(StringBuilder request, Consent consent, String traceId,
                                          PartyInternalObjectsProcessor childObjProcessor, String objectReferenceId) {
        LogUtil.debug(log, "modifytemplateForConsent", traceId,
                "Entering: modifytemplateForConsent method in MaintainPartyServiceProcessor");
        RequestTransfomerUtil.modifyTemplate(request, "@ConsentObjectReferenceId@", objectReferenceId, traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@AgreeInd@", consent.getAgreeIndicator(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@LanguageAgreedInValue@",
                StringUtils.isNotEmpty(consent.getLanguageAgreedInValue()) ? consent.getLanguageAgreedInValue()
                        : OCVConstants.ENGLISH,
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@EnforcementType@", "0", traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ConsentCreateDate@", consent.getConsentDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ConsentStartDate@", consent.getStartDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ConsentEndDate@", consent.getEndDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ConsentSourceIdentValue@", consent.getSource(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@EndReasonValue@",
                StringUtils.isNotEmpty(consent.getEndReasonType()) ? consent.getEndReasonType().trim() : null, traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ProcPurpValue@",
                StringUtils.isNotEmpty(consent.getProcessingPurposeType()) ? consent.getProcessingPurposeType().trim()
                        : null,
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ProcPurpVersion@", consent.getVersion(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ProfileSystemValue@", consent.getSource(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ProcessingPurposeObjectReferenceId@", objectReferenceId,
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ProcessingPurposeStartDate@", consent.getStartDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ProcessingPurposeEndDate@", consent.getEndDate(), traceId);
    }

    private void createAndModifyTemplateForConsent(StringBuilder request, Consent consent, String traceId,
                                                   PartyInternalObjectsProcessor childObjProcessor,
                                                   String objectReferenceId) {
        LogUtil.debug(log, "createAndModifyTemplateForConsent", traceId,
                "Entering: createAndModifyTemplateForConsent method in MaintainPartyServiceProcessor");
        String consentRequest = MDMRequestTemplates.MAINTAIN_PARTY_CONSENT_REQUEST;
        request.insert(request.indexOf("</PartyWrapperBObj>"), consentRequest);
        modifytemplateForConsent(request, consent, traceId, childObjProcessor, objectReferenceId);
        LogUtil.debug(log, "createAndModifyTemplateForConsent", traceId,
                "Exit: createAndModifyTemplateForConsent method in MaintainPartyServiceProcessor");
    }

    private void createAndModifyTemplateForKycVerification(StringBuilder request, KYCVerification kycVerification,
                                                           String traceId,
                                                           PartyInternalObjectsProcessor childObjProcessor,
                                                           Map<String, String> objRefNumMap) {
        LogUtil.debug(log, "createAndModifyTemplateForKycVerification", traceId,
                "Entering: createAndModifyTemplateForKycVerification method in MaintainPartyServiceProcessor");
        String kycVerificationRequest = MDMRequestTemplates.MAINTAIN_PARTY_KYC_VERIFICATION_REQUEST;
        request.insert(request.indexOf("<ContentReferenceBObj>"), kycVerificationRequest);
        modifytemplateForKycVerification(request, kycVerification, traceId, childObjProcessor, objRefNumMap);
        LogUtil.debug(log, "createAndModifyTemplateForKycVerification", traceId,
                "Exit: createAndModifyTemplateForKycVerification method in MaintainPartyServiceProcessor");
    }

    private void modifytemplateForKycVerification(StringBuilder request, KYCVerification kycVerification,
                                                  String traceId, PartyInternalObjectsProcessor childObjProcessor,
                                                  Map<String, String> objRefNumMap) {
        LogUtil.debug(log, "modifytemplateForKycVerifications", traceId,
                "Entering: modifytemplateForKycVerification method in MaintainPartyServiceProcessor");
        // Initialising Object
        String objRefId = "dummy";
        if (ObjectUtils.isNotEmpty(objRefNumMap)) {
            objRefId = objRefNumMap.values().stream().findFirst().get();
        }
        RequestTransfomerUtil.modifyTemplate(request, "@KycIdentifierObjectReferenceId@", objRefId, traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@VerificationDt@", kycVerification.getVerificationDate(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@VerificationStValue@",
                kycVerification.getVerificationStatusType(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@KycVerLvlValue@", kycVerification.getKycVerificationLevelType(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@KycStatusValue@", kycVerification.getKycStatusType(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ConsentProvided@", kycVerification.getConsentProvided(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ConsentDt@", kycVerification.getConsentDate(), traceId);
        // RequestTransfomerUtil.modifyTemplate(request, "@CaseID@",
        // kycVerification.getCaseID(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@KycSourceIdentifierValue@", kycVerification.getSource(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ExpiryDt@", kycVerification.getExpiryDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@Comments@", kycVerification.getComments(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@KycStartDate@", kycVerification.getStartDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@KycEndDate@", kycVerification.getEndDate(), traceId);

        List<KycVerificationMethods> kycVerificationMethodsList = populateKYCMethods(kycVerification, traceId);

        prepareEVRequest(request, kycVerificationMethodsList, objRefId, childObjProcessor, traceId);
        prepareSelfiRequest(kycVerificationMethodsList, request, objRefId, traceId);
        prepareMVRequest(kycVerificationMethodsList, request, objRefId, traceId);

        LogUtil.debug(log, "modifytemplateForKycVerifications", traceId,
                "Exit: modifytemplateForKycVerifications method in MaintainPartyServiceProcessor");

    }

    private void prepareMVRequest(List<KycVerificationMethods> kycVerificationMethodsList, StringBuilder request,
                                  String objRefId, String traceId) {
        LogUtil.debug(log, "prepareMVRequest", traceId,
                "Entering: prepareMVRequest method in MaintainPartyServiceProcessor");

        for (KycVerificationMethods method : kycVerificationMethodsList) {
            if (method.getVerificationMethodType().equalsIgnoreCase(OCVConstants.KYC_METHOD_IDMV)) {
                String kycRequest = MDMRequestTemplates.MAINTAIN_PARTY_MV_REQUEST;
                request.insert(request.indexOf("</XKycVerificationBObj>"), kycRequest);
                modifytemplateForKycMethods(request, method, objRefId, traceId);
                modifytemplateForAdditionalMVParams(request, method, traceId);
            }
        }
        LogUtil.debug(log, "prepareMVRequest", traceId,
                "Exit: prepareMVRequest method in MaintainPartyServiceProcessor");

    }

    private void prepareSelfiRequest(List<KycVerificationMethods> kycVerificationMethodsList, StringBuilder request,
                                     String objRefId, String traceId) {
        LogUtil.debug(log, "prepareSelfiRequest", traceId,
                "Entering: prepareSelfiRequest method in MaintainPartyServiceProcessor");

        for (KycVerificationMethods method : kycVerificationMethodsList) {
            if (method.getVerificationMethodType().equalsIgnoreCase(OCVConstants.KYC_METHOD_SELFIEEV)
                    || method.getVerificationMethodType().equalsIgnoreCase(OCVConstants.KYC_METHOD_SELFIEMV)) {
                String kycRequest = MDMRequestTemplates.MAINTAIN_PARTY_SELFI_REQUEST;
                request.insert(request.indexOf("</XKycVerificationBObj>"), kycRequest);
                modifytemplateForKycMethods(request, method, objRefId, traceId);
                modifytemplateForAdditionalSelfiParams(request, method, traceId);
            }
        }
        LogUtil.debug(log, "prepareSelfiRequest", traceId,
                "Exit: prepareSelfiRequest method in MaintainPartyServiceProcessor");

    }

    private void prepareEVRequest(StringBuilder request, List<KycVerificationMethods> kycVerificationMethodsList,
                                  String objRefId, PartyInternalObjectsProcessor childObjProcessor, String traceId) {
        LogUtil.debug(log, "prepareEVRequest", traceId,
                "Entering: prepareEVRequest method in MaintainPartyServiceProcessor");
        for (KycVerificationMethods method : kycVerificationMethodsList) {
            if (method.getVerificationMethodType().equalsIgnoreCase(OCVConstants.KYC_METHOD_IDEV)
                    || method.getVerificationMethodType().equalsIgnoreCase(OCVConstants.KYC_METHOD_IDAEV)) {
                String kycRequest = MDMRequestTemplates.MAINTAIN_PARTY_IDEV_REQUEST;
                request.insert(request.indexOf("</XKycVerificationBObj>"), kycRequest);
                modifytemplateForKycMethods(request, method, objRefId, traceId);
                modifytemplateForAdditionalEVParams(request, method, traceId);
                populateEvMatchStatus(request, method, traceId, childObjProcessor);
            }
        }

        LogUtil.debug(log, "prepareEVRequest", traceId,
                "Exit: prepareEVRequest method in MaintainPartyServiceProcessor");

    }

    private void modifytemplateForKycMethods(StringBuilder request, KycVerificationMethods method, String objRefId,
                                             String traceId) {
        LogUtil.debug(log, "modifytemplateForKycMethods", traceId,
                "Entering: modifytemplateForKycMethods method in MaintainPartyServiceProcessor");

        RequestTransfomerUtil.modifyTemplate(request, "@KycIdentifierObjectReferenceId@", objRefId, traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@VerificationDt@", method.getVerificationDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@VerificationMethodValue@", method.getVerificationMethodType(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@VerificationStatusValue@", method.getVerificationStatusType(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ServiceProvider@", method.getServiceProvider(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@SubmittedDt@", method.getSubmittedDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@SubmittedBy@", method.getSubmittedBy(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@SourceIdentifierValue@", method.getSource(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@StartDate@", method.getStartDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@EndDate@", method.getEndDate(), traceId);

        LogUtil.debug(log, "modifytemplateForKycMethods", traceId,
                "Exit: modifytemplateForKycMethods method in MaintainPartyServiceProcessor");

    }

    private void modifytemplateForAdditionalEVParams(StringBuilder request, KycVerificationMethods method,
                                                     String traceId) {
        RequestTransfomerUtil.modifyTemplate(request, "@ServiceRequestStatus@", method.getServiceRequestStatus(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ResponseId@", method.getResponseId(), traceId);

    }

    private void modifytemplateForAdditionalSelfiParams(StringBuilder request, KycVerificationMethods method,
                                                        String traceId) {

        RequestTransfomerUtil.modifyTemplate(request, "@ResponseId@", method.getResponseId(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PdfFileName@", method.getPdfFileName(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ImageFileName@", method.getImageFileName(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ExpiryDt@", method.getExpiryDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@Comments@", method.getComments(), traceId);

    }

    private void modifytemplateForAdditionalMVParams(StringBuilder request, KycVerificationMethods method,
                                                     String traceId) {
        RequestTransfomerUtil.modifyTemplate(request, "@Comments@", method.getComments(), traceId);
    }

    private List<KycVerificationMethods> populateKYCMethods(KYCVerification kycVerification, String traceId) {
        LogUtil.debug(log, "populateKYCMethods", traceId,
                "Entering: populateKYCMethods method in MaintainPartyServiceProcessor");
        List<KycVerificationMethods> kycVerificationMethodsList = CollectionUtils
                .isNotEmpty(kycVerification.getKycVerificationMethods()) ? kycVerification.getKycVerificationMethods()
                : Collections.emptyList();

        return kycVerificationMethodsList;

    }

    private void populateEvMatchStatus(StringBuilder request, KycVerificationMethods method, String traceId,
                                       PartyInternalObjectsProcessor childObjProcessor) {

        List<EVMatchStatus> evMatchStatusList = CollectionUtils.isNotEmpty(method.getEvMatchStatus())
                ? method.getEvMatchStatus() : Collections.emptyList();
        childObjProcessor.prepareEvMatchStatus(request, method, evMatchStatusList, traceId);
    }

    private void preparePersonDetails(Party party, StringBuilder request, String traceId) {
        RequestTransfomerUtil.modifyTemplate(request, "@ClientStatusValue@", party.getStatus(), traceId);
        // OCT-10973 Entity change for BVD
        RequestTransfomerUtil.modifyTemplate(request, "@EntityStatusValue@", party.getEntityStatus(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PersonSourceIdentifierValue@", party.getSource(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@BirthDate@", party.getDateOfBirth(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@GenderType@", party.getGender(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@MaritalStatusValue@", party.getMaritalStatus(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@DeceasedDate@", party.getDeceasedDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XEmployeeIndicator@", party.getEmployeeIndicator(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XBankruptDate@", party.getBankruptDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XEmployerName@", party.getEmployerName(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@SinceDate@", party.getSourceEstablishedDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@LeftDate@", party.getSourceClosedDate(), traceId);
    }

    private void preparePersonNames(StringBuilder request, List<Name> personNameList, String traceId) {
        LogUtil.debug(log, "preparePersonNames", traceId,
                "Entering: preparePersonNames method in MaintainPartyServiceProcessor");
        int namesCount = 0;
        for (Name personName : personNameList) {
            if (namesCount == 0) {
                modifytemplateForPersonNames(request, personName, traceId);
                namesCount++;
            } else {
                createAndModifyTemplateForPersonNames(request, personName, traceId);
            }
        }
        RequestTransfomerUtil.removeObjectFromTemplate(request, "<TCRMPersonNameBObj>", "</TCRMPersonNameBObj>",
                namesCount, traceId);
        LogUtil.debug(log, "preparePersonNames", traceId,
                "Exit: preparePersonNames method in MaintainPartyServiceProcessor");
    }

    private void createAndModifyTemplateForPersonNames(StringBuilder request, Name personName, String traceId) {
        LogUtil.debug(log, "createAndModifyTemplateForPersonNames", traceId,
                "Entering: createAndModifyTemplateForPersonNames method in MaintainPartyServiceProcessor");
        String personNameRequest = MDMRequestTemplates.MAINTAIN_PARTY_PERSONNAME_REQUEST;
        request.insert(request.indexOf("<TCRMPartyPrivPrefBObj>"), personNameRequest);
        modifytemplateForPersonNames(request, personName, traceId);
        LogUtil.debug(log, "createAndModifyTemplateForPersonNames", traceId,
                "Exit: createAndModifyTemplateForPersonNames method in MaintainPartyServiceProcessor");
    }

    private void modifytemplateForPersonNames(StringBuilder request, Name personName, String traceId) {
        LogUtil.debug(log, "modifytemplateForPersonNames", traceId,
                "Entering: modifytemplateForPersonNames method in MaintainPartyServiceProcessor");
        RequestTransfomerUtil.modifyTemplate(request, "@LastName@", personName.getLastName(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@GivenNameOne@", personName.getFirstName(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@GivenNameTwo@", personName.getMiddleName(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@NameUsageValue@", personName.getNameUsageType(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PrefixDescription@", personName.getPrefix(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@Suffix@", personName.getSuffix(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PersonNameStartDate@", personName.getStartDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PersonNameEndDate@", personName.getEndDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PersonNameSourceIdentifierValue@", personName.getSource(),
                traceId);
        LogUtil.debug(log, "modifytemplateForPersonNames", traceId,
                "Exit: modifytemplateForPersonNames method in MaintainPartyServiceProcessor");
    }

    private void prepareOccupationDetails(Party party, StringBuilder request, String traceId) {
        LogUtil.debug(log, "prepareOccupationDetails", traceId,
                "Entering: prepareOccupationDetails method in MaintainPartyServiceProcessor");
        if (null != party.getOccupation()) {
            RequestTransfomerUtil.modifyTemplate(request, "@XOccupationValue@", party.getOccupation().getCode(),
                    traceId);
            RequestTransfomerUtil.modifyTemplate(request, "@XSourceOccupation@",
                    party.getOccupation().getSourceOccupationCode(), traceId);
        } else {
            RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@XOccupationValue@", traceId);
            RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@XSourceOccupation@", traceId);
        }
        LogUtil.debug(log, "prepareOccupationDetails", traceId,
                "Exit: prepareOccupationDetails method in MaintainPartyServiceProcessor");
    }

    private void prepareTaxDetails(Party party, StringBuilder request, String traceId) {
        LogUtil.debug(log, "prepareTaxDetails", traceId,
                "Entering: prepareTaxDetails method in MaintainPartyServiceProcessor");
        if (StringUtils.isNotEmpty(party.getSelfCertTaxFlag())) {
            RequestTransfomerUtil.modifyTemplate(request, "@XTaxSelfCertFlag@", party.getSelfCertTaxFlag(), traceId);
        } else {
            RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@XTaxSelfCertFlag@", traceId);
        }
        if (StringUtils.isNotEmpty(party.getSelfCertTaxDate())) {
            RequestTransfomerUtil.modifyTemplate(request, "@XTaxSelfCertDt@", party.getSelfCertTaxDate(), traceId);
        } else {
            RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@XTaxSelfCertDt@", traceId);
        }
        LogUtil.debug(log, "prepareTaxDetails", traceId,
                "Exit: prepareTaxDetails method in MaintainPartyServiceProcessor");
    }

    private void prepareKycDetails(Party party, StringBuilder request, String traceId) {
        LogUtil.debug(log, "prepareKycDetails", traceId,
                "Entering: prepareKycDetails method in MaintainPartyServiceProcessor");
        if (null != party.getKycDetails()) {
            LogUtil.debug(log, "kyc status", party.getKycDetails().getStatus(),
                    "Entering: prepareKycDetails method in MaintainPartyServiceProcessor");
            RequestTransfomerUtil.modifyTemplate(request, "@XKycVerificationLevelValue@",
                    party.getKycDetails().getVerificationLevel(), traceId);
            RequestTransfomerUtil.modifyTemplate(request, "@XKycStatusValue@", party.getKycDetails().getStatus(),
                    traceId);
        } else {
            RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@XKycVerificationLevelValue@", traceId);
            RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@XKycStatusValue@", traceId);
        }
        LogUtil.debug(log, "prepareKycDetails", traceId,
                "Exit: prepareKycDetails method in MaintainPartyServiceProcessor");
    }

    public StringBuilder prepareOrgMDMRequest(StringBuilder request, APIRequest<Party> apiRequest,
                                              String anzxAddressChannel, StreetSuffixConfig streetSuffixCfg) {
        LogUtil.debug(log, "prepareOrgMDMRequest", apiRequest.getTraceId(),
                "Entering: prepareOrgMDMRequest method in MaintainPartyServiceProcessor");

        prepareControlObject(request, apiRequest.getRequestBody(), apiRequest.getRequestTimestamp(),
                apiRequest.getTraceId(), apiRequest.getChannel(), apiRequest.getUserId(), apiRequest.getRequestMode());

        StringBuilder mdmRequest = prepareOrgReq(request, apiRequest.getRequestBody(), apiRequest.getTraceId(),
                apiRequest.getHeaders(), anzxAddressChannel, streetSuffixCfg);
        LogUtil.debug(log, "prepareOrgMDMRequest", apiRequest.getTraceId(),
                "Exit: prepareOrgMDMRequest method in MaintainPartyServiceProcessor");
        return mdmRequest;
    }

    public StringBuilder preparePersonMDMRequest(StringBuilder request, APIRequest<Party> apiRequest,
                                                 String anzxAddressChannel, StreetSuffixConfig stSuffixCfg,
                                                 String fenergoSourceId,
                                                 IdempotencyConfigUtil idempotencyUtil, boolean isGoldenProfile) {
        LogUtil.debug(log, "preparePersonMDMRequest", apiRequest.getTraceId(),
                "Entering: preparePersonMDMRequest method in MaintainPartyServiceProcessor");

        prepareControlObject(request, apiRequest.getRequestBody(), apiRequest.getRequestTimestamp(),
                apiRequest.getTraceId(), apiRequest.getChannel(), apiRequest.getUserId(), apiRequest.getRequestMode());

        if (idempotencyUtil.isChannelIncluded(apiRequest.getChannel(), apiRequest.getTraceId())
                && null != apiRequest.getRequestMode() && idempotencyUtil.isRequestModeIncluded(true,
                apiRequest.getChannel(), apiRequest.getRequestMode(), apiRequest.getTraceId())) {
            String persistsResponse = OCVConstants.FALSE;

            if (OCVConstants.REQUEST_MODE_CREATE_CUSTOMER.equalsIgnoreCase(apiRequest.getRequestMode())
                    && !isGoldenProfile && OCVConstants.CRM.equalsIgnoreCase(apiRequest.getChannel())) {
                persistsResponse = OCVConstants.FALSE;
            } else if (OCVConstants.REQUEST_MODE_CREATE_CUSTOMER.equalsIgnoreCase(apiRequest.getRequestMode())
                    || (OCVConstants.REQUEST_MODE_UPDATEKYC.equalsIgnoreCase(apiRequest.getRequestMode())
                    && isGoldenProfile)) {
                persistsResponse = OCVConstants.TRUE;
            }
            prepareIdemptotencyControlObj(request, apiRequest.getHeaders().get(OCVConstants.IDEMPOTENCY_KEY),
                    apiRequest.getHeaders().get(OCVConstants.IDEMPOTENCY_FIRST_SENT), persistsResponse,
                    apiRequest.getTraceId());

        } else {
            prepareIdemptotencyControlObj(request, null, null, null, apiRequest.getTraceId());
        }
        prepareControlObjectExt(request, apiRequest.getTraceId(), fenergoSourceId);

        StringBuilder mdmRequest = preparePersonRequest(request, apiRequest.getRequestBody(), apiRequest.getHeaders(),
                apiRequest.getTraceId(), anzxAddressChannel, stSuffixCfg);
        LogUtil.debug(log, "preparePersonMDMRequest", apiRequest.getTraceId(),
                "Exit: preparePersonMDMRequest method in MaintainPartyServiceProcessor");
        return mdmRequest;
    }

    private String generateObjectReferenceId() {
        return System.currentTimeMillis() + String.valueOf(random.nextInt(9000) + 1000);
    }
}
