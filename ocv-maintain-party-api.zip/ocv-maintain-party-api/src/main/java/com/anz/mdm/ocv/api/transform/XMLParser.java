package com.anz.mdm.ocv.api.transform;

import java.io.IOException;
import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.anz.mdm.ocv.api.util.LogUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * Parse xml and get the value from xpath expression
 *
 */

@Slf4j
public class XMLParser {

    private static DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
    private static XPath xPath = XPathFactory.newInstance().newXPath();

    private Document document = null;

    public XMLParser(String file, String traceId) {
        Long startTime = System.currentTimeMillis();
        LogUtil.debug(log, "XMLParser", traceId, "Entering: XMLParser method in XMLParser",
                System.currentTimeMillis() - startTime);
        DocumentBuilder documentBuilder = null;

        InputSource inputStore = new InputSource(new StringReader(file));
        try {
            documentBuilder = documentFactory.newDocumentBuilder();
            this.document = documentBuilder.parse(inputStore);
        } catch (ParserConfigurationException e) {
            log.error("Exception building documentBuilder :::  " + e);
        } catch (SAXException | IOException e) {
            log.error("Exception parsing document :::  " + e);
        }
        LogUtil.debug(log, "XMLParser", traceId, "Exiting: XMLParser method in XMLParser",
                System.currentTimeMillis() - startTime);
    }

    public String evaluate(String xPathExpression, String traceId) {
        Long startTime = System.currentTimeMillis();
        LogUtil.debug(log, "evaluate", traceId, "Entering: evaluate method in XMLParser");
        String value = "";
        try {
            if (document != null) {
                value = xPath.evaluate(xPathExpression, document);
            }
        } catch (XPathExpressionException e) {
            log.error("Exception evaluating xpath :::  " + e);
        }
        LogUtil.debug(log, "evaluate", traceId, "Exiting: evaluate method in XMLParser",
                System.currentTimeMillis() - startTime);
        return value;
    }

}