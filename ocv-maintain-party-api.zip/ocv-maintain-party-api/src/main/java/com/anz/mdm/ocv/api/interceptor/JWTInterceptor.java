/* Change as part of JWT 17031 feature */

package com.anz.mdm.ocv.api.interceptor;

import java.io.IOException;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import com.anz.mdm.ocv.api.UAMAccessConfiguration;
import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.downsteamservices.JWTService;
import com.anz.mdm.ocv.api.exception.UnauthorizedException;
import com.anz.mdm.ocv.api.util.LogUtil;
import com.anz.mdm.ocv.api.validator.APIRequest;

import com.anz.mdm.ocv.party.v1.Party;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Setter
@Slf4j
@Component
@Configuration
@ConfigurationProperties(prefix = "")
public class JWTInterceptor {

    @Autowired
    private JWTService theJWTService;

    @Autowired
    private UAMAccessConfiguration uamAccessConfiguration;

    private String base64EncodedBody = null;

    public JWTInterceptor(JWTService theJWTService, UAMAccessConfiguration uamAccessConfiguration) {
        this.theJWTService = theJWTService;
        this.uamAccessConfiguration = uamAccessConfiguration;
    }

    /**
     * JWT intercepter retrieve the incoming JWT Token, channel name to identify the
     * target Issuer end point. Incoming channel is invalid the signature validation
     * is skip and unauthorized exception is thrown. Application = OCV will skip the
     * validation process.
     * 
     */

    public boolean validateJWT(APIRequest<Party> apiRequest) throws Exception {
        boolean jwtValidationStatus;
        String channelName = apiRequest.getChannel();
        Long startTime = System.currentTimeMillis();
        LogUtil.debug(log, "validateJWT", apiRequest.getTraceId(), "Entering validate Process in JWTInterceptor");
        String applicationName = apiRequest.getApplication();
        String excludeChannelFound = isChannelInExcludeList(channelName, apiRequest.getTraceId());
        if (("OCV".equalsIgnoreCase(applicationName)) || !("".equalsIgnoreCase(excludeChannelFound))) {
            LogUtil.debug(log, "validateJWT", apiRequest.getTraceId(), "Skip the validateJWT process in JWTInterceptor",
                    System.currentTimeMillis() - startTime);
            return true;
        }
        String jwtToken = apiRequest.getJwtToken();
        String jwtParsedToken = getJWTExtractToken(jwtToken, apiRequest.getTraceId());
        String requestIssuer = extractIssuer(jwtToken, apiRequest.getTraceId());
        String jwtEndpoint = prepareDynamicIssEndpoint(requestIssuer, apiRequest.getTraceId());
        String keysFromConfigMap = lookUpIssuerKeys(apiRequest.getTraceId());
        jwtValidationStatus = theJWTService.getSignatureStatus(jwtParsedToken, jwtEndpoint, apiRequest,
                keysFromConfigMap);
        LogUtil.debug(log, "validateJWT", apiRequest.getTraceId(), "Exiting validate Process in JWTInterceptor",
                System.currentTimeMillis() - startTime);

        return jwtValidationStatus;
    }

    @SuppressWarnings("unchecked")
    private String lookUpIssuerKeys(String requestTraceId) {
        LogUtil.debug(log, "lookUpIssuerKeys", requestTraceId, "Executing lookUpIssuerKeys");
        Map<String, String> keysList = uamAccessConfiguration.getIssuer("UAM", OCVConstants.UAM_ISSUER_LIST_NAME);
        LogUtil.debug(log, "lookUpIssuerKeys", requestTraceId, "Exit lookUpIssuerKeys");
        return (String) keysList.get("KEYS");
    }

    @SuppressWarnings("unchecked")
    private String isChannelInExcludeList(String channelName, String requestTraceId) {
        LogUtil.debug(log, "isChannelInExcludeList", requestTraceId, "Executing isChannelInExcludeList");
        String channelFound = "";
        Map<String, String> channels = uamAccessConfiguration.getIssuer("JWT", OCVConstants.UAM_CHANNEL_LIST_NAME);
        String list = (String) channels.get("EXCLUDECHANNELSLIST");
        List<String> channelList = Arrays.asList(list.split("\\|"));
        for (String value : channelList) {
            if (channelName.equalsIgnoreCase(value)) {
                channelFound = "true";
                break;
            }
        }
        LogUtil.debug(log, "isChannelInExcludeList", requestTraceId, "Exit isChannelInExcludeList");
        return channelFound;
    }

    @SuppressWarnings("unchecked")
    private String prepareDynamicIssEndpoint(String requestIssuerName, String requestTraceId) {
        LogUtil.debug(log, "prepareDynamicIssEndpoint", requestTraceId, "Executing prepareDynamicIssEndpoint");
        Map<String, String> issuerList = uamAccessConfiguration.getIssuer("UAM", OCVConstants.UAM_ISSUER_LIST_NAME);
        String endPointUrl = getTargetJwksendpoint(issuerList, requestIssuerName, requestTraceId);

        if ("".equalsIgnoreCase(endPointUrl)) {
            LogUtil.error(log, "prepareDynamicIssEndpoint", requestTraceId, "", OCVConstants.INVALID_JWT_ISSUER,
                    OCVConstants.INVALID_JWT_ISSUER_ERROR_CODE);
            throw new UnauthorizedException(OCVConstants.INVALID_JWT_ISSUER_ERROR_CODE,
                    OCVConstants.INVALID_JWT_ISSUER);
        }
        LogUtil.debug(log, "prepareDynamicIssEndpoint", requestTraceId, "Exit prepareDynamicIssEndpoint");
        return endPointUrl;
    }

    /*
     * Issuer endpoint is retrieved from the APIRequest and retrieve the
     * corresponding issuer Name mapped in the configuration map
     */

    private String getTargetJwksendpoint(Map<String, String> issuers, String reqIssuer, String requestTraceId) {
        LogUtil.debug(log, "getTargetJwksendpoint", requestTraceId, "Executing TargetJwksendpoint");
        String list = (String) issuers.get("ISSUERLIST");
        String issuerFound = "";
        List<String> issuerList = Arrays.asList(list.split("\\|"));
        for (String value : issuerList) {
            String[] splitIssuerString = value.split("=");
            if (splitIssuerString[0].equalsIgnoreCase(reqIssuer)) {
                issuerFound = splitIssuerString[1];
                break;
            }
        }
        LogUtil.debug(log, "getTargetJwksendpoint", requestTraceId, "Exit TargetJwksendpoint");
        return issuerFound;
    }

    /*
     * Retrieve the jwtToken received in the incoming API request Authorization HTTP
     * Header as Bearer + jwtToken
     */

    private static String getJWTExtractToken(String jwtToken, String requestTraceId) {
        LogUtil.debug(log, "getJWTExtractToken", requestTraceId, "Executing JWTExtractToken");
        String[] splitJwtString = jwtToken.split("\\ ");
        String token;
        try {
            token = splitJwtString[1];
        } catch (ArrayIndexOutOfBoundsException e) {
            throw new UnauthorizedException(OCVConstants.INVALID_JWT_TOKEN_ERROR_CODE, OCVConstants.INVALID_JWT_TOKEN);
        }
        LogUtil.debug(log, "getJWTExtractToken", requestTraceId, "Exit JWTExtractToken");
        return token;
    }

    private String extractIssuer(String jwtToken, String requestTraceId)
            throws JsonParseException, JsonMappingException, IOException, JSONException {
        LogUtil.debug(log, "extractIssuer", requestTraceId, "Executing extractIssuer");
        String[] splitJwtString = jwtToken.split("\\.");
        try {
            base64EncodedBody = splitJwtString[1];
        } catch (ArrayIndexOutOfBoundsException e) {
            throw new UnauthorizedException(OCVConstants.INVALID_JWT_TOKEN_ERROR_CODE, OCVConstants.INVALID_JWT_TOKEN);
        }

        byte[] decodedBytes = Base64.getUrlDecoder().decode(base64EncodedBody);
        String decodedUrl = new String(decodedBytes, "UTF-8");
        JSONObject jObj = new JSONObject(decodedUrl);

        // issuer detail from JWT is empty
        String issuerName = null;
        if (jObj.get("iss") != null) {
            issuerName = (String) jObj.get("iss");
        } else {
            issuerName = " ";
        }
        LogUtil.debug(log, "extractIssuer", requestTraceId, "Exit extractIssuer");
        return issuerName;
    }
}