package com.anz.mdm.ocv.api.exception;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ElasticSearchUnavailableException extends APIException {

    private static final long serialVersionUID = 1L;
    private String message;
    private String moreInfo;


    public ElasticSearchUnavailableException(String statusCode, String message, String moreInfo) {
        super(statusCode);
        this.message = message;
        this.moreInfo = moreInfo;
    }

}
