package com.anz.mdm.ocv.api.exception;

import lombok.Getter;
import lombok.Setter;

/**
 * APIException prepares error message with statusCode.
 *
 * Could be used to handle generic functionality here
 * 
 * @author Amit Gera
 *
 */
@Getter
@Setter
public class APIException extends RuntimeException {

    private String statusCode;

    private static final long serialVersionUID = 1L;

    public APIException(String statusCode) {
        super(statusCode);
        this.statusCode = statusCode;
    }
}
