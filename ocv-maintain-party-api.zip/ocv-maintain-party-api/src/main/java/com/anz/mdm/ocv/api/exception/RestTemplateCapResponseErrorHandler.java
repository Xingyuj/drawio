package com.anz.mdm.ocv.api.exception;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.ResponseErrorHandler;

import com.anz.mdm.ocv.api.util.LogUtil;

import lombok.extern.slf4j.Slf4j;

/*
 * This class will override default springboot ResponseErrorHandler 
 * and gives us flexibility to cascade error response from downstream api to user.
 * Also treat 404 not as error but an accepted HHTp status to provide blank array as response.
 * @author Deepika Handa
 */
@Slf4j
public class RestTemplateCapResponseErrorHandler implements ResponseErrorHandler {

    private List acceptableStatus;

    public RestTemplateCapResponseErrorHandler(String goodStatus) {

        acceptableStatus = Arrays.stream(goodStatus.split(",")).map(HttpStatus::valueOf).collect(Collectors.toList());

    }

    @Override
    public boolean hasError(ClientHttpResponse response) throws IOException {
        return acceptableStatus.contains(response.getStatusCode());
    }

    @Override
    public void handleError(ClientHttpResponse response) throws IOException {
        response.getStatusText();
        if (response.getStatusCode().equals(HttpStatus.BAD_REQUEST)) {
            LogUtil.debug(log, "handleError", response.getStatusCode().toString());
        }

    }
}
