package com.anz.mdm.ocv.api.exception;

/**
 * Exception to handle backend service exceptions
 * 
 * @author handad
 *
 */

public class BackendServiceException extends APIException {
    private static final long serialVersionUID = 1L;


    public BackendServiceException(String statusCode) {
        super(statusCode);

    }

}
