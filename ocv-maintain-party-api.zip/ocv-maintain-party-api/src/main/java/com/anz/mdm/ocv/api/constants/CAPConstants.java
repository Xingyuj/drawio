package com.anz.mdm.ocv.api.constants;

public enum CAPConstants {

    F("Female"), M("Male"), N("Non Binary"), ;
    public static final String SLASH = "/";
    public static final String CAP_ORG_IND = "*";
    public static final String UNKNOWN = "Unknown";
    public static final String LEGAL_PREFIX = "Legal";
    public static final String STRING_Y = "Y";
    public static final String STRING_MAILING_LOWERCASE = "mailing";
    public static final String STRING_MAILING = "Mailing";
    public static final String STRING_RESIDENTIAL = "Residential";
    public static final String STRING_MARRIED = "Married";
    public static final String CAP_MARRIED_DEFACTO = "Married/Defacto";
    public static final Integer MAX_ADDRESS_LENGTH = 40;
    
    // Create Cap Customer 2.0.0 Mandatory Headers
    public static final String CAP_X_OPERATOR_ID = "X-Operator-Id";
    public static final String CAP_X_OPERATOR_BRANCH = "X-Operator-Branch";
    public static final String CAP_X_WORKSTATION = "X-Workstation";
    public static final String CAP_X_IDEMPOTENCY_KEY = "X-idempotency-key";
    public static final String CAP_X_IDEMPOTENCY_FIRST_SENT = "X-idempotency-first-sent";

    private String field;

    CAPConstants(String field) {
        this.field = field;
    }

    public String getValue() {
        return field;
    }
}
