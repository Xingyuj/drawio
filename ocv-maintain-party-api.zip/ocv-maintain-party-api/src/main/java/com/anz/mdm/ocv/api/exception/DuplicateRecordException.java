package com.anz.mdm.ocv.api.exception;

/**
 * Handles record not found exceptions
 *
 * @author Ramesh Kanuganti
 */
public class DuplicateRecordException extends APIException {

    private static final long serialVersionUID = -8484627633200126920L;

    private String statusMessage;

    public DuplicateRecordException(String statusCode, String statusMessage) {
        super(statusCode);
        this.statusMessage = statusMessage;
    }

    public String getStatusMessage() {
        return statusMessage;
    }
}
