package com.anz.mdm.ocv.api.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.http.HttpException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.downsteamservices.CapTransformationService;
import com.anz.mdm.ocv.api.downsteamservices.DataStandardisationService;
import com.anz.mdm.ocv.api.downsteamservices.DataValidationService;
import com.anz.mdm.ocv.api.downsteamservices.DeletePartyService;
import com.anz.mdm.ocv.api.downsteamservices.MaintainPartyService;
import com.anz.mdm.ocv.api.downsteamservices.RetrievePartyService;
import com.anz.mdm.ocv.api.downsteamservices.StandardisedParty;
import com.anz.mdm.ocv.api.downsteamservices.TokenService;
import com.anz.mdm.ocv.api.downsteamservices.ValidatedParty;
import com.anz.mdm.ocv.api.dto.APIResponse;
import com.anz.mdm.ocv.api.exception.BadRequestException;
import com.anz.mdm.ocv.api.exception.JwtValidationException;
import com.anz.mdm.ocv.api.interceptor.JWTInterceptor;
import com.anz.mdm.ocv.api.model.CAPParty;
import com.anz.mdm.ocv.api.util.APIServiceUtil;
import com.anz.mdm.ocv.api.util.IdempotencyConfigUtil;
import com.anz.mdm.ocv.api.util.LogRequestModel;
import com.anz.mdm.ocv.api.util.LogUtil;
import com.anz.mdm.ocv.api.validator.APIRequest;
import com.anz.mdm.ocv.api.validator.DeletePartyValidator;
import com.anz.mdm.ocv.api.validator.MaintainCapPartyValidator;
import com.anz.mdm.ocv.api.validator.MaintainPartyValidator;
import com.anz.mdm.ocv.api.validator.ValidationResult;
import com.anz.mdm.ocv.common.v1.KYCVerification;
import com.anz.mdm.ocv.common.v1.SourceSystem;
import com.anz.mdm.ocv.party.v1.Party;
import com.anz.mdm.ocv.party.v1.SearchPartyResultWrapper;

import lombok.extern.slf4j.Slf4j;

/**
 * Serves as the entry point to the RESTful endpoints.
 *
 * @author Amit Gera
 */
@Slf4j
@RestController
public class APIController {

    @Autowired
    private DataStandardisationService dataStandardisationService;

    @Autowired
    private MaintainPartyService maintainPartyService;

    @Autowired
    private MaintainPartyValidator maintainPartyValidator;

    @Autowired
    private MaintainCapPartyValidator maintainPartyCapValidator;

    @Autowired
    private DeletePartyService deletePartyService;

    @Autowired
    private DataValidationService dataValidationService;

    @Autowired
    private RetrievePartyService retrievePartyService;

    @Autowired
    private CapTransformationService capTransformationService;

    @Autowired
    private LogRequestModel logAttributes;

    @Autowired
    private TokenService tokenService;

    @Autowired
    private JWTInterceptor jwtInterceptor;

    @Autowired
    private IdempotencyConfigUtil idempotencyUtil;

    public APIController(DataStandardisationService dataStandardisationService,
                         MaintainPartyService maintainPartyService, DeletePartyService deletePartyService,
                         LogRequestModel logAttributes, DataValidationService dataValidationService,
                         RetrievePartyService retrievePartyService, CapTransformationService capTransformationService,
                         JWTInterceptor jwtInterceptor, IdempotencyConfigUtil idempotencyUtil) {
        super();

        this.maintainPartyService = maintainPartyService;
        this.deletePartyService = deletePartyService;
        this.dataStandardisationService = dataStandardisationService;
        this.logAttributes = logAttributes;
        this.dataValidationService = dataValidationService;
        this.retrievePartyService = retrievePartyService;
        this.capTransformationService = capTransformationService;
        this.jwtInterceptor = jwtInterceptor;
        this.idempotencyUtil = idempotencyUtil;
    }

    public void setTokenService(TokenService tokenService) {
        this.tokenService = tokenService;
    }

    // This method will serve as health check for liveness probe
    @RequestMapping(method = RequestMethod.GET, value = "/health", produces = {"application/json"})
    @ResponseBody
    public ResponseEntity<Object> health() throws Exception {
        String response = "{\"status\": \"UP\"}";
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.POST, value = "/parties", consumes = {
            MediaType.APPLICATION_JSON_VALUE}, produces = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseBody
    public ResponseEntity<Object> maintainParty(@RequestHeader Map<String, String> headers,
                                                @RequestParam Map<String, String> queryParameters,
                                                @RequestBody Party party)
            throws HttpException, IOException, Exception {
        Long startTime = System.currentTimeMillis();
        String traceId = headers.get(OCVConstants.TRACE_ID_HEADER);
        LogUtil.debug(log, "maintainParty", traceId, "Entering: maintainParty method in APIController");
        LogUtil.debug(log, "maintainParty", traceId, "Headers: " + headers);
        LogUtil.debug(log, "partyRequest for AR&C:", new APIServiceUtil().printPartyRequest(party), "maintainPartyAPI");
        String response = null;
        APIRequest<Party> apiRequest = new APIRequest<Party>(headers, queryParameters, party);
        String requestTime = headers.get(OCVConstants.REQUEST_TIMESTAMP);
        ValidationResult validationResult = maintainPartyValidator.validateRequest(apiRequest);
        if (!validationResult.isValid()) {

            LogUtil.debug(log, "maintainParty", logAttributes.getTraceId(),
                    "Request Validation failed with error code :" + validationResult.getErrorCode());
            throw new BadRequestException(validationResult.getErrorCode(), validationResult.getStatus());
        }
        populateLogAttributes(apiRequest);
        logAttributes.setServiceName(OCVConstants.MAINTAINPARTY_SERVICE);
        Long dlStartTime = System.currentTimeMillis();

        boolean signatureValidationStatus = jwtInterceptor.validateJWT(apiRequest);
        if (signatureValidationStatus) {
            LogUtil.debug(log, "maintainParty", logAttributes.getTraceId(), "Invoking data standardisation service");
            final StandardisedParty standardisedParty = dataStandardisationService.standardiseParty(apiRequest);
            LogUtil.debug(log, "maintainParty", logAttributes.getTraceId(), "Data standardisation completed",
                    System.currentTimeMillis() - dlStartTime);
            final APIRequest<Party> standardisedApiRequest = new APIRequest<>(headers, queryParameters,
                    standardisedParty.getParty());
            LogUtil.debug(log, "validateParty", traceId, "Invoking data validation service");
            // Change start for https://jira.service.anz/browse/OCT-25769
            ValidatedParty validatedParty = dataValidationService.validateParty(standardisedApiRequest);
            LogUtil.debug(log, "maintainParty", logAttributes.getTraceId(), "Invoking RedHatRuleEngineService");
            validatedParty = dataStandardisationService.standardisePhoneWithRHDM(validatedParty, headers,
                    queryParameters);
            // Change end for https://jira.service.anz/browse/OCT-25769

            final APIRequest<Party> validatedApiRequest = new APIRequest<>(headers, queryParameters,
                    validatedParty.getParty());
            response = maintainPartyService.processParty(validatedApiRequest, requestTime, apiRequest.getTraceId(),
                    false);
        } else {
            LogUtil.debug(log, "maintainParty Api", traceId,
                    "Header and Signature tampered causing signature validation failure. Pls try with a valid JWT",
                    System.currentTimeMillis() - startTime);
            throw new JwtValidationException(OCVConstants.INVALID_JWT_CODE, OCVConstants.INVALID_JWT);
        }

        HttpHeaders responseHeaders = new APIServiceUtil().setHeaders(traceId);

        LogUtil.info(log, "maintainParty", logAttributes.getTraceId(), "Successful",
                (System.currentTimeMillis() - startTime), apiRequest.getChannel(),
                apiRequest.getRequestBody().getPartyType(), OCVConstants.MAINTAINPARTY_SERVICE);

        return new ResponseEntity<>(response, responseHeaders, HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.POST, value = "/v2/parties", consumes = {
            MediaType.APPLICATION_JSON_VALUE}, produces = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseBody
    public ResponseEntity<Object> maintainPartyV2(@RequestHeader Map<String, String> headers,
                                                  @RequestParam Map<String, String> queryParameters,
                                                  @RequestBody Party party)
            throws HttpException, IOException, Exception {
        Long startTime = System.currentTimeMillis();
        String traceId = headers.get(OCVConstants.TRACE_ID_HEADER);
        new APIServiceUtil().captureLogs(log, traceId, headers, party);
        APIResponse response = null;
        final APIRequest<Party> standardisedApiRequest;
        APIRequest<Party> apiRequest = new APIRequest<Party>(headers, queryParameters, party);
        String requestTime = apiRequest.getRequestTimestamp();
        populateLogAttributes(apiRequest);
        validateRequest(apiRequest);
        logAttributes.setServiceName(OCVConstants.MAINTAINPARTY_SERVICE);
        Long dlStartTime = System.currentTimeMillis();
        String channel = apiRequest.getChannel();
        final StandardisedParty standardisedParty;
        boolean signatureValidationStatus = jwtInterceptor.validateJWT(apiRequest);
        if (signatureValidationStatus) {
            LogUtil.debug(log, "maintainParty", logAttributes.getTraceId(), "Invoking data standardisation service");
            standardisedParty = dataStandardisationService.standardiseParty(apiRequest);
            LogUtil.debug(log, "maintainParty", logAttributes.getTraceId(), "Data standardisation completed",
                    System.currentTimeMillis() - dlStartTime);
            standardisedApiRequest = new APIRequest<>(headers, queryParameters, standardisedParty.getParty());
            LogUtil.debug(log, "validateParty", traceId, "Invoking data validation service");
            // Change start for https://jira.service.anz/browse/OCT-25769
            ValidatedParty validatedParty = dataValidationService.validateParty(standardisedApiRequest);
            LogUtil.debug(log, "maintainParty", logAttributes.getTraceId(), "Invoking RedHatRuleEngineService");
            validatedParty = dataStandardisationService.standardisePhoneWithRHDM(validatedParty, headers,
                    queryParameters);
            // Change end for https://jira.service.anz/browse/OCT-25769
            final APIRequest<Party> validatedApiRequest = new APIRequest<>(headers, queryParameters,
                    validatedParty.getParty());
            checkRequestFromCloudConsumer(validatedApiRequest);
            idempotencyUtil.validate(validatedApiRequest, apiRequest, logAttributes.getTraceId());
            response = processParty(apiRequest, requestTime, channel, validatedApiRequest, startTime);
        } else {
            LogUtil.debug(log, "maintainParty api", traceId,
                    "Header and Signature tampered causing " + "signature validation failure. Try with a valid JWT",
                    System.currentTimeMillis() - startTime);
            throw new JwtValidationException(OCVConstants.INVALID_JWT_CODE, OCVConstants.INVALID_JWT);
        }
        LogUtil.info(log, "maintainParty", logAttributes.getTraceId(), "Successful",
                (System.currentTimeMillis() - startTime), channel, apiRequest.getRequestBody().getPartyType(),
                OCVConstants.MAINTAINPARTY_SERVICE);

        HttpHeaders responseHeaders = new APIServiceUtil().setHeaders(traceId);
        return new ResponseEntity<>(response, responseHeaders, HttpStatus.OK);
    }

    private APIResponse processParty(APIRequest<Party> apiRequest, String requestTime, String channel,
                                     final APIRequest<Party> validatedApiRequest, Long startTime) throws IOException,
            Exception {
        APIResponse response;
        if (OCVConstants.FENERGOANZX_CHANNEL.equalsIgnoreCase(channel)
                && OCVConstants.REQUEST_MODE_UPDATEKYC.equalsIgnoreCase(apiRequest.getRequestMode())) {
            response = createUpdateProfilesForInt2(apiRequest, validatedApiRequest, requestTime,
                    logAttributes.getTraceId(), apiRequest.getRequestMode(), startTime);
        } else if ((OCVConstants.FENERGOANZX_CHANNEL.equalsIgnoreCase(channel)
                || OCVConstants.AEGISANZX_CHANNEL.equalsIgnoreCase(channel)
                || OCVConstants.AX1_CHANNEL.equalsIgnoreCase(channel))
                && OCVConstants.REQUEST_MODE_UPDATE_ANZX.equalsIgnoreCase(apiRequest.getRequestMode())) {
            response = createUpdateProfilesForInt3(apiRequest, validatedApiRequest, requestTime,
                    logAttributes.getTraceId(), apiRequest.getRequestMode(), startTime);
        } else {
            response = maintainPartyService.createOrUpdateParty(validatedApiRequest, requestTime,
                    logAttributes.getTraceId(), null, false);
        }
        response.setResponseFromIdempotency(null);
        return response;
    }

    private void checkRequestFromCloudConsumer(APIRequest<Party> validatedApiRequest) {
        if (tokenService.checkForSensitiveConsumer(validatedApiRequest)) {
            tokenService.decryptSensitiveAttributes(validatedApiRequest);
        }
    }

    private void validateRequest(APIRequest<Party> apiRequest) throws BadRequestException {
        if (OCVConstants.FENERGOANZX_CHANNEL.equalsIgnoreCase(apiRequest.getChannel())
                || OCVConstants.AEGISANZX_CHANNEL.equalsIgnoreCase(apiRequest.getChannel())) {
            ValidationResult validationResult = maintainPartyCapValidator.validateRequest(apiRequest);
            validateResult(validationResult);
        } else {
            ValidationResult validationResult = maintainPartyValidator.validateRequest(apiRequest);
            validateResult(validationResult);
        }
    }

    private APIResponse createUpdateProfilesForInt2(APIRequest<Party> apiRequest, APIRequest<Party> validatedApiRequest,
                                                    String requestTime, String traceId, String requestMode,
                                                    Long startTime) throws IOException, Exception {
        Long interaction2StartTime = System.currentTimeMillis();
        APIResponse response = maintainPartyService.createOrUpdateParty(validatedApiRequest, requestTime, traceId, null,
                false);
        LogUtil.info(log, "createUpdateProfilesForInt2", traceId, "Successful FENERGO Update",
                (System.currentTimeMillis() - startTime), validatedApiRequest.getChannel(),
                validatedApiRequest.getRequestBody().getPartyType(), OCVConstants.MAINTAINPARTY_SERVICE);
        Boolean kysStatusFlag = validateKycVerificationStatus(validatedApiRequest);
        if (Boolean.FALSE.equals(kysStatusFlag) || (null != response && response.getResponseFromIdempotency())) {
            return response;
        }
        // Populate the latest Ocvid in the Request

        new APIServiceUtil().populateLatestOCVIdInRequest(response, validatedApiRequest);
        SearchPartyResultWrapper serchResult = retrievePartyService
                .getResponse(capTransformationService.getRetrieveRequest(validatedApiRequest), traceId);
        Map<String, Party> idMap = capTransformationService.getIdMap(serchResult);
        if (null != idMap.get(OCVConstants.CAP_CIS_SOURCE)) {
            // existing to bank
            response = updateGoldenProfile(validatedApiRequest, requestTime, traceId, idMap, requestMode);
        } else {
            response = createCAPProfile(apiRequest, validatedApiRequest, requestTime, traceId);
        }
        LogUtil.debug(log, "maintain Party - Create CAP profile", traceId, "CAP Profile Creation/Updation completed",
                System.currentTimeMillis() - interaction2StartTime);
        return response;
    }

    private APIResponse createCAPProfile(APIRequest<Party> apiRequest, APIRequest<Party> validatedApiRequest,
                                         String requestTime, String traceId) throws Exception, IOException {

        String fenergoSourceId = null;
        if (validatedApiRequest.getRequestBody().getSourceSystems().size() > 0
                && validatedApiRequest.getRequestBody().getSourceSystems().get(0) != null) {
            fenergoSourceId = validatedApiRequest.getRequestBody().getSourceSystems().get(0).getSourceSystemId();
        }

        CAPParty capCreateResponse = capTransformationService.createCapProfileV2(apiRequest, validatedApiRequest,
                traceId);
        if (capCreateResponse.isResult()) {
            return createCustomerInMdm(apiRequest, validatedApiRequest, requestTime, traceId, capCreateResponse,
                    fenergoSourceId);
        }
        LogUtil.error(log, "createUpdateProfilesForInt2", "Cap Profile Creation failed",
                "Cap Profile Creation failed in CAP");

        return null;
    }

    private APIResponse createCustomerInMdm(APIRequest<Party> apiRequest, APIRequest<Party> validatedApiRequest,
                                            String requestTime, String traceId, CAPParty capCreateResponse,
                                            String fenergoSourceId)
            throws Exception, IOException {
        APIServiceUtil apiServiceUtil = new APIServiceUtil();
        apiServiceUtil.populatePrivacyPreference(capCreateResponse);
        return createCapProfileInMdm(validatedApiRequest, requestTime, traceId, capCreateResponse, fenergoSourceId);
    }

    private APIResponse createCapProfileInMdm(APIRequest<Party> validatedApiRequest, String requestTime, String traceId,
                                              CAPParty capCreateResponse, String fenergoSourceId) throws IOException,
            Exception {
        APIResponse response;
        /*
         * OCT-21879: Remove OCV ID as hard-linking capability assists in keeping profile in cluster.
         */
        APIServiceUtil.removeOcvId(validatedApiRequest);
        validatedApiRequest.getRequestBody().setSource(OCVConstants.CAP_CIS_SOURCE);
        response = maintainPartyService.createOrUpdateParty(capCreateResponse.getPartyApiReq(), requestTime,
                traceId, fenergoSourceId, true);
        return response;
    }

    private Boolean validateKycVerificationStatus(APIRequest<Party> validatedApiRequest) {
        KYCVerification kycVerification = ObjectUtils
                .isNotEmpty(validatedApiRequest.getRequestBody().getKycVerifications())
                ? validatedApiRequest.getRequestBody().getKycVerifications().get(0)
                : null;
        if (ObjectUtils.isNotEmpty(kycVerification)
                && kycVerification.getVerificationStatusType().equalsIgnoreCase(OCVConstants.KYC_STATUS_FAIL)) {
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }

    private APIResponse createUpdateProfilesForInt3(APIRequest<Party> apiRequest, APIRequest<Party> validatedApiRequest,
                                                    String requestTime, String traceId, String requestMode,
                                                    Long startTime) throws IOException, Exception {
        APIResponse response = null;
        SearchPartyResultWrapper serchResult = retrievePartyService
                .getResponse(capTransformationService.getRetrieveRequest(validatedApiRequest), traceId);
        Map<String, Party> idMap = capTransformationService.getIdMap(serchResult);
        if (null != idMap.get(OCVConstants.FENERGO_SOURCE)) {
            // existing to bank
            APIServiceUtil.removeOcvId(validatedApiRequest);
            updateFenergoProfile(validatedApiRequest, requestTime, traceId, idMap, startTime);
        }
        Long capCreateStartTime = System.currentTimeMillis();
        LogUtil.debug(log, "maintain Party - Create CAP profile", traceId,
                "Invoking CAP Transformataion Service and Creating CAP profile through APIC");
        if (null != idMap.get(OCVConstants.CAP_CIS_SOURCE)) {
            // existing to bank
            response = updateGoldenProfile(validatedApiRequest, requestTime, traceId, idMap, requestMode);
        }
        LogUtil.debug(log, "createUpdateProfilesForInt3", traceId, "Profiles updation completed",
                System.currentTimeMillis() - capCreateStartTime);
        return response;
    }

    private APIResponse updateFenergoProfile(APIRequest<Party> validatedApiRequest, String requestTime, String traceId,
                                             Map<String, Party> idMap, Long startTime) throws IOException, Exception {
        List<SourceSystem> sourceSystems = validatedApiRequest.getRequestBody().getSourceSystems();
        if (CollectionUtils.isEmpty(sourceSystems)) {
            SourceSystem srcSys = new SourceSystem();
            srcSys.setSourceSystemId(
                    idMap.get(OCVConstants.FENERGO_SOURCE).getSourceSystems().get(0).getSourceSystemId());
            srcSys.setSourceSystemName(OCVConstants.FENERGO_SOURCE);
            validatedApiRequest.getRequestBody().getSourceSystems().add(srcSys);
        }
        APIResponse response = maintainPartyService.createOrUpdateParty(validatedApiRequest, requestTime, traceId, null,
                false);
        LogUtil.info(log, "updateFenergoProfile", traceId, "Successful FENERGO Update",
                (System.currentTimeMillis() - startTime), validatedApiRequest.getChannel(),
                validatedApiRequest.getRequestBody().getPartyType(), OCVConstants.MAINTAINPARTY_SERVICE);
        return response;
    }

    private APIResponse updateGoldenProfile(APIRequest<Party> validatedApiRequest, String requestTime, String traceId,
                                            Map<String, Party> idMap, String requestMode) throws IOException,
            Exception {
        SourceSystem srcSys = new SourceSystem();
        srcSys.setSourceSystemId(idMap.get(OCVConstants.CAP_CIS_SOURCE).getSourceSystems().get(0).getSourceSystemId());
        srcSys.setSourceSystemName(OCVConstants.CAP_CIS_SOURCE);

        /*
         * Hard-linking capability assists in keeping profiles in same cluster.
         */
        String fenergoSourceId = null;
        if (OCVConstants.REQUEST_MODE_UPDATEKYC.equalsIgnoreCase(requestMode)
                && validatedApiRequest.getRequestBody().getSourceSystems().size() > 0
                && validatedApiRequest.getRequestBody().getSourceSystems().get(0) != null) {
            fenergoSourceId = validatedApiRequest.getRequestBody().getSourceSystems().get(0).getSourceSystemId();
        }

        validatedApiRequest.getRequestBody().getSourceSystems().clear();
        validatedApiRequest.getRequestBody().getSourceSystems().add(srcSys);
        validatedApiRequest.getRequestBody().setSource(OCVConstants.CAP_CIS_SOURCE);
        APIServiceUtil.removeOcvId(validatedApiRequest);
        APIResponse response = maintainPartyService.createOrUpdateParty(validatedApiRequest, requestTime,
                traceId, fenergoSourceId, true);
        return response;
    }

    // This method will process request for delete parties, url will change
    @RequestMapping(method = RequestMethod.DELETE, value = "/parties/{partyId}")
    @ResponseBody
    public Object deleteParty(@RequestHeader Map<String, String> headers,
                              @RequestParam Map<String, String> queryParameters,
                              @PathVariable(OCVConstants.DELETE_PARTYID) String id)
            throws HttpException, IOException, Exception {
        String traceId = headers.get(OCVConstants.TRACE_ID_HEADER);
        LogUtil.debug(log, "deleteParty", traceId, "Entering: deleteParty method in APIController");
        Long startTime = System.currentTimeMillis();
        String requestTime = headers.get(OCVConstants.REQUEST_TIMESTAMP);
        DeletePartyValidator deletePartyValidator = new DeletePartyValidator();
        String response = null;
        LogUtil.debug(log, "deleteParty", traceId, "Entering:deleteParty method in APIController");
        Party party = new Party();
        String idType = queryParameters.get(OCVConstants.DELETE_IDTYPE);
        if (idType != null || id != null) {

            SourceSystem sourceSystem = new SourceSystem();
            sourceSystem.setSourceSystemId(id);
            sourceSystem.setSourceSystemName(idType);
            party.getSourceSystems().add(sourceSystem);
        }
        APIRequest<Party> apiRequest = new APIRequest<>(headers, queryParameters, party);
        ValidationResult validationResult = deletePartyValidator.validateRequest(apiRequest);
        if (!validationResult.isValid()) {
            LogUtil.debug(log, "deleteParty", traceId,
                    "Request Validation failed with error code :" + validationResult.getErrorCode());
            throw new BadRequestException(validationResult.getErrorCode(), validationResult.getStatus());
        }
        populateLogAttributes(apiRequest);
        logAttributes.setServiceName(OCVConstants.DELETEPARTY_SERVICE);
        Long endTime = System.currentTimeMillis();
        LogUtil.debug(log, "deleteParty", traceId, "Invoking Delete Party service");
        response = deletePartyService.processDeleteParty(apiRequest, requestTime, traceId);
        LogUtil.debug(log, "delParty", traceId, "Exiting: DeleteParty method in APIController", (endTime - startTime));
        return response;
    }

    // This method will process request for delete parties, url will change
    @RequestMapping(method = RequestMethod.DELETE, value = "/v2/parties/{partyId}")
    @ResponseBody
    public Object deletePartyV2(@RequestHeader Map<String, String> headers,
                                @RequestParam Map<String, String> queryParameters,
                                @PathVariable(OCVConstants.DELETE_PARTYID) String id)
            throws HttpException, IOException, Exception {
        String traceId = headers.get(OCVConstants.TRACE_ID_HEADER);
        LogUtil.debug(log, "deleteParty", traceId, "Entering: deleteParty method in APIController");
        Long startTime = System.currentTimeMillis();
        String requestTime = headers.get(OCVConstants.REQUEST_TIMESTAMP);
        DeletePartyValidator deletePartyValidator = new DeletePartyValidator();
        APIResponse response = null;
        LogUtil.debug(log, "deleteParty", traceId, "Entering:deleteParty method in APIController");
        Party party = new Party();
        String idType = queryParameters.get(OCVConstants.DELETE_IDTYPE);
        if (idType != null || id != null) {

            SourceSystem sourceSystem = new SourceSystem();
            sourceSystem.setSourceSystemId(id);
            sourceSystem.setSourceSystemName(idType);
            party.getSourceSystems().add(sourceSystem);
        }
        APIRequest<Party> apiRequest = new APIRequest<>(headers, queryParameters, party);
        ValidationResult validationResult = deletePartyValidator.validateRequest(apiRequest);
        if (!validationResult.isValid()) {
            LogUtil.debug(log, "deleteParty", traceId,
                    "Request Validation failed with error code :" + validationResult.getErrorCode());
            throw new BadRequestException(validationResult.getErrorCode(), validationResult.getStatus());
        }
        populateLogAttributes(apiRequest);
        logAttributes.setServiceName(OCVConstants.DELETEPARTY_SERVICE);
        Long endTime = System.currentTimeMillis();
        LogUtil.debug(log, "deleteParty", traceId, "Invoking Delete Party service");
        response = deletePartyService.deleteParty(apiRequest, requestTime, traceId);
        LogUtil.debug(log, "delParty", traceId, "Exiting: DeleteParty method in APIController", (endTime - startTime));
        return response;
    }

    public void populateLogAttributes(APIRequest<Party> apiRequest) {
        logAttributes.setChannel(apiRequest.getChannel());
        logAttributes.setTraceId(apiRequest.getTraceId());
        logAttributes.setPartyType(apiRequest.getRequestBody().getPartyType());
    }

    private void validateResult(ValidationResult validationResult) throws BadRequestException {
        if (!validationResult.isValid()) {
            LogUtil.debug(log, "maintainParty", logAttributes.getTraceId(),
                    "Request Validation failed with error code :" + validationResult.getErrorCode());
            throw new BadRequestException(validationResult.getErrorCode(), validationResult.getStatus());
        }
    }

}