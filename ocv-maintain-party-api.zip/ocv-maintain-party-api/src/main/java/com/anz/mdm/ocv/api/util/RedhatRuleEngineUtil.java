package com.anz.mdm.ocv.api.util;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.downsteamservices.StandardisedParty;
import com.anz.mdm.ocv.api.validator.APIRequest;
import com.anz.mdm.ocv.common.v1.Phone;
import com.anz.mdm.ocv.common.v1.SourceSystem;
import com.anz.mdm.ocv.party.v1.Party;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public final class RedhatRuleEngineUtil {

    private static final String METHOD_NAME = "RedhatRuleEngineUtil";

    private static final String COMMA = ",";
    
    private static final String INVOCATION_ERROR = "RedhatRuleEngineService invocation failed";

    private static final String REDHAT_RULE_ENGINE_FAILED = "MAINTAINPARTY_RedhatRuleEngineService_FAILED";

    private static final String LOGPHONEFAILMESSAGE = "%s, Request Time: %s, Source System IDs: "
            + "[ %s ], Source Names: [ %s ]";
    
    private static final String PHONE_STANDARDISATION_ERROR = "Phone is not standardised";
    

    private RedhatRuleEngineUtil() {
        //not used
    }
    
    public static HttpEntity<Party> prepareInput(APIRequest<Party> apiRequest, long startTime) {
        String traceId = apiRequest.getTraceId();
        LogUtil.debug(log, METHOD_NAME, traceId, "Entering prepareInput", System.currentTimeMillis() - startTime);
        HttpEntity<Party> request = null;
        try {
            request = new HttpEntity<>(apiRequest.getRequestBody(), prepareHeaders(apiRequest.getTraceId()));
        } catch (Exception e) {
            LogUtil.info(log, METHOD_NAME, traceId, "prepareInput:" + e.getMessage(),
                    System.currentTimeMillis() - startTime, "", apiRequest.getChannel(),
                    OCVConstants.MAINTAINPARTY_SERVICE);
        }
        LogUtil.debug(log, METHOD_NAME, traceId, "Exiting prepareInput", System.currentTimeMillis() - startTime);
        return request;
    }

    public static Object prepareSuccessOutput(StandardisedParty request,StandardisedParty target,
            final APIRequest<Party> apiRequest, final long startTime) {
        String traceId = apiRequest.getTraceId();
        LogUtil.debug(log, METHOD_NAME, traceId, "Entering prepareSuccessOutput",
                System.currentTimeMillis() - startTime);
        try {
            mapTarPhoneToSrc(request, target, apiRequest);
        } catch (Exception e) {
            LogUtil.info(log, METHOD_NAME, traceId, "prepareOutput:" + e.getMessage(),
                    System.currentTimeMillis() - startTime, "", apiRequest.getChannel(),
                    OCVConstants.MAINTAINPARTY_SERVICE);
        }
        LogUtil.debug(log, METHOD_NAME, traceId, "Exiting prepareSuccessOutput",
                System.currentTimeMillis() - startTime);
        return request;
    }
    
    public static Object prepareErrorOutput(final Throwable throwable, final APIRequest<Party> apiRequest) {
        String traceId = apiRequest.getTraceId();
        LogUtil.debug(log, METHOD_NAME, apiRequest.getTraceId(), "Entering prepareErrorOutput");
        String channel = apiRequest.getChannel();
        StandardisedParty standardisedParty = null;
        try {
            logError(INVOCATION_ERROR, "RedhatRuleEngineService failed. TraceId:" + apiRequest.getTraceId(),
                    throwable.getMessage(), apiRequest, METHOD_NAME);
            standardisedParty = new StandardisedParty(apiRequest.getRequestBody(), false);
        } catch (Exception e) {
            LogUtil.info(log, METHOD_NAME, traceId, "prepareErrorOutput:" + e.getMessage(), System.currentTimeMillis(),
                    "", channel, OCVConstants.MAINTAINPARTY_SERVICE);
        }
        LogUtil.debug(log, METHOD_NAME, apiRequest.getTraceId(), "Exiting prepareErrorOutput");
        return standardisedParty;
    }

    /**
     * This method populates the Standardized phone from RHDM response to Request.
     */
    private static void mapTarPhoneToSrc(StandardisedParty source,StandardisedParty target,
            final APIRequest<Party> apiRequest) throws Exception {
        Long startTime = System.currentTimeMillis();
        LogUtil.debug(log, METHOD_NAME, apiRequest.getTraceId(), "Entering mapTarPhoneToSrc",
                System.currentTimeMillis() - startTime);
        List<Phone> sourcePhones = source.getParty().getPhones();
        List<Phone> targetPhones = target.getParty().getPhones();
        final List<SourceSystem> sourceSystems = apiRequest.getRequestBody().getSourceSystems();
        final String commaSeparatedSourceSystemIds = (sourceSystems == null) ? ""
                : sourceSystems.stream().map(s -> s.getSourceSystemId()).collect(Collectors.joining(COMMA));

        final String commaSeparatedSourceSystemNames = (sourceSystems == null) ? ""
                : sourceSystems.stream().map(s -> s.getSourceSystemName()).collect(Collectors.joining(COMMA));

        final String logMessage = String.format(LOGPHONEFAILMESSAGE, PHONE_STANDARDISATION_ERROR,
                apiRequest.getRequestTimestamp(), commaSeparatedSourceSystemIds, commaSeparatedSourceSystemNames);

        // Copy standardisedPhone from target to source
        sourcePhones.stream().forEach(srcPhone -> targetPhones.stream().forEach(tarPhone -> {
            if (srcPhone.getPhone().equalsIgnoreCase(tarPhone.getPhone())
                    && srcPhone.getPhoneUsageType().equalsIgnoreCase(tarPhone.getPhoneUsageType())
                    && null != tarPhone.getStandardisedPhone()) {
                srcPhone.setStandardisedPhone(tarPhone.getStandardisedPhone());
                logPhoneRejection(tarPhone, apiRequest, logMessage, startTime);
            }
        }));

        LogUtil.debug(log, METHOD_NAME, apiRequest.getTraceId(), "Exiting from mapTarPhoneToSrc",
                (System.currentTimeMillis() - startTime));
    }

    /**
     * This method will log phone rejection reasons
     */
    private static void logPhoneRejection(Phone phone, final APIRequest<Party> apiRequest, 
            String logMessage, long startTime) {
        if (null != phone && null != phone.getStandardisedPhone()
                && OCVConstants.FALSE.equalsIgnoreCase(phone.getStandardisedPhone().getValidationOutcome())) {
            phone.getStandardisedPhone().getRejectionReasons().stream().forEach(reason -> {
                LogUtil.info(log, METHOD_NAME, apiRequest.getTraceId(),
                        logMessage + " with rejection reason:" + reason.getRejectionReason(),
                        System.currentTimeMillis() - startTime, apiRequest.getChannel(),
                        apiRequest.getRequestBody().getPartyType(), OCVConstants.MAINTAINPARTY_SERVICE);
            });
        }
    }
    
    /**
     * This method will populate headers for rest call
     */
    protected static HttpHeaders prepareHeaders(final String traceId) throws Exception {
        LogUtil.debug(log, METHOD_NAME, traceId, "Entering prepareHeaders");
        final HttpHeaders headers = new HttpHeaders();
        headers.set(OCVConstants.ACCEPT_HEADER, MediaType.APPLICATION_JSON_VALUE);
        headers.set(OCVConstants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        headers.set(OCVConstants.TRACE_ID_HEADER, traceId);
        LogUtil.debug(log, METHOD_NAME, traceId, "Exiting prepareHeaders");
        return headers;
    }

    /**
     * This method will log error
     */
    protected static void logError(final String errorString, final String reason, final String reasonCode,
            final APIRequest<Party> apiRequest, final String method) throws Exception {

        final String requestTime = apiRequest.getRequestTimestamp();
        final List<SourceSystem> sourceSystems = apiRequest.getRequestBody().getSourceSystems();

        /*
         * Generally, there would be single Source System ID and Name. But as it is
         * defined as a List, we need to take care of this and take it as a comma
         * separated string
         */
        final String commaSeparatedSourceSystemIds = (sourceSystems == null) ? ""
                : sourceSystems.stream().map(s -> s.getSourceSystemId()).collect(Collectors.joining(COMMA));

        final String commaSeparatedSourceSystemNames = (sourceSystems == null) ? ""
                : sourceSystems.stream().map(s -> s.getSourceSystemName()).collect(Collectors.joining(COMMA));

        // Excluding traceId here as it gets logged in the wrapper LogUtil
        // function
        final String logMessage = String.format(
                "Request Time: %s %s: %s , Source System IDs: [ %s ], Source Names: [ %s ]", requestTime,
                REDHAT_RULE_ENGINE_FAILED, errorString, commaSeparatedSourceSystemIds, commaSeparatedSourceSystemNames);

        LogUtil.error(log, method, apiRequest.getTraceId(), reason, reasonCode, apiRequest.getChannel(),
                apiRequest.getRequestBody().getPartyType(), OCVConstants.MAINTAINPARTY_SERVICE, logMessage);
    }

}