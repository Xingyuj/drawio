package com.anz.mdm.ocv.api.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BatchInput {

    private String value;

    private String transformation;
}