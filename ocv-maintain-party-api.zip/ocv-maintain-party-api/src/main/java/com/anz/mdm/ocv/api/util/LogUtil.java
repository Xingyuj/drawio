package com.anz.mdm.ocv.api.util;

import org.slf4j.Logger;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

/**
 * This Utility class provides convenience methods for log formatting meeting
 * documented Logging standards. The following log levels are in use INFO, FINE
 * ERROR. Copied from Kakfa Controller project
 * 
 * @author palanisk
 *
 */

@Slf4j
public final class LogUtil {

    private LogUtil() {

    }

    /**
     * Log Level INFO is used to log a successful execution of ***Search API***.
     * Successful execution will log traceId, log message, elapsedTimeMillis,
     * party type, channel and downstream Service used to bring results.
     * 
     * @param logger
     *            the logger from the caller class
     * @param method
     *            the method from where log is streamed
     * @param traceId
     *            the trace Id for the transaction
     * @param logMessage
     *            the actual log message
     * @param elapsedTimeMillis
     *            time taken by the method
     * @param partyType
     *            time taken by the method
     * @param channel
     *            time taken by the method
     * @param serviceName
     *            downstream service used for search
     */
    // CHECKSTYLE:OFF - checkstyle considers this as utility class
    public static void info(Logger logger, String method, String traceId, String logMessage, long elapsedTimeMillis,
            String channel, String partyType, String serviceName) {
        if (logger.isInfoEnabled()) {
            StringBuilder sb = new StringBuilder();
            sb.append("method=\"").append(method).append("\",");
            sb.append("traceId=\"").append(traceId != null ? traceId : "").append("\",");
            sb.append("description=\"").append(logMessage).append("\",");
            sb.append("serviceName =\"").append(serviceName).append("\",");
            sb.append("channel=\"").append(channel).append("\",");
            sb.append("partyType=\"").append(partyType).append("\",");
            sb.append("time-taken=\"").append(elapsedTimeMillis).append("\"");
            logger.info(sb.toString());
        }
    }
    // CHECKSTYLE:ON

    /**
     * Log level DEBUG is used to log class & method entry/exit, diagnostic
     * trace, service execution time, other log statements (developer
     * discretion) Format : method="", requestID="",description="",
     * time-taken=""
     * 
     * @param logger
     *            the logger from the caller class
     * @param method
     *            the method from where log is streamed
     * @param requestID
     *            the request Id for the transaction
     * @param logMessage
     *            the actual log message
     * @param elapsedTimeMillis
     *            time taken by the method
     */
    public static void debug(Logger logger, String method, String traceId, String logMessage, long elapsedTimeMillis) {

        if (logger.isDebugEnabled()) {
            StringBuilder sb = new StringBuilder();
            sb.append("method=\"").append(method).append("\",");
            sb.append("traceId=\"").append(traceId != null ? traceId : "").append("\",");
            sb.append("description=\"").append(logMessage).append("\",");
            if (elapsedTimeMillis > 0) {
                sb.append("time-taken=\"").append(elapsedTimeMillis).append("\"");
            } else {
                sb.deleteCharAt(sb.length() - 1);
            }
            logger.debug(sb.toString());
        }
    }

    /**
     * Log level DEBUG is used to log class & method entry/exit, diagnostic
     * trace, service execution time, other log statements (developer
     * discretion) Format : method="", requestID="",description="",
     * time-taken=""
     * 
     * @param logger
     *            the logger from the caller class
     * @param method
     *            the method from where log is streamed
     * @param requestID
     *            the request Id for the transaction
     * @param logMessage
     *            the actual log message
     */
    public static void debug(Logger logger, String method, String traceId, String logMessage) {
        debug(logger, method, traceId, logMessage, 0);
    }

    /**
     * Log level DEBUG is used to log class & method entry/exit, diagnostic
     * trace, service execution time, other log statements (developer
     * discretion) Format : method="", requestID="",description="",
     * time-taken=""
     * 
     * @param logger
     *            the logger from the caller class
     * @param method
     *            the method from where log is streamed
     * @param logMessage
     *            the actual log message
     */
    public static void debug(Logger logger, String method, String logMessage) {
        debug(logger, method, null, logMessage, 0);
    }

    /**
     * Log level error is used to log error conditions together with a unique
     * trace ID , message, error code and error message Format : method="",
     * traceId="",description="", error-code="",error-message=""
     * 
     * @param logger
     *            the logger from the caller class
     * @param method
     *            the method from where log is streamed
     * @param traceId
     *            the request Id for the transaction
     * @param logMessage
     *            the actual log message
     * @param error
     *            the error message
     * @param erroCode
     *            the errorCode
     */
    public static void error(Logger logger, String method, String traceId, String logMessage, String error,
            String errorCode) {

        StringBuilder sb = new StringBuilder();
        sb.append("method=\"").append(method).append("\",");
        sb.append("traceId=\"").append(traceId).append("\",");
        sb.append("description=\"").append(logMessage).append("\",");
        sb.append("error-code=\"").append(errorCode == null ? "" : errorCode).append("\",");
        sb.append("error-message=\"").append(error == null ? "" : error).append("\",");
        logger.error(sb.toString());
    }

    /**
     * Log level error is used to log error conditions together with a unique
     * trace ID , error code and error message, party type, channel and
     * serviceName Format : method="", traceId="",serviceName="",
     * error-code="",error-message="", channel="", partyType = ""
     * 
     * @param logger
     *            the logger from the caller class
     * @param method
     *            the method from where log is streamed
     * @param traceId
     *            the request Id for the transaction
     * @param error
     *            the error message
     * @param erroCode
     *            the errorCode
     * 
     * @param channel
     *            the channel
     * 
     * @param partyType
     *            the partyType
     * @param serviceName
     *            service used to fetch the result
     */
    // CHECKSTYLE:OFF - checkstyle considers this as utility class
    public static void error(Logger logger, String method, String traceId, String error, String errorCode,
            String channel, String partyType, String serviceName,String logMessage) {

        StringBuilder sb = new StringBuilder();
        sb.append("method=\"").append(method).append("\",");
        sb.append("traceId=\"").append(traceId).append("\",");
        sb.append("description=\"").append(logMessage).append("\",");
        sb.append("serviceName =\"").append(serviceName).append("\",");
        sb.append("error-code=\"").append(errorCode == null ? "" : errorCode).append("\",");
        sb.append("error-message=\"").append(error == null ? "" : error).append("\",");
        sb.append("channel=\"").append(channel).append("\",");
        sb.append("partyType=\"").append(partyType).append("\"");
        logger.error(sb.toString());
    }

    /**
     * Log level error is used to log error conditions together with a unique
     * trace ID , error code and error message, party type, channel and
     * serviceName Format : method="", traceId="",serviceName="",
     * error-code="",error-message="", channel="", partyType = ""
     * 
     * @param logger
     *            the logger from the caller class
     * @param method
     *            the method from where log is streamed
     * @param traceId
     *            the request Id for the transaction
     * @param error
     *            the error message
     * @param erroCode
     *            the errorCode
     * 
     * @param channel
     *            the channel
     * 
     * @param partyType
     *            the partyType
     * @param serviceName
     *            service used to fetch the result
     */
    // CHECKSTYLE:OFF - checkstyle considers this as utility class
    public static void error(Logger logger, String method, String traceId, String error, String errorCode,
            String channel, String partyType, String serviceName) {

        StringBuilder sb = new StringBuilder();
        sb.append("method=\"").append(method).append("\",");
        sb.append("traceId=\"").append(traceId).append("\",");
        sb.append("serviceName =\"").append(serviceName).append("\",");
        sb.append("error-code=\"").append(errorCode == null ? "" : errorCode).append("\",");
        sb.append("error-message=\"").append(error == null ? "" : error).append("\",");
        sb.append("channel=\"").append(channel).append("\",");
        sb.append("partyType=\"").append(partyType).append("\"");
        logger.error(sb.toString());
    }

    // CHECKSTYLE:ON
    /**
     * Log level error is used to log error
     * 
     * @param logger
     *            the logger from the caller class
     * @param method
     *            the method from where log is streamed
     * @param traceId
     *            the trace Id for the transaction
     * @param error
     *            the error message
     * 
     * @param channel
     *            the channel
     * 
     */
    public static void error(Logger logger, String method, String traceId, String error, String channel) {

        StringBuilder sb = new StringBuilder();
        sb.append("method=\"").append(method).append("\",");
        sb.append("traceId=\"").append(traceId).append("\",");
        sb.append("error-message=\"").append(error == null ? "" : error).append("\",");
        sb.append("channel=\"").append(channel).append("\",");
        logger.error(sb.toString());
    }

    /**
     * Log level error is used to log error conditions together with a unique
     * request ID , verbose message along with the error code and error message
     * Format : method="", requestID="",description="",
     * error-code="",error-message=""
     * 
     * @param logger
     *            the logger from the caller class
     * @param method
     *            the method from where log is streamed
     * @param logMessage
     *            the actual log message
     * @param error
     *            the error message
     */
    public static void error(Logger logger, String method, String logMessage, String error) {
        error(logger, method, null, logMessage, error, null);
    }

    public static void logErrorMessage(String exception, String traceId, String channel, String partyType)
            throws Exception {
        LogUtil.debug(log, "logErrorMessage", traceId, "Entering: logErrorMessage method in MaintainPartyService");
        if (exception.contains("<ErrorMessage>")) {
            String errorMessage = exception.substring(
                    exception.lastIndexOf("<ErrorMessage>") + "<ErrorMessage>".length(),
                    exception.lastIndexOf("</ErrorMessage>"));
            LogUtil.error(log, "logErrorMessage", traceId, "Request failed at MDM", errorMessage, null);
        } else if (exception.contains("<Detail>")) {
            String errorMessage = exception.substring(exception.lastIndexOf("<Detail>") + "<Detail>".length(),
                    exception.lastIndexOf("</Detail>"));
            LogUtil.error(log, "logErrorMessage", traceId, "Request failed at MDM", errorMessage, null);
        }
        LogUtil.debug(log, "logErrorMessage", traceId, "Exit: logErrorMessage method in MaintainPartyService");

    }
    
    public static String printObjectAsString(Object obj) {
        String json = "";
        ObjectMapper mapper = new ObjectMapper();
        try {
            json = mapper.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            LogUtil.error(log, "printObjectAsString", "JsonProcessingException: ", e.getLocalizedMessage());
        }
        return json;
    }
}