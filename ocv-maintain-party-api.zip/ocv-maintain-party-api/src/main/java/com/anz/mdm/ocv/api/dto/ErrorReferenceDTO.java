package com.anz.mdm.ocv.api.dto;

import com.fasterxml.jackson.core.type.TypeReference;

public class ErrorReferenceDTO extends TypeReference<CapErrorResponseDTO> {

}
