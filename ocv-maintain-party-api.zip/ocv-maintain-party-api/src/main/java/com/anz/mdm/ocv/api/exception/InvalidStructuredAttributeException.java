package com.anz.mdm.ocv.api.exception;

/**
 * Exception will be used when the Unauthorized Exception is thrown from backend
 * 
 * @author surendrn
 *
 */
public class InvalidStructuredAttributeException extends APIException {

    private static final long serialVersionUID = 1L;

    private String statusMessage;

    public InvalidStructuredAttributeException(String statusCode, String statusMessage) {
        super(statusCode);
        this.statusMessage = statusMessage;
    }

    public String getStatusMessage() {
        return statusMessage;
    }
}
