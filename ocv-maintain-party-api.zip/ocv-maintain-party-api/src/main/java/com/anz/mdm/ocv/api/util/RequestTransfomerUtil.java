package com.anz.mdm.ocv.api.util;

import static org.springframework.util.StringUtils.isEmpty;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

import org.apache.commons.text.StringEscapeUtils;
import org.springframework.core.io.ClassPathResource;
import org.springframework.util.FileCopyUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * RequestTransfomerUtil modifies the request template to prepare valid MDM xml
 * 
 * @author Naresh Surakarapu
 *
 */

@Slf4j
public final class RequestTransfomerUtil {

    private RequestTransfomerUtil() {
        super();
    }

    public static String fetchTemplate(String xmlFilePath, String traceId) throws IOException {
        LogUtil.debug(log, "fetchTemplate", traceId, "Entering: fetchTemplate method in RequestTransfomerUtil");
        ClassPathResource classpathResource = new ClassPathResource(xmlFilePath);
        try {
            byte[] bdata = FileCopyUtils.copyToByteArray(classpathResource.getInputStream());
            LogUtil.debug(log, "fetchTemplate", traceId, "Exiting: fetchTemplate method in RequestTransfomerUtil");
            return new String(bdata, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw e;
        }
    }

    public static void modifyTemplate(StringBuilder request, String source, String target, String traceId) {
        LogUtil.debug(log, "modifyTemplate", traceId, "Entering: modifyTemplate method in RequestTransfomerUtil");
        if (!isEmpty(target)) {
            request.replace(request.indexOf(source), request.indexOf(source) + source.length(),
                    StringEscapeUtils.escapeXml11(target));
        } else {
            removeAttributeTagFromTemplate(request, source, traceId);
        }
        LogUtil.debug(log, "modifyTemplate", traceId, "Exiting: modifyTemplate method in RequestTransfomerUtil");
    }

    public static void addNewLineToTemplate(StringBuilder request, String parentTag,
                                            String tagName, String attributeName, Object value) {
        LogUtil.debug(log, "addNewLineToTemplate",
                "Entering: addNewLineToTemplate method in RequestTransfomerUtil");
        int offset = request.indexOf("</" + parentTag + ">");
        if (offset < 0) {
            log.warn("parent tag: {} not found", parentTag);
        }
        StringBuilder newLineBuilder = new StringBuilder();
        newLineBuilder.append("<").append(tagName).append(" ")
                .append("name=\"").append(attributeName).append("\">")
                .append(value).append("</").append(tagName).append(">");
        request.insert(offset, newLineBuilder);
        LogUtil.debug(log, "addNewLineToTemplate",
                "Exiting: addNewLineToTemplate method in RequestTransfomerUtil");
    }

    public static void removeAttributeTagFromTemplate(StringBuilder request, String source, String traceId) {
        LogUtil.debug(log, "removeAttributeTagFromTemplate", traceId,
                "Entering: removeAttributeTagFromTemplate method " + "in RequestTransfomerUtil");
        int j = 0;
        for (int i = request.indexOf(source); i < request.length(); i++) {
            if (request.charAt(i) == '>') {
                j = i + 1;

                break;
            }
        }
        int k = 0;
        for (int i = request.indexOf(source); -1 < i; i--) {
            if (request.charAt(i) == '<') {
                k = i;
                break;
            }
        }
        request.delete(k, j);
        LogUtil.debug(log, "removeAttributeTagFromTemplate", traceId,
                "Exiting: removeAttributeTagFromTemplate method " + "in RequestTransfomerUtil");

    }

    public static void removeObjectFromTemplate(StringBuilder request, String fromString, String toString, int count,
            String traceId) {
        if (count == 0) {
            request.delete(request.indexOf(fromString), request.indexOf(toString) + toString.length());
        }

    }
}
