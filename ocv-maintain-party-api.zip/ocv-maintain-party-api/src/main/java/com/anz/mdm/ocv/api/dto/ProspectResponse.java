package com.anz.mdm.ocv.api.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProspectResponse {
    private String ocvId;
    private String profileId;
    private String capCisId;
}
