package com.anz.mdm.ocv.api.model;

import java.util.Objects;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BatchResult {

    private String encoded_value;

    private String actual_value;

    private String decoded_value;

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        BatchResult that = (BatchResult) o;
        return Objects.equals(decoded_value, that.decoded_value);
    }

    @Override
    public int hashCode() {
        return Objects.hash(decoded_value);
    }
}