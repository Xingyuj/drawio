package com.anz.mdm.ocv.api.exception;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * To handle all bad request
 * 
 * @author Sugandha Rajpal
 *
 */
@Getter
@Setter
public class BadRequestException extends APIException {

    private static final long serialVersionUID = 1L;

    private String statusMessage;

    public BadRequestException(String statusCode, String statusMessage) {
        super(statusCode);
        this.statusMessage = statusMessage;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

}
