package com.anz.mdm.ocv.api.model;

import com.anz.mdm.ocv.api.validator.APIRequest;
import com.anz.mdm.ocv.party.v1.Party;

public class CAPParty {

    private APIRequest<Party> partyApiReq;
    private boolean result;

    public CAPParty(final APIRequest<Party> partyApiReq, final boolean result) {
        this.partyApiReq = partyApiReq;
        this.result = result;
    }

    public APIRequest<Party> getPartyApiReq() {
        return partyApiReq;
    }

    public void setPartyApiReq(APIRequest<Party> partyApiReq) {
        this.partyApiReq = partyApiReq;
    }

    public boolean isResult() {
        return result;
    }

    public void setResult(boolean result) {
        this.result = result;
    }

}
