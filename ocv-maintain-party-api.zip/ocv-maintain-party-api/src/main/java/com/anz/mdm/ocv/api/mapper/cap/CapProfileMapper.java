package com.anz.mdm.ocv.api.mapper.cap;

import com.anz.mdm.ocv.api.dto.CapProfileDTO;
import com.anz.mdm.ocv.cap.v1.CapProfile;

public interface CapProfileMapper {

    CapProfile map(CapProfileDTO capDTO);

}
