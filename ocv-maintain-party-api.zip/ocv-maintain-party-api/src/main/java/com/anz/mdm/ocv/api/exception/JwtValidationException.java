/* included as part of JWT 17031 feature */

package com.anz.mdm.ocv.api.exception;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class JwtValidationException extends APIException {

    private static final long serialVersionUID = 1L;
    private String statusMessage;

    public JwtValidationException(String statusCode, String statusMessage) {
        super(statusCode);
        this.statusMessage = statusMessage;
    }

    public String getStatusMessage() {
        return statusMessage;
    }
}
