package com.anz.mdm.ocv.api.model;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class VaultResponse {

    private List<BatchResult> batch_results = null;
}
