package com.anz.mdm.ocv.api.exception;

/**
 * Exception will be used when the backened service is not available
 * 
 * @author surakarn
 *
 */

public class ServiceUnavailableException extends APIException {
    private static final long serialVersionUID = 1L;

    private String statusMessage;

    public ServiceUnavailableException(String statusCode) {
        super(statusCode);
    }

    public ServiceUnavailableException(String statusCode, String statusMessage) {
        super(statusCode);
        this.statusMessage = statusMessage;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

}
