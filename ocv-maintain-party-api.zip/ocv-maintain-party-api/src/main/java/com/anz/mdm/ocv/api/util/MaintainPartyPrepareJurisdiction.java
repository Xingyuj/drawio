package com.anz.mdm.ocv.api.util;

import java.util.List;

import com.anz.mdm.ocv.api.constants.MDMRequestTemplates;
import com.anz.mdm.ocv.common.v1.JurisdictionDetail;

import lombok.extern.slf4j.Slf4j;

/**
 * Serves as a processor to transform the JSON request to MDM specific request
 * for jurisdiction objects
 * 
 * @author kukatlar
 *
 */

@Slf4j
public class MaintainPartyPrepareJurisdiction {
    private int keyValueCount = 0;

    // changes for jurisdiction key value object
    public void prepareJurisdictionKeyValueObjects(StringBuilder request, List<JurisdictionDetail> jurisdictionDetails,
            String traceId) {
        LogUtil.debug(log, "prepareJurisdictionKeyValueObjects", traceId,
                "Entering: prepareJurisdictionKeyValueObjects method in MaintainPartyPrepareJurisdiction");
        for (JurisdictionDetail jurisdictionDetail : jurisdictionDetails) {

            if (keyValueCount == 0) {
                modifytemplateForJurisdictionKeyValues(request, jurisdictionDetail, traceId);
                keyValueCount++;
            } else {
                createAndModifyTemplateForJurisdictionKeyValues(request, jurisdictionDetail, traceId);
            }
            LogUtil.debug(log, "prepareJurisdictionKeyValueObjects", traceId,
                    "Exit: prepareJurisdictionKeyValueObjects method in MaintainPartyPrepareJurisdiction");
        }

        RequestTransfomerUtil.removeObjectFromTemplate(request, "<KeyValueBObj>", "</KeyValueBObj>", keyValueCount,
                traceId);

        LogUtil.debug(log, "prepareJurisdictionKeyValueObjects", traceId,
                "Exit: prepareJurisdictionKeyValueObjects method in MaintainPartyPrepareJurisdiction");
    }

    public void createAndModifyTemplateForJurisdictionKeyValues(StringBuilder request,
            JurisdictionDetail jurisdictionDetail, String traceId) {
        LogUtil.debug(log, "createAndModifyTemplateForJurisdictionKeyValues", traceId,
                "Entering: createAndModifyTemplateForJurisdictionKeyValues method in MaintainPartyPrepareJurisdiction");
        String keyValueRequest = MDMRequestTemplates.MAINTAIN_PARTY_KEY_VALUE_REQUEST;

        request.insert(request.indexOf("<KeyValueBObj>"), keyValueRequest);
        modifytemplateForJurisdictionKeyValues(request, jurisdictionDetail, traceId);

        LogUtil.debug(log, "createAndModifyTemplateForJurisdictionKeyValues", traceId,
                "Exit: createAndModifyTemplateForJurisdictionKeyValues method in MaintainPartyPrepareJurisdiction");
    }

    public void modifytemplateForJurisdictionKeyValues(StringBuilder request, JurisdictionDetail jurisdictionDetail,
            String traceId) {
        LogUtil.debug(log, "modifytemplateForJurisdictionKeyValues", traceId,
                "Entering: modifytemplateForJurisdictionKeyValues method in MaintainPartyPrepareJurisdiction");
        RequestTransfomerUtil.modifyTemplate(request, "@key@", jurisdictionDetail.getKey(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@value@", "Y", traceId);

        LogUtil.debug(log, "modifytemplateForJurisdictionKeyValues", traceId,
                "Exit: modifytemplateForJurisdictionKeyValues method in MaintainPartyPrepareJurisdiction");
    }

}
