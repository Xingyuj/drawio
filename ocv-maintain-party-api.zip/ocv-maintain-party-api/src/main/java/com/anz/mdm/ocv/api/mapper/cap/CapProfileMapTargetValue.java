package com.anz.mdm.ocv.api.mapper.cap;

import org.mapstruct.factory.Mappers;

import com.anz.mdm.ocv.api.dto.CapProfileDTO;
import com.anz.mdm.ocv.cap.v1.CapProfile;

public class CapProfileMapTargetValue implements CapProfileMapper {

    private CapProfileMapValueSetter mapper = Mappers.getMapper(CapProfileMapValueSetter.class);

    @Override
    public CapProfile map(final CapProfileDTO capDTO) {
        return mapper.map(capDTO);
    }
}
