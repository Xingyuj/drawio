package com.anz.mdm.ocv.api.exception;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class VaultBatchInputException extends APIException {

    private static final long serialVersionUID = 1L;
    private String statusMessage;
    private String statusCode;

    public VaultBatchInputException(String statusCode, String statusMessage) {
        super(statusMessage);
        this.statusCode = statusCode;
        this.statusMessage = statusMessage;
    }
}
