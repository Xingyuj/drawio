package com.anz.mdm.ocv.api.util;

import java.util.List;
import java.util.Map;

import com.anz.mdm.ocv.api.constants.MDMRequestTemplates;
import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.exception.InvalidStructuredAttributeException;
import com.anz.mdm.ocv.api.processor.PartyInternalObjectsProcessor;
import com.anz.mdm.ocv.common.v1.AnzsicDetail;
import com.anz.mdm.ocv.common.v1.AtomicAttributes;
import com.anz.mdm.ocv.common.v1.Identifier;
import com.anz.mdm.ocv.common.v1.PartyMacroRole;
import com.anz.mdm.ocv.common.v1.StructuredAttributes;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class MaintainPartyAdditionalAttributes {
    
   
    
    
    public void prepareAtomicAttributes(StringBuilder request, List<AtomicAttributes> atomicAttributes, 
            String entityName, String objectReferenceId, String traceId) {
        LogUtil.debug(log, "prepareAtomicAttributes", traceId,
                "Entering: prepareAtomicAttributes method in MaintainPartyAdditionalAttributes"); 
        
        for (AtomicAttributes atomicAttribute : atomicAttributes) {
            atomicAttribute.setEntityName(entityName);
            atomicAttribute.setObjectReferenceId(objectReferenceId);
            createAndModifyTemplateForAtomicAttributes(request, atomicAttribute, traceId);
        }
        LogUtil.debug(log, "prepareAtomicAttributes", traceId,
                "Exit: prepareAtomicAttributes method in MaintainPartyAdditionalAttributes");
    }
    
    public void createAndModifyTemplateForAtomicAttributes(StringBuilder request, AtomicAttributes atomicAttribute, 
            String traceId) {
        LogUtil.debug(log, "createAndModifyTemplateForAtomicAttributes", traceId,
                "Entering: createAndModifyTemplateForAtomicAttributes method in MaintainPartyAdditionalAttributes");
        String atomicAttributeRequest = MDMRequestTemplates.MAINTAIN_PARTY_ATOMICATTRIBUTES_REQUEST;
        if (request.toString().contains("<XAttributeAtomicBObj>")) {
            request.insert(request.indexOf("<XAttributeAtomicBObj>"), atomicAttributeRequest);
        } else {
            request.insert(request.indexOf("<TCRMPartyMacroRoleBObj>"), atomicAttributeRequest);
        }
        modifytemplateForAtomicAttributes(request, atomicAttribute, traceId);
        LogUtil.debug(log, "createAndModifyTemplateForAtomicAttributes", traceId,
                "Exit: createAndModifyTemplateForAtomicAttributes method in MaintainPartyAdditionalAttributes");
    }
    
    public void modifytemplateForAtomicAttributes(StringBuilder request, AtomicAttributes atomicAttribute,
            String traceId) {
        LogUtil.debug(log, "modifytemplateForAtomicAttributes", traceId,
                "Entering: modifytemplateForAtomicAttributes method in MaintainPartyAdditionalAttributes");
        RequestTransfomerUtil.modifyTemplate(request, "@ObjectReferenceId@", atomicAttribute.getObjectReferenceId(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@EntityName@", atomicAttribute.getEntityName(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@InstancePK@", null,
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@AttributeNameType@", null,
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@AttributeNameValue@", atomicAttribute.getType(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@AttributeValue@", atomicAttribute.getValue().trim(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@SourceIdentifierValue@", atomicAttribute.getSource(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@StartDate@", atomicAttribute.getStartDate(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@EndDate@", atomicAttribute.getEndDate(),
                traceId);
       
        LogUtil.debug(log, "modifytemplateForAtomicAttributes", traceId,
                "Exit: modifytemplateForAtomicAttributes method in MaintainPartyAdditionalAttributes");
    }
    
    public void prepareStructuredAttributes(StringBuilder request, List<StructuredAttributes> structAttributes, 
            String entityName, String objectReferenceId, String traceId) {
        LogUtil.debug(log, "prepareStructuredAttributes", traceId,
                "Entering: prepareStructuredAttributes method in MaintainPartyAdditionalAttributes");
        for (StructuredAttributes structAttribute : structAttributes) {
            structAttribute.setEntityName(entityName);
            structAttribute.setObjectReferenceId(objectReferenceId);
            createAndModifyTemplateForStructuredAttributes(request, structAttribute, traceId);
        }
        LogUtil.debug(log, "prepareStructuredAttributes", traceId,
                "Exit: prepareStructuredAttributes method in MaintainPartyAdditionalAttributes");
    }
    
    public void createAndModifyTemplateForStructuredAttributes(StringBuilder request, 
            StructuredAttributes structAttibute, String traceId) {
        LogUtil.debug(log, "createAndModifyTemplateForStructuredAttributes", traceId,
                "Entering: createAndModifyTemplateForStructuredAttributes method in MaintainPartyAdditionalAttributes");
        String structAttributeRequest = MDMRequestTemplates.MAINTAIN_PARTY_STRUCTUREDATTRIBUTES_REQUEST;
        if (request.toString().contains("<XAttributeStrucBObj>")) {
            request.insert(request.indexOf("<XAttributeStrucBObj>"), structAttributeRequest);
        } else {
            request.insert(request.indexOf("<TCRMPartyMacroRoleBObj>"), structAttributeRequest);
        }
        modifytemplateForStructuredAttributes(request, structAttibute, traceId);
        LogUtil.debug(log, "createAndModifyTemplateForStructuredAttributes", traceId,
                "Exit: createAndModifyTemplateForStructuredAttributes method in MaintainPartyAdditionalAttributes");
    }
    
    public void modifytemplateForStructuredAttributes(StringBuilder request, 
            StructuredAttributes structAttibute, String traceId) {
        LogUtil.debug(log, "modifytemplateForStructuredAttributes", traceId,
                "Entering: modifytemplateForStructuredAttributes method in MaintainPartyAdditionalAttributes");
        RequestTransfomerUtil.modifyTemplate(request, "@StrucObjectReferenceId@", structAttibute.getObjectReferenceId(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@StrucEntityName@", structAttibute.getEntityName(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@StrucInstancePK@", null,
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@StrucAttributeNameType@", null,
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@StrucAttributeNameValue@", structAttibute.getType(),
                traceId);
        String valueStr = "";
        try {
            Map<String, String> structValueMap = (Map<String, String>) structAttibute.getValue();
            for (Map.Entry<String,String> entry : structValueMap.entrySet()) {
                String val = entry.getValue().trim();
                entry.setValue(val);
            }
            valueStr = new ObjectMapper().writeValueAsString(structValueMap);
        } catch (JsonProcessingException | ClassCastException e) {
            throw new InvalidStructuredAttributeException(
                    OCVConstants.INVALID_STRUCT_ATTR_ERROR, 
                    OCVConstants.INVALID_STRUCT_ATTR);
        }
        valueStr = valueStr.replace("\\\"", "\""); //replace \" with " to keep the source characters in DB
        valueStr = valueStr.replace("\\\\", "\\"); //replace \\ with \ to keep the source characters in DB
        RequestTransfomerUtil.modifyTemplate(request, "@StrucAttributeValue@", valueStr,
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@StrucSourceIdentifierValue@", structAttibute.getSource(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@StrucStartDate@", structAttibute.getStartDate(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@StrucEndDate@", structAttibute.getEndDate(),
                traceId);
        LogUtil.debug(log, "modifytemplateForStructuredAttributes", traceId,
                "Exit: modifytemplateForStructuredAttributes method in MaintainPartyAdditionalAttributes");
    }
    
    public void preparePartyMacroRoles(StringBuilder request, List<PartyMacroRole> partyMacroRoles, 
            String traceId) {
        LogUtil.debug(log, "preparePartyMacroRole", traceId,
                "Entering: preparePartyMacroRole method in MaintainPartyAdditionalAttributes");
        int partyMacroRoleCount = 0;
        for (PartyMacroRole partyMacroRole : partyMacroRoles) {
            if (partyMacroRoleCount == 0) {
                modifytemplateForPartyMacroRole(request, partyMacroRole, traceId);
                partyMacroRoleCount++;
            } else {
                createAndModifyTemplateForPartyMacroRole(request, partyMacroRole, traceId);
            }
            
            // Adding party macro role level atomic attributes to xml
            if (partyMacroRole.getAtomicAttributes().size() > 0) {
                prepareAtomicAttributes(request, 
                        partyMacroRole.getAtomicAttributes(), OCVConstants.ENTITYNAME_MACROROLE, "", traceId);
            }
            
            // Adding party macro role level structured attributes to xml
            if (partyMacroRole.getStructuredAttributes().size() > 0) {
                prepareStructuredAttributes(request, 
                        partyMacroRole.getStructuredAttributes(), OCVConstants.ENTITYNAME_MACROROLE, "", traceId);
            }
        }
        RequestTransfomerUtil.removeObjectFromTemplate(request, "<TCRMPartyMacroRoleBObj>",
                "</TCRMPartyMacroRoleBObj>", partyMacroRoleCount, traceId);
        LogUtil.debug(log, "preparePartyMacroRole", traceId,
                "Exit: preparePartyMacroRole method in MaintainPartyAdditionalAttributes");
    }
    
    public void createAndModifyTemplateForPartyMacroRole(StringBuilder request, PartyMacroRole partyMacroRole, 
            String traceId) {
        LogUtil.debug(log, "createAndModifyTemplateForPartyMacroRole", traceId,
                "Entering: createAndModifyTemplateForPartyMacroRole method in MaintainPartyAdditionalAttributes");
        String partyMacroRoleRequest = MDMRequestTemplates.MAINTAIN_PARTY_PARTYMACROROLE_REQUEST;
        request.insert(request.indexOf("<TCRMPartyMacroRoleBObj>"), partyMacroRoleRequest);
        modifytemplateForPartyMacroRole(request, partyMacroRole, traceId);
        LogUtil.debug(log, "createAndModifyTemplateForPartyMacroRole", traceId,
                "Exit: createAndModifyTemplateForPartyMacroRole method in MaintainPartyAdditionalAttributes");
    }
    
    public void modifytemplateForPartyMacroRole(StringBuilder request, PartyMacroRole partyMacroRole, 
            String traceId) {
        LogUtil.debug(log, "modifytemplateForPartyMacroRole", traceId,
                "Entering: modifytemplateForPartyMacroRole method in MaintainPartyAdditionalAttributes");
        RequestTransfomerUtil.modifyTemplate(request, "@RoleValue@", partyMacroRole.getRoleValue(),
                traceId);
        LogUtil.debug(log, "modifytemplateForPartyMacroRole", traceId,
                "Exit: modifytemplateForPartyMacroRole method in MaintainPartyAdditionalAttributes");
    }
    
    public void prepareAnzsicDetails(StringBuilder request, List<AnzsicDetail> anzsicDetails, 
            String traceId) {
        LogUtil.debug(log, "prepareAnzsicDetails", traceId,
                "Entering: prepareAnzsicDetails method in MaintainPartyAdditionalAttributes");
        int anzsicDetailCount = 0;
        for (AnzsicDetail anzsicDetail : anzsicDetails) {
            if (anzsicDetailCount == 0) {
                modifytemplateForAnzsicDetails(request, anzsicDetail, traceId);
                anzsicDetailCount++;
            } else {
                createAndModifyTemplateForAnzsicDetails(request, anzsicDetail, traceId);
            }
        }
        RequestTransfomerUtil.removeObjectFromTemplate(request, "<XEntityIndustryBObj>",
                "</XEntityIndustryBObj>", anzsicDetailCount, traceId);
        LogUtil.debug(log, "prepareAnzsicDetails", traceId,
                "Exit: prepareAnzsicDetails method in MaintainPartyAdditionalAttributes");
    }
    
    public void createAndModifyTemplateForAnzsicDetails(StringBuilder request, AnzsicDetail anzsicDetail, 
            String traceId) {
        LogUtil.debug(log, "createAndModifyTemplateForAnzsicDetails", traceId,
                "Entering: createAndModifyTemplateForAnzsicDetails method in MaintainPartyAdditionalAttributes");
        String anzsicDetailRequest = MDMRequestTemplates.MAINTAIN_PARTY_XENTITYINDUSTRY_REQUEST;
        request.insert(request.indexOf("<XEntityIndustryBObj>"), anzsicDetailRequest);
        modifytemplateForAnzsicDetails(request, anzsicDetail, traceId);
        LogUtil.debug(log, "createAndModifyTemplateForAnzsicDetails", traceId,
                "Exit: createAndModifyTemplateForAnzsicDetails method in MaintainPartyAdditionalAttributes");
    }
    
    public void modifytemplateForAnzsicDetails(StringBuilder request, AnzsicDetail anzsicDetail, 
            String traceId) {
        LogUtil.debug(log, "modifytemplateForAnzsicDetails", traceId,
                "Entering: modifytemplateForAnzsicDetails method in MaintainPartyAdditionalAttributes");
        RequestTransfomerUtil.modifyTemplate(request, "@XEntityIndustryBObjEntityName@", 
                "CONTACT", traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XEntityIndustryBObjIndustryValue@", 
                anzsicDetail.getCode(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XEntityIndustryBObjSourceIdentifierValue@", 
                anzsicDetail.getSource(), traceId);
        LogUtil.debug(log, "modifytemplateForAnzsicDetails", traceId,
                "Exit: modifytemplateForAnzsicDetails method in MaintainPartyAdditionalAttributes");
    }
    
    public void prepareAdditionalAttributes(StringBuilder request, String entityName, Identifier identifier, 
           String objectReferenceId, String traceId) {
        LogUtil.debug(log, "prepareAdditionalAttributes", traceId,
                "Entering: prepareAdditionalAttributes method in MaintainPartyAdditionalAttributes");
        String objectReference = identifier.getIdentifierUsageType() + "|" + identifier.getIdentifier();
        if (identifier.getAtomicAttributes().size() > 0) { 
            prepareAtomicAttributes(request, 
                   identifier.getAtomicAttributes(), entityName, objectReference, traceId);
        }
        if (identifier.getStructuredAttributes().size() > 0) { 
            prepareStructuredAttributes(request, 
                   identifier.getStructuredAttributes(), entityName, objectReference, traceId);
        }
        
        prepareIdentifierValidationAndVerification(request, identifier, objectReferenceId, traceId);
        
        LogUtil.debug(log, "prepareAdditionalAttributes", traceId,
                "Exit: prepareAdditionalAttributes method in MaintainPartyAdditionalAttributes");
    }

    private void prepareIdentifierValidationAndVerification(StringBuilder request, Identifier identifier,
            String objectReferenceId, String traceId) {
        LogUtil.debug(log, "prepareIdentifierValidationAndVerification", traceId,
                "Entering: prepareIdentifierValidationAndVerification method in MaintainPartyAdditionalAttributes");
        if (identifier.getValidationDetails().size() > 0) { 
            PartyInternalObjectsProcessor  partyInternalObjectsProcessor = new PartyInternalObjectsProcessor();
            partyInternalObjectsProcessor.prepareValidationDetails(request, identifier.getValidationDetails(),
                    identifier.getIdentifierUsageType(), objectReferenceId,
                    OCVConstants.OCV_ENTITYNAME_INDENTIFIER, traceId);
        }
        
        if (identifier.getVerificationDetails().size() > 0) { 
            PartyInternalObjectsProcessor  partyInternalObjectsProcessor = new PartyInternalObjectsProcessor();
            partyInternalObjectsProcessor.prepareVerificationDetails(request, identifier.getVerificationDetails(),
                    identifier.getIdentifierUsageType(), objectReferenceId,
                    OCVConstants.OCV_ENTITYNAME_INDENTIFIER, traceId);
        }
        LogUtil.debug(log, "prepareIdentifierValidationAndVerification", traceId,
                "Exit: prepareIdentifierValidationAndVerification method in MaintainPartyAdditionalAttributes");
    }
}
