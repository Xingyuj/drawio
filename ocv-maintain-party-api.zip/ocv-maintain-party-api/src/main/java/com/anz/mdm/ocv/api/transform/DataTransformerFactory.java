package com.anz.mdm.ocv.api.transform;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.xml.XMLConstants;
import javax.xml.transform.Templates;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.stream.StreamSource;

import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;

import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.exception.APIException;
import com.anz.mdm.ocv.api.util.LogUtil;

import lombok.extern.slf4j.Slf4j;

import net.sf.saxon.TransformerFactoryImpl;

/**
 * Factory class for Datatransfomer
 * 
 * @author palanisk
 *
 */
@Slf4j
public final class DataTransformerFactory {

    private static Map<Context, Templates> templatesMap = new HashMap<Context, Templates>();

    private static Map<Context, String> contextXSLRegistry = new HashMap<Context, String>();

    private static DataTransformerFactory factorySingletonInstance;

    private static TransformerFactoryImpl transformerFactory;
    private static ResourceLoader resourceLoader;

    static {
        contextXSLRegistry.put(Context.PARTYAPI, OCVConstants.MDM_XSL_FILE_MAINTAINPARTY);
        contextXSLRegistry.put(Context.DELETEPARTYAPI, OCVConstants.MDM_XSL_FILE_DELETEPARTY);
        resourceLoader = new DefaultResourceLoader();
        transformerFactory = new TransformerFactoryImpl();
        try {
            loadStyleSheet(Context.PARTYAPI);
            loadStyleSheet(Context.DELETEPARTYAPI);
        } catch (TransformerConfigurationException | IOException e) {
            LogUtil.error(log, "DataTransformerFactory", "Error loading transfomer ", e.getMessage());
        }
    }

    private DataTransformerFactory() {
    }

    /**
     * This method returns an instance of the factory
     */
    public static DataTransformerFactory getInstance() {
        if (null == factorySingletonInstance) {
            synchronized (DataTransformerFactory.class) {
                if (null == factorySingletonInstance) {
                    factorySingletonInstance = new DataTransformerFactory();
                }
            }
        }
        return factorySingletonInstance;
    }

    /**
     * Returns an instance of the transformer class based on the context
     * information. Uses lazy initialization
     * 
     * @param context
     *            Context to be used
     * @return instance of Transformer
     * @throws TransformerConfigurationException
     *             Configuration error
     * @throws IOException
     *             Exception when class path resource is not found
     */
    public Transformer getTransformer(Context context, String traceId)
            throws TransformerConfigurationException, IOException {
        if (templatesMap.get(context) == null) {
            LogUtil.error(log, traceId, "getTransformer", "FAILURE: No Transformer found ");
            throw new APIException("Failure performing XSL Transform. No Transfomer could be loaded");
        }
        return templatesMap.get(context).newTransformer();
    }

    private static void loadStyleSheet(Context context) throws TransformerConfigurationException, IOException {
        Long startTime = System.currentTimeMillis();
        transformerFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
        Resource xsltResource = resourceLoader.getResource(contextXSLRegistry.get(context));
        StreamSource stylesource = new StreamSource(xsltResource.getInputStream());
        Templates cachedXSLT = transformerFactory.newTemplates(stylesource);
        templatesMap.put(context, cachedXSLT);
        LogUtil.debug(log, "loadTransformer", null, "Exit : loadTransformer", (System.currentTimeMillis() - startTime));
    }

    public StreamSource getResources(Context context, String traceId) throws IOException {
        Resource xsltResource = resourceLoader.getResource(contextXSLRegistry.get(context));
        StreamSource stylesource = new StreamSource(xsltResource.getInputStream());
        return stylesource;
    }

}
