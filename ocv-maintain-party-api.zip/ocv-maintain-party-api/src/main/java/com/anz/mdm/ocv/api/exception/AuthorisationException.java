package com.anz.mdm.ocv.api.exception;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * @author Sugandha Rajpal
 *
 */
@Getter
@Setter
public class AuthorisationException extends APIException {

    private static final long serialVersionUID = 1L;

    public AuthorisationException(String statusCode) {
        super(statusCode);
    }
}
