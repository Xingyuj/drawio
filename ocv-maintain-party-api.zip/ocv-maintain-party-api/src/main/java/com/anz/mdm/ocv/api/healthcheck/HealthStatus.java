package com.anz.mdm.ocv.api.healthcheck;
/*
 * This class will act like pojo class for health check.
 * @author Deepika Handa
 */
public class HealthStatus {
    private String status;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}