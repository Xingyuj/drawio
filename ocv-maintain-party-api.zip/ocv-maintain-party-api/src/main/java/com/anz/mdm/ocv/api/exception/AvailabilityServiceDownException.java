package com.anz.mdm.ocv.api.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@AllArgsConstructor
public class AvailabilityServiceDownException extends Exception {

    private static final long serialVersionUID = 7673088688643507216L;
    
    private String message;
    private String errorCode;

    /**
     * Instantiates a new party create service unavailable exception.
     *
     * @param message
     *            the message
     */
    public AvailabilityServiceDownException(String message) {
        super(message);
    }
}
