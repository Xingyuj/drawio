package com.anz.mdm.ocv.api.util;

import java.io.IOException;

import java.util.Base64;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.exception.UnauthorizedException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;


/**
 * @author kopparar
 *
 */
public class JWTScopeExtractUtil {

    private String jwtSub = null;
    private String base64EncodedBody = null;

    public JWTScope getJWTExtractDetails(String jwtToken)
            throws JsonParseException, JsonMappingException, IOException, JSONException {

        String[] splitJwtString = jwtToken.split("\\.");
        try {
            base64EncodedBody = splitJwtString[1];
        } catch (ArrayIndexOutOfBoundsException e) {
            throw new UnauthorizedException(OCVConstants.INVALID_JWT_TOKEN_ERROR_CODE, OCVConstants.INVALID_JWT_TOKEN);

        }
        byte[] decodedBytes = Base64.getUrlDecoder().decode(base64EncodedBody);
        String decodedUrl = new String(decodedBytes, "UTF-8");
        JSONObject jObj = new JSONObject(decodedUrl);
        JSONArray extractedScopeFromJwtToken = null;
        if (decodedUrl.contains("scopes") && decodedUrl.contains("scope")) {
            extractedScopeFromJwtToken = (JSONArray) jObj.get("scopes");
        } else {
            extractedScopeFromJwtToken = (JSONArray) jObj.get("scope");
        }

        jwtSub = (String) jObj.get("sub");
        // subject detail from JWT is empty
        if (null == jwtSub) {
            jwtSub = "empty";
        }

        return new JWTScope(extractedScopeFromJwtToken, jwtSub);
    }

}