package com.anz.mdm.ocv.api.exception;

import lombok.Getter;
import lombok.Setter;

/**
 * Handles ServerException
 * 
 * @author Deepika Handa
 *
 */
@Getter
@Setter
public class ServerException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public ServerException(Throwable e) {
        super(e);
    }

    public ServerException(String message) {
        super(message);
    }
}
