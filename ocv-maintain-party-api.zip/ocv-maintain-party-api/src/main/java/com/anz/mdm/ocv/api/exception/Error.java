package com.anz.mdm.ocv.api.exception;

import lombok.Getter;
import lombok.Setter;

/**
 * Error class includes all error parameters
 * 
 * @author geraa
 *
 */
@Getter
@Setter
public class Error {
    private String statusCode;
    private String statusMessage;
    private String moreInformation;
    private String location;
}
