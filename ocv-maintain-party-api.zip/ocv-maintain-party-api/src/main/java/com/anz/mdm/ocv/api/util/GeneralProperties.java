package com.anz.mdm.ocv.api.util;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Setter;

/**
 *
 * @author Ravi Batra
 *
 *         This class would load properties needed by other components.
 *         Properties would be defined in config file(s) e.g. application.yml
 *
 */

@Component
@ConfigurationProperties("app")
@Setter
public class GeneralProperties {

    private Map<String, String> statusMessages = new ConcurrentHashMap<>();

    public String getStatusMessage(final String statusCode) {
        return statusMessages.get(statusCode);
    }
}
