package com.anz.mdm.ocv.api.interceptor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.anz.mdm.ocv.api.UAMAccessConfiguration;
import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.util.JWTScope;
import com.anz.mdm.ocv.api.util.LogUtil;
import com.anz.mdm.ocv.api.validator.APIRequest;
import com.anz.mdm.ocv.api.validator.ValidationResult;
import com.anz.mdm.ocv.party.v1.Party;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class UAMInterceptor {

    @Autowired
    private UAMAccessConfiguration uamAccessConfiguration;
  
    public UAMInterceptor(UAMAccessConfiguration uamAccessConfiguration) {
        super();
        this.uamAccessConfiguration = uamAccessConfiguration;
    }

    public void validateJWTTokenScope(APIRequest<Party> apiRequest, ValidationResult validationResult) {
        LogUtil.debug(log, "validateJWTTokenScope", 
                apiRequest.getTraceId(), "Enter: UAMIntercepter.validateJWTTokenScope");
        JWTScope jwtScope = apiRequest.getJwtScope();
        Map<?, ?> accessList = uamAccessConfiguration.getAccessMap("UAM");
        String[] validScopes = accessList.get("VALID_OCV_SCOPES_MAINTAIN_PARTY_API").toString().split("\\|");
        List<String> validScopeList = Arrays.asList(validScopes);
        List<String> scopeListToPass = getScopeListToPass(jwtScope.getScopes(), validScopeList,
                apiRequest.getTraceId());
        if (scopeListToPass.size() == 0) {
            validationResult.setErrorCode(OCVConstants.INVALID_OCV_SCOPE_ERROR_CODE);
        }
        
        LogUtil.debug(log, "validateJWTTokenScope", 
                apiRequest.getTraceId(), "Exit: UAMIntercepter.validateJWTTokenScope");
    }

    private List<String> getScopeListToPass(String[] extractedScopeFromJwtToken,
            List<String> validScopeList, String traceId) {
        LogUtil.debug(log, "getScopeListToPass", traceId, "Enter");
        ArrayList<String> scopeListToPass = new ArrayList<String>();
        for (int i = 0; i < extractedScopeFromJwtToken.length; i++) {
            if (extractedScopeFromJwtToken[i].indexOf(".") != -1 && null != validScopeList
                    && validScopeList.contains(extractedScopeFromJwtToken[i])) {
                String[] scopeElemArray = extractedScopeFromJwtToken[i].split("\\.");
                scopeListToPass.addAll(Arrays.asList(scopeElemArray[3]));
            } else {
                LogUtil.debug(log, "getScopeListToPass", traceId, OCVConstants.INVALID_OCV_JWT_SCOPE);
            } // end of if condition for index check of . to skip the scopes
        }
        return scopeListToPass;
    }
}
