package com.anz.mdm.ocv.api.exception;

import lombok.Getter;
import lombok.Setter;

/**
 * Error class includes all error parameters
 * 
 * @author geraa
 *
 */
@Getter
@Setter
public class ErrorCap {
    private String code;
    private String type;
    private String message;
    private String description;
    private String severity;
    private String location;
}
