package com.anz.mdm.ocv.api.validator;

import static org.springframework.util.StringUtils.isEmpty;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;

import org.json.JSONException;

import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.exception.UnauthorizedException;
import com.anz.mdm.ocv.api.util.JWTScope;
import com.anz.mdm.ocv.api.util.JWTScopeExtractUtil;

/**
 * Wrapper Object to encapsulate API requests. Contains three objects of the API
 * requests viz HTTP Headers, URI and payload (for PUT and POST). The body is
 * generic to aid in API specific validations.
 * 
 * @author Amit Gera
 *
 * @param <T>
 *            Entity either body or return type
 */
public class APIRequest<T> {

    // Headers
    private String acceptHeader = null;
    private String jwtToken = null;
    private String traceId = null;
    private String channel = null;
    private String requestTime = null;
    private String userId = null;
    private String requestMode = null;
    private JWTScope jwtScope = null;
    private String application = null;
    private String idempotentKey = null;
    private String idempotentFirstSent = null;
    private JWTScopeExtractUtil jwtUtils = new JWTScopeExtractUtil();

    // Query Parameters
    private Map<String, String> queryParameters = new HashMap<String, String>();

    // Message body (only for PUT and POST)
    private T requestBody = null;

    public APIRequest(Map<String, String> headers, Map<String, String> queryParameters, T requestBody) {

        Map<String, String> lowerCaseMap = new HashMap<String, String>();

        Iterator<Entry<String, String>> keys = headers.entrySet().iterator();

        while (keys.hasNext()) {
            Entry<String, String> entry = keys.next();
            lowerCaseMap.put(entry.getKey().toLowerCase(Locale.ENGLISH), entry.getValue());
        }

        // headers
        this.acceptHeader = lowerCaseMap.get(OCVConstants.ACCEPT_HEADER);

        this.traceId = lowerCaseMap.get(OCVConstants.TRACE_ID_HEADER);

        this.jwtToken = lowerCaseMap.get(OCVConstants.AUTHORIZATION_HEADER);

        this.channel = lowerCaseMap.get(OCVConstants.CHANNEL);

        this.requestTime = lowerCaseMap.get(OCVConstants.REQUEST_TIMESTAMP);

        this.queryParameters = queryParameters;

        this.userId = lowerCaseMap.get(OCVConstants.USER_ID_HEADER);

        this.requestMode = lowerCaseMap.get(OCVConstants.REQUEST_MODE_HEADER);
        this.application = lowerCaseMap.get(OCVConstants.APPLICATION);
        
        this.idempotentFirstSent = lowerCaseMap.get(OCVConstants.IDEMPOTENCY_FIRST_SENT);
        this.idempotentKey = lowerCaseMap.get(OCVConstants.IDEMPOTENCY_KEY);
        // the body (for PUT and POST) requests
        this.requestBody = requestBody;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public boolean areMandatoryHeadersPresent() {
        return !(isEmpty(getAcceptHeader()) || isEmpty(getTraceId()) || isEmpty(getJwtToken())
                || isEmpty(getChannel()));
    }

    public String checkMandatoryHeaders() {
        if (isEmpty(getAcceptHeader())) {
            return OCVConstants.MISSING_ACCEPT_HEADER;
        } else if (isEmpty(getTraceId())) {
            return OCVConstants.MISSING_TRACE_ID;
        } else if (isEmpty(getJwtToken())) {
            return OCVConstants.MISSING_JWT_TOKEN;
        } else if (isEmpty(getChannel())) {
            return OCVConstants.MISSING_CHANNEL;
        }
        return null;
    }

    public String getQueryParameter(String paramName) {
        return this.queryParameters.get(paramName);
    }

    public String getFields() {
        return getQueryParameter(OCVConstants.FIELDS_PARAMETER);
    }

    public String getOffset() {
        return getQueryParameter(OCVConstants.OFFSET_PARAMETER);
    }

    public String getLimit() {
        return getQueryParameter(OCVConstants.LIMIT_PARAMETER);
    }

    public String getAcceptHeader() {
        return this.acceptHeader;
    }

    public String getJwtToken() {
        return this.jwtToken;
    }

    public String getTraceId() {
        return this.traceId;
    }

    public Map<String, String> getQueryParameters() {
        return queryParameters;
    }

    public T getRequestBody() {
        return this.requestBody;
    }
    
    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getChannel() {
        return this.channel;
    }

    public String getRequestTimestamp() {
        return this.requestTime;
    }

    public String getUserId() {
        return userId;
    }

    public String getRequestMode() {
        return requestMode;
    }
    
    public String getIdempotentKey() {
        return idempotentKey;
    }

    public String getIdempotentFirstSent() {
        return idempotentFirstSent;
    }


    public String getApplication() {
        return this.application;
    }
    
    public Map<String, String> getHeaders() {

        Map<String, String> headers = new HashMap<String, String>();
        headers.put(OCVConstants.ACCEPT_HEADER, getAcceptHeader());
        headers.put(OCVConstants.TRACE_ID_HEADER, getTraceId());
        headers.put(OCVConstants.AUTHORIZATION_HEADER, getJwtToken());
        headers.put(OCVConstants.CHANNEL, getChannel());
        headers.put(OCVConstants.REQUEST_TIMESTAMP, getRequestTimestamp());
        headers.put(OCVConstants.USER_ID_HEADER, getUserId());
        headers.put(OCVConstants.REQUEST_MODE_HEADER, getRequestMode());
        headers.put(OCVConstants.APPLICATION, getApplication());
        headers.put(OCVConstants.IDEMPOTENCY_KEY, getIdempotentKey());
        headers.put(OCVConstants.IDEMPOTENCY_FIRST_SENT, getIdempotentFirstSent());
        return headers;

    }

    public JWTScope getJwtScope() {
        if (jwtScope == null) {
            try {
                jwtScope = jwtUtils.getJWTExtractDetails(jwtToken);
            } catch (JSONException | IOException e) {
                throw new UnauthorizedException(OCVConstants.INVALID_JWT_TOKEN_ERROR_CODE,
                        OCVConstants.INVALID_JWT_TOKEN);
            }
        }
        return jwtScope;
    }
}
