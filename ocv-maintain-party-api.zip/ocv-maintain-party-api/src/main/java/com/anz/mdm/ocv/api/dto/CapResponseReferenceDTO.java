package com.anz.mdm.ocv.api.dto;

import com.anz.mdm.ocv.cap.v1.CapResponse;
import com.fasterxml.jackson.core.type.TypeReference;

public class CapResponseReferenceDTO extends TypeReference<CapResponse> {

}
