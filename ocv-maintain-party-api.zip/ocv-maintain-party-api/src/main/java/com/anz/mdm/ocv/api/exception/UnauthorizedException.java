package com.anz.mdm.ocv.api.exception;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * To handle all bad request
 * 
 * @author kopparar
 *
 */
@Getter
@Setter
public class UnauthorizedException extends APIException {

    private static final long serialVersionUID = 1L;
    private String statusMessage;

    public UnauthorizedException(String statusCode, String statusMessage) {
        super(statusCode);
        this.statusMessage = statusMessage;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

}