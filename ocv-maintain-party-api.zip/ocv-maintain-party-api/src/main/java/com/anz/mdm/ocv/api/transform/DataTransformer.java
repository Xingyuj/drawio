package com.anz.mdm.ocv.api.transform;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Component;

import com.anz.mdm.ocv.api.exception.ServerException;
import com.anz.mdm.ocv.api.util.LogUtil;
import com.anz.mdm.ocv.api.util.StringEscaper;

import lombok.extern.slf4j.Slf4j;

/**
 * Serves as transformer to convert xmlResponse from MDM to JSON using xslt.
 * 
 * @author Deepika Handa
 */
@Slf4j
@Component
public class DataTransformer {

    public DataTransformer(TransformerFactory transformerFactory) {
        super();
    }

    public String transformData(HttpEntity<String> response, Transformer transformer, String traceId, Context context)
            throws TransformerConfigurationException, IOException {
        LogUtil.debug(log, "transformXmlResponseToJson using transformer", traceId, "Entering transformData");
        String jsonResponse = "";
        Long startTime = System.currentTimeMillis();
        LogUtil.debug(log, "transformData", traceId, "Transforming xml data to Json");
        try {
            jsonResponse = transformToJson(response, transformer, traceId);
        } catch (TransformerFactoryConfigurationError | TransformerException e) {
            LogUtil.error(log, "transformData", traceId, "Exception occured while transforming XML", null);
            throw new ServerException(e);
        }
        LogUtil.debug(log, "transformXmlResponseToJson using transformer", traceId, "Exit transformData",
                (System.currentTimeMillis() - startTime));
        return jsonResponse;
    }

    public String transformToJson(HttpEntity<String> response, Transformer transformer, String traceId)
            throws TransformerException {
        LogUtil.debug(log, "transformToJson", traceId, "Entering transformDataRetry");
        String jsonResponse = "";
        String responseXml = null;
        if (null != response) {
            responseXml = response.getBody();
            if (null != responseXml) {
                responseXml = StringEscaper.escapeXMLForJSON(responseXml);
                StreamSource xmlsource = new StreamSource(new StringReader(responseXml));
                StringWriter outWriter = new StringWriter();
                StreamResult result = new StreamResult(outWriter);
                // Transform the document and store it in a file
                transformer.transform(xmlsource, result);
                StringBuffer sb = outWriter.getBuffer();
                jsonResponse = sb.toString();
            }
        }
        return jsonResponse;
    }

}
