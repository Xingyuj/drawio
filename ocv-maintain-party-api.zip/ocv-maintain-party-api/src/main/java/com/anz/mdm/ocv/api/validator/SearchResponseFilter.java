package com.anz.mdm.ocv.api.validator;


import java.util.List;
import java.util.stream.Collectors;


import org.springframework.stereotype.Component;

import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.util.LogUtil;
import com.anz.mdm.ocv.party.v1.Party;

import lombok.extern.slf4j.Slf4j;

/**
 * This class will filter response from retrieve party api and elastic search
 * 
 * 
 * @author Deepika Handa
 */
@Slf4j
@Component
public class SearchResponseFilter {

    public List<Party> filterOrgRecordsNotClg(List<Party> parties,String traceId) {
        LogUtil.debug(log, "filterOrgRecords", traceId, "Entering filterOrgRecords");
        return parties.stream().filter(party -> OCVConstants.NON_INDIVIDUAL_PARTY_TYPE.equals(party.getPartyType())
                && !"CG".equals(party.getOrganisationType())).collect(Collectors.toList());

    }

    public List<Party> filterRecordsBasedOnPartyType(List<Party> parties, String partyType, String traceId) {
        LogUtil.debug(log, "filterRecordsBasedOnPartyType", traceId, "Entering filterRecordsBasedOnPartyType");
        return (List<Party>) parties.stream().filter(party -> partyType.equals(party.getPartyType()))
                .collect(Collectors.toList());

    }

    public List<Party> filterRecordsBasedOnOrgType(String orgType, List<Party> parties,String traceId) {
        LogUtil.debug(log, "filterRecordsBasedOnOrgType", traceId, "Entering filterRecordsBasedOnOrgType");
        return parties.stream().filter(party -> OCVConstants.NON_INDIVIDUAL_PARTY_TYPE.equals(party.getPartyType())
                && orgType.equals(party.getOrganisationType())).collect(Collectors.toList());

    }
 

}
