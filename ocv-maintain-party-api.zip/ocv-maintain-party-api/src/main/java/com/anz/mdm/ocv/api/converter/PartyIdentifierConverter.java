package com.anz.mdm.ocv.api.converter;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.dto.APIResponse;
import com.anz.mdm.ocv.api.util.LogUtil;
import com.ibm.mdm.schema.TCRMPartyIdentificationBObjType;

import lombok.extern.slf4j.Slf4j;

/**
 * PartyIdentifierConverter class transforms the identifier details like ABN,
 * ACN, passport from MDM TCRMService object to Party object
 */

@Slf4j
@Component(value = "partyIdentifierConverter")
public class PartyIdentifierConverter {

    public void convertIdentifierDetails(APIResponse apiResponse, List<TCRMPartyIdentificationBObjType> identifiersList,
                                         String traceId) {
        Long startTime = System.currentTimeMillis();
        LogUtil.debug(log, "convertIdentifierDetails", traceId, "starting identifier details transformation ",
                startTime);
        TCRMPartyIdentificationBObjType ocvIdIndentifier = identifiersList.stream()
                .filter(iden -> OCVConstants.OCV_ID_IDENTIFIER_TYPE.equalsIgnoreCase(iden.getIdentificationValue())
                        && (null == iden.getEndDate() || iden.getEndDate().isEmpty()))
                .findAny().orElse(null);

        List<TCRMPartyIdentificationBObjType> profileIdListIndentifier =
                (List<TCRMPartyIdentificationBObjType>) identifiersList.stream()
                .filter(iden -> OCVConstants.OCV_PROFILE_ID_TYPE.equalsIgnoreCase(iden.getIdentificationValue())
                        && (null == iden.getEndDate() || iden.getEndDate().isEmpty())).collect(Collectors.toList());

        Long endTime = System.currentTimeMillis();
        LogUtil.debug(log, "convertIdentifierDetails", traceId, "finishing identifier details transformation ",
                endTime - startTime);
        if (null != ocvIdIndentifier) {
            apiResponse.setOcvId(ocvIdIndentifier.getIdentificationNumber());
        }

        if (profileIdListIndentifier != null && profileIdListIndentifier.size() > 0) {
            List<String> profileIdList = new ArrayList<String>();
            for (TCRMPartyIdentificationBObjType profileId : profileIdListIndentifier) {
                profileIdList.add(profileId.getIdentificationNumber());
            }
            apiResponse.setProfileIds(profileIdList);
        }
    }
}
