package com.anz.mdm.ocv.api.constants;

/**
 * MDMRequestTemplates class includes pre defined xml format for all children
 * objects of a party
 * 
 */

public final class MDMRequestTemplates {

    private MDMRequestTemplates() {

    }

    public static final String MDM_MAINTAIN_PARTY_REQUEST_XML_ORG = "templates/maintainParty_NonIndividual_Full.xml";
    public static final String MDM_MAINTAIN_PARTY_REQUEST_XML_PERSON = "templates/maintainParty_Individual_Full.xml";
    public static final String SEARCH_PARTY_ORGANISATION_XML = "templates/MDMSearchOrgReqXML.xml";
    public static final String MDM_SEARCH_INDIVIDUAL_PARTY_REQUEST_XML = "templates/MDMSearchPartyIndividual.xml";
    public static final String MDM_DELETE_PARTY_REQUEST_XML = "templates/deleteParty_Full.xml";
    public static final String FORMAT_SPACE = "                    ";
    public static final String MAINTAIN_PARTY_PREFERENCE_REQUEST = "<TCRMPartyPrivPrefBObj>\r\n" + FORMAT_SPACE
            + "<PrivPrefEntity>@PrivPrefEntity@</PrivPrefEntity>\r\n" + FORMAT_SPACE
            + "<PrivPrefReasonValue>@PrivPrefReasonValue@</PrivPrefReasonValue>\r\n" + FORMAT_SPACE
            + " <SourceIdentValue>@PartyPrivPrefSourceIdentValue@</SourceIdentValue>\r\n" + FORMAT_SPACE
            + "<ValueString>@ValueString@</ValueString>\r\n" + FORMAT_SPACE
            + "<StartDate>@PartyPrivPrefStartDate@</StartDate>\r\n" + FORMAT_SPACE
            + "<EndDate>@PartyPrivPrefEndDate@</EndDate>\r\n" + FORMAT_SPACE
            + "<PrivPrefValue>@PrivPrefValue@</PrivPrefValue>\r\n" + "                 </TCRMPartyPrivPrefBObj>";

    public static final String MAINTAIN_PARTY_IDENTIFIER_REQUEST = "<TCRMPartyIdentificationBObj>\r\n" + FORMAT_SPACE
            + "<ObjectReferenceId>@IdentifierObjectReferenceId@</ObjectReferenceId>\r\n" + FORMAT_SPACE
            + "<IdentificationValue>@IdentificationValue@</IdentificationValue>\r\n" + FORMAT_SPACE
            + "<IdentificationNumber>@IdentificationNumber@</IdentificationNumber>\r\n" + FORMAT_SPACE
            + "<IdentificationStatusValue>@IdentificationStatusValue@" + "</IdentificationStatusValue>\r\n"
            + FORMAT_SPACE + "<IdentificationExpiryDate>@IdentificationExpiryDate@</IdentificationExpiryDate>"
            + FORMAT_SPACE + "<StartDate>@PartyIdentificatioStartDate@</StartDate>\r\n" + FORMAT_SPACE
            + "<EndDate>@PartyIdentificatioEndDate@</EndDate>\r\n" + FORMAT_SPACE
            + "<IdentificationIssueLocation>@IdentificationIssueLocation@" + "</IdentificationIssueLocation>\r\n"
            + FORMAT_SPACE + "<SourceIdentifierValue>@PartyIdentificatioSourceIdentifierValue@"
            + "</SourceIdentifierValue>\r\n" + FORMAT_SPACE + "<TCRMExtension>\r\n" + FORMAT_SPACE
            + "    <ExtendedObject>XPartyIdentificationBObjExt</ExtendedObject>\r\n" + FORMAT_SPACE
            + "    <XPartyIdentificationBObjExt>\r\n" + FORMAT_SPACE
            + "        <XOccurenceNum>@XPartyIdentificationXOccurenceNum@" + "</XOccurenceNum>\r\n" + FORMAT_SPACE
            + "        <XCountryValue>@XCountryValue@" + "</XCountryValue>\r\n" + FORMAT_SPACE
            + "        <XProvStateValue>@XProvStateValue@" + "</XProvStateValue>\r\n" + FORMAT_SPACE
            + "    </XPartyIdentificationBObjExt>\r\n" + FORMAT_SPACE + " </TCRMExtension>\r\n" + "                   "
            + "</TCRMPartyIdentificationBObj>";

    public static final String MAINTAIN_PARTY_CHILD_IDENTIFIER_REQUEST = "<TCRMPartyIdentificationBObj>\r\n"
            + FORMAT_SPACE
            + "<ObjectReferenceId>@IdentifierObjectReferenceId@</ObjectReferenceId>\r\n" + FORMAT_SPACE
            + "<IdentificationValue>@IdentificationValue@</IdentificationValue>\r\n" + FORMAT_SPACE
            + "<IdentificationNumber>@IdentificationNumber@</IdentificationNumber>\r\n" + FORMAT_SPACE
            + FORMAT_SPACE + "<SourceIdentifierValue>@PartyIdentificatioSourceIdentifierValue@"
            + "</SourceIdentifierValue>\r\n" + FORMAT_SPACE + "<TCRMExtension>\r\n" + FORMAT_SPACE
            + "    <ExtendedObject>XPartyIdentificationBObjExt</ExtendedObject>\r\n" + FORMAT_SPACE
            + "    <XPartyIdentificationBObjExt>\r\n" + FORMAT_SPACE
            + "        <XCountryValue>@XCountryValue@" + "</XCountryValue>\r\n" + FORMAT_SPACE
            + "        <XProvStateValue>@XProvStateValue@" + "</XProvStateValue>\r\n" + FORMAT_SPACE
            + "    </XPartyIdentificationBObjExt>\r\n" + FORMAT_SPACE + " </TCRMExtension>\r\n" + "                   "
            + "</TCRMPartyIdentificationBObj>";

    public static final String MAINTAIN_PARTY_RELATED_IDENTIFIER_REQUEST = "<XIdentifierRelationshipBObj>\r\n"
            + "<RelTpCdValue>@RelTpCdValue@</RelTpCdValue>\r\n" + FORMAT_SPACE
            + "<ToIdentifierId>@ToIdentifierId@</ToIdentifierId>\r\n" + FORMAT_SPACE
            + "<FromIdentifierId>@FromIdentifierId@" + "</FromIdentifierId>\r\n" + FORMAT_SPACE
            + "<FromIdentifierValue>@FromIdentifierValue@" + "</FromIdentifierValue>\r\n" + FORMAT_SPACE
            + "<ToIdentifierValue>@ToIdentifierValue@" + "</ToIdentifierValue>\r\n" + FORMAT_SPACE
            + "</XIdentifierRelationshipBObj>";
    
    public static final String MAINTAIN_PARTY_DOCUMENT_REFERENCE_REQUEST = "<ContentReferenceBObj>\r\n" + FORMAT_SPACE
            + "<ContentRefPart1>@ContentRefPart1@</ContentRefPart1>\r\n" + FORMAT_SPACE
            + "<ContentRefPart2>@ContentRefPart2@</ContentRefPart2>\r\n" + FORMAT_SPACE
            + "<ContentRefPart3>@ContentRefPart3@" + "</ContentRefPart3>\r\n" + FORMAT_SPACE 
            + "<ContentRefPart4>@ContentRefPart4@</ContentRefPart4>\r\n" + FORMAT_SPACE 
            + "<ContentVersion>@ContentVersion@</ContentVersion>\r\n" + FORMAT_SPACE
            + "<StartDate>@DocRefStartDate@" + "</StartDate>\r\n" + FORMAT_SPACE 
            + "<EndDate>@DocRefEndDate@</EndDate>\r\n" + FORMAT_SPACE
            + "<RepositoryName>@RepositoryName@</RepositoryName>\r\n" + FORMAT_SPACE
            + "<DocumentName>@DocumentName@" + "</DocumentName>\r\n" + FORMAT_SPACE 
            + "<Author>@Author@</Author>\r\n" 
            + "                 </ContentReferenceBObj>";
    
    public static final String MAINTAIN_PARTY_EV_MATCH_STATUS_REQUEST = "<XEVMatchStatusBObj>\r\n" + FORMAT_SPACE
            + "<ObjectReferenceId>@KycIdentifierObjectReferenceId@</ObjectReferenceId>\r\n" + FORMAT_SPACE
            + "<DataSourceName>@DataSourceName@</DataSourceName>\r\n" + FORMAT_SPACE
            + "<MatchStatus>@MatchStatus@</MatchStatus>\r\n" 
            + "                 </XEVMatchStatusBObj>\r\n" + FORMAT_SPACE;

    public static final String MAINTAIN_PARTY_KYC_VERIFICATION_DOC_REQUEST =
            "<XKycVerificationDocBObj>\r\n" + FORMAT_SPACE
            + "<ObjectReferenceId>@KycIdentifierObjectReferenceId@</ObjectReferenceId>\r\n" + FORMAT_SPACE
            + " </XKycVerificationDocBObj>\r\n" + FORMAT_SPACE;
    
    public static final String MAINTAIN_PARTY_KYC_VERIFICATION_REQUEST = "<XKycVerificationBObj>\r\n" + FORMAT_SPACE
            + "<ObjectReferenceId>@KycIdentifierObjectReferenceId@</ObjectReferenceId>\r\n" + FORMAT_SPACE
            + "<VerificationDt>@VerificationDt@</VerificationDt>\r\n" + FORMAT_SPACE
            + "<VerificationMethValue>@VerificationMethValue@</VerificationMethValue>\r\n"
            + FORMAT_SPACE + "<VerificationStValue>@VerificationStValue@</VerificationStValue>\r\n" + FORMAT_SPACE
            + "<KycVerLvlValue>@KycVerLvlValue@</KycVerLvlValue>\r\n" + FORMAT_SPACE
            + "<KycStatusValue>@KycStatusValue@</KycStatusValue>\r\n" + FORMAT_SPACE
            + "<EvServiceProvider>@EvServiceProvider@</EvServiceProvider>\r\n" + FORMAT_SPACE
            + "<EvConsentProvided>@EvConsentProvided@</EvConsentProvided>\r\n" + FORMAT_SPACE
            + "<EvConsentDt>@EvConsentDt@</EvConsentDt>\r\n" + FORMAT_SPACE
            + "<EvResponseId>@EvResponseId@</EvResponseId>\r\n" + FORMAT_SPACE
            + "<EvOverallMatchStatus>@EvOverallMatchStatus@</EvOverallMatchStatus>\r\n" + FORMAT_SPACE
            + "<EvSubmittedDt>@EvSubmittedDt@</EvSubmittedDt>\r\n" + FORMAT_SPACE
            + "<EvSubmittedBy>@EvSubmittedBy@</EvSubmittedBy>\r\n" + FORMAT_SPACE
            + "<EvServiceReqSt>@EvServiceReqSt@</EvServiceReqSt>\r\n" + FORMAT_SPACE
            + "<SourceIdentifierValue>@KycSourceIdentifierValue@</SourceIdentifierValue>\r\n" + FORMAT_SPACE
            + "<StartDt>@KycStartDate@</StartDt>\r\n" + FORMAT_SPACE
            + "<EndDt>@KycEndDate@</EndDt>\r\n"
            + "</XKycVerificationBObj>\r\n" + FORMAT_SPACE;

    public static final String MAINTAIN_PARTY_IDEV_REQUEST = "<XEIDVerificationBObj>\r\n" + FORMAT_SPACE
            + "<ObjectReferenceId>@KycIdentifierObjectReferenceId@</ObjectReferenceId>\r\n" + FORMAT_SPACE
            + "<VerificationDt>@VerificationDt@</VerificationDt>\r\n" + FORMAT_SPACE
            + "<VerificationMethodValue>@VerificationMethodValue@</VerificationMethodValue>\r\n" + FORMAT_SPACE
            + "<VerificationStatusValue>@VerificationStatusValue@</VerificationStatusValue>\r\n" + FORMAT_SPACE
            + "<ServiceProvider>@ServiceProvider@</ServiceProvider>\r\n" + FORMAT_SPACE
            + "<ResponseId>@ResponseId@</ResponseId>\r\n" + FORMAT_SPACE
            + "<SubmittedDt>@SubmittedDt@</SubmittedDt>\r\n" + FORMAT_SPACE
            + "<SubmittedBy>@SubmittedBy@</SubmittedBy>\r\n" + FORMAT_SPACE
            + "<ServiceRequestStatus>@ServiceRequestStatus@</ServiceRequestStatus>\r\n" + FORMAT_SPACE
            + "<SourceIdentifierValue>@SourceIdentifierValue@</SourceIdentifierValue>\r\n" + FORMAT_SPACE
            + "<StartDate>@StartDate@</StartDate>\r\n" + FORMAT_SPACE
            + "<EndDate>@EndDate@</EndDate>\r\n" + FORMAT_SPACE
            + "</XEIDVerificationBObj>\r\n" + FORMAT_SPACE;

    public static final String MAINTAIN_PARTY_SELFI_REQUEST = "<XIDEntityVerificationBObj>\r\n" + FORMAT_SPACE
            + "<ObjectReferenceId>@KycIdentifierObjectReferenceId@</ObjectReferenceId>\r\n" + FORMAT_SPACE
            + "<VerificationDt>@VerificationDt@</VerificationDt>\r\n" + FORMAT_SPACE
            + "<VerificationMethodValue>@VerificationMethodValue@</VerificationMethodValue>\r\n" + FORMAT_SPACE
            + "<VerificationStatusValue>@VerificationStatusValue@</VerificationStatusValue>\r\n" + FORMAT_SPACE
            + "<ServiceProvider>@ServiceProvider@</ServiceProvider>\r\n" + FORMAT_SPACE
            + "<ResponseId>@ResponseId@</ResponseId>\r\n" + FORMAT_SPACE
            + "<SubmittedDt>@SubmittedDt@</SubmittedDt>\r\n" + FORMAT_SPACE
            + "<SubmittedBy>@SubmittedBy@</SubmittedBy>\r\n" + FORMAT_SPACE
            + "<SourceIdentifierValue>@SourceIdentifierValue@</SourceIdentifierValue>\r\n" + FORMAT_SPACE
            + "<PdfFileName>@PdfFileName@</PdfFileName>\r\n" + FORMAT_SPACE
            + "<ImageFileName>@ImageFileName@</ImageFileName>\r\n" + FORMAT_SPACE
            + "<ExpiryDt>@ExpiryDt@</ExpiryDt>\r\n" + FORMAT_SPACE
            + "<Comments>@Comments@</Comments>\r\n" + FORMAT_SPACE
            + "<StartDate>@StartDate@</StartDate>\r\n" + FORMAT_SPACE
            + "<EndDate>@EndDate@</EndDate>\r\n" + FORMAT_SPACE
            + "</XIDEntityVerificationBObj>\r\n" + FORMAT_SPACE;

    public static final String MAINTAIN_PARTY_MV_REQUEST = "<XMIDVerificationBObj>\r\n" + FORMAT_SPACE
            + "<ObjectReferenceId>@KycIdentifierObjectReferenceId@</ObjectReferenceId>\r\n" + FORMAT_SPACE
            + "<VerificationDt>@VerificationDt@</VerificationDt>\r\n" + FORMAT_SPACE
            + "<VerificationMethodValue>@VerificationMethodValue@</VerificationMethodValue>\r\n" + FORMAT_SPACE
            + "<VerificationStatusValue>@VerificationStatusValue@</VerificationStatusValue>\r\n" + FORMAT_SPACE
            + "<ServiceProvider>@ServiceProvider@</ServiceProvider>\r\n" + FORMAT_SPACE
            + "<SubmittedDt>@SubmittedDt@</SubmittedDt>\r\n" + FORMAT_SPACE
            + "<SubmittedBy>@SubmittedBy@</SubmittedBy>\r\n" + FORMAT_SPACE
            + "<SourceIdentifierValue>@SourceIdentifierValue@</SourceIdentifierValue>\r\n" + FORMAT_SPACE
            + "<Comments>@Comments@</Comments>\r\n" + FORMAT_SPACE
            + "<StartDate>@StartDate@</StartDate>\r\n" + FORMAT_SPACE
            + "<EndDate>@EndDate@</EndDate>\r\n" + FORMAT_SPACE
            + "</XMIDVerificationBObj>\r\n" + FORMAT_SPACE;

    
    public static final String MAINTAIN_PARTY_CONSENT_REQUEST = "<ConsentBObj>\r\n" + FORMAT_SPACE
            + "<ObjectReferenceId>@ConsentObjectReferenceId@</ObjectReferenceId>\r\n" + FORMAT_SPACE
            + "<AgreeInd>@AgreeInd@</AgreeInd>\r\n" + FORMAT_SPACE 
            + "<LanguageAgreedInValue>@LanguageAgreedInValue@</LanguageAgreedInValue>\r\n" + FORMAT_SPACE
            + "<EnforcementType>@EnforcementType@</EnforcementType>\r\n" + FORMAT_SPACE
            + "<CreateDate>@ConsentCreateDate@</CreateDate>\r\n" + FORMAT_SPACE
            + "<StartDate>@ConsentStartDate@</StartDate>\r\n" + FORMAT_SPACE
            + "<EndDate>@ConsentEndDate@</EndDate>\r\n" + FORMAT_SPACE
            + "<SourceIdentValue>@ConsentSourceIdentValue@</SourceIdentValue>\r\n" + FORMAT_SPACE
            + "<EndReasonValue>@EndReasonValue@</EndReasonValue>\r\n" + FORMAT_SPACE
            + "<ProfileSystemValue>@ProfileSystemValue@</ProfileSystemValue>\r\n" + FORMAT_SPACE
            + "<ProcessingPurposeBObj>\r\n" + FORMAT_SPACE
            + "        <ObjectReferenceId>@ProcessingPurposeObjectReferenceId@" + "</ObjectReferenceId>\r\n" 
            + FORMAT_SPACE + "        <ProcPurpValue>@ProcPurpValue@" + "</ProcPurpValue>\r\n" 
            + FORMAT_SPACE + "        <ProcPurpVersion>@ProcPurpVersion@" + "</ProcPurpVersion>\r\n" 
            + FORMAT_SPACE + "        <StartDate>@ProcessingPurposeStartDate@" + "</StartDate>\r\n" 
            + FORMAT_SPACE + "        <EndDate>@ProcessingPurposeEndDate@</EndDate>\r\n" 
            + FORMAT_SPACE + "</ProcessingPurposeBObj>\r\n"
            + "                 </ConsentBObj>\n";
    
    /**
     * XContact_Status is extension objects of ContactMethod to include status
     * flag
     */
    public static final String XCONTACT_STATUS = "<TCRMExtension><ExtendedObject>XContactMethodBObjExt"
            + "</ExtendedObject>\r\n" + " <XContactMethodBObjExt>\r\n" + FORMAT_SPACE
            + "  <XContactMethodStatusValue>@ContactMethodStatus@</XContactMethodStatusValue>\r\n" + FORMAT_SPACE
            + "  <XContactName>@ContactMethodContactName@</XContactName>\r\n" + FORMAT_SPACE
            + "  <XContactTitle>@ContactMethodContactTitle@</XContactTitle>\r\n" + FORMAT_SPACE
            + "  <XPreferredContactInd>@ContactMethodPrefInd@</XPreferredContactInd>\r\n" + FORMAT_SPACE
            + "</XContactMethodBObjExt>\r\n" + FORMAT_SPACE + "</TCRMExtension>\r\n";

    /**
     * XContact_PHONE is Phone objects of ContactMethod to include status
     * flag
     */
    public static final String XCONTACT_PHONE = "<@TCRMPhoneNumberBObjStartTag@>\r\n" + FORMAT_SPACE
            + "        <PhoneCountryCode>@ContactMethodPhoneCountryCode@</PhoneCountryCode>\r\n" + FORMAT_SPACE
            + "        <PhoneNumber>@ContactMethodPhoneNumber@</PhoneNumber>\r\n" + FORMAT_SPACE
            + "    </@TCRMPhoneNumberBObjEndTag@>\r\n";

    
    public static final String MAINTAIN_PARTY_CONTACTMETHOD_REQUEST;
    
    static {
        MAINTAIN_PARTY_CONTACTMETHOD_REQUEST = "<TCRMPartyContactMethodBObj>\r\n" + FORMAT_SPACE
                + "<ObjectReferenceId>@ContactValidationVerificationObjectReferenceId@</ObjectReferenceId>\r\n"
                + FORMAT_SPACE
                + "<ContactMethodUsageValue>@ContactMethodUsageValue@</ContactMethodUsageValue>\r\n" 
                + FORMAT_SPACE
                + "<PreferredContactMethodIndicator>@PreferredContactMethodIndicator@"
                + "</PreferredContactMethodIndicator>\r\n"
                + FORMAT_SPACE + "<StartDate>@PartyContactMethodStartDate@</StartDate>\r\n" + FORMAT_SPACE
                + "<EndDate>@PartyContactMethodEndDate@</EndDate>\r\n" + FORMAT_SPACE
                + "<SourceIdentifierValue>@PartyContactMethodSourceIdentifierValue@</SourceIdentifierValue>\r\n"
                + FORMAT_SPACE + "<TCRMExtension>\r\n" + FORMAT_SPACE
                + "    <ExtendedObject>XPartyContactMethodGroupBObjExt</ExtendedObject>\r\n" + FORMAT_SPACE
                + "    <XPartyContactMethodGroupBObjExt>\r\n" + FORMAT_SPACE
                + "        <XOccurenceNum>@PartyContactMethodXOccurenceNum@</XOccurenceNum>\r\n" + FORMAT_SPACE
                + "    </XPartyContactMethodGroupBObjExt>\r\n" + FORMAT_SPACE + "</TCRMExtension>\r\n" + FORMAT_SPACE
                + "  <TCRMContactMethodBObj>\r\n" + FORMAT_SPACE
                + "    <ReferenceNumber>@ContactMethodReferenceNumber@</ReferenceNumber>\r\n" + FORMAT_SPACE
                + "    <ContactMethodValue>@ContactMethodValue@</ContactMethodValue>\r\n" 
                + FORMAT_SPACE + XCONTACT_PHONE
                + FORMAT_SPACE + XCONTACT_STATUS                                
                + "</TCRMContactMethodBObj>\r\n" + "</TCRMPartyContactMethodBObj>";
    }
    

    public static final String ADDR_LINE_4_5_6 = "<XAddressLineFour>@XAddressLineFour@</XAddressLineFour>\r\n"
            + FORMAT_SPACE + "            <XAddressLineFive>@XAddressLineFive@</XAddressLineFive>\r\n" + FORMAT_SPACE
            + "            <XAddressLineSix>@XAddressLineSix@</XAddressLineSix>\r\n" + FORMAT_SPACE;

    public static final String ADDR_STREET = "<LatitudeDegrees>@LatitudeDegrees@</LatitudeDegrees>\r\n" + FORMAT_SPACE
            + "<LongitudeDegrees>@LongitudeDegrees@</LongitudeDegrees>\r\n" + FORMAT_SPACE
            + "<BuildingName>@BuildingName@</BuildingName>\r\n" + FORMAT_SPACE
            + "<PreDirectional>@PreDirectional@</PreDirectional>\r\n" + FORMAT_SPACE
            + "<StreetNumber>@StreetNumber@</StreetNumber>\r\n" + FORMAT_SPACE
            + "<StreetPrefix>@StreetPrefix@</StreetPrefix>\r\n" + FORMAT_SPACE
            + "<StreetName>@StreetName@</StreetName>\r\n" + FORMAT_SPACE
            + "<StreetSuffix>@StreetSuffix@</StreetSuffix>\r\n" + FORMAT_SPACE
            + "<PostDirectional>@PostDirectional@</PostDirectional>\r\n" + FORMAT_SPACE
            + "<StnInfo>@StnInfo@</StnInfo>\r\n" + FORMAT_SPACE + "<StnId>@StnId@</StnId>\r\n" + FORMAT_SPACE
            + "<BoxDesignator>@BoxDesignator@</BoxDesignator>\r\n" + FORMAT_SPACE + "<BoxId>@BoxId@</BoxId>\r\n";

    public static final String MAINTAIN_PARTY_ADDR_REQ_1 = "<TCRMPartyAddressBObj>\r\n"
            + "<ObjectReferenceId>@AddressValidationObjRefId@</ObjectReferenceId>\r\n" + FORMAT_SPACE
            + "<AddressUsageValue>@AddressUsageValue@</AddressUsageValue>\r\n" + FORMAT_SPACE
            + "<StartDate>@PartyAddressStartDate@</StartDate>\r\n" + FORMAT_SPACE
            + "<EndDate>@PartyAddressEndDate@</EndDate>\r\n" + FORMAT_SPACE
            + "<SourceIdentifierValue>@PartyAddressSourceIdentifierValuee@</SourceIdentifierValue>\r\n" + FORMAT_SPACE;

    public static final String ADDR_REQUEST_2 = FORMAT_SPACE + "<TCRMAddressBObj>\r\n" + FORMAT_SPACE
            + "<ObjectReferenceId>@AddressValidationObjectReferenceId@</ObjectReferenceId>\r\n" + FORMAT_SPACE
            + " <ResidenceValue>@ResidenceValue@</ResidenceValue>\r\n" + FORMAT_SPACE
            + "    <AddressLineOne>@AddressLineOne@</AddressLineOne>\r\n" + FORMAT_SPACE
            + "    <AddressLineTwo>@AddressLineTwo@</AddressLineTwo>\r\n" + FORMAT_SPACE
            + "    <AddressLineThree>@AddressLineThree@</AddressLineThree>\r\n" + FORMAT_SPACE
            + "    <City>@City@</City>\r\n" + FORMAT_SPACE + "    <ZipPostalCode>@ZipPostalCode@</ZipPostalCode>\r\n"
            + FORMAT_SPACE + "    <ZipPostalBarCode>@ZipPostalBarCode@</ZipPostalBarCode>\r\n" + FORMAT_SPACE
            + "    <ResidenceNumber>@ResidenceNumber@</ResidenceNumber>\r\n" + FORMAT_SPACE
            + "    <ProvinceStateValue>@ProvinceStateValue@</ProvinceStateValue>\r\n" + FORMAT_SPACE
            + "    <CountyCode>@CountyCode@</CountyCode>\r\n" + FORMAT_SPACE
            + "    <CountryValue>@CountryValue@</CountryValue>\r\n" + FORMAT_SPACE + ADDR_STREET
            + "    <Region>@Region@</Region>\r\n" + FORMAT_SPACE
            + "    <DelDesignator>@DelDesignator@</DelDesignator>\r\n" + FORMAT_SPACE + "    <DelId>@DelId@</DelId>\r\n"
            + FORMAT_SPACE + "    <DelInfo>@DelInfo@</DelInfo>\r\n";

    public static final String ADDR_REQUEST_3 = "    <TCRMExtension>\r\n" + FORMAT_SPACE
            + "        <ExtendedObject>XAddressBObjExt</ExtendedObject>\r\n" + FORMAT_SPACE
            + "        <XAddressBObjExt>\r\n" + "            <XCountryName>@XCountryName@</XCountryName>\r\n"
            + FORMAT_SPACE + ADDR_LINE_4_5_6 + "            <XLevelType>@XLevelType@</XLevelType>\r\n"
            + FORMAT_SPACE + "            <XLevelNum>@XLevelNum@</XLevelNum>\r\n"
            + FORMAT_SPACE + "        </XAddressBObjExt>\r\n" + "    </TCRMExtension>\r\n"
            + FORMAT_SPACE + "  </TCRMAddressBObj>\r\n" + "                 </TCRMPartyAddressBObj>";

    public static final String MAINTAIN_PARTY_CONTEQUIV_REQUEST = "<TCRMAdminContEquivBObj>\r\n" + FORMAT_SPACE
            + "<AdminPartyId>@AdminPartyId@</AdminPartyId>\r\n" + FORMAT_SPACE
            + "<AdminSystemValue>@AdminSystemValue@</AdminSystemValue>\r\n"
            + "                 </TCRMAdminContEquivBObj>";

    public static final String MAINTAIN_PARTY_ORGNAME_REQUEST = "<TCRMOrganizationNameBObj>\r\n" + FORMAT_SPACE
            + "<OrganizationName>@OrganizationName@</OrganizationName>\r\n" + FORMAT_SPACE
            + "<StartDate>@OrgNameStartDate@</StartDate>\r\n" + FORMAT_SPACE + "<EndDate>@OrgNameEndDate@</EndDate>\r\n"
            + FORMAT_SPACE + "<NameUsageValue>@OrgNameUsageValue@</NameUsageValue>\r\n" + FORMAT_SPACE
            + "<SourceIdentifierValue>@OrgNameSourceIdentifierValue@</SourceIdentifierValue>\r\n"
            + "                 </TCRMOrganizationNameBObj>";

    public static final String MAINTAIN_PARTY_PERSONNAME_REQUEST = "<TCRMPersonNameBObj>\r\n" + FORMAT_SPACE
            + "<NameUsageValue>@NameUsageValue@</NameUsageValue>\r\n" + FORMAT_SPACE
            + "<PrefixDescription>@PrefixDescription@</PrefixDescription>\r\n" + FORMAT_SPACE
            + "<GivenNameOne>@GivenNameOne@</GivenNameOne>\r\n" + FORMAT_SPACE
            + "<GivenNameTwo>@GivenNameTwo@</GivenNameTwo>\r\n" + FORMAT_SPACE + "<LastName>@LastName@</LastName>\r\n"
            + FORMAT_SPACE + "<Suffix>@Suffix@</Suffix>\r\n" + FORMAT_SPACE
            + "<StartDate>@PersonNameStartDate@</StartDate>\r\n" + FORMAT_SPACE
            + "<EndDate>@PersonNameEndDate@</EndDate>\r\n" + FORMAT_SPACE
            + "<SourceIdentifierValue>@PersonNameSourceIdentifierValue@</SourceIdentifierValue>\r\n"
            + "                 </TCRMPersonNameBObj>";
    public static final String SUCCESS_RESULT_CODE = "<ResultCode>SUCCESS</ResultCode>";

    public static final String WARNING_COMP_CODE = "<ComponentID>110024</ComponentID>";
    public static final String WARNING_WRAPPER_BOBJ = "<PartyWrapperBObj";
    public static final String WARNING_MESSAGE = "<ErrorMessage>The data submitted already exists on the database; "
            + "no update applied.</ErrorMessage>";

    public static final String MAINTAIN_PARTY_COMMERCIALCONTACTS_REQUEST = "<CommercialContact:CommercialContact>  \n"
            + FORMAT_SPACE + "<CommercialContact:Name>@CommercialContactName@</CommercialContact:Name>\r\n"
            + FORMAT_SPACE + "<CommercialContact:Title>@CommercialContactTitle@</CommercialContact:Title>\n"
            + FORMAT_SPACE + "<CommercialContact:Phone>@CommercialContactPhone@</CommercialContact:Phone>\n"
            + FORMAT_SPACE + "<CommercialContact:Fax>@CommercialContactFax@</CommercialContact:Fax>\n" + FORMAT_SPACE
            + "<CommercialContact:Mobile>@CommercialContactMobile@</CommercialContact:Mobile>\n" + FORMAT_SPACE
            + "<CommercialContact:PreferredIndicator>@CommercialContactPreferredIndicator@"
            + "</CommercialContact:PreferredIndicator>\n" + FORMAT_SPACE
            + "<CommercialContact:Occurrence>@CommercialContactOccurrence@</CommercialContact:Occurrence>\n"
            + FORMAT_SPACE + "</CommercialContact:CommercialContact>";

    public static final String MAINTAIN_PARTY_KEY_VALUE_REQUEST = "\n" + FORMAT_SPACE + "<KeyValueBObj>\n"
            + FORMAT_SPACE + "<Key>@key@</Key>\n" + FORMAT_SPACE + "<Value>@value@</Value>\n" + FORMAT_SPACE
            + "</KeyValueBObj>\n";
    public static final String MAINTAIN_PARTY_ATOMICATTRIBUTES_REQUEST = "<XAttributeAtomicBObj>\r\n" + FORMAT_SPACE
            + "<ObjectReferenceId>@ObjectReferenceId@</ObjectReferenceId>\r\n" + FORMAT_SPACE
            + "<EntityName>@EntityName@</EntityName>\r\n" + FORMAT_SPACE
            + "<InstancePK>@InstancePK@</InstancePK>\r\n" + FORMAT_SPACE
            + "<AttributeNameType>@AttributeNameType@</AttributeNameType>\r\n" + FORMAT_SPACE
            + "<AttributeNameValue>@AttributeNameValue@</AttributeNameValue>\r\n" + FORMAT_SPACE
            + "<AttributeValue>@AttributeValue@</AttributeValue>\r\n" + FORMAT_SPACE 
            + "<SourceIdentifierValue>@SourceIdentifierValue@</SourceIdentifierValue>\r\n" + FORMAT_SPACE 
            + "<StartDate>@StartDate@</StartDate>\r\n" + FORMAT_SPACE 
            + "<EndDate>@EndDate@</EndDate>\r\n" + FORMAT_SPACE 
            + "                 </XAttributeAtomicBObj>";
    
    public static final String MAINTAIN_PARTY_STRUCTUREDATTRIBUTES_REQUEST = "<XAttributeStrucBObj>\r\n" + FORMAT_SPACE
            + "<ObjectReferenceId>@StrucObjectReferenceId@</ObjectReferenceId>\r\n" + FORMAT_SPACE
            + "<EntityName>@StrucEntityName@</EntityName>\r\n" + FORMAT_SPACE
            + "<InstancePK>@StrucInstancePK@</InstancePK>\r\n" + FORMAT_SPACE
            + "<AttributeNameType>@StrucAttributeNameType@</AttributeNameType>\r\n" + FORMAT_SPACE
            + "<AttributeNameValue>@StrucAttributeNameValue@</AttributeNameValue>\r\n" + FORMAT_SPACE
            + "<AttributeValue>@StrucAttributeValue@</AttributeValue>\r\n" + FORMAT_SPACE 
            + "<SourceIdentifierValue>@StrucSourceIdentifierValue@</SourceIdentifierValue>\r\n" + FORMAT_SPACE 
            + "<StartDate>@StrucStartDate@</StartDate>\r\n" + FORMAT_SPACE 
            + "<EndDate>@StrucEndDate@</EndDate>\r\n" + FORMAT_SPACE 
            + "                 </XAttributeStrucBObj>";
    
    public static final String MAINTAIN_PARTY_PARTYMACROROLE_REQUEST = "<TCRMPartyMacroRoleBObj>\r\n" + FORMAT_SPACE
            + "<RoleValue>@RoleValue@</RoleValue>\r\n" + FORMAT_SPACE
            + "                 </TCRMPartyMacroRoleBObj>";
    
    public static final String MAINTAIN_PARTY_XENTITYINDUSTRY_REQUEST = "<XEntityIndustryBObj>\r\n" + FORMAT_SPACE
            + "<EntityName>@XEntityIndustryBObjEntityName@</EntityName>\r\n" + FORMAT_SPACE
            + "<IndustryValue>@XEntityIndustryBObjIndustryValue@</IndustryValue>\r\n" + FORMAT_SPACE
            + "<SourceIdentifierValue>@XEntityIndustryBObjSourceIdentifierValue@</SourceIdentifierValue>\r\n" 
            + FORMAT_SPACE + "                 </XEntityIndustryBObj>";
    
    public static final String MAINTAIN_PARTY_XATTRVALIDATION_DETAILS_REQUEST = "<XAttrValidationBObj>\r\n"
            + FORMAT_SPACE
            + "<ObjectReferenceId>@ValidationObjectReferenceId@</ObjectReferenceId>\r\n" + FORMAT_SPACE
            + "<EntityName>@XAttrValidationBObjEntityName@</EntityName>\r\n" + FORMAT_SPACE
            + "<XAttrNameValue>@XAttrValidationBObjXAttrNameValue@</XAttrNameValue>\r\n" + FORMAT_SPACE
            + "<XAttrStatus>@XAttrValidationBObjXAttrStatus@</XAttrStatus>\r\n" + FORMAT_SPACE
            + "<StatusReason>@XAttrValidationBObjStatusReason@</StatusReason>\r\n" + FORMAT_SPACE
            + "<ValidatedBy>@XAttrValidationBObjValidatedBy@</ValidatedBy>\r\n" + FORMAT_SPACE
            + "<ValidatedDt>@XAttrValidationBObjValidatedDt@</ValidatedDt>\r\n" + FORMAT_SPACE
            + "<ValidationMethod>@XAttrValidationBObjValidationMethod@</ValidationMethod>\r\n" + FORMAT_SPACE
            + "<Channel>@XAttrValidationBObjChannel@</Channel>\r\n" + FORMAT_SPACE
            + "<ReValTimeDesignator>@XAttrValidationBObjReValTimeDesignator@</ReValTimeDesignator>\r\n" + FORMAT_SPACE
            + "<ReValTimeInterval>@XAttrValidationBObjReValTimeInterval@</ReValTimeInterval>\r\n" + FORMAT_SPACE
            + "<ReValDt>@XAttrValidationBObjReValDt@</ReValDt>\r\n" + FORMAT_SPACE
            + "<StartDate>@XAttrValidationBObjStartDate@</StartDate>\r\n" + FORMAT_SPACE
            + "<EndDate>@XAttrValidationBObjEndDate@</EndDate>\r\n"
            + FORMAT_SPACE + "                 </XAttrValidationBObj>";
    
    public static final String MAINTAIN_PARTY_XATTRVERIFICATION_REQUEST = "<XAttrVerificationBObj>\r\n" + FORMAT_SPACE
            + "<ObjectReferenceId>@VerificationObjectReferenceId@</ObjectReferenceId>"
            + "<EntityName>@XAttrVerificationBObjEntityName@</EntityName>\r\n" + FORMAT_SPACE
            + "<XAttrNameValue>@XAttrVerificationBObjXAttrNameValue@</XAttrNameValue>\r\n" + FORMAT_SPACE
            + "<VerifiedBy>@XAttrVerificationBObjVerifiedBy@</VerifiedBy>\r\n" + FORMAT_SPACE
            + "<VerifiedDt>@XAttrVerificationBObjVerifiedDt@</VerifiedDt>\r\n" + FORMAT_SPACE
            + "<VerificationMethod>@XAttrVerificationBObjVerificationMethod@</VerificationMethod>\r\n" + FORMAT_SPACE
            + "<DocRef>@XAttrVerificationBObjDocRef@</DocRef>\r\n" + FORMAT_SPACE
            + "<Channel>@XAttrVerificationBObjChannel@</Channel>\r\n" + FORMAT_SPACE
            + "<ReVerTimeDesignator>@XAttrVerificationBObjReVerTimeDesignator@</ReVerTimeDesignator>\r\n" + FORMAT_SPACE
            + "<ReVerTimeInterval>@XAttrVerificationBObjReVerTimeInterval@</ReVerTimeInterval>\r\n" + FORMAT_SPACE
            + "<ReVerDt>@XAttrVerificationBObjReVerDt@</ReVerDt>\r\n" + FORMAT_SPACE
            + "<StartDate>@XAttrVerificationBObjStartDate@</StartDate>\r\n" + FORMAT_SPACE
            + "<EndDate>@XAttrVerificationBObjEndDate@</EndDate>\r\n"
            + FORMAT_SPACE + "                 </XAttrVerificationBObj>";
    
    public static final String MAINTAIN_PARTY_XNO_TIN_REASON_REQUEST = "<XNoTinReasonBObj>\r\n" + FORMAT_SPACE
            + "<ObjectReferenceId>@XNoTinReasonObjectReferenceId@</ObjectReferenceId>\r\n" + FORMAT_SPACE
            + "<NoTinReasonValue>@NoTinReasonValue@</NoTinReasonValue>\r\n" + FORMAT_SPACE
            + "<NoTinReasonCatValue>@NoTinReasonCatValue@</NoTinReasonCatValue>\r\n" + FORMAT_SPACE
            + "<OperatorConfirmedReason>@NoTinReasonOperatorConfirmedReason@</OperatorConfirmedReason>\r\n"
            + FORMAT_SPACE + "<Reason>@NoTinReason@</Reason>\r\n" + FORMAT_SPACE
            + "<StartDate>@NoTinReasonStartDate@</StartDate>\r\n" + FORMAT_SPACE
            + "<EndDate>@NoTinReasonEndDate@</EndDate>\r\n" + FORMAT_SPACE
            + "<SourceIdentifierValue>@NoTinReasonSourceIdentifierValue@</SourceIdentifierValue>\r\n"  
            + FORMAT_SPACE + "                 </XNoTinReasonBObj>";
    
    public static final String MAINTAIN_PARTY_XCONT_TAX_COUNTRY_REQUEST = "<XContTaxCountryBObj>\r\n" + FORMAT_SPACE
            + "<ObjectReferenceId>@TaxCountryObjectReferenceId@</ObjectReferenceId>\r\n" + FORMAT_SPACE
            + "<CountryValue>@TaxCountryValue@</CountryValue>\r\n" + FORMAT_SPACE
            + "<ResidentFromDt>@TaxCountryResidentFromDt@</ResidentFromDt>\r\n" + FORMAT_SPACE
            + "<ResidentToDt>@TaxCountryResidentToDt@</ResidentToDt>\r\n" + FORMAT_SPACE
            + "<StartDate>@TaxCountryStartDate@</StartDate>\r\n" + FORMAT_SPACE
            + "<EndDate>@TaxCountryEndDate@</EndDate>\r\n" + FORMAT_SPACE
            + "<SourceIdentifierValue>@TaxCountrySourceIdentifierValue@</SourceIdentifierValue>\r\n" + FORMAT_SPACE
            + "<XNoTinReasonBObj>\r\n" + FORMAT_SPACE
            + "<ObjectReferenceId>@XNoTinReasonObjectReferenceId@</ObjectReferenceId>\r\n" + FORMAT_SPACE
            + "<NoTinReasonValue>@NoTinReasonValue@</NoTinReasonValue>\r\n" + FORMAT_SPACE 
            + "<NoTinReasonCatValue>@NoTinReasonCatValue@</NoTinReasonCatValue>\r\n" + FORMAT_SPACE
            + "<OperatorConfirmedReason>@NoTinReasonOperatorConfirmedReason@</OperatorConfirmedReason>\r\n" 
            + FORMAT_SPACE + "<Reason>@NoTinReason@</Reason>\r\n" + FORMAT_SPACE
            + "<StartDate>@NoTinReasonStartDate@</StartDate>\r\n" + FORMAT_SPACE
            + "<EndDate>@NoTinReasonEndDate@</EndDate>\r\n" + FORMAT_SPACE
            + "<SourceIdentifierValue>@NoTinReasonSourceIdentifierValue@</SourceIdentifierValue>\r\n" + FORMAT_SPACE
            + "</XNoTinReasonBObj>\r\n" + FORMAT_SPACE
            + "                </XContTaxCountryBObj>";

    public static final String MAINTAIN_PARTY_XCONT_CITIZENSHIP_DETAILS_REQUEST = "<XContCitizenshipBObj>\r\n"
            + FORMAT_SPACE
            + "<ObjectReferenceId>@CitizenshipCountryObjectReferenceId@</ObjectReferenceId>\r\n" + FORMAT_SPACE
            + "<SourceIdentifierValue>@CitizenshipSourceIdentifierValue@</SourceIdentifierValue>\r\n" + FORMAT_SPACE
            + "<XCountryValue>@CitizenshipCountryValue@</XCountryValue>\r\n" + FORMAT_SPACE
            + FORMAT_SPACE + "                 </XContCitizenshipBObj>";

}