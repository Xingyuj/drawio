package com.anz.mdm.ocv.api.exception;

import lombok.Getter;
import lombok.Setter;

/**
 * To handle UnAuthorised MDM Exception
 * 
 * @author surendrn
 *
 */
@Getter
@Setter
public class UnAuthorizedMDMException extends APIException {

    private static final long serialVersionUID = 1L;
    private String statusMessage;

    public UnAuthorizedMDMException(String statusCode, String statusMessage) {
        super(statusCode);
        this.statusMessage = statusMessage;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

}