package com.anz.mdm.ocv.api.util;

import java.util.List;

import com.anz.mdm.ocv.api.constants.MDMRequestTemplates;
import com.anz.mdm.ocv.common.v1.BankingRelationships;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class MaintainPartyOrgBankingRelationship {

    public void prepareBankingRelationShipKeyValueObjects(StringBuilder request,
            List<BankingRelationships> bankingRelationShips, String traceId) {
        LogUtil.debug(log, "prepareBankingRelationShipKeyValueObjects", traceId,
                "Entering: prepareBankingRelationShipKeyValueObjects method in MaintainPartyOrgBankingRelationship");

        for (BankingRelationships bankingRelationShip : bankingRelationShips) {

            createAndModifyTemplateForBankingRelationShipKeyValues(request, bankingRelationShip, traceId);

        }

        LogUtil.debug(log, "prepareBankingRelationShipKeyValueObjects", traceId,
                "Exit: prepareBankingRelationShipKeyValueObjects method in MaintainPartyOrgBankingRelationship");

    }

    private void createAndModifyTemplateForBankingRelationShipKeyValues(StringBuilder request,
            BankingRelationships bankingRelationShip, String traceId) {
        LogUtil.debug(log, "createAndModifyTemplateForBankingRelationShipKeyValues", traceId,
                "Entering: createAndModifyTemplateForBankingRelationShipKeyValues method in "
                        + "PartyInternalObjectsProcessor");
        String keyValueRequest = MDMRequestTemplates.MAINTAIN_PARTY_KEY_VALUE_REQUEST;

        request.insert(request.indexOf("<TCRMPartyMacroRoleBObj>"), keyValueRequest);
        modifytemplateForBankingRelationShipKeyValues(request, bankingRelationShip, traceId);

        LogUtil.debug(log, "createAndModifyTemplateForBankingRelationShipKeyValues", traceId,
                "Exit: createAndModifyTemplateForBankingRelationShipKeyValues method in"
                        + " MaintainPartyOrgBankingRelationship");

    }

    private void modifytemplateForBankingRelationShipKeyValues(StringBuilder request,
            BankingRelationships bankingRelationShip, String traceId) {
        LogUtil.debug(log, "modifytemplateForBankingRelationShipKeyValues", traceId,
                "Entering: modifytemplateForBankingRelationShipKeyValues method in "
                        + "MaintainPartyOrgBankingRelationship");
        RequestTransfomerUtil.modifyTemplate(request, "@key@", bankingRelationShip.getKey(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@value@", bankingRelationShip.getValue(), traceId);

        LogUtil.debug(log, "modifytemplateForBankingRelationShipKeyValues", traceId,
                "Exit: modifytemplateForBankingRelationShipKeyValues method in MaintainPartyOrgBankingRelationship");

    }

}
