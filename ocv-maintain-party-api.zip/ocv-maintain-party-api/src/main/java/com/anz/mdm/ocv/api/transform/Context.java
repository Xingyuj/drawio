package com.anz.mdm.ocv.api.transform;

/**
 * Enum class that defines the various messaging contexts application
 * 
 * @author surakarn
 *
 */
public enum Context {
    PARTYAPI, SEARCHAPI_CERTIFIED_PROBABLE, SEARCHAPI_CERTIFIED, DELETEPARTYAPI;
}