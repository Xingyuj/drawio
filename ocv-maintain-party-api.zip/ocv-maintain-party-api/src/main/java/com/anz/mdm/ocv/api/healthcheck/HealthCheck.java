package com.anz.mdm.ocv.api.healthcheck;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.anz.mdm.ocv.api.util.LogUtil;

import lombok.extern.slf4j.Slf4j;

/*
 * This class will override springboot healthcheck functionality for the fuzzy requests.
 * @author Deepika Handa
 */

@Slf4j
@Component
public class HealthCheck implements HealthIndicator {

    @Autowired
    @Qualifier("ApiRestTemplate")
    private RestTemplate restTemplate;

    public String check() {
        LogUtil.debug(log, "check", "starting health check");
        ResponseEntity<HealthStatus> response = null;
        String healthStatus = null;
        try {
            response = restTemplate.getForEntity("https://localhost:8443/health", HealthStatus.class);
        } catch (Exception e) {
            LogUtil.debug(log, "check", "Exception occured while performing request to health check");
        }
        if (response != null) {
            HealthStatus health = response.getBody();
            if (null != health) {
                healthStatus = health.getStatus();
            }
        }

        return healthStatus;
    }

    @Override
    public Health health() {
        String healthStatus = check();
        LogUtil.debug(log, "healthstatus", healthStatus);
        if (!"UP".equals(healthStatus)) {
            LogUtil.debug(log, "health", "liveness probe : Unhealthy");
            return Health.down().build();
        }
        return Health.up().build();
    }
}