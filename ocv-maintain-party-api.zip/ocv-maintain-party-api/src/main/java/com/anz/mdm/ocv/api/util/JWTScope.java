package com.anz.mdm.ocv.api.util;

import org.json.JSONArray;

public class JWTScope {

    private String[] scopes;
    private String jwtSub;

    public JWTScope(JSONArray extractedScopeFromJwtToken, String jwtSub) {
        if (extractedScopeFromJwtToken != null) {
            String[] arr = new String[extractedScopeFromJwtToken.length()];
            for (int i = 0; i < arr.length; i++) {
                arr[i] = extractedScopeFromJwtToken.optString(i);
            }

            this.scopes = arr;
        }
        this.jwtSub = jwtSub;
    }

    public String[] getScopes() {
        return scopes.clone();
    }

    public String getJwtSub() {
        return jwtSub;
    }

}
