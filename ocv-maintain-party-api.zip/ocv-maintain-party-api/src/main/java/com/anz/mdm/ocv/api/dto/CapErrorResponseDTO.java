package com.anz.mdm.ocv.api.dto;

import java.util.List;

import com.anz.mdm.ocv.api.exception.ErrorCap;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * ErrorResponseDto used to transform error response from CAP service
 * 
 * @author gorebalr
 *
 */
@Setter
@Getter
public class CapErrorResponseDTO {

    private int httpCode;
    private String httpMessage;
    private String moreInformation;
    private String type;
    private List<ErrorCap> errors;
}
