package com.anz.mdm.ocv.api.util;

public final class ExceptionUtil {

    private ExceptionUtil() {
        super();
    }

    public static String getErrorMessage(String exception) {
        if (null != exception && exception.contains("<ErrorMessage>")) {
            String errorMessage = exception.substring(
                    exception.lastIndexOf("<ErrorMessage>") + "<ErrorMessage>".length(),
                    exception.lastIndexOf("</ErrorMessage>"));
            return errorMessage;
        }
        return null;
    }
}
