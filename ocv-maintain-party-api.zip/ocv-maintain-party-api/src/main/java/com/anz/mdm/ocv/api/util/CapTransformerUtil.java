package com.anz.mdm.ocv.api.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Component;

import com.anz.mdm.ocv.api.constants.CAPConstants;
import com.anz.mdm.ocv.api.dto.AddressDTO;
import com.anz.mdm.ocv.api.dto.CapProfileDTO;
import com.anz.mdm.ocv.api.dto.CapProfileDTOV2;
import com.anz.mdm.ocv.cap.v1.AddressDetails;
import com.anz.mdm.ocv.cap.v2.Addresses;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Setter
@Getter
@Slf4j
@Component
public final class CapTransformerUtil {

    private CapTransformerUtil() {
        super();
    }

    public static List<AddressDetails> getAddress(final CapProfileDTO capDTO) {
        if (null != capDTO && null != capDTO.getAddresses()) {
            List<AddressDetails> addressList = new ArrayList<AddressDetails>();
            if (capDTO.getAddresses().size() > 0) {
                Optional.ofNullable(capDTO.getAddresses().get(0)).ifPresent(address -> {
                    addressList.add(getSetAddress(address));
                });
            }
            if (capDTO.getAddresses().size() > 1) {
                Optional.ofNullable(capDTO.getAddresses().get(1)).ifPresent(address -> {
                    addressList.add(getSetAddress(address));
                });
            }
            return addressList;
        } else {
            return null;
        }
    }

    public static Addresses getCapV2Address(final CapProfileDTOV2 capDTO) {
        Addresses addresses = new Addresses();
        capDTO.getAddresses().stream().filter(e -> CAPConstants.STRING_RESIDENTIAL.equalsIgnoreCase(e.getUsage()))
                .findFirst().ifPresent(addressDto -> addresses.setResidential(mapV2Address(addressDto)));
        capDTO.getAddresses().stream().filter(e -> CAPConstants.STRING_MAILING.equalsIgnoreCase(e.getUsage()))
                .findFirst().ifPresent(addressDto -> addresses.setMailing(mapV2Address(addressDto)));
        return addresses;
    }

    private static AddressDetails getSetAddress(AddressDTO addressDTO) {
        AddressDetails address = new AddressDetails();
        address.setAddressLine1(addressDTO.getAddressLine1());
        address.setAddressLine2(addressDTO.getAddressLine2());
        address.setAddressLine3(addressDTO.getAddressLine3());
        address.setCity(addressDTO.getCity());
        address.setCountryCode(addressDTO.getCountryCode());
        address.setPostcode(addressDTO.getPostCode());
        address.setStateProvince(addressDTO.getStateprovince());
        address.setCountryName(addressDTO.getCountryName());
        address.setStartDate(addressDTO.getStartDate());
        address.setEndDate(addressDTO.getEndDate());
        address.setUsage(addressDTO.getUsage());
        address.setDeliveryPointID(addressDTO.getDeliveryPointId());
        return address;

    }

    private static com.anz.mdm.ocv.cap.v2.AddressDetails mapV2Address(AddressDTO addressDTO) {
        com.anz.mdm.ocv.cap.v2.AddressDetails address = new com.anz.mdm.ocv.cap.v2.AddressDetails();
        address.setAddressLine1(addressDTO.getAddressLine1());
        address.setAddressLine2(addressDTO.getAddressLine2());
        address.setAddressLine3(addressDTO.getAddressLine3());
        address.setCity(addressDTO.getCity());
        address.setCountryCode(addressDTO.getCountryCode());
        address.setPostCode(addressDTO.getPostCode());
        address.setState(addressDTO.getStateprovince());
        address.setStartDate(addressDTO.getStartDate());
        address.setEndDate(addressDTO.getEndDate());
        address.setDeliveryPointID(addressDTO.getDeliveryPointId());
        return address;
    }
}
