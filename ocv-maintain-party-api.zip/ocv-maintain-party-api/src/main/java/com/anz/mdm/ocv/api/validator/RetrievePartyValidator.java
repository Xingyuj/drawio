package com.anz.mdm.ocv.api.validator;

import com.anz.mdm.ocv.party.v1.Party;

import lombok.extern.slf4j.Slf4j;

/**
 * RetrievePartyValidator class validates the GET API request
 * 
 * @author Naresh Surakarapu
 *
 */
@Slf4j
public class RetrievePartyValidator extends AbstractValidator<Party> {

    @Override
    public ValidationResult validateBody(APIRequest<Party> apiRequest) {
        // There is no body for GET Requests
        return null;
    }

    @Override
    public ValidationResult validateQueryParameters(APIRequest<Party> apiRequest) {

        return null;
    }
}
