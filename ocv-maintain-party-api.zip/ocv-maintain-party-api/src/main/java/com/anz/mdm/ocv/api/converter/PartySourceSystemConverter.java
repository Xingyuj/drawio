package com.anz.mdm.ocv.api.converter;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.anz.mdm.ocv.api.dto.APIResponse;
import com.anz.mdm.ocv.api.util.LogUtil;
import com.anz.mdm.ocv.common.v1.SourceSystem;
import com.ibm.mdm.schema.TCRMAdminContEquivBObjType;

import lombok.extern.slf4j.Slf4j;

/**
 * PartySourceSystemConverter class transforms the source system details from
 * MDM TCRMService object to Party object
 * 
 */

@Slf4j
@Component(value = "partySourceSystemConverter")
public class PartySourceSystemConverter {

    public void convertSourceSystems(APIResponse apiResponse, List<TCRMAdminContEquivBObjType> sourceList,
            String traceId) {
        Long startTime = System.currentTimeMillis();
        LogUtil.debug(log, "convertSourceSystems", traceId, "starting source systems transformation");
        List<SourceSystem> sourceSystems = new ArrayList<>();
        for (TCRMAdminContEquivBObjType tcrmAdminContEquivBObjType : sourceList) {
            SourceSystem srcSystem = new SourceSystem();
            srcSystem.setSourceSystemId(tcrmAdminContEquivBObjType.getAdminPartyId());
            srcSystem.setSourceSystemName(tcrmAdminContEquivBObjType.getAdminSystemValue());
            sourceSystems.add(srcSystem);
        }
        apiResponse.setSourceSystems(sourceSystems);
        Long endTime = System.currentTimeMillis();
        LogUtil.debug(log, "convertSourceSystems", traceId, "finishing source systems transformation ",
                endTime - startTime);
    }
}
