package com.anz.mdm.ocv.api.validator;


import java.util.Arrays;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.util.LogUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * Generic Abstract validator. It can be used for any request body. Any resource
 * specific validator must extend this.
 * 
 * @author Amit Gera
 *
 */
@Slf4j
public abstract class AbstractValidator<T> {

    protected abstract ValidationResult validateBody(APIRequest<T> request);

    protected abstract ValidationResult validateQueryParameters(APIRequest<T> request);

    private APIRequest<T> apiRequest;
    
    public static final Set<String> HEADER_KEYS = new HashSet<String>(Arrays.asList(OCVConstants.IDEMPOTENCY_KEY));

    public APIRequest<T> getAPIRequest() {
        return apiRequest;
    }

    /**
     * Template method to validate the API request
     * 
     * @param apiRequest
     *            the API Request
     * @param traceId
     *            the traceId
     * @return ValidationResult the validation result
     */
    public ValidationResult validateRequest(APIRequest<T> apiRequest1) {
        this.apiRequest = apiRequest1;
        Long startTime = System.currentTimeMillis();
        LogUtil.debug(log, "maintainParty", apiRequest.getTraceId(),
                "Entering: validateRequest method in AbstractValidator");
        ValidationResult validationResult = new ValidationResult();
        boolean areHeadersOK = apiRequest.areMandatoryHeadersPresent();

        if (!areHeadersOK) {
            String validationStatus = apiRequest.checkMandatoryHeaders();
            validationResult.setStatus(validationStatus);
            validationResult.setErrorCode(OCVConstants.MANDATORY_HEADER_MISSING_ERROR_CODE);
        }

        LogUtil.debug(log, "validateRequest", apiRequest.getTraceId(),
                "mandatory headers check passed: " + validationResult.isValid());
        if (validationResult.isValid()) {
            validationResult = validateQueryParameters(apiRequest);
        }
        LogUtil.debug(log, "validateRequest", apiRequest.getTraceId(),
                "query parameters check passed: " + validationResult.isValid());

        if (validationResult.isValid()) {
            validationResult = validateBody(apiRequest);
        }
        LogUtil.debug(log, "validateRequest", apiRequest.getTraceId(),
                "body check passed: " + validationResult.isValid());
        Long endTime = System.currentTimeMillis();

        LogUtil.debug(log, "validateRequest", apiRequest.getTraceId(),
                "Exiting: validateRequest method in AbstractValidator.", (endTime - startTime));
        return validationResult;
    }

    protected ValidationResult validateSecureHeaders(APIRequest apiRequestValidation, 
            ValidationResult validationResult) {
        Optional<String> validationMessage = checkSecureHeader(HEADER_KEYS, apiRequestValidation);
        if (validationResult.isValid() && validationMessage.isPresent()) {
            validationResult.setStatus(validationMessage.get() + OCVConstants.SPECIAL_CHARACTER_IN_HEADER_MSG);
            validationResult.setErrorCode(OCVConstants.SPECIAL_CHARACTER_IN_HEADER);
        }
        return validationResult;
    }

    protected Optional<String> checkSecureHeader(Set<String> headerKeys, APIRequest apiRequestValidation) {
        String headerKey = null;
        Pattern p = Pattern.compile("^$|[a-zA-Z0-9,]+$", Pattern.CASE_INSENSITIVE);
        Optional<String> entry = headerKeys.stream()
                .filter(e -> containsSpecialChars(((String) apiRequestValidation.getHeaders().get(e)), p)).findFirst();
        if (entry.isPresent()) {
            headerKey = entry.get();
        }
        return Optional.ofNullable(headerKey);
    }

    private boolean containsSpecialChars(String value, Pattern p) {
        boolean hasSpecialChars = false;
        if (!StringUtils.isEmpty(value)) {
            hasSpecialChars = !(p.matcher(value).find());
        }
        return hasSpecialChars;
    }

}