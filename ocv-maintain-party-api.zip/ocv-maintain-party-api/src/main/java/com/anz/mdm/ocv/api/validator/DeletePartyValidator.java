package com.anz.mdm.ocv.api.validator;

import static org.springframework.util.StringUtils.isEmpty;

import org.springframework.stereotype.Component;

import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.util.LogUtil;
import com.anz.mdm.ocv.party.v1.Party;

import lombok.extern.slf4j.Slf4j;

/**
 * Validation class for delete API
 * 
 * @author surakarn
 *
 */

@Slf4j
@Component
public class DeletePartyValidator extends AbstractValidator<Party> {

    @Override
    public ValidationResult validateBody(APIRequest<Party> apiRequest) {

        Party requestBody = apiRequest.getRequestBody();
        String traceId = apiRequest.getTraceId();
        LogUtil.debug(log, "DeletePartyValidator.validateBody", traceId, "Entering: DeletePartyValidator.validateBody");
        ValidationResult validationResult = new ValidationResult();

        if ((requestBody.getSourceSystems().size() == 0)
                || (isEmpty(requestBody.getSourceSystems().get(0).getSourceSystemId())
                        || isEmpty(requestBody.getSourceSystems().get(0).getSourceSystemName()))) {
            LogUtil.debug(log, "validateBody", "setting error code 4004");
            validationResult.setErrorCode(OCVConstants.MANDATORY_ATTRIBUTES_MISSING);
        }

        LogUtil.debug(log, "DeletePartyValidator.validateBody", traceId, "Exit: DeletePartyValidator.validateBody");
        return validationResult;
    }

    @Override
    public ValidationResult validateQueryParameters(APIRequest<Party> apiRequest) {
        LogUtil.debug(log, "DeletePartyValidator.validateQueryParameters", apiRequest.getTraceId(),
                "Exit: DeletePartyValidator.validateQueryParameters");
        ValidationResult validationResult = new ValidationResult();
        LogUtil.debug(log, "DeletePartyValidator.validateQueryParameters", apiRequest.getTraceId(),
                "Exit: DeletePartyValidator.validateQueryParameters");
        return validationResult;
    }

    @Override
    public ValidationResult validateRequest(APIRequest<Party> apiRequest) {
        Long startTime = System.currentTimeMillis();
        String traceId = apiRequest.getTraceId();
        LogUtil.debug(log, "purgeParty", traceId, "Entering: validateRequest method in DeleteValidator");
        ValidationResult validationResult = new ValidationResult();
        boolean areHeadersOK = apiRequest.areMandatoryHeadersPresent() && !isEmpty(apiRequest.getRequestTimestamp())
                && !isEmpty(apiRequest.getUserId());

        if (!areHeadersOK) {
            validationResult.setErrorCode(OCVConstants.MANDATORY_HEADER_MISSING_ERROR_CODE);
        }

        LogUtil.debug(log, "validateRequest", traceId, "mandatory headers check passed: " + validationResult.isValid());

        if (validationResult.isValid()) {
            validationResult = validateQueryParameters(apiRequest);
        }
        LogUtil.debug(log, "validateRequest", traceId, "query parameters check passed: " + validationResult.isValid());

        if (validationResult.isValid()) {
            validationResult = validateBody(apiRequest);
        }
        LogUtil.debug(log, "validateRequest", traceId, "body check passed: " + validationResult.isValid());
        Long endTime = System.currentTimeMillis();
        LogUtil.debug(log, "validateRequest", traceId, "Exiting: validateRequest method in AbstractValidator.",
                (endTime - startTime));
        return validationResult;
    }

}