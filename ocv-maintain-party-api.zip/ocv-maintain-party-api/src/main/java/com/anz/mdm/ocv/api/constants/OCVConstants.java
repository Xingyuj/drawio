package com.anz.mdm.ocv.api.constants;

/**
 * OCVConstants include all constants
 * 
 * @author surakarn
 *
 */

public final class OCVConstants {

    private OCVConstants() {

    }

    public static final String MAINTAIN_PARTY = "/v2/parties";
    public static final String AUTHORIZATION_HEADER = "authorization";
    public static final String USER_ID_HEADER = "userid";
    public static final String TRACE_ID_HEADER = "x-b3-traceid";
    public static final String ACCEPT_HEADER = "accept";
    public static final String CONTENT_TYPE = "content-type";
    public static final String CHANNEL_HEADER = "channel";
    public static final String REQUEST_TIMESTAMP = "requesttime";
    public static final String ROLES_REQUIRED = "rolesRequired";
    public static final String CHANNEL = "channel";
    public static final String IDEMPOTENCY_KEY = "idempotency-key";
    public static final String IDEMPOTENCY_FIRST_SENT = "idempotency-first-sent";
    public static final String INVOKING_APPLICATION_HEADER = "application";
    public static final String OCV = "OCV";
    public static final String INPUT_FORMAT_ERROR_CODE = "4005";
    public static final String OFFSET_PARAMETER = "offset";
    public static final String LIMIT_PARAMETER = "limit";
    public static final String FIELDS_PARAMETER = "fields";

    public static final int DEFAULT_OFFSET = 0;
    public static final int DEFAULT_LIMIT = 10;
    public static final int DEFAULT_START_INDEX = 0;
    public static final int INTEGER_ONE = 1;
    public static final int INTEGER_ZERO = 0;
    public static final int INTEGER_TEN = 10;
    public static final int MAX_ENTITY_COUNT = 100;

    public static final String COMMA_OPERATOR = ",";
    public static final String SPACE_OPERATOR = " ";

    // carry forward for some time
    public static final String INVALID_LIMIT_PARAM_ERROR_CODE = "api.param.limit.invalid.code";
    public static final String INVALID_OFFSET_PARAM_ERROR_CODE = "api.param.offset.invalid.code";
    public static final String NORESULT_FOR_OFFSET_ERROR_CODE = "api.param.offset.noresult.code";

    public static final String IDEMPOTENT_FIRST_SENT_WRONG_FORMAT = "4222";
    public static final String MANDATORY_HEADER_MISSING_ERROR_CODE = "4001";
    public static final String IDEMPOTENT_TIME_LIMIT_EXPIRED = "4221";
    public static final String RESPONSE_FROM_IDEMPOTENCY = "responseFromIdempotency";
    public static final String RESOURCE_NOT_FOUND_ERROR_CODE = "api.error.resourcenotfound";
    public static final String INTERNAL_SERVER_ERROR_CODE = "api.error.backend.unavailable";
    public static final String MANDATORY_PARAMS_MISSING_ERROR = "4002";
    public static final String RECORD_NOT_FOUND_ERROR = "4041";
    public static final String SSL_VERSION = "TLSv1.2";
    public static final String MANDATORY_ATTRIBUTES_MISSING = "4004";
    public static final String OFFSET_LIMIT_NOT_INTEGER_VALUES = "4007";
    public static final String SECURITY_EMAIL_MOB_ERROR_CODE = "40013";
    public static final String KYCVERIFICATION_ERROR_CODE = "40014";
    public static final String SOURCE_IS_EMPTY = "4020";

    public static final String PARTY_TYPE = "Party";

    public static final String APPLICATION_XML = "application/xml";
    public static final String TARGETAPPLICATION = "TargetApplication";
    public static final String TCRM = "tcrm";
    public static final String REQUESTTYPE = "RequestType";
    public static final String STANDARD = "standard";
    public static final String TCRMSERVICE = "TCRMService";
    public static final String PARSER = "Parser";
    public static final String RESPONSETYPE = "ResponseType";
    public static final String CONSTRUCTOR = "Constructor";
    public static final String OPERATIONTYPE = "OperationType";
    public static final String ALL = "all";
    // query parameters

    public static final String MINSCORE = "MinScore";
    public static final String INDIVIDUAL_PARTY_TYPE = "P"; // check for actual
                                                            // value
    public static final String NON_INDIVIDUAL_PARTY_TYPE = "O"; // check for
                                                                // actual value
    public static final String ORGANISATION_NAME = "OrganizationName"; // check
                                                                       // for
                                                                       // the
                                                                       // actual
                                                                       // Value

    public static final String MDM_EXCEPTION = "Exception occured at MDM.";
    public static final String MDM_EXCEPTION_ERROR_CODE = "5003";
    public static final String RECORD_NOT_FOUND = "No record is found.";
    public static final String FATAL = "FATAL";
    public static final String SUCCESS = "SUCCESS";
    public static final String WARNING = "WARNING";

    public static final String MDM_XSL_FILE_MAINTAINPARTY = "classpath:templates/maintainPartyTransform.xsl";
    public static final String MDM_XSL_FILE_DELETEPARTY = "classpath:templates/deletePartyTransform.xsl";

    public static final String BACKEND_SERVICE_EXCEPTION_ERROR_CODE = "5003";
    public static final String PROBABLE_RECORDS = "probable";
    public static final String FALSE = "false";
    public static final String TRUE = "true";
    public static final String SUFFICIENT_DATA_NOT_PROVIDED = "4008";
    
    public static final String SERVICE_NOT_AVAILABLE = "5002";
    public static final String CONNECT_TIMEOUT_EXCEPTION = "5004";
    public static final String READ_TIMEOUT_EXCEPTION = "5005";
    public static final String UNAUTHORIZED_EXCEPTION = "5006";

    public static final String MISSING_ACCEPT_HEADER = "Missing Accept Header";
    public static final String MISSING_TRACE_ID = "Missing Trace Id";
    public static final String MISSING_JWT_TOKEN = "Missing JWT Token";
    public static final String MISSING_CHANNEL = "Missing Channel";
    public static final String REQUEST_TIME = "Missing Request Time";
    public static final String USER_ID = "Missing User Id";

    public static final String DELETE_IDTYPE = "idType";
    public static final String DELETE_PARTYID = "partyId";

    public static final String UAM_ACCESS_LIST_NAME = "ACCESS";
    public static final String INVALID_OCV_SCOPE_ERROR_CODE = "4011";
    public static final String INVALID_OCV_JWT_SCOPE = "Invalid JWT Scopes for OCV access";
    public static final String INVALID_JWT_TOKEN_ERROR_CODE = "4012";
    public static final String INVALID_JWT_TOKEN = "JWT Token is not valid";
    public static final String UNAUTHORIZED_MDM_EXCEPTION = "Authorisation failed for MDM service";
    public static final String IDENTIFIER_VALUE_MISSING = "Identifier Value is missing";
    public static final String IDENTIFIER_TYPE_MISSING = "Identifier Usage Type is missing";
    public static final String SRC_SYSTEM_ID_MISSING = "Source System id is missing";
    public static final String SRC_SYSTEM_TYPE_MISSING = "Source System Name is missing";
    public static final String SECURITY_EMAIL_ERROR_MESSAGE = "Email must contain Security Email only";
    public static final String SECURITY_MOBILE_ERROR_MESSAGE = "Phone must contain Security Mobile only";
    public static final String SEC_EMAIL_INT_1_SRC_ERR_MSG = "Source must be FENERGOANZX for Security Email";
    public static final String SEC_EMAIL_INT_1_2_SRC_ERR_MSG = "Source must be FENERGOANZX or AEGISANZX "
            + "for Security Email";
    public static final String SEC_MOBILE_INT_1_SRC_ERR_MSG = "Source must be FENERGOANZX for Security Mobile";
    public static final String SEC_MOBILE_INT_1_2_SRC_ERR_MSG = "Source must be FENERGOANZX or AEGISANZX "
            + "for Security Mobile";
    public static final String KYCVERIFICATION_ERROR_MESSAGE = "Multiple KYC is not supported";

    public static final String MMLO_CHANNEL = "MMLO";
    public static final String MAINTAINPARTY_SERVICE = "maintainParty";
    public static final String DELETEPARTY_SERVICE = "deleteParty";
    public static final String RETRIEVEPARTY_SERVICE = "RetrievePartyAPI";

    // Create party in CAP constants
    public static final String FENERGOANZX_CHANNEL = "FENERGOANZX";
    public static final String AEGISANZX_CHANNEL = "AEGISANZX";

    public static final String LEGAL_NAME = "Legal Name";
    public static final String MISSING_MANDATORY_ATTRIBUTES_ERROR_MESSAGE = "Missing ";
    public static final String NAME = "name";
    public static final String FIRST_NAME = "firstName";
    public static final String LAST_NAME = "lastName";
    public static final String ADDRESS = "address";
    public static final String ADDRESS_USAGE_TYPE = "addressUsageType";
    public static final String COUNTRY = "country";
    public static final String STATE = "state";
    public static final String CITY = "city";
    public static final String POSTAL_CODE = "postalCode";
    public static final String PARTY_TYPE_ATTR = "partyType";
    public static final String LEGAL_NAME_USAGE_TYPE = "legal name type";
    public static final String SECURITY_EMAIL = "Security Email";
    public static final String SECURITY_MOBILE = "Security Mobile";
    public static final String SPAN_ID_HEADER = "X-B3-SpanId";
    public static final String IBM_CLIENT_ID_HEADER = "X-IBM-Client-ID";
    public static final String ORIG_APP_HEADER = "X-Originating-App";
    public static final String ANZ_APP_HEADER = "Anz-Application-Id";
    public static final String REQUEST_ID = "RequestId";
    public static final String PARENT_SPAN_ID_HEADER = "X-B3-ParentSpanId";
    public static final String CAPTRANSFORMATION_SERVICE = "CapTransformationService";
    public static final String REQUEST_MODE_HEADER = "requestmode";
    public static final String CAP_CIS_SOURCE = "CAP-CIS";
    public static final String AU_JURISDICTION = "AU";
    public static final String FENERGO_SOURCE = "FENERGOANZX";
    public static final String FENERGO_SOURCE_DELTA = "FENERGOANZXDELTA";
    public static final String AEGIS_SOURCE = "AEGISANZX";
    public static final String OCV_STRING = "OCV";
    public static final String BRANCH_ID = "4111";
    public static final String X_WORKSTATION = "OCVANZX";
    public static final String MISSING_REQUESTMODE = "Missing Request Mode";
    public static final String OCV_ID_IDENTIFIER_TYPE = "One Customer ID";
    public static final String REQUEST_MODE_UPDATE_ANZX = "updateCustomer";
    public static final String REQUEST_MODE_UPDATEKYC = "updateCustomerKYC";
    public static final String REQUEST_MODE_CREATE_CUSTOMER = "createCustomer";
    public static final String ONE_CUSTOMER_ID = "One Customer ID";
    public static final String KYC_STATUS_FAIL = "Fail";


    public static final String FPE_IDENTIFIER = "fpe.personal-identifier";
    public static final String FPE_ACCOUNT_NUMBER = "fpe.bank-card-number";
    public static final String TOKEN_PREFIX = "enc(";
    public static final String TOKEN_SUFFIX = ")";

    public static final String OCV_VAULT_SERVICE_NOT_AVAILABLE_EXCEPTION = "5008";
    public static final String OCV_VAULT_INVALID_FORMAT_EXCEPTION = "5009";
    public static final String OCV_VAULT_SERVICE_UNAVAILABLE_MSG = "OCV-Vault service unavailable!!!";
    public static final String INVALID_OCV_VAULT_RESPONSE_MSG = "Invalid response from OCV-Vault service";

    public static final String VAULT_SERVICE_BATCH_INPUT_EXCEPTION = "4022";
    public static final String VAULT_SERVICE_BATCH_INPUT_EXCEPTION_MSG
            = "Invalid input to Hashicorp ADP service";
    
    public static final String ENGLISH = "English";
    public static final String BKSV = "BKSV";
    public static final String APPLICATION = "application";

    /* included as part of JWT 17031 feature */
    public static final String UAM_LIST_NAME = "UAM";
    public static final String UAM_ISSUER_LIST_NAME = "ISSUER";
    public static final String UAM_CHANNEL_LIST_NAME = "VALIDATION";
    
    /* included as part of JWT 17031 feature */
    public static final String INVALID_JWT_ISSUER_ERROR_CODE = "4013";
    public static final String INVALID_JWT_ISSUER = "JWT Issuer is not valid";
    public static final String INVALID_JWT_EXPIRED_CODE = "4014";
    public static final String INVALID_JWT_EXPIRED = "Expired JWT for OCV access";
    public static final String INVALID_JWT_SIGNATURE_CODE = "4015";
    public static final String INVALID_JWT_SIGNATURE = "Invalid Signature in JWT";
    public static final String INVALID_JWT_BODY_CODE = "4016";
    public static final String INVALID_JWT_BODY = "Invalid Body in JWT";
    public static final String INVALID_JWT_HEADER_CODE = "4017";
    public static final String INVALID_JWT_HEADER = "Invalid Header in JWT";
    public static final String INVALID_JWT_TIMEOUT_CODE = "4018";
    public static final String INVALID_JWT_TIMEOUT = "Connection / Read Time out while validating JWT";
    public static final String INVALID_CHANNEL_ERROR_CODE = "4019";
    public static final String INVALID_CHANNEL = "Invalid Channel Request";
    public static final String INVALID_JWT_CODE = "40110";
    public static final String INVALID_JWT = "Invalid JWT Request";

    public static final String ENTITYNAME_MACROROLE = "CONTMACROROLE";
    public static final String ENTITYNAME_IDENTIFIER = "IDENTIFIER";
    public static final String INVALID_STRUCT_ATTR_ERROR = "5007";
    public static final String INVALID_STRUCT_ATTR = "Exception occured while parsing Structured Attributes";
    
    public static final String OCV_ENTITYNAME_CONTACTMETHOD = "CONTACTMETHOD";
    
    public static final String OCV_ENTITYNAME_INDENTIFIER = "IDENTIFIER";
    public static final String OCV_ENTITYNAME_ADDRESS = "ADDRESS";
    public static final String OCV_ENTITYNAME_ADDRESS_ATTR = "AddressValidation";

    public static final String AX1_CHANNEL = "AX1";
    public static final String INVALID_JSON_INPUT = "40014";
    public static final String INVALID_JSON_ERROR_MESSAGE = "The body of the request, which was "
            + "expected to be JSON, was invalid.";

    public static final String KYC_METHOD_IDEV = "IDEV";
    public static final String KYC_METHOD_IDAEV = "IDAEV";
    public static final String KYC_METHOD_SELFIEEV = "SELFIEEV";
    public static final String KYC_METHOD_SELFIEMV = "SELFIEMV";
    public static final String KYC_METHOD_IDMV = "IDMV";

    public static final String ERROR_REASON_CODE_DUPLICATE = "12";
    public static final String ERROR_TYPE_DUPLICATE = "DKERR";
    public static final String ERROR_CONTAINS_DUPLICATE_INDEX = "I3_CONTEQUIV";
    public static final String UPDATE_CUSTOMER_TAG = "<updateMethodCode>updateCustomerKYC</updateMethodCode>";
  
    public static final String YES = "Y";
    public static final String INCLUDE_ACCOUNTS = "includeAccounts";
    public static final String ACCOUNT_PROD_TP = "accountProductTypes";
    public static final String PCB_ACCOUNT = "CAP-CIS:PCB";
    public static final String SPECIAL_CHARACTER_IN_HEADER = "40012";
    public static final String SPECIAL_CHARACTER_IN_HEADER_MSG = " header has special character";
    public static final String CAP_UNAVAILABLE_CODE = "53"; 
    public static final String CAP_UNAVAILABLE_DESCRIPTION = "TRANSACTION UNAVAILABLE"; 
    public static final String CAP_SERVICE_UNAVAILABLE = "CAP Service unavailable";
    public static final String CAP_UNAVAILABLE_ERROR_CODE = "5014";
    
    public static final String APIC_FORBIDDEN_ERROR_CODE = "403";
    public static final String APIC_INSUFFICIENT_SCOPE = "Insufficient Scope";
    public static final String INVALID_APIC_CAP_SCOPE_ERROR_CODE = "4021";
    public static final int MAX_HEADERS = 65536;
    
    public static final String OCV_ID_UNDER_REVEIEW = "4091";
    public static final String UNDER_REVIEW = "blockWhenOCVIdUnderReview";
    public static final String ANZX_ONBOARDING = "ANZxOBD";
    public static final String KYC_COMPLETED_MESSAGE = "KYC already completed for this profile.";
    public static final String KYC_COMPLETED_ANZX_CUSTOMER_EXISTS = "The Customer already has an ANZx profile";
    public static final String DUPLICATE_RECORD_FOUND_ERROR = "4042";
    public static final String DUPLICATE_ANZX_CUSTOMER_FOUND_ERROR = "4092";

    public static final String COMMERCIAL_PHONE = "Commercial Contact Phone";
    public static final String COMMERCIAL_MOBILE = "Commercial Contact Mobile";
    public static final String COMMERCIAL_FAX = "Commercial Contact Fax";
    public static final String UNAUTHORIZED_RHDM_EXCEPTION = "Authorisation failed for RHDM service";
    
    public static final String ADVERTISING_IND = "Advertising Indicator";
    public static final String ADVERTISING_DISC_IND_NO = "N";
    public static final String ADVERTISING_DISC_NOT_ALLOWED = "Not Allowed";
    public static final String LOW_END_DATE = "1901-01-01";
    
    public static final String DISCLOSURE_IND = "Disclosure Indicator";
    public static final String ERROR_REASON_CODE_DUPLICATE_PRIVPREF = "10339";
    public static final String ERROR_TYPE_DIERR = "DIERR";
    public static final String NO_CAP_CIS_IDS_IDENTIFIED = "4049";
    public static final String OCV_PROFILE_ID_TYPE = "OCV Profile ID";
    public static final String CRM = "CRM";
}

