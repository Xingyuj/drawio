package com.anz.mdm.ocv.api.dto;

import java.util.List;

import com.anz.mdm.ocv.common.v1.SourceSystem;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class APIResponse {

    private String ocvId;
    protected List<SourceSystem> sourceSystems;
    Boolean responseFromIdempotency = false;
    protected List<String> profileIds;
}
