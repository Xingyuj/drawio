package com.anz.mdm.ocv.api.exception;

/**
 * 
 * @author junejak
 * Handles record not found exceptions
 * 
 */
public class RecordNotFoundException extends APIException {

    private static final long serialVersionUID = -8484627633200126920L;

    private String statusMessage;

    public RecordNotFoundException(String statusCode, String statusMessage) {
        super(statusCode);
        this.statusMessage = statusMessage;
    }

    public String getStatusMessage() {
        return statusMessage;
    }
}
