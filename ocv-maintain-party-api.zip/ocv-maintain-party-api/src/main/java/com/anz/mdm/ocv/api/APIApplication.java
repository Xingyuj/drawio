package com.anz.mdm.ocv.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.context.annotation.ComponentScan;

//CHECKSTYLE:OFF - checkstyle considers this as utility class
@SpringBootApplication
@ComponentScan("com.anz.mdm.ocv.api")
@ComponentScan("com.anz.mdm.ocv.jwt")
@EnableHystrix
public class APIApplication {

    public static void main(String[] args) {
        SpringApplication.run(APIApplication.class, args);
    }

}
// CHECKSTYLE:ON