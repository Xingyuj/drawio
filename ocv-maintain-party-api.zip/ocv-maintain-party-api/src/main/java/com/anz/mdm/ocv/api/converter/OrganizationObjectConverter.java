package com.anz.mdm.ocv.api.converter;

import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.anz.mdm.ocv.api.dto.APIResponse;
import com.anz.mdm.ocv.api.util.LogUtil;
import com.ibm.mdm.schema.TCRMOrganizationBObjType;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component(value = "organizationObjectConverter")
public class OrganizationObjectConverter {

    private PartyIdentifierConverter identifierConverter = new PartyIdentifierConverter();
    private PartySourceSystemConverter sourceSystemConverter = new PartySourceSystemConverter();

    public APIResponse convertOrgDetails(TCRMOrganizationBObjType tcrmOrgObject, String traceId) {
        APIResponse apiResponse = new APIResponse();
        Long startTime = System.currentTimeMillis();
        LogUtil.debug(log, "convertOrgDetails", traceId, "starting org details transformation ");
        identifierConverter.convertIdentifierDetails(apiResponse, tcrmOrgObject.getTCRMPartyIdentificationBObj(),
                traceId);
        if (!CollectionUtils.isEmpty(tcrmOrgObject.getTCRMAdminContEquivBObj())) {
            sourceSystemConverter.convertSourceSystems(apiResponse, tcrmOrgObject.getTCRMAdminContEquivBObj(), traceId);
        }
        Long endTime = System.currentTimeMillis();
        LogUtil.debug(log, "convertOrgDetails", traceId, "finishing org details transformation ", endTime - startTime);
        return apiResponse;
    }
}
