package com.anz.mdm.ocv.api.dto;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Component
public class CapProfileDTOV2 extends CapProfileDTO {

    private boolean contactPreferredIndicator;

    public boolean isContactPreferredIndicator() {
        return contactPreferredIndicator;
    }

    public void setContactPreferredIndicator(boolean contactPreferredIndicator) {
        this.contactPreferredIndicator = contactPreferredIndicator;
    }

}
