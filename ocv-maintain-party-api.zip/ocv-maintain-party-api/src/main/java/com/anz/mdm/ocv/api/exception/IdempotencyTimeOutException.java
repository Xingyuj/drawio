package com.anz.mdm.ocv.api.exception;

public class IdempotencyTimeOutException extends APIException {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private String statusMessage;

    public IdempotencyTimeOutException(String statusCode, String statusMessage) {
        super(statusCode);
        this.statusMessage = statusMessage;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

}
