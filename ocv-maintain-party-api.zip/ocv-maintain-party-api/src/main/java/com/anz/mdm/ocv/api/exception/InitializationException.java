package com.anz.mdm.ocv.api.exception;

/**
 * 
 * To handler all InitializationExceptions
 * 
 * @author Sugandha Rajpal
 *
 */
public class InitializationException extends Exception {

    private static final long serialVersionUID = 1L;

    public InitializationException(Exception e) {
        super(e);
    }

}
