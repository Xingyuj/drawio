package com.anz.mdm.ocv.api.processor;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;

import com.anz.mdm.ocv.api.constants.MDMRequestTemplates;
import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.util.LogUtil;
import com.anz.mdm.ocv.api.util.MaintainPartyAdditionalAttributes;
import com.anz.mdm.ocv.api.util.RequestTransfomerUtil;
import com.anz.mdm.ocv.api.util.StreetSuffixConfig;
import com.anz.mdm.ocv.common.v1.Address;
import com.anz.mdm.ocv.common.v1.Citizenship;
import com.anz.mdm.ocv.common.v1.DocumentReference;
import com.anz.mdm.ocv.common.v1.EVMatchStatus;
import com.anz.mdm.ocv.common.v1.Email;
import com.anz.mdm.ocv.common.v1.Fax;
import com.anz.mdm.ocv.common.v1.Identifier;
import com.anz.mdm.ocv.common.v1.KYCVerificationDocRef;
import com.anz.mdm.ocv.common.v1.KycVerificationMethods;
import com.anz.mdm.ocv.common.v1.NoTaxReason;
import com.anz.mdm.ocv.common.v1.Phone;
import com.anz.mdm.ocv.common.v1.PrivacyPreference;
import com.anz.mdm.ocv.common.v1.RelatedIdentifier;
import com.anz.mdm.ocv.common.v1.SocialMedia;
import com.anz.mdm.ocv.common.v1.SourceSystem;
import com.anz.mdm.ocv.common.v1.StandardisedPhone;
import com.anz.mdm.ocv.common.v1.ValidationDetails;
import com.anz.mdm.ocv.common.v1.VerificationDetails;
import com.anz.mdm.ocv.party.v1.Party;

import lombok.extern.slf4j.Slf4j;

/**
 * Serves as a processor to transform the JSON request to MDM specific request
 * for party children objects
 *
 */

@Slf4j
@Component
public class PartyInternalObjectsProcessor {


    private SecureRandom random = new SecureRandom();
    // OCT-19371 : Enhance API for Verification and validation attributes START

    public void prepareValidationDetails(StringBuilder request, List<ValidationDetails> validationDetails,
            String usageType, String objectReferenceId, String entityName, String traceId) {
        LogUtil.debug(log, "prepareValidationDetails", traceId,
                "Entering: prepareValidationDetails method in prepareValidationDetails");
        int validationCount = 0;

        for (ValidationDetails validationDetail : validationDetails) {
            if (validationCount == 0
                    && (request
                            .indexOf("<ObjectReferenceId>@ValidationObjectReferenceId@</ObjectReferenceId>") != -1)) {

                modifyTemplateForValidationDetails(request, usageType, validationDetail, objectReferenceId, entityName,
                        traceId);
                validationCount++;
            } else {
                createAndModifyTemplateForValidationDetails(request, usageType, validationDetail, objectReferenceId,
                        entityName, traceId);
            }
        }

        LogUtil.debug(log, "prepareValidationDetails", traceId,
                "Exit: prepareValidationDetails method in prepareValidationDetails");
    }

    public void createAndModifyTemplateForValidationDetails(StringBuilder request, String addressUsageType,
            ValidationDetails validationDetails, String objectReferenceId, String entityName, String traceId) {

        LogUtil.debug(log, "createAndModifyTemplateForValidationDetails", traceId,
                "Entering: createAndModifyTemplateForValidationDetails method in PartyInternalObjectsProcessor");

        String verificationTemplate = MDMRequestTemplates.MAINTAIN_PARTY_XATTRVALIDATION_DETAILS_REQUEST;
        request.insert(request.indexOf("<XAttrVerificationBObj>"), verificationTemplate);

        modifyTemplateForValidationDetails(request, addressUsageType, validationDetails, objectReferenceId, entityName,
                traceId);

        LogUtil.debug(log, "createAndModifyTemplateForValidation", traceId,
                "Entering: createAndModifyTemplateForValidation method in PartyInternalObjectsProcessor");
    }

    private void modifyTemplateForValidationDetails(StringBuilder request, String usageType,
            ValidationDetails validationDetails, String objectReferenceId, String entityName, String traceId) {

        LogUtil.debug(log, "modifyTemplateForValidationDetails", traceId,
                "Entering: modifyTemplateForValidationDetails method in PartyInternalObjectsProcessor");

        RequestTransfomerUtil.modifyTemplate(request, "@ValidationObjectReferenceId@", objectReferenceId, traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XAttrValidationBObjEntityName@", entityName, traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XAttrValidationBObjXAttrNameValue@", usageType, traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XAttrValidationBObjXAttrStatus@",
                validationDetails.getStatus(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XAttrValidationBObjStatusReason@",
                validationDetails.getStatusReason(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XAttrValidationBObjValidatedBy@",
                validationDetails.getValidatedBy(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XAttrValidationBObjValidatedDt@",
                validationDetails.getValidationDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XAttrValidationBObjValidationMethod@",
                validationDetails.getValidationMethod(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XAttrValidationBObjChannel@", validationDetails.getChannel(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XAttrValidationBObjReValTimeDesignator@",
                validationDetails.getReValidationTimeDesignator(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XAttrValidationBObjReValTimeInterval@",
                validationDetails.getReValidationTimeInterval(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XAttrValidationBObjReValDt@",
                validationDetails.getReValidationDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XAttrValidationBObjStartDate@",
                validationDetails.getStartDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XAttrValidationBObjEndDate@", validationDetails.getEndDate(),
                traceId);

        LogUtil.debug(log, "modifyTemplateForValidationDetails", traceId,
                "Entering: modifyTemplateForValidationDetails method in PartyInternalObjectsProcessor");
    }

    public void prepareVerificationDetails(StringBuilder request, List<VerificationDetails> verificationDetails,
            String usageType, String objectReferenceId, String entityName, String traceId) {
        LogUtil.debug(log, "prepareVerificationDetails", traceId,
                "Entering: prepareVerificationDetails method in prepareVerificationDetails");
        int verificationCount = 0;

        for (VerificationDetails verificationDetail : verificationDetails) {
            if (verificationCount == 0
                    && (request
                            .indexOf("<ObjectReferenceId>@VerificationObjectReferenceId@</ObjectReferenceId>") != -1)) {

                modifyTemplateForVerification(request, usageType, verificationDetail, objectReferenceId, entityName,
                        traceId);
                verificationCount++;
            } else {
                createAndModifyTemplateForVerification(request, usageType, verificationDetail, objectReferenceId,
                        entityName, traceId);
            }
        }

        LogUtil.debug(log, "prepareVerificationDetails", traceId,
                "Exit: prepareVerificationDetails method in prepareVerificationDetails");
    }

    private void createAndModifyTemplateForVerification(StringBuilder request, String usageType,
            VerificationDetails verificationDetails, String objectReferenceId, String entityName, String traceId) {
        LogUtil.debug(log, "createAndModifyTemplateForVerification", traceId,
                "Entering: createAndModifyTemplateForVerification method in PartyInternalObjectsProcessor");

        String verificationTemplate = MDMRequestTemplates.MAINTAIN_PARTY_XATTRVERIFICATION_REQUEST;
        request.insert(request.indexOf("<XAttrVerificationBObj>"), verificationTemplate);
        modifyTemplateForVerification(request, usageType, verificationDetails, objectReferenceId, entityName, traceId);

        LogUtil.debug(log, "createAndModifyTemplateForVerification", traceId,
                "Entering: createAndModifyTemplateForVerification method in PartyInternalObjectsProcessor");
    }

    private void modifyTemplateForVerification(StringBuilder request, String usageType,
            VerificationDetails verificationDetails, String objectReferenceId, String entityName, String traceId) {
        LogUtil.debug(log, "modifyTemplateForVerification", traceId,
                "Entering: modifyTemplateForVerification method in PartyInternalObjectsProcessor");

        RequestTransfomerUtil.modifyTemplate(request, "@VerificationObjectReferenceId@", objectReferenceId, traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XAttrVerificationBObjEntityName@", entityName, traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XAttrVerificationBObjXAttrNameValue@", usageType, traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XAttrVerificationBObjVerifiedBy@",
                verificationDetails.getVerifiedBy(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XAttrVerificationBObjVerifiedDt@",
                verificationDetails.getVerifiedDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XAttrVerificationBObjVerificationMethod@",
                verificationDetails.getVerificationMethod(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XAttrVerificationBObjDocRef@",
                verificationDetails.getDocumentReference(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XAttrVerificationBObjChannel@",
                verificationDetails.getChannel(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XAttrVerificationBObjReVerTimeInterval@",
                verificationDetails.getReVerificationTimeInterval(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XAttrVerificationBObjReVerTimeDesignator@",
                verificationDetails.getReVerificationTimeDesignator(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XAttrVerificationBObjReVerDt@",
                verificationDetails.getReVerificationDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XAttrVerificationBObjStartDate@",
                verificationDetails.getStartDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XAttrVerificationBObjEndDate@",
                verificationDetails.getEndDate(), traceId);
        LogUtil.debug(log, "modifyTemplateForVerification", traceId,
                "Entering: modifyTemplateForVerification method in PartyInternalObjectsProcessor");

    }

    // OCT-19371 : Enhance API for Verification and validation attributes END

    public void prepareContactMethods(StringBuilder request, List<Phone> phones, List<Email> emails, List<Fax> faxes,
            List<SocialMedia> socialMedia, String traceId, String channel) {
        LogUtil.debug(log, "prepareContactMethods", traceId,
                "Entering: prepareOrgRequest method in PartyInternalObjectsProcessor");
        int finalContactCount = 0;
        if (null != channel
                && (OCVConstants.FENERGOANZX_CHANNEL.equalsIgnoreCase(channel)
                        || OCVConstants.AEGISANZX_CHANNEL.equalsIgnoreCase(channel) || OCVConstants.FENERGO_SOURCE_DELTA
                            .equals(channel))) {
            if (phones != null) {
                finalContactCount = finalContactCount
                        + prepareContMethPhone(request, phones, finalContactCount, channel, traceId);
            }
            if (emails != null) {
                finalContactCount = finalContactCount
                        + prepareContMethEmail(request, emails, finalContactCount, channel, traceId);
            }
        } else {
            if (phones != null) {
                finalContactCount = finalContactCount
                        + prepareContMethPhone(request, phones, finalContactCount, traceId);
            }
            if (emails != null) {
                finalContactCount = finalContactCount
                        + prepareContMethEmail(request, emails, finalContactCount, traceId);
            }
        }

        finalContactCount = finalContactCount
                + prepareFaxAndSocialMedia(finalContactCount, request, faxes, socialMedia, traceId);

        RequestTransfomerUtil.removeObjectFromTemplate(request, "<TCRMPartyContactMethodBObj>",
                "</TCRMPartyContactMethodBObj>", finalContactCount, traceId);
        LogUtil.debug(log, "prepareContactMethods", traceId,
                "Exit: prepareOrgRequest method in PartyInternalObjectsProcessor");
    }

    public int prepareFaxAndSocialMedia(int contactCount, StringBuilder request, List<Fax> faxes,
            List<SocialMedia> socialMedia, String traceId) {
        LogUtil.debug(log, "prepareContactMethods", traceId,
                "Entering: prepareOrgRequest method in PartyInternalObjectsProcessor");
        int finalContactCount = contactCount;
        if (faxes != null) {
            finalContactCount = finalContactCount + prepareContMethFax(request, faxes, finalContactCount, traceId);
        }
        if (socialMedia != null) {
            finalContactCount = finalContactCount
                    + prepareContMethSocialMedia(request, socialMedia, finalContactCount, traceId);
        }
        return finalContactCount;
    }

    public int prepareContMethFax(StringBuilder request, List<Fax> faxes, int locCount, String traceId) {
        int count = locCount;
        for (Fax fax : faxes) {
            if (count == 0) {
                modifytemplateForFax(request, fax, traceId);
                count++;
            } else {
                createAndModifyTemplateForFax(request, fax, traceId);
            }
        }
        return count;
    }

    public int prepareContMethSocialMedia(StringBuilder request, List<SocialMedia> socialMedia, int locCount,
            String traceId) {
        int count = locCount;
        for (SocialMedia sMedia : socialMedia) {
            if (count == 0) {
                modifytemplateForSocialMedia(request, sMedia, traceId);
                count++;
            } else {
                createAndModifyTemplateForSocialMedia(request, sMedia, traceId);
            }
        }
        return count;
    }

    public int prepareContMethEmail(StringBuilder request, List<Email> emails, int locCount, String traceId) {
        int count = locCount;
        for (Email email : emails) {
            String objectReferenceId = "";
            if (count == 0) {
                modifytemplateForEmails(request, email, objectReferenceId, traceId);
                count++;
            } else {
                createAndModifyTemplateForEmail(request, email, objectReferenceId, traceId);
            }
        }
        return count;
    }

    public int prepareContMethEmail(StringBuilder request, List<Email> emails, int locCount, String channel,
            String traceId) {
        int count = locCount;
        for (Email email : emails) {
            String objectReferenceId = generateIdForSecurityeMail(request, email, channel, traceId);
            if (count == 0) {
                modifytemplateForEmails(request, email, objectReferenceId, traceId);
                count++;
            } else {
                createAndModifyTemplateForEmail(request, email, objectReferenceId, traceId);
            }
            if (null != email.getEmailUsageType() && email.getEmailUsageType().equals(OCVConstants.SECURITY_EMAIL)
                    && null != email.getValidationDetails()) {
                prepareValidationDetails(request, email.getValidationDetails(), email.getEmailUsageType(),
                        objectReferenceId, OCVConstants.OCV_ENTITYNAME_CONTACTMETHOD, traceId);
            }
            if (null != email.getEmailUsageType() && email.getEmailUsageType().equals(OCVConstants.SECURITY_EMAIL)
                    && null != email.getValidationDetails()) {
                prepareVerificationDetails(request, email.getVerificationDetails(), email.getEmailUsageType(),
                        objectReferenceId, OCVConstants.OCV_ENTITYNAME_CONTACTMETHOD, traceId);
            }
        }
        return count;
    }

    public int prepareContMethPhone(StringBuilder request, List<Phone> phones, int locCount, String traceId) {
        int count = locCount;
        for (Phone phone : phones) {
            String objectReferenceId = "";
            if (count == 0) {
                modifytemplateForPhones(request, phone, objectReferenceId, traceId);
                count++;
            } else {
                createAndModifyTemplateForPhones(request, phone, objectReferenceId, traceId);
            }

        }
        return count;
    }

    public int prepareContMethPhone(StringBuilder request, List<Phone> phones, int locCount, String channel,
            String traceId) {
        int count = locCount;
        for (Phone phone : phones) {
            String objectReferenceId = generateIdForSecurityMobile(request, phone, channel, traceId);
            phone.setPreferred(OCVConstants.YES); // Always set true for ANZX mobile
            if (count == 0) {
                modifytemplateForPhones(request, phone, objectReferenceId, traceId);
                count++;
            } else {
                createAndModifyTemplateForPhones(request, phone, objectReferenceId, traceId);
            }

            if (null != phone.getPhoneUsageType() && phone.getPhoneUsageType().equals(OCVConstants.SECURITY_MOBILE)
                    && phone.getValidationDetails().size() > 0) {
                prepareValidationDetails(request, phone.getValidationDetails(), phone.getPhoneUsageType(),
                        objectReferenceId, OCVConstants.OCV_ENTITYNAME_CONTACTMETHOD, traceId);

            }
            if (null != phone.getPhoneUsageType() && phone.getPhoneUsageType().equals(OCVConstants.SECURITY_MOBILE)
                    && phone.getVerificationDetails().size() > 0) {
                prepareVerificationDetails(request, phone.getVerificationDetails(), phone.getPhoneUsageType(),
                        objectReferenceId, OCVConstants.OCV_ENTITYNAME_CONTACTMETHOD, traceId);

            }

        }
        return count;
    }

    public String generateIdForSecurityMobile(StringBuilder request, Phone phone, String channel, String traceId) {
        String objectReferenceId = null;

        if ((null != phone.getPhoneUsageType()
                && phone.getPhoneUsageType().equals(OCVConstants.SECURITY_MOBILE) && phone
                .getValidationDetails().size() > 0)
                || (null != phone.getPhoneUsageType()
                && phone.getPhoneUsageType().equals(OCVConstants.SECURITY_MOBILE) && phone
                        .getVerificationDetails().size() > 0)) {
            objectReferenceId = generateObjectReferenceId();
        }
        return objectReferenceId;
    }

    public String generateIdForSecurityeMail(StringBuilder request, Email email, String channel, String traceId) {
        String objectReferenceId = null;
        if ((null != email.getEmailUsageType() && email.getEmailUsageType().equals(OCVConstants.SECURITY_EMAIL) && email
                .getValidationDetails().size() > 0)
                || (null != email.getEmailUsageType()
                && email.getEmailUsageType().equals(OCVConstants.SECURITY_EMAIL) && email
                        .getVerificationDetails().size() > 0)) {
            objectReferenceId = generateObjectReferenceId();
        }
        return objectReferenceId;
    }

    public void preparePreferences(StringBuilder request, List<PrivacyPreference> privacyPreferences, String partyType,
            String traceId) {
        LogUtil.debug(log, "preparePreferences", traceId,
                "Entering: preparePreferences method in PartyInternalObjectsProcessor");
        int preferencesCount = 0;
        for (PrivacyPreference privacyPreference : privacyPreferences) {
            if (preferencesCount == 0) {
                modifytemplateForPref(request, privacyPreference, traceId);
                preferencesCount++;

            } else {
                if (partyType.equalsIgnoreCase("P")) {
                    createAndModifyTemplateForIndPreferences(request, privacyPreference, traceId);
                } else {
                    createAndModifyTemplateForOrgPreferences(request, privacyPreference, traceId);
                }
            }
        }
        RequestTransfomerUtil.removeObjectFromTemplate(request, "<TCRMPartyPrivPrefBObj>", "</TCRMPartyPrivPrefBObj>",
                preferencesCount, traceId);
        LogUtil.debug(log, "preparePreferences", traceId,
                "Exit: preparePreferences method in PartyInternalObjectsProcessor");
    }

    public void preparePartyAddress(StringBuilder request, List<Address> addressList, String traceId, String channel,
            String anzxAddressChannel,StreetSuffixConfig stSuffixCfg) {
        LogUtil.debug(log, "preparePartyAddress", traceId,
                "Entering: preparePartyAddress method in PartyInternalObjectsProcessor");
        int addressesCount = 0;
        for (Address address : addressList) {
            String objectReferenceId = getObjectRefIdForAddress(address);
            if (addressesCount == 0) {
                modifytemplateForAddresses(request, address, objectReferenceId, traceId, channel,
                        anzxAddressChannel, stSuffixCfg);
                addressesCount++;

            } else {
                createAndModifyTemplateForAddresses(request, address, objectReferenceId, traceId, channel,
                        anzxAddressChannel,stSuffixCfg);
            }
            prepareAddressValidationDetails(request, address, objectReferenceId, traceId);
        }
        RequestTransfomerUtil.removeObjectFromTemplate(request, "<TCRMPartyAddressBObj>", "</TCRMPartyAddressBObj>",
                addressesCount, traceId);
        LogUtil.debug(log, "preparePartyAddress", traceId,
                "Exit: preparePartyAddress method in PartyInternalObjectsProcessor");
    }

    private String getObjectRefIdForAddress(Address address) {
        String objectReferenceId = null;
        if (!ObjectUtils.isEmpty(address.getValidationDetails())) {
            objectReferenceId = generateObjectReferenceId();
        }
        return objectReferenceId;
    }

    public Map<String, String> prepareIdentifiers(StringBuilder request, List<Identifier> identifiers, String traceId,
            List<String> kycDocs) {
        LogUtil.debug(log, "prepareIdentifiers", traceId,
                "Entering: prepareIdentifiers method in PartyInternalObjectsProcessor");
        int identifiersCount = 0;
        int relIdentifiersCount = 0;
        String objectReferenceRelId = null;
        Map<String, String> objRefNumMap = new HashMap<String, String>();
        Map<String, String> relObjRefNumMap = new HashMap<String, String>();
        for (Identifier identifier : identifiers) {
            String objectReferenceId = null;
            if (null != kycDocs && kycDocs.contains(identifier.getIdentifierUsageType())
                    || !CollectionUtils.isEmpty(identifier.getValidationDetails())
                    || !CollectionUtils.isEmpty(identifier.getVerificationDetails())) {
                objectReferenceId = generateObjectReferenceId();
                objRefNumMap.put(identifier.getIdentifierUsageType(), objectReferenceId);
            }

            //Generate objectRefId for #interaction1 only when childIdentifier is present
            objectReferenceId = getObjectReferenceId(identifier, objectReferenceId,traceId);

            if (identifiersCount == 0) {
                modifytemplateForIdentifiers(request, identifier, objectReferenceId, traceId);
                identifiersCount++;

            } else {
                createAndModifyTemplateForIdentifier(request, identifier, objectReferenceId, traceId);
            }

            //Create TCRMPartyIdentificationBObj for Identifier child objects
            if (null != identifier.getRelatedIdentifiers() && identifier.getRelatedIdentifiers().size() > 0) {
                relIdentifiersCount++;
                modifytemplateForChildIdentifiers(request, identifier,
                        objectReferenceId, relObjRefNumMap,traceId);
                //Create XIdentifierRelationshipBObj
                createTemplateForRelIdentifier(request, identifier, objectReferenceId, relObjRefNumMap, traceId);
            }

            MaintainPartyAdditionalAttributes partyAdditionalsAttributes = new MaintainPartyAdditionalAttributes();
            partyAdditionalsAttributes.prepareAdditionalAttributes(request, OCVConstants.ENTITYNAME_IDENTIFIER,
                    identifier, objectReferenceId, traceId);
        }
        RequestTransfomerUtil.removeObjectFromTemplate(request, "<TCRMPartyIdentificationBObj>",
                "</TCRMPartyIdentificationBObj>", identifiersCount, traceId);
        RequestTransfomerUtil.removeObjectFromTemplate(request, "<XIdentifierRelationshipBObj>",
                "</XIdentifierRelationshipBObj>", relIdentifiersCount, traceId);
        LogUtil.debug(log, "prepareIdentifiers", traceId,
                "Exit: prepareIdentifiers method in PartyInternalObjectsProcessor");
        return objRefNumMap;
    }

    private String getObjectReferenceId(Identifier identifier, String objectReferenceId, String traceId) {
        LogUtil.debug(log, "getObjectReferenceId", traceId,
                "Entering: getObjectReferenceId method in PartyInternalObjectsProcessor");
        //Assign objectRefId for #interaction1 only when childIdentifier is present
        if (ObjectUtils.isEmpty(objectReferenceId) && !ObjectUtils.isEmpty(identifier.getRelatedIdentifiers())
                && identifier.getRelatedIdentifiers().size() > 0) {
            return generateObjectReferenceId();
        }

        LogUtil.debug(log, "getObjectReferenceId", traceId,
                "Exit: getObjectReferenceId method in PartyInternalObjectsProcessor");

        return objectReferenceId;
    }

    private void createTemplateForRelIdentifier(StringBuilder request, Identifier identifier, String referenceId,
            Map<String, String> relObjRefNumMap,String traceId) {

        LogUtil.debug(log, "createTemplateForRelIdentifier", traceId,
                "Entering: createTemplateForRelIdentifier method in PartyInternalObjectsProcessor");
        int relIdentifierCount = 0;
        if (null != identifier.getRelatedIdentifiers() && identifier.getRelatedIdentifiers().size() > 0) {

            for (RelatedIdentifier childIdentifier : identifier.getRelatedIdentifiers()) {
                if (relIdentifierCount == 0) {
                    createARelIdentifier(request, identifier,childIdentifier,referenceId,
                            relObjRefNumMap, traceId);
                    relIdentifierCount++;
                } else {
                    createAndModifyRelIdentifier(request, identifier, childIdentifier, referenceId,
                            relObjRefNumMap, traceId);
                }
            }
        }
        LogUtil.debug(log, "createTemplateForRelIdentifier", traceId,
                "Exit: createTemplateForRelIdentifier method in PartyInternalObjectsProcessor");


    }

    //Related Identifier code change
    private void modifytemplateForChildIdentifiers(StringBuilder request, Identifier identifier,
            String objectReferenceId, Map<String, String> relObjRefNumMap, String traceId) {
        LogUtil.debug(log, "modifytemplateForChildIdentifiers", traceId,
                "Entering: modifytemplateForChildIdentifiers method in PartyInternalObjectsProcessor");
        for (RelatedIdentifier childIdentifier : identifier.getRelatedIdentifiers()) {
            //Create TCRMPartyIdentificationBObj for Child Identifiers
            String objectReferenceRelId = generateObjectReferenceId();
            relObjRefNumMap.put(childIdentifier.getIdentifier(),objectReferenceRelId);
            createAndModifyTemplateForChildIdentifier(request, childIdentifier, objectReferenceRelId, traceId);
        }

        LogUtil.debug(log, "modifytemplateForChildIdentifiers", traceId,
                "Exit: modifytemplateForChildIdentifiers method in PartyInternalObjectsProcessor");

    }

    private void createARelIdentifier(StringBuilder request, Identifier identifier,
            RelatedIdentifier childIdentifier, String objectReferenceId,
            Map<String,String> relObjRefNumMap,String traceId) {
        LogUtil.debug(log, "createARelIdentifier", traceId,
                "Entering: createARelIdentifier method in PartyInternalObjectsProcessor");
        RequestTransfomerUtil.modifyTemplate(request, "@RelTpCdValue@",
                identifier.getIdentifierUsageType() + " " + "-" + " "
                        + childIdentifier.getIdentifierUsageType(), traceId);
        if (! MapUtils.isEmpty(relObjRefNumMap)) {
            relObjRefNumMap.forEach((k, v) -> {
                if (k.equals(childIdentifier.getIdentifier())) {
                    RequestTransfomerUtil.modifyTemplate(request, "@ToIdentifierId@", v, traceId);
                }
            });
        }
        RequestTransfomerUtil.modifyTemplate(request, "@FromIdentifierId@", objectReferenceId, traceId);
        RequestTransfomerUtil
                .modifyTemplate(request, "@FromIdentifierValue@", identifier.getIdentifierUsageType(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ToIdentifierValue@",
                childIdentifier.getIdentifierUsageType(),
                traceId);

        LogUtil.debug(log, "createARelIdentifier", traceId,
                "Exit: createARelIdentifier method in PartyInternalObjectsProcessor");

    }

    private void createAndModifyRelIdentifier(StringBuilder request, Identifier identifier,
            RelatedIdentifier childIdentifier, String objectReferenceId, Map<String,String> relObjRefNumMap,
            String traceId) {
        LogUtil.debug(log, "createAndModifyRelIdentifier", traceId,
                "Entering: createAndModifyRelIdentifier method in PartyInternalObjectsProcessor");
        LogUtil.debug(log, "createAndModifyTemplateForIdentifier", traceId,
                "Entering: createAndModifyTemplateForIdentifier method in PartyInternalObjectsProcessor");
        String identifierRequest = MDMRequestTemplates.MAINTAIN_PARTY_RELATED_IDENTIFIER_REQUEST;
        request.insert(request.indexOf("<XIdentifierRelationshipBObj>"), identifierRequest);
        createARelIdentifier(request, identifier,childIdentifier, objectReferenceId, relObjRefNumMap,traceId);
        LogUtil.debug(log, "createAndModifyRelIdentifier", traceId,
                "Exit: createAndModifyRelIdentifier method in PartyInternalObjectsProcessor");

    }


    public void prepareContEquivs(StringBuilder request, List<SourceSystem> sourceSystems, String partyType,
            String traceId) {
        LogUtil.debug(log, "prepareContEquivs", traceId,
                "Entering: prepareContEquivs method in PartyInternalObjectsProcessor");
        int sourceSystemsCount = 0;
        for (SourceSystem sourceSystem : sourceSystems) {
            if (sourceSystemsCount == 0) {
                modifytemplateForSourceSystems(request, sourceSystem, traceId);
                sourceSystemsCount++;
            } else {
                if (partyType.equalsIgnoreCase("P")) {
                    createModifyTemplateForSourceSystemForInd(request, sourceSystem, traceId);
                } else {
                    createModifyTemplateForSourceSystemForOrg(request, sourceSystem, traceId);
                }
            }
        }
        RequestTransfomerUtil.removeObjectFromTemplate(request, "<TCRMAdminContEquivBObj>",
                "</TCRMAdminContEquivBObj>", sourceSystemsCount, traceId);
        LogUtil.debug(log, "prepareContEquivs", traceId,
                "Exit: prepareContEquivs method in PartyInternalObjectsProcessor");
    }

    public void prepareEvMatchStatus(StringBuilder request, KycVerificationMethods method,
            List<EVMatchStatus> evMatchStatusList, String traceId) {
        LogUtil.debug(log, "prepareEvMatchStatus", traceId,
                "Entering: prepareEvMatchStatus method in PartyInternalObjectsProcessor");
        int evMatchStatusCount = 0;
        for (EVMatchStatus evMatchStatus : evMatchStatusList) {
            modifytemplateForEvMatchStatus(request, method,evMatchStatus, traceId);
            evMatchStatusCount++;
        }
        RequestTransfomerUtil.removeObjectFromTemplate(request, "<XEVMatchStatusBObj>", "</XEVMatchStatusBObj>",
                evMatchStatusCount, traceId);
        LogUtil.debug(log, "prepareEvMatchStatus", traceId,
                "Exit: prepareEvMatchStatus method in PartyInternalObjectsProcessor");
    }

    public void createAndModifyTemplateForOrgPreferences(StringBuilder request, PrivacyPreference privacyPreference,
            String traceId) {
        LogUtil.debug(log, "createAndModifyTemplateForOrgPreferences", traceId,
                "Entering: createAndModifyTemplateForOrgPreferences method in PartyInternalObjectsProcessor");
        String preferenceRequest = MDMRequestTemplates.MAINTAIN_PARTY_PREFERENCE_REQUEST;
        request.insert(request.indexOf("<TCRMPartyDemographicsBObj>"), preferenceRequest);
        modifytemplateForPref(request, privacyPreference, traceId);
        LogUtil.debug(log, "createAndModifyTemplateForOrgPreferences", traceId,
                "Exit: createAndModifyTemplateForOrgPreferences method in PartyInternalObjectsProcessor");
    }

    public void createAndModifyTemplateForIndPreferences(StringBuilder request, PrivacyPreference privacyPreference,
            String traceId) {
        LogUtil.debug(log, "createAndModifyTemplateForIndPreferences", traceId,
                "Entering: createAndModifyTemplateForIndPreferences method in PartyInternalObjectsProcessor");
        String preferenceRequest = MDMRequestTemplates.MAINTAIN_PARTY_PREFERENCE_REQUEST;
        request.insert(request.indexOf("</TCRMPersonBObj>"), preferenceRequest);
        modifytemplateForPref(request, privacyPreference, traceId);
        LogUtil.debug(log, "createAndModifyTemplateForIndPreferences", traceId,
                "Exit: createAndModifyTemplateForIndPreferences method in PartyInternalObjectsProcessor");
    }

    public void modifytemplateForPref(StringBuilder request, PrivacyPreference privacyPreference, String traceId) {
        LogUtil.debug(log, "modifytemplateForPreferences", traceId,
                "Entering: modifytemplateForPreferences method in PartyInternalObjectsProcessor");
        RequestTransfomerUtil.modifyTemplate(request, "@PrivPrefEntity@", "CONTACT", traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PrivPrefReasonValue@", privacyPreference.getPreferenceReason(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PartyPrivPrefSourceIdentValue@", privacyPreference.getSource(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ValueString@", privacyPreference.getPreferenceValue(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PartyPrivPrefStartDate@", privacyPreference.getStartDate(),
                traceId);
        RequestTransfomerUtil
                .modifyTemplate(request, "@PartyPrivPrefEndDate@", privacyPreference.getEndDate(), traceId);
        RequestTransfomerUtil
                .modifyTemplate(request, "@PrivPrefValue@", privacyPreference.getPreferenceType(), traceId);
        LogUtil.debug(log, "modifytemplateForPreferences", traceId,
                "Exit: modifytemplateForPreferences method in PartyInternalObjectsProcessor");
    }

    public void createAndModifyTemplateForIdentifier(StringBuilder request, Identifier identifier,
            String objectReferenceId, String traceId) {
        LogUtil.debug(log, "createAndModifyTemplateForIdentifier", traceId,
                "Entering: createAndModifyTemplateForIdentifier method in PartyInternalObjectsProcessor");
        String identifierRequest = MDMRequestTemplates.MAINTAIN_PARTY_IDENTIFIER_REQUEST;
        request.insert(request.indexOf("<TCRMAdminContEquivBObj>"), identifierRequest);
        modifytemplateForIdentifiers(request, identifier, objectReferenceId, traceId);
        LogUtil.debug(log, "createAndModifyTemplateForIdentifier", traceId,
                "Exit: createAndModifyTemplateForIdentifier method in PartyInternalObjectsProcessor");
    }

    public void createAndModifyTemplateForChildIdentifier(StringBuilder request, RelatedIdentifier childIdentifier,
            String objectReferenceId, String traceId) {
        LogUtil.debug(log, "createAndModifyTemplateForIdentifier", traceId,
                "Entering: createAndModifyTemplateForIdentifier method in PartyInternalObjectsProcessor");
        String childIdentifierRequest = MDMRequestTemplates.MAINTAIN_PARTY_CHILD_IDENTIFIER_REQUEST;
        request.insert(request.indexOf("<TCRMAdminContEquivBObj>"), childIdentifierRequest);
        preparetemplateForChildIdentifiers(request, childIdentifier, objectReferenceId, traceId);
        LogUtil.debug(log, "createAndModifyTemplateForIdentifier", traceId,
                "Exit: createAndModifyTemplateForIdentifier method in PartyInternalObjectsProcessor");
    }

    public void modifytemplateForIdentifiers(StringBuilder request, Identifier identifier, String objectReferenceId,
            String traceId) {
        LogUtil.debug(log, "modifytemplateForIdentifiers", traceId,
                "Entering: modifytemplateForIdentifiers method in PartyInternalObjectsProcessor");
        RequestTransfomerUtil.modifyTemplate(request, "@IdentifierObjectReferenceId@", objectReferenceId, traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@IdentificationValue@", identifier.getIdentifierUsageType(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@IdentificationNumber@", identifier.getIdentifier(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@IdentificationStatusValue@", identifier.getStatus(), traceId);
        RequestTransfomerUtil
                .modifyTemplate(request, "@IdentificationExpiryDate@", identifier.getExpiryDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PartyIdentificatioStartDate@", identifier.getStartDate(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PartyIdentificatioEndDate@", identifier.getEndDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PartyIdentificatioSourceIdentifierValue@",
                identifier.getSource(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XPartyIdentificationXOccurenceNum@", identifier.getSequence(),
                traceId);
        RequestTransfomerUtil
                .modifyTemplate(request, "@XCountryValue@", identifier.getIdentificationCountry(), traceId);
        RequestTransfomerUtil
                .modifyTemplate(request, "@XProvStateValue@", identifier.getIdentificationState(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@IdentificationIssueLocation@",
                identifier.getIdentificationIssueLocation(), traceId);
        LogUtil.debug(log, "modifytemplateForIdentifiers", traceId,
                "Exit: modifytemplateForIdentifiers method in PartyInternalObjectsProcessor");
    }

    public void preparetemplateForChildIdentifiers(StringBuilder request, RelatedIdentifier relIdentifier,
            String objectReferenceId, String traceId) {
        LogUtil.debug(log, "preparetemplateForChildIdentifiers", traceId,
                "Entering: preparetemplateForChildIdentifiers method in PartyInternalObjectsProcessor");
        RequestTransfomerUtil.modifyTemplate(request, "@IdentifierObjectReferenceId@", objectReferenceId, traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@IdentificationValue@", relIdentifier.getIdentifierUsageType(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@IdentificationNumber@", relIdentifier.getIdentifier(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PartyIdentificatioSourceIdentifierValue@",
                relIdentifier.getSource(), traceId);
        RequestTransfomerUtil
                .modifyTemplate(request, "@XCountryValue@", relIdentifier.getIdentificationCountry(), traceId);
        RequestTransfomerUtil
                .modifyTemplate(request, "@XProvStateValue@", relIdentifier.getIdentificationState(), traceId);
        LogUtil.debug(log, "preparetemplateForChildIdentifiers", traceId,
                "Exit: preparetemplateForChildIdentifiers method in PartyInternalObjectsProcessor");
    }

    public void createAndModifyTemplateForEmail(StringBuilder request, Email email, String objectReferenceId,
            String traceId) {
        LogUtil.debug(log, "createAndModifyTemplateForEmail", traceId,
                "Entering: createAndModifyTemplateForEmail method in PartyInternalObjectsProcessor");
        String contactMethod = MDMRequestTemplates.MAINTAIN_PARTY_CONTACTMETHOD_REQUEST;
        request.insert(request.indexOf("<TCRMPartyIdentificationBObj>"), contactMethod);
        modifytemplateForEmails(request, email, objectReferenceId, traceId);
        LogUtil.debug(log, "createAndModifyTemplateForEmail", traceId,
                "Exit: createAndModifyTemplateForEmail method in PartyInternalObjectsProcessor");
    }

    public void createAndModifyTemplateForFax(StringBuilder request, Fax fax, String traceId) {
        LogUtil.debug(log, "createAndModifyTemplateForFax", traceId,
                "Entering: createAndModifyTemplateForFax method in PartyInternalObjectsProcessor");
        String contactMethod = MDMRequestTemplates.MAINTAIN_PARTY_CONTACTMETHOD_REQUEST;
        request.insert(request.indexOf("<TCRMPartyIdentificationBObj>"), contactMethod);
        modifytemplateForFax(request, fax, traceId);
        LogUtil.debug(log, "createAndModifyTemplateForFax", traceId,
                "Exit: createAndModifyTemplateForFax method in PartyInternalObjectsProcessor");
    }

    public void createAndModifyTemplateForSocialMedia(StringBuilder request, SocialMedia sMedia, String traceId) {
        LogUtil.debug(log, "createAndModifyTemplateForSocialMedia", traceId,
                "Entering: createAndModifyTemplateForSocialMedia method in PartyInternalObjectsProcessor");
        String contactMethod = MDMRequestTemplates.MAINTAIN_PARTY_CONTACTMETHOD_REQUEST;
        request.insert(request.indexOf("<TCRMPartyIdentificationBObj>"), contactMethod);
        modifytemplateForSocialMedia(request, sMedia, traceId);
        LogUtil.debug(log, "createAndModifyTemplateForSocialMedia", traceId,
                "Exit: createAndModifyTemplateForSocialMedia method in PartyInternalObjectsProcessor");
    }

    public void modifytemplateForEmails(StringBuilder request, Email email, String objectReferenceId, String traceId) {
        LogUtil.debug(log, "modifytemplateForEmails", traceId,
                "Entering: modifytemplateForEmails method in PartyInternalObjectsProcessor");

        RequestTransfomerUtil.modifyTemplate(request, "@ContactValidationVerificationObjectReferenceId@",
                objectReferenceId, traceId);

        RequestTransfomerUtil.modifyTemplate(request, "@ContactMethodUsageValue@", email.getEmailUsageType(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PreferredContactMethodIndicator@", email.getPreferred(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PartyContactMethodStartDate@", email.getStartDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PartyContactMethodEndDate@", email.getEndDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PartyContactMethodSourceIdentifierValue@", email.getSource(),
                traceId);
        RequestTransfomerUtil
                .modifyTemplate(request, "@PartyContactMethodXOccurenceNum@", email.getSequence(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ContactMethodReferenceNumber@", email.getEmail(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ContactMethodValue@", "Email Address", traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ContactMethodStatus@", email.getStatus(), traceId);
        
        //Change start for https://jira.service.anz/browse/OCT-25769
        RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@ContactMethodContactName@", traceId);
        RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@ContactMethodContactTitle@",traceId);
        RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@ContactMethodPrefInd@", traceId);
        RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@TCRMPhoneNumberBObjStartTag@", traceId);
        RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@ContactMethodPhoneCountryCode@", traceId);
        RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@ContactMethodPhoneNumber@", traceId);
        RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@TCRMPhoneNumberBObjEndTag@", traceId);
        //Change start for https://jira.service.anz/browse/OCT-25769
        LogUtil.debug(log, "modifytemplateForEmails", traceId,
                "Exit: modifytemplateForEmails method in PartyInternalObjectsProcessor");
    }

    public void modifytemplateForFax(StringBuilder request, Fax fax, String traceId) {
        LogUtil.debug(log, "modifytemplateForFax", traceId,
                "Entering: modifytemplateForFax method in PartyInternalObjectsProcessor");
        RequestTransfomerUtil
                .modifyTemplate(request, "@ContactValidationVerificationObjectReferenceId@", null, traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ContactMethodUsageValue@", fax.getFaxUsageType(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PreferredContactMethodIndicator@", fax.getPreferred(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PartyContactMethodStartDate@", fax.getStartDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PartyContactMethodEndDate@", fax.getEndDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PartyContactMethodSourceIdentifierValue@", fax.getSource(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PartyContactMethodXOccurenceNum@", fax.getSequence(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ContactMethodReferenceNumber@", fax.getFax(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ContactMethodValue@", "Telephone Number", traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ContactMethodStatus@", fax.getStatus(), traceId);
        
        //Change start for https://jira.service.anz/browse/OCT-25769
        RequestTransfomerUtil.modifyTemplate(request, "@ContactMethodContactName@", fax.getContactName(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ContactMethodContactTitle@", fax.getContactTitle(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ContactMethodPrefInd@", fax.getContactPreferredInd(), traceId);
        RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@TCRMPhoneNumberBObjStartTag@", traceId);
        RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@ContactMethodPhoneCountryCode@", traceId);
        RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@ContactMethodPhoneNumber@", traceId);
        RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@TCRMPhoneNumberBObjEndTag@", traceId);
        //Change end for https://jira.service.anz/browse/OCT-25769
        LogUtil.debug(log, "modifytemplateForFax", traceId,
                "Exit: modifytemplateForFax method in PartyInternalObjectsProcessor");
    }

    public void modifytemplateForSocialMedia(StringBuilder request, SocialMedia socialMedia, String traceId) {
        LogUtil.debug(log, "modifytemplateForSocialMedia", traceId,
                "Entering: modifytemplateForSocialMedia method in PartyInternalObjectsProcessor");
        RequestTransfomerUtil
                .modifyTemplate(request, "@ContactValidationVerificationObjectReferenceId@", null, traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ContactMethodUsageValue@", socialMedia.getSocialMediaType(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PreferredContactMethodIndicator@", "", traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PartyContactMethodStartDate@", socialMedia.getStartDate(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PartyContactMethodEndDate@", socialMedia.getEndDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PartyContactMethodSourceIdentifierValue@",
                socialMedia.getSource(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PartyContactMethodXOccurenceNum@", socialMedia.getSequence(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ContactMethodReferenceNumber@", socialMedia.getSocialMedia(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ContactMethodValue@", "Social Media", traceId);

        RequestTransfomerUtil.modifyTemplate(request, "@ContactMethodStatus@", socialMedia.getStatus(), traceId);
        //Change start for https://jira.service.anz/browse/OCT-25769
        RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@ContactMethodContactName@", traceId);
        RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@ContactMethodContactTitle@",traceId);
        RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@ContactMethodPrefInd@", traceId);
        RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@TCRMPhoneNumberBObjStartTag@", traceId);
        RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@ContactMethodPhoneCountryCode@", traceId);
        RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@ContactMethodPhoneNumber@", traceId);
        RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@TCRMPhoneNumberBObjEndTag@", traceId);
        //Change end for https://jira.service.anz/browse/OCT-25769
        LogUtil.debug(log, "modifytemplateForSocialMedia", traceId,
                "Exit: modifytemplateForSocialMedia method in PartyInternalObjectsProcessor");
    }

    public void createAndModifyTemplateForPhones(StringBuilder request, Phone phone, String objectReferenceId,
            String traceId) {
        LogUtil.debug(log, "createAndModifyTemplateForPhones", traceId,
                "Entering: createAndModifyTemplateForPhones method in PartyInternalObjectsProcessor");
        String contactMethod = MDMRequestTemplates.MAINTAIN_PARTY_CONTACTMETHOD_REQUEST;
        request.insert(request.indexOf("<TCRMPartyIdentificationBObj>"), contactMethod);
        modifytemplateForPhones(request, phone, objectReferenceId, traceId);
        LogUtil.debug(log, "createAndModifyTemplateForPhones", traceId,
                "Exit: createAndModifyTemplateForPhones method in PartyInternalObjectsProcessor");
    }

    public void modifytemplateForPhones(StringBuilder request, Phone phone, String objectReferenceId, String traceId) {
        LogUtil.debug(log, "modifytemplateForPhones", traceId,
                "Entering: modifytemplateForPhones method in PartyInternalObjectsProcessor");

        RequestTransfomerUtil.modifyTemplate(request, "@ContactValidationVerificationObjectReferenceId@",
                objectReferenceId, traceId);

        RequestTransfomerUtil.modifyTemplate(request, "@ContactMethodUsageValue@", phone.getPhoneUsageType(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PreferredContactMethodIndicator@", phone.getPreferred(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PartyContactMethodStartDate@", phone.getStartDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PartyContactMethodEndDate@", phone.getEndDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PartyContactMethodSourceIdentifierValue@", phone.getSource(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PartyContactMethodXOccurenceNum@", phone.getSequence(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ContactMethodReferenceNumber@", phone.getPhone(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ContactMethodValue@", "Telephone Number", traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ContactMethodStatus@", phone.getStatus(), traceId);

        // Change start for https://jira.service.anz/browse/OCT-25769
        RequestTransfomerUtil.modifyTemplate(request, "@ContactMethodContactName@", phone.getContactName(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ContactMethodContactTitle@", phone.getContactTitle(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ContactMethodPrefInd@", phone.getContactPreferredInd(),
                traceId);
        StandardisedPhone standardisedPhone = phone.getStandardisedPhone();
        if (null != standardisedPhone && OCVConstants.TRUE.equalsIgnoreCase(standardisedPhone.getValidationOutcome())) {
            RequestTransfomerUtil.modifyTemplate(request, "@TCRMPhoneNumberBObjStartTag@", "TCRMPhoneNumberBObj",
                    traceId);
            RequestTransfomerUtil.modifyTemplate(request, "@ContactMethodPhoneNumber@",
                    standardisedPhone.getStandardisedPhoneNumber(), traceId);
            RequestTransfomerUtil.modifyTemplate(request, "@ContactMethodPhoneCountryCode@",
                    standardisedPhone.getStandardisedPhoneCountryCode(), traceId);
            RequestTransfomerUtil.modifyTemplate(request, "@TCRMPhoneNumberBObjEndTag@", "TCRMPhoneNumberBObj",
                    traceId);
        } else {
            RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@TCRMPhoneNumberBObjStartTag@", traceId);
            RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@ContactMethodPhoneCountryCode@", traceId);
            RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@ContactMethodPhoneNumber@", traceId);
            RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@TCRMPhoneNumberBObjEndTag@", traceId);
        }
        // Change end for https://jira.service.anz/browse/OCT-25769
        LogUtil.debug(log, "modifytemplateForPhones", traceId,
                "Exit: modifytemplateForPhones method in PartyInternalObjectsProcessor");
    }

    public void createAndModifyTemplateForAddresses(StringBuilder request, Address address, String objectReferenceId,
            String traceId, String channel, String anzxAddressChannel, StreetSuffixConfig stSuffixCfg) {
        LogUtil.debug(log, "createAndModifyTemplateForAddresses", traceId,
                "Entering: createAndModifyTemplateForAddresses method in PartyInternalObjectsProcessor");
        String addressRequest = MDMRequestTemplates.MAINTAIN_PARTY_ADDR_REQ_1 + MDMRequestTemplates.ADDR_REQUEST_2
                + MDMRequestTemplates.ADDR_REQUEST_3;
        request.insert(request.indexOf("<TCRMPartyContactMethodBObj>"), addressRequest);
        modifytemplateForAddresses(request, address, objectReferenceId, traceId, channel,
                anzxAddressChannel,stSuffixCfg);
        LogUtil.debug(log, "createAndModifyTemplateForAddresses", traceId,
                "Exit: createAndModifyTemplateForAddresses method in PartyInternalObjectsProcessor");
    }

    public void modifytemplateForAddresses(StringBuilder request, Address address, String objectReferenceId,
            String traceId, String channel, String anzxAddressChannel, StreetSuffixConfig stSuffixCfg) {
        LogUtil.debug(log, "modifytemplateForAddresses", traceId,
                "Entering: modifytemplateForAddresses method" + " in PartyInternalObjectsProcessor");
        RequestTransfomerUtil.modifyTemplate(request, "@AddressValidationObjRefId@", objectReferenceId, traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@AddressValidationObjectReferenceId@",
                objectReferenceId, traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@AddressUsageValue@", address.getAddressUsageType(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PartyAddressStartDate@", address.getStartDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PartyAddressEndDate@", address.getEndDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PartyAddressSourceIdentifierValuee@",
                address.getSource(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@AddressLineOne@", address.getAddressLineOne(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@AddressLineTwo@", address.getAddressLineTwo(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@AddressLineThree@", address.getAddressLineThree(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@City@", address.getCity(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ZipPostalCode@", address.getPostalCode(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ProvinceStateValue@", address.getState(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@CountryValue@", address.getCountry(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@Region@", address.getRegion(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@DelId@", address.getDeliveryId(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XCountryName@", address.getCountry(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XAddressLineFour@", address.getAddressLineFour(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XAddressLineFive@", address.getAddressLineFive(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XAddressLineSix@", address.getAddressLineSix(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ResidenceNumber@", address.getResidenceNumber(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@StreetNumber@", address.getStreetNumber(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@StreetPrefix@", address.getStreetPrefix(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@StreetName@", address.getStreetName(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@StreetSuffix@",
                    stSuffixCfg.getPropertyValue(StringUtils.isNotBlank(address.getStreetSuffix())
                            ? address.getStreetSuffix() : ""), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@BuildingName@", address.getBuildingName(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XLevelType@", address.getLevel(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@XLevelNum@", address.getLevelNumber(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@CountyCode@", address.getCountyCode(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@LatitudeDegrees@", address.getLatitudeDegrees(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@LongitudeDegrees@", address.getLongitudeDegrees(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ZipPostalBarCode@", address.getPostalBarCode(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PreDirectional@", address.getPreDirectional(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@PostDirectional@", address.getPostDirectional(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@BoxDesignator@", address.getBoxDesignator(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@StnId@", address.getStnId(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ResidenceValue@", address.getResidenceType(), traceId);
        transformPoBoxAddress(request, address, traceId, channel, anzxAddressChannel);
        LogUtil.debug(log, "modifytemplateForAddresses", traceId,
                "Exit: modifytemplateForAddresses method in PartyInternalObjectsProcessor");

    }

    private void transformPoBoxAddress(StringBuilder request, Address address, String traceId, String channel,
            String anzxAddressChannel) {
        Long startTime = System.currentTimeMillis();
        LogUtil.debug(log, "transformPoBoxAddress", traceId,
                "Entering: transformPoBoxAddress method in PartyInternalObjectsProcessor");
        if (StringUtils.isNotBlank(anzxAddressChannel)) {
            List<String> channelsList = new ArrayList<String>(Arrays.asList(anzxAddressChannel.split(",")));
            String stnInfo = address.getStnInfo();
            String boxId = address.getBoxId();
            if (channelsList.contains(channel)) {
                LogUtil.debug(log, "transformPoBoxAddress", traceId, "Channel from header is an ANZx channel.");
                RequestTransfomerUtil.modifyTemplate(request, "@DelDesignator@", stnInfo, traceId);
                RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@StnInfo@", traceId);
                LogUtil.debug(log, "transformPoBoxAddress", traceId, "Assigning BoxId to DelInfo.");
                RequestTransfomerUtil.modifyTemplate(request, "@DelInfo@", boxId, traceId);
                RequestTransfomerUtil.removeAttributeTagFromTemplate(request, "@BoxId@", traceId);
            } else {
                RequestTransfomerUtil.modifyTemplate(request, "@StnInfo@", address.getStnInfo(), traceId);
                RequestTransfomerUtil.modifyTemplate(request, "@BoxId@", address.getBoxId(), traceId);
                RequestTransfomerUtil.modifyTemplate(request, "@DelDesignator@", address.getDelDesignator(), traceId);
                RequestTransfomerUtil.modifyTemplate(request, "@DelInfo@", address.getDelInfo(), traceId);
            }
        }

        Long endTime = System.currentTimeMillis();
        LogUtil.debug(log, "transformPoBoxAddress", traceId,
                "Exit: transformPoBoxAddress method in PartyInternalObjectsProcessor", (endTime - startTime));
    }

    public void createModifyTemplateForSourceSystemForInd(StringBuilder request, SourceSystem sourceSystem,
            String traceId) {
        LogUtil.debug(log, "createAndModifyTemplateForSourceSystems", traceId,
                "Entering: createAndModifyTemplateForSourceSystems method in PartyInternalObjectsProcessor");
        String contequivRequest = MDMRequestTemplates.MAINTAIN_PARTY_CONTEQUIV_REQUEST;
        request.insert(request.indexOf("<TCRMPersonNameBObj>"), contequivRequest);
        modifytemplateForSourceSystems(request, sourceSystem, traceId);
        LogUtil.debug(log, "createAndModifyTemplateForSourceSystems", traceId,
                "Exit: createAndModifyTemplateForSourceSystems method in PartyInternalObjectsProcessor");
    }

    public void createModifyTemplateForSourceSystemForOrg(StringBuilder request, SourceSystem sourceSystem,
            String traceId) {
        LogUtil.debug(log, "createAndModifyTemplateForSourceSystems", traceId,
                "Entering: createAndModifyTemplateForSourceSystems method in PartyInternalObjectsProcessor");
        String contequivRequest = MDMRequestTemplates.MAINTAIN_PARTY_CONTEQUIV_REQUEST;
        request.insert(request.indexOf("<TCRMPartyPrivPrefBObj>"), contequivRequest);
        modifytemplateForSourceSystems(request, sourceSystem, traceId);
        LogUtil.debug(log, "createAndModifyTemplateForSourceSystems", traceId,
                "Exit: createAndModifyTemplateForSourceSystems method in PartyInternalObjectsProcessor");
    }

    public void modifytemplateForSourceSystems(StringBuilder request, SourceSystem sourceSystem, String traceId) {
        LogUtil.debug(log, "modifytemplateForSourceSystems", traceId,
                "Entering: modifytemplateForSourceSystems method in PartyInternalObjectsProcessor");
        RequestTransfomerUtil.modifyTemplate(request, "@AdminPartyId@", sourceSystem.getSourceSystemId(), traceId);
        RequestTransfomerUtil
                .modifyTemplate(request, "@AdminSystemValue@", sourceSystem.getSourceSystemName(), traceId);
        LogUtil.debug(log, "modifytemplateForSourceSystems", traceId,
                "Exit: modifytemplateForSourceSystems method in PartyInternalObjectsProcessor");
    }

    private String generateObjectReferenceId() {
        return System.currentTimeMillis() + String.valueOf(random.nextInt(9000) + 1000);
    }

    /*
     * Method to prepare Document Reference- Not in Beta scope, need to revisit
     */
    public void prepareDocumentReferences(Party party, StringBuilder request, String traceId) {
        LogUtil.debug(log, "prepareDocumentReferences", traceId,
                "Entering: prepareDocumentReferences method in PartyInternalObjectsProcessor");
        int docRefcount = 0;
        if (!CollectionUtils.isEmpty(party.getIdentifiers())) {
            for (DocumentReference docRef : party.getIdentifiers().get(0).getDocumentReference()) {
                if (docRefcount == 0) {
                    modifytemplateForDocumentReference(request, docRef, traceId);
                    docRefcount++;

                } else {
                    createAndModifyTemplateForDocumentReference(request, docRef, traceId);
                }
            }
        }
        RequestTransfomerUtil.removeObjectFromTemplate(request, "<ContentReferenceBObj>", "</ContentReferenceBObj>",
                docRefcount, traceId);
        LogUtil.debug(log, "prepareDocumentReferences", traceId,
                "Exit: prepareDocumentReferences method in PartyInternalObjectsProcessor");
    }

    private void createAndModifyTemplateForDocumentReference(StringBuilder request, DocumentReference docRef,
            String traceId) {
        LogUtil.debug(log, "createAndModifyTemplateForDocumentReference", traceId,
                "Entering: createAndModifyTemplateForDocumentReference method in PartyInternalObjectsProcessor");
        String contequivRequest = MDMRequestTemplates.MAINTAIN_PARTY_DOCUMENT_REFERENCE_REQUEST;
        request.insert(request.indexOf("<ConsentBObj>"), contequivRequest);
        modifytemplateForDocumentReference(request, docRef, traceId);
        LogUtil.debug(log, "createAndModifyTemplateForDocumentReference", traceId,
                "Exit: createAndModifyTemplateForDocumentReference method in PartyInternalObjectsProcessor");
    }

    public void modifytemplateForDocumentReference(StringBuilder request, DocumentReference docRef, String traceId) {
        LogUtil.debug(log, "modifytemplateForDocumentReference", traceId,
                "Entering: modifytemplateForDocumentReference method in PartyInternalObjectsProcessor");
        RequestTransfomerUtil.modifyTemplate(request, "@ContentRefPart1@", docRef.getContentRef1(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ContentRefPart2@", docRef.getContentRef2(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ContentRefPart3@", docRef.getContentRef3(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ContentRefPart4@", docRef.getContentRef4(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@ContentVersion@", docRef.getContentVersion(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@DocRefStartDate@", docRef.getStartDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@DocRefEndDate@", docRef.getEndDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@RepositoryName@", docRef.getRepositoryType(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@DocumentName@", docRef.getDocumentName(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@Author@", docRef.getAuthor(), traceId);
        LogUtil.debug(log, "modifytemplateForDocumentReference", traceId,
                "Exit: modifytemplateForDocumentReference method in PartyInternalObjectsProcessor");
    }

    public void modifytemplateForEvMatchStatus(StringBuilder request, KycVerificationMethods method,
            EVMatchStatus evMatchStatus, String traceId) {
        LogUtil.debug(log, "modifytemplateForEvMatchStatus", traceId,
                "Entering: modifytemplateForEvMatchStatus method in PartyInternalObjectsProcessor");
        String evMatchStatusRequest = MDMRequestTemplates.MAINTAIN_PARTY_EV_MATCH_STATUS_REQUEST;
        if (method.getVerificationMethodType().equalsIgnoreCase(OCVConstants.KYC_METHOD_IDEV)
                || method.getVerificationMethodType().equalsIgnoreCase(OCVConstants.KYC_METHOD_IDAEV)) {
            request.insert(request.lastIndexOf("</XEIDVerificationBObj>"), evMatchStatusRequest);
        }
        createAndModifyTemplateForEvMatchStatus(request, method, evMatchStatus, traceId);
        LogUtil.debug(log, "modifytemplateForEvMatchStatus", traceId,
                "Exit: modifytemplateForEvMatchStatus method in PartyInternalObjectsProcessor");
    }

    private void createAndModifyTemplateForEvMatchStatus(StringBuilder request, KycVerificationMethods method,
            EVMatchStatus evMatchStatus, String traceId) {
        LogUtil.debug(log, "createAndModifyTemplateForEvMatchStatus", traceId,
                "Entering: createAndModifyTemplateForEvMatchStatus method in PartyInternalObjectsProcessor");

        String objRefId = getObjectRefIdForKYCObjects(request);

        RequestTransfomerUtil.modifyTemplate(request, "@KycIdentifierObjectReferenceId@",objRefId ,
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@DataSourceName@", evMatchStatus.getDataSourceName(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@MatchStatus@", evMatchStatus.getMatchStatus(), traceId);
        LogUtil.debug(log, "createAndModifyTemplateForEvMatchStatus", traceId,
                "Exit: createAndModifyTemplateForEvMatchStatus method"
                        + " in PartyInternalObjectsProcessor");
    }


    private String getObjectRefIdForKYCObjects(StringBuilder request) {
        if (request.indexOf("<XKycVerificationBObj>") != -1) {
            String refId = request.substring(request.indexOf("<XKycVerificationBObj>"));
            if (refId.indexOf("<ObjectReferenceId>") != -1) {
                refId = refId.substring(refId.indexOf("<ObjectReferenceId>") + "<ObjectReferenceId>".length(),
                        refId.indexOf("</ObjectReferenceId>"));
                return refId;
            }
        }

        return null;

    }

    //OCT-18590 : validation attributes for Address START
    private void prepareAddressValidationDetails(StringBuilder request,
            Address address, String objectReferenceId, String traceId) {
        LogUtil.debug(log, "prepareAddressValidationDetails", traceId,
                "Entering: prepareAddressValidationDetails method"
                        + " in PartyInternalObjectsProcessor");
        int validationCount = 0;
        if (null != address.getValidationDetails()) {
            List<ValidationDetails> validationAddress = address.getValidationDetails();
            for (ValidationDetails validationDetails : validationAddress) {
                if (validationCount == 0 && (request.indexOf("<ObjectReferenceId>"
                        + "@ValidationObjectReferenceId@</ObjectReferenceId>") != -1)) {
                    modifyTemplateForValidationDetails(request, OCVConstants.OCV_ENTITYNAME_ADDRESS_ATTR,
                            validationDetails, objectReferenceId, OCVConstants.OCV_ENTITYNAME_ADDRESS, traceId);
                    validationCount++;
                } else {
                    createAndModifyTemplateForValidationDetails(request, OCVConstants.OCV_ENTITYNAME_ADDRESS_ATTR,
                            validationDetails, objectReferenceId, OCVConstants.OCV_ENTITYNAME_ADDRESS, traceId);
                }
            }
        }
        if (request.indexOf("<ObjectReferenceId>@ValidationObjectReferenceId@</ObjectReferenceId>") != -1) {
            RequestTransfomerUtil.removeObjectFromTemplate(request, "<XAttrValidationBObj>", "</XAttrValidationBObj>",
                    validationCount, traceId);
        }
        LogUtil.debug(log, "prepareAddressValidationDetails", traceId,
                "Exit: prepareAddressValidationDetails method in PartyInternalObjectsProcessor");
    }

    // OCT-18590 : validation attributes for Address END
    public void prepareNoTaxReasons(StringBuilder request, List<NoTaxReason> noTaxReasons, String objectReferenceId,
            String traceId) {
        LogUtil.debug(log, "prepareEvMatchStatus", traceId,
                "Entering: prepareEvMatchStatus method in PartyInternalObjectsProcessor");
        int noTaxreasonsCount = 0;
        for (NoTaxReason noTaxReason : noTaxReasons) {
            if (noTaxreasonsCount == 0) {
                modifytemplateForNoTaxReasons(request, noTaxReason, objectReferenceId, traceId);
                noTaxreasonsCount++;

            } else {
                createAndModifyTemplateForNoTaxReasons(request, noTaxReason, objectReferenceId, traceId);
            }
        }
        RequestTransfomerUtil.removeObjectFromTemplate(request, "<XNoTinReasonBObj>", "</XNoTinReasonBObj>",
                noTaxreasonsCount, traceId);
        LogUtil.debug(log, "prepareEvMatchStatus", traceId,
                "Exit: prepareEvMatchStatus method in PartyInternalObjectsProcessor");
    }

    private void createAndModifyTemplateForNoTaxReasons(StringBuilder request, NoTaxReason noTaxReason,
            String objectReferenceId, String traceId) {
        LogUtil.debug(log, "createAndModifyTemplateForNoTaxReasons", traceId,
                "Entering: createAndModifyTemplateForNoTaxReasons method in PartyInternalObjectsProcessor");
        String noTaxReasonsRequest = MDMRequestTemplates.MAINTAIN_PARTY_XNO_TIN_REASON_REQUEST;
        request.insert(request.indexOf("<XNoTinReasonBObj>"), noTaxReasonsRequest);
        modifytemplateForNoTaxReasons(request, noTaxReason, objectReferenceId, traceId);
        LogUtil.debug(log, "createAndModifyTemplateForNoTaxReasons", traceId,
                "Exit: createAndModifyTemplateForNoTaxReasons method in PartyInternalObjectsProcessor");
    }

    public void modifytemplateForNoTaxReasons(StringBuilder request, NoTaxReason noTaxReason, String objectReferenceId,
            String traceId) {
        LogUtil.debug(log, "modifytemplateForNoTaxReasons", traceId,
                "Entering: modifytemplateForNoTaxReasons method in PartyInternalObjectsProcessor");

        RequestTransfomerUtil.modifyTemplate(request, "@XNoTinReasonObjectReferenceId@", objectReferenceId, traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@NoTinReasonValue@", noTaxReason.getNoTaxReasonType(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@NoTinReasonCatValue@", noTaxReason.getNoTaxReasonCategory(),
                traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@NoTinReasonOperatorConfirmedReason@",
                noTaxReason.getOperatorConfirmedReason(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@NoTinReason@", noTaxReason.getReason(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@NoTinReasonStartDate@", noTaxReason.getStartDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@NoTinReasonEndDate@", noTaxReason.getEndDate(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@NoTinReasonSourceIdentifierValue@", noTaxReason.getSource(),
                traceId);
        LogUtil.debug(log, "modifytemplateForNoTaxReasons", traceId,
                "Exit: modifytemplateForNoTaxReasons method in PartyInternalObjectsProcessor");
    }

    public void prepareCitizenship(StringBuilder request, List<Citizenship> citizenShip,
            String traceId) {
        LogUtil.debug(log, "preparePartyAddress", traceId,
                "Entering: preparePartyAddress method in PartyInternalObjectsProcessor");
        int countryCount = 0;
        int objectSeqCount = 0;
        for (Citizenship country: citizenShip) {
            objectSeqCount++;
            if (countryCount == 0) {
                modifytemplateForCitizenship(request, country, String.valueOf(objectSeqCount), traceId);
                countryCount++;

            } else {
                createAndModifyTemplateForCitizenship(request, country, String.valueOf(objectSeqCount), traceId);
            }

        }
        RequestTransfomerUtil.removeObjectFromTemplate(request, "<XContCitizenshipBObj>", "</XContCitizenshipBObj>",
                countryCount, traceId);
        LogUtil.debug(log, "prepareCitizenship", traceId,
                "Exit: prepareCitizenship method in PartyInternalObjectsProcessor");

    }

    private void createAndModifyTemplateForCitizenship(StringBuilder request, Citizenship country,
            String objectReferenceId, String traceId) {

        LogUtil.debug(log, "createAndModifyTemplateForCitizenship", traceId,
                "Entering: createAndModifyTemplateForCitizenship method in PartyInternalObjectsProcessor");
        String citizenshipRequest = MDMRequestTemplates.MAINTAIN_PARTY_XCONT_CITIZENSHIP_DETAILS_REQUEST;
        request.insert(request.indexOf("<XContCitizenshipBObj>"), citizenshipRequest);
        modifytemplateForCitizenship(request, country, objectReferenceId, traceId);
        LogUtil.debug(log, "createAndModifyTemplateForCitizenship", traceId,
                "Exit: createAndModifyTemplateForCitizenship method in PartyInternalObjectsProcessor");


    }

    private void modifytemplateForCitizenship(StringBuilder request, Citizenship country,
            String objectSeqCount, String traceId) {

        LogUtil.debug(log, "modifytemplateForCitizenship", country.getCitizenshipCountry(),
                "Entering: modifytemplateForCitizenship method"
                        + " in PartyInternalObjectsProcessor");
        RequestTransfomerUtil.modifyTemplate(request, "@CitizenshipCountryObjectReferenceId@",
                objectSeqCount, traceId);
        RequestTransfomerUtil.modifyTemplate(request,"@CitizenshipSourceIdentifierValue@",
                country.getSource(),traceId);
        RequestTransfomerUtil.modifyTemplate(request,"@CitizenshipCountryValue@",
                country.getCitizenshipCountry(),traceId);
        LogUtil.debug(log, "modifytemplateForCitizenship", traceId,
                "Exit: modifytemplateForCitizenship method in PartyInternalObjectsProcessor");


    }

    public void prepareKYCDocRef(StringBuilder request, KycVerificationMethods method,
            List<KYCVerificationDocRef> kycVerificationDocRefList,
            String traceId) {
        LogUtil.debug(log, "prepareKYCDocRef", traceId,
                "Entering: prepareKYCDocRef method in PartyInternalObjectsProcessor");
        int kYCVerificationDocRefCount = 0;
        for (KYCVerificationDocRef kYCVerificationDocRef : kycVerificationDocRefList) {
            if (kYCVerificationDocRefCount == 0) {
                modifytemplateForkYCVerificationDocRef(request, method,kYCVerificationDocRef, traceId);
                kYCVerificationDocRefCount++;

            } else {
                createAndModifyTemplateForkYCVerificationDocRef(request, method,kYCVerificationDocRef, traceId);
            }
        }
        RequestTransfomerUtil.removeObjectFromTemplate(request, "<XKycVerificationDocBObj>",
                "</XKycVerificationDocBObj>", kYCVerificationDocRefCount, traceId);
        LogUtil.debug(log, "prepareKYCDocRef", traceId,
                "Exit: prepareKYCDocRef method in PartyInternalObjectsProcessor");
    }

    private void createAndModifyTemplateForkYCVerificationDocRef(StringBuilder request, KycVerificationMethods method,
            KYCVerificationDocRef kYCVerificationDocRef, String traceId) {
        LogUtil.debug(log, "createAndModifyTemplateForkYCVerificationDocRef", traceId,
                "Entering: createAndModifyTemplateForkYCVerificationDocRef method in PartyInternalObjectsProcessor");
        String objRefId = getObjectRefIdForKYCObjects(request);

        RequestTransfomerUtil.modifyTemplate(request, "@KycIdentifierObjectReferenceId@",objRefId ,
                traceId);
       /* RequestTransfomerUtil.modifyTemplate(request, "@IdentifierId@",kYCVerificationDocRef.getIdentifierType() ,
                traceId);*/
        LogUtil.debug(log, "createAndModifyTemplateForkYCVerificationDocRef", traceId,
                "Exit: createAndModifyTemplateForkYCVerificationDocRef method in PartyInternalObjectsProcessor");

    }

    private void modifytemplateForkYCVerificationDocRef(StringBuilder request, KycVerificationMethods method,
            KYCVerificationDocRef kYCVerificationDocRef,
            String traceId) {
        LogUtil.debug(log, "modifytemplateForkYCVerificationDocRef", traceId,
                "Entering: modifytemplateForkYCVerificationDocRef method in PartyInternalObjectsProcessor");
        String kYCVerificationDocReq = MDMRequestTemplates.MAINTAIN_PARTY_KYC_VERIFICATION_DOC_REQUEST;
        if (method.getVerificationMethodType().equalsIgnoreCase(OCVConstants.KYC_METHOD_IDEV)
                || method.getVerificationMethodType().equalsIgnoreCase(OCVConstants.KYC_METHOD_IDAEV)) {
            request.insert(request.lastIndexOf("</XEIDVerificationBObj>"), kYCVerificationDocReq);
        }

        if (method.getVerificationMethodType().equalsIgnoreCase(OCVConstants.KYC_METHOD_IDMV)) {
            request.insert(request.lastIndexOf("</XMIDVerificationBObj>"), kYCVerificationDocReq);
        }
        createAndModifyTemplateForkYCVerificationDocRef(request, method, kYCVerificationDocRef, traceId);
        LogUtil.debug(log, "createAndModifyTemplateForkYCVerificationDocRef", traceId,
                "Exit: createAndModifyTemplateForkYCVerificationDocRef method in PartyInternalObjectsProcessor");
    }
}