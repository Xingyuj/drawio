package com.anz.mdm.ocv.api.util;

import java.util.List;

import com.anz.mdm.ocv.api.constants.MDMRequestTemplates;
import com.anz.mdm.ocv.common.v1.BankingService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class MaintainPartyOrgBankingServices {
   

    public void prepareKeyValueforBankingServicesObjects(StringBuilder request, List<BankingService> bankingServices,
            String traceId) {
        LogUtil.debug(log, "prepareKeyValueforbankingServicesObjects", traceId,
                "Entering: prepareKeyValueforbankingServicesObjects method in MaintainPartyOrgBankingServices");

        for (BankingService bankingService : bankingServices) {

           
            createModifyTemplateForBankingServiceKeyValue(request, bankingService, traceId);
        }
        
        LogUtil.debug(log, "prepareKeyValueforbankingServicesObjects", traceId,
                "Exiting: prepareKeyValueforbankingServicesObjects method in MaintainPartyOrgBankingServices");

    }

    public void createModifyTemplateForBankingServiceKeyValue(StringBuilder request, BankingService bankingService,
            String traceId) {
        LogUtil.debug(log, "createModifyTemplateForBankingServiceKeyValue", traceId,
                "Entering: createModifyTemplateForBankingServiceKeyValue method in MaintainPartyOrgBankingServices");
        String keyValueRequest = MDMRequestTemplates.MAINTAIN_PARTY_KEY_VALUE_REQUEST;
        request.insert(request.indexOf("<TCRMPartyMacroRoleBObj>"), keyValueRequest);
        modifytemplateForBankingServicesKeyValues(request, bankingService, traceId);
        LogUtil.debug(log, "createModifyTemplateForBankingServiceKeyValue", traceId,
                "Exit: createModifyTemplateForBankingServiceKeyValue method in MaintainPartyOrgBankingServices");
    }

    public void modifytemplateForBankingServicesKeyValues(StringBuilder request, BankingService bankingService,
            String traceId) {
        LogUtil.debug(log, "modifytemplateForBankingServicesKeyValues", traceId,
                "Entering: modifytemplateForBankingServicesKeyValues method in MaintainPartyOrgBankingServices");
        RequestTransfomerUtil.modifyTemplate(request, "@key@", bankingService.getKey(), traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@value@", bankingService.getValue(), traceId);

        LogUtil.debug(log, "modifytemplateForBankingServicesKeyValues", traceId,
                "Exit: modifytemplateForBankingServicesKeyValues method in MaintainPartyOrgBankingServices");
    }

}
