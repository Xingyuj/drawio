package com.anz.mdm.ocv.api.exception;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageConversionException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.util.GeneralProperties;
import com.anz.mdm.ocv.api.util.LogRequestModel;
import com.anz.mdm.ocv.api.util.LogUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * GlobalExceptionHandler handles all exceptions
 * 
 */
@Slf4j
@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    @Autowired
    private GeneralProperties properties;

    @Autowired
    private LogRequestModel logAttributes;

    public void setLogAttributes(LogRequestModel logAttributes) {
        this.logAttributes = logAttributes;
    }

    @ExceptionHandler(ServerException.class)
    public ResponseEntity<ErrorResponse> serverExceptionHandler(Exception ex, WebRequest request) throws IOException {
        ErrorResponse response = new ErrorResponse();
        response.setHttpCode(500);
        response.setHttpMessage("Internal Server Error");
        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.set("x-b3-traceid", request.getHeader("x-b3-traceid"));
        responseHeaders.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains;");

        LogUtil.error(log, "serverExceptionHandler ", logAttributes.getTraceId(), "Server Exception", null,
                logAttributes.getChannel(), logAttributes.getPartyType(), logAttributes.getServiceName());
        return new ResponseEntity<ErrorResponse>(response, responseHeaders, HttpStatus.INTERNAL_SERVER_ERROR);

    }

    @ExceptionHandler(InitializationException.class)
    public ResponseEntity<ErrorResponse> intialisationExceptionHandler(Exception ex, WebRequest request)
            throws IOException {
        ErrorResponse response = new ErrorResponse();
        response.setHttpCode(500);
        response.setHttpMessage("Internal Server Error");
        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.set("x-b3-traceid", request.getHeader("x-b3-traceid"));
        responseHeaders.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains;");

        LogUtil.error(log, "InitializationException ", logAttributes.getTraceId(), "InitializationException Exception",
                null, logAttributes.getChannel(), logAttributes.getPartyType(), logAttributes.getServiceName());
        return new ResponseEntity<ErrorResponse>(response, responseHeaders, HttpStatus.INTERNAL_SERVER_ERROR);

    }

    @ExceptionHandler(RecordNotFoundException.class)
    public ResponseEntity<ErrorResponse> recordNotFoundHandler(RecordNotFoundException ex, WebRequest request)
            throws IOException {
        ErrorResponse response = new ErrorResponse();
        response.setHttpCode(404);
        response.setHttpMessage(properties.getStatusMessage("404"));
        Error error = new Error();
        error.setStatusCode(ex.getStatusCode());
        error.setStatusMessage(ex.getStatusMessage());
        List<Error> errors = new ArrayList<Error>();
        errors.add(error);
        response.setErrors(errors);
        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.set("x-b3-traceid", request.getHeader("x-b3-traceid"));
        responseHeaders.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains;");

        LogUtil.error(log, "RecordNotFoundException ", logAttributes.getTraceId(), ex.getStatusMessage(),
                ex.getStatusCode(), logAttributes.getChannel(), logAttributes.getPartyType(),
                logAttributes.getServiceName());
        return new ResponseEntity<ErrorResponse>(response, responseHeaders, HttpStatus.NOT_FOUND);

    }

    @ExceptionHandler(BadRequestException.class)
    public ResponseEntity<ErrorResponse> badRequestHandler(BadRequestException exception, WebRequest request)
            throws IOException {
        ErrorResponse response = new ErrorResponse();
        response.setHttpCode(400);
        response.setHttpMessage("Bad Request");

        // BadRequestException bre = (BadRequestException) exception;
        Error error = new Error();
        error.setLocation("OCV");
        error.setStatusCode(exception.getStatusCode());
        error.setStatusMessage(properties.getStatusMessage(exception.getStatusCode()));
        error.setMoreInformation(exception.getStatusMessage());
        List<Error> errors = new ArrayList<Error>();
        errors.add(error);
        response.setErrors(errors);
        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.set("x-b3-traceid", request.getHeader("x-b3-traceid"));
        responseHeaders.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains;");

        LogUtil.error(log, "badRequestHandler ", logAttributes.getTraceId(), "Bad request Exception",
                exception.getStatusCode(), logAttributes.getChannel(), logAttributes.getPartyType(),
                logAttributes.getServiceName());
        return new ResponseEntity<ErrorResponse>(response, responseHeaders, HttpStatus.BAD_REQUEST);

    }

    @ExceptionHandler(VaultBatchInputException.class)
    public ResponseEntity<ErrorResponse> vaultBatchInputExceptionHandler(
            VaultBatchInputException exception, WebRequest request)
            throws IOException {
        ErrorResponse response = new ErrorResponse();
        response.setHttpCode(HttpStatus.BAD_REQUEST.value());
        response.setHttpMessage(HttpStatus.BAD_REQUEST.name());

        Error error = new Error();
        error.setLocation("ADP Hashicorp Vault Service");
        error.setStatusCode(exception.getStatusCode());
        error.setStatusMessage(properties.getStatusMessage(exception.getStatusCode()));
        error.setMoreInformation(exception.getStatusMessage());
        List<Error> errors = new ArrayList<Error>();
        errors.add(error);
        response.setErrors(errors);
        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.set("x-b3-traceid", request.getHeader("x-b3-traceid"));
        responseHeaders.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains;");

        LogUtil.error(log, "vaultBatchInputExceptionHandler ", logAttributes.getTraceId(), "vaultBatchInputException",
                exception.getStatusCode(), logAttributes.getChannel(), logAttributes.getPartyType(),
                logAttributes.getServiceName());
        return new ResponseEntity<ErrorResponse>(response, responseHeaders, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(UnauthorizedException.class)
    public ResponseEntity<ErrorResponse> unAuthRequestHandler(UnauthorizedException exception, WebRequest request)
            throws IOException {
        log.error(exception.getMessage());
        ErrorResponse response = new ErrorResponse();
        response.setHttpCode(401);
        response.setHttpMessage("Unauthorized Request");
        response.setMoreInformation("Unauthorized Request");

        Error error = new Error();
        error.setLocation("OCV");
        error.setStatusCode(exception.getStatusCode());
        error.setStatusMessage(properties.getStatusMessage(exception.getStatusCode()));
        error.setMoreInformation(exception.getStatusMessage());
        List<Error> errors = new ArrayList<Error>();
        errors.add(error);
        response.setErrors(errors);
        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.set("x-b3-traceid", request.getHeader("x-b3-traceid"));
        responseHeaders.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains;");

        LogUtil.error(log, "unAuthRequestHandler ", logAttributes.getTraceId(), "UnauthorizedException Exception",
                exception.getStatusCode(), logAttributes.getChannel(), logAttributes.getPartyType(),
                logAttributes.getServiceName());
        return new ResponseEntity<ErrorResponse>(response, responseHeaders, HttpStatus.UNAUTHORIZED);

    }

    @ExceptionHandler(ResourceAccessException.class)
    public final ResponseEntity<ErrorResponse> resourceAccessException(Exception ex, WebRequest request) {
        log.error(ex.getMessage());
        ErrorResponse response = new ErrorResponse();
        response.setHttpCode(500);
        response.setHttpMessage("Internal Server Error");
        Error error = new Error();
        error.setLocation("OCV");
        if (ex.getMessage().contains("SocketTimeoutException")) {
            error.setStatusCode("5005");
            error.setStatusMessage(properties.getStatusMessage("5005"));
        } else if (ex.getMessage().contains("ConnectTimeoutException")) {
            error.setStatusCode("5004");
            error.setStatusMessage(properties.getStatusMessage("5004"));
        } else {
            error.setStatusCode("5002");
            error.setStatusMessage(properties.getStatusMessage("5002"));
        }
        List<Error> errors = new ArrayList<Error>();
        errors.add(error);
        response.setErrors(errors);
        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.set("x-b3-traceid", request.getHeader("x-b3-traceid"));
        responseHeaders.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains;");

        LogUtil.error(log, "resourceAccessException ", logAttributes.getTraceId(), "ResourceAccessException Exception",
                error.getStatusCode(), logAttributes.getChannel(), logAttributes.getPartyType(),
                logAttributes.getServiceName());
        return new ResponseEntity<ErrorResponse>(response, responseHeaders, HttpStatus.INTERNAL_SERVER_ERROR);

    }

    @ExceptionHandler(HttpServerErrorException.class)
    public final ResponseEntity<ErrorResponse> handleHttpServerErrorException(Exception ex, WebRequest request) {
        log.error(ex.getMessage());
        ErrorResponse response = new ErrorResponse();
        response.setHttpCode(500);
        Error error = new Error();
        error.setStatusCode("5002");
        response.setHttpMessage(properties.getStatusMessage("5002"));
        error.setMoreInformation("HttpServerErrorException occured");
        List<Error> errors = new ArrayList<Error>();
        errors.add(error);
        response.setErrors(errors);
        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.set("x-b3-traceid", request.getHeader("x-b3-traceid"));
        responseHeaders.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains;");

        LogUtil.error(log, "handleHttpServerErrorException ", logAttributes.getTraceId(),
                "HttpServerErrorException Exception", "5002", logAttributes.getChannel(), logAttributes.getPartyType(),
                logAttributes.getServiceName());
        return new ResponseEntity<ErrorResponse>(response, responseHeaders, HttpStatus.INTERNAL_SERVER_ERROR);

    }

    @ExceptionHandler(ServiceUnavailableException.class)
    public final ResponseEntity<ErrorResponse> serviceUnavailableException(ServiceUnavailableException ex,
            WebRequest request) {
        log.error(ex.getMessage());
        ErrorResponse response = new ErrorResponse();
        response.setHttpCode(500);
        Error error = new Error();
        error.setStatusCode(ex.getStatusCode());
        error.setStatusMessage(properties.getStatusMessage(ex.getStatusCode()));
        List<Error> errors = new ArrayList<Error>();
        errors.add(error);
        response.setErrors(errors);
        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.set("x-b3-traceid", request.getHeader("x-b3-traceid"));
        responseHeaders.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains;");

        LogUtil.error(log, "ServiceUnavailableException ", logAttributes.getTraceId(),
                "serviceUnavailableException Exception", ex.getStatusCode(), logAttributes.getChannel(),
                logAttributes.getPartyType(), logAttributes.getServiceName());
        return new ResponseEntity<ErrorResponse>(response, responseHeaders, HttpStatus.INTERNAL_SERVER_ERROR);

    }

    @ExceptionHandler(MDMException.class)
    public final ResponseEntity<ErrorResponse> mdmException(MDMException ex, WebRequest request) {
        log.error(ex.getMessage());
        ErrorResponse response = new ErrorResponse();
        response.setHttpCode(500);
        response.setHttpMessage("Internal Server Error");
        Error error = new Error();
        error.setStatusCode(ex.getStatusCode());
        error.setStatusMessage(properties.getStatusMessage(ex.getStatusCode()));
        error.setMoreInformation(ex.getStatusMessage());
        List<Error> errors = new ArrayList<Error>();
        errors.add(error);
        response.setErrors(errors);
        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.set("x-b3-traceid", request.getHeader("x-b3-traceid"));
        responseHeaders.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains;");

        LogUtil.error(log, "mdmException ", logAttributes.getTraceId(), "MDMException Exception", ex.getStatusCode(),
                logAttributes.getChannel(), logAttributes.getPartyType(), logAttributes.getServiceName());
        return new ResponseEntity<ErrorResponse>(response, responseHeaders, HttpStatus.INTERNAL_SERVER_ERROR);

    }

    @ExceptionHandler(UnAuthorizedMDMException.class)
    public ResponseEntity<ErrorResponse> unAuthorizedMDMExceptionHandler(UnAuthorizedMDMException exception,
            WebRequest request) throws IOException {
        log.error(exception.getMessage());
        ErrorResponse response = new ErrorResponse();
        response.setHttpCode(500);
        response.setHttpMessage("Internal Server Error");

        Error error = new Error();
        error.setLocation("OCV");
        error.setStatusCode(exception.getStatusCode());
        error.setStatusMessage(properties.getStatusMessage(exception.getStatusCode()));
        error.setMoreInformation(exception.getStatusMessage());
        List<Error> errors = new ArrayList<Error>();
        errors.add(error);
        response.setErrors(errors);
        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.set("x-b3-traceid", request.getHeader("x-b3-traceid"));
        responseHeaders.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains;");

        LogUtil.error(log, "UnAuthorizedMDMException ", logAttributes.getTraceId(),
                "UnAuthorizedMDMException Exception", exception.getStatusCode(), logAttributes.getChannel(),
                logAttributes.getPartyType(), logAttributes.getServiceName());

        return new ResponseEntity<ErrorResponse>(response, responseHeaders, HttpStatus.INTERNAL_SERVER_ERROR);

    }

    @ExceptionHandler(BackendServiceException.class)
    public final ResponseEntity<ErrorResponse> backendServiceException(BackendServiceException ex, WebRequest request) {
        log.error(ex.getMessage());
        ErrorResponse response = new ErrorResponse();
        response.setHttpCode(500);
        response.setHttpMessage("Internal Server Error");
        Error error = new Error();
        error.setStatusCode(ex.getStatusCode());
        error.setStatusMessage(properties.getStatusMessage(ex.getStatusCode()));
        // error.setMoreInformation(ex.getStatusMessage());
        List<Error> errors = new ArrayList<Error>();
        errors.add(error);
        response.setErrors(errors);
        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.set("x-b3-traceid", request.getHeader("x-b3-traceid"));
        responseHeaders.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains;");

        LogUtil.error(log, "BackendServiceException ", logAttributes.getTraceId(), "BackendServiceException Exception",
                ex.getStatusCode(), logAttributes.getChannel(), logAttributes.getPartyType(),
                logAttributes.getServiceName());

        return new ResponseEntity<ErrorResponse>(response, responseHeaders, HttpStatus.INTERNAL_SERVER_ERROR);

    }

    @ExceptionHandler(ElasticSearchUnavailableException.class)
    public ResponseEntity<ErrorResponse> elasticUnavailableException(ElasticSearchUnavailableException ex,
            WebRequest request) throws IOException {
        ErrorResponse response = new ErrorResponse();
        response.setHttpMessage("Internal Server Error");
        Error error = new Error();
        error.setLocation("OCV");
        error.setStatusCode(ex.getStatusCode());
        error.setStatusMessage(properties.getStatusMessage(ex.getStatusCode()));
        error.setMoreInformation(ex.getMoreInfo());
        List<Error> errors = new ArrayList<Error>();
        errors.add(error);
        response.setHttpCode(500);
        response.setErrors(errors);
        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.set("x-b3-traceid", request.getHeader("x-b3-traceid"));
        responseHeaders.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains;");

        return new ResponseEntity<ErrorResponse>(response, responseHeaders, HttpStatus.INTERNAL_SERVER_ERROR);

    }

    @ExceptionHandler(JwtValidationException.class)
    public ResponseEntity<ErrorResponse> jwtValidationExceptionHandler(JwtValidationException ex, WebRequest request)
            throws IOException {
        ErrorResponse response = new ErrorResponse();
        String moreinfo = "Backend service Unauthorized Exception";
        response.setHttpMessage("Unauthorized Request Token");
        Error error = new Error();
        error.setLocation("OCV");
        error.setStatusCode(ex.getStatusCode());
        error.setStatusMessage(properties.getStatusMessage(ex.getStatusCode()));
        error.setMoreInformation("Backend service jwt validation exception");
        List<Error> errors = new ArrayList<Error>();
        errors.add(error);
        response.setHttpCode(401);
        response.setErrors(errors);
        response.setMoreInformation(moreinfo);
        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.set("x-b3-traceid", request.getHeader("x-b3-traceid"));
        responseHeaders.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains;");

        LogUtil.error(log, "JwtValidationExceptionHandler ", logAttributes.getTraceId(), ex.getStatusMessage(),
                ex.getStatusCode(), logAttributes.getChannel(), logAttributes.getPartyType(),
                logAttributes.getServiceName());
        return new ResponseEntity<ErrorResponse>(response, responseHeaders, HttpStatus.UNAUTHORIZED);
    }

    @ExceptionHandler(InvalidStructuredAttributeException.class)
    public ResponseEntity<ErrorResponse> invalidStructuredAttributeExceptionHandler(
            InvalidStructuredAttributeException exception, WebRequest request) throws IOException {
        log.error(exception.getMessage());
        ErrorResponse response = new ErrorResponse();
        response.setHttpCode(500);
        response.setHttpMessage("Internal Server Error");

        Error error = new Error();
        error.setLocation("OCV");
        error.setStatusCode(exception.getStatusCode());
        error.setStatusMessage(properties.getStatusMessage(exception.getStatusCode()));
        error.setMoreInformation(exception.getStatusMessage());
        List<Error> errors = new ArrayList<Error>();
        errors.add(error);
        response.setErrors(errors);
        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.set("x-b3-traceid", request.getHeader("x-b3-traceid"));
        responseHeaders.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains;");

        LogUtil.error(log, "InvalidStructuredAttributeException ", logAttributes.getTraceId(),
                "InvalidStructuredAttributeException Exception", exception.getStatusCode(), logAttributes.getChannel(),
                logAttributes.getPartyType(), logAttributes.getServiceName());

        return new ResponseEntity<ErrorResponse>(response, responseHeaders, HttpStatus.INTERNAL_SERVER_ERROR);

    }

    @ExceptionHandler(HttpMessageConversionException.class)
    public ResponseEntity<ErrorResponse> httpMessageConversionException(HttpMessageConversionException ex,
            WebRequest request) throws IOException {

        ErrorResponse response = new ErrorResponse();
        response.setHttpCode(400);
        response.setHttpMessage("Bad Request");
        Error error = new Error();
        error.setLocation("OCV");
        if (null != ex) {
            log.error(ex.getMessage());
            error.setStatusCode(OCVConstants.INVALID_JSON_INPUT);
            error.setStatusMessage(properties.getStatusMessage(OCVConstants.INVALID_JSON_INPUT));
            error.setMoreInformation(OCVConstants.INVALID_JSON_ERROR_MESSAGE);
        }

        List<Error> errors = new ArrayList<Error>();
        errors.add(error);
        response.setErrors(errors);

        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.set("x-b3-traceid", request.getHeader("x-b3-traceid"));
        responseHeaders.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains;");

        LogUtil.error(log, "badRequestHandler ", logAttributes.getTraceId(), "Bad request Exception", "",
                logAttributes.getChannel(), logAttributes.getPartyType(), logAttributes.getServiceName());

        return new ResponseEntity<ErrorResponse>(response, responseHeaders, HttpStatus.BAD_REQUEST);

    }
    
    @ExceptionHandler(IdempotencyTimeOutException.class)
    public final ResponseEntity<ErrorResponse> idempotencyTimeoutException(IdempotencyTimeOutException ex,
            WebRequest request) {
        log.error(ex.getMessage());
        ErrorResponse response = new ErrorResponse();
        response.setHttpCode(422);
        Error error = new Error();
        error.setStatusCode(ex.getStatusCode());
        error.setStatusMessage(properties.getStatusMessage(ex.getStatusCode()));
        List<Error> errors = new ArrayList<Error>();
        errors.add(error);
        response.setErrors(errors);
        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.set("x-b3-traceid", request.getHeader("x-b3-traceid"));
        responseHeaders.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains;");

        LogUtil.error(log, "IdempotencyTimeOutException ", logAttributes.getTraceId(),
                "IdempotencyTimeOutException Exception", "422", logAttributes.getChannel(),
                logAttributes.getPartyType(), logAttributes.getServiceName());
        return new ResponseEntity<ErrorResponse>(response, responseHeaders, HttpStatus.UNPROCESSABLE_ENTITY);

    }
    
    @ExceptionHandler(AvailabilityServiceDownException.class)
    public final ResponseEntity<ErrorResponse> capAvailabilityServiceDownException(AvailabilityServiceDownException ex,
            WebRequest request) {
        log.error(ex.getMessage());
        ErrorResponse response = new ErrorResponse();
        response.setHttpCode(503);
        Error error = new Error();
        error.setStatusCode(ex.getErrorCode());
        error.setStatusMessage(properties.getStatusMessage(ex.getErrorCode()));
        error.setLocation("CAP");
        List<Error> errors = new ArrayList<Error>();
        errors.add(error);
        response.setErrors(errors);
        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.set("x-b3-traceid", request.getHeader("x-b3-traceid"));
        responseHeaders.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains;");

        LogUtil.error(log, "AvailabilityServiceDownException ", logAttributes.getTraceId(),
                "AvailabilityServiceDownException", "503", logAttributes.getChannel(),
                logAttributes.getPartyType(), logAttributes.getServiceName());
        return new ResponseEntity<ErrorResponse>(response, responseHeaders, HttpStatus.SERVICE_UNAVAILABLE);

    }
    
    @ExceptionHandler(DuplicateRecordException.class)
    public ResponseEntity<ErrorResponse> duplicateRecordFoundHandler(DuplicateRecordException ex, WebRequest request)
            throws IOException {
        ErrorResponse response = new ErrorResponse();
        response.setHttpCode(409);
        response.setHttpMessage("Conflict/Duplicate Record Detected");

        Error error = new Error();
        error.setLocation("OCV");
        if (null != ex) {
            log.error(ex.getMessage());
            error.setStatusCode(ex.getStatusCode());
            error.setStatusMessage(properties.getStatusMessage(ex.getStatusCode()));
            error.setMoreInformation(ex.getStatusMessage());

        }
        List<Error> errors = new ArrayList<Error>();
        errors.add(error);
        response.setErrors(errors);
        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.set("x-b3-traceid", request.getHeader("x-b3-traceid"));
        responseHeaders.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains;");
        return new ResponseEntity<ErrorResponse>(response, responseHeaders, HttpStatus.CONFLICT);

    }
}