package com.anz.mdm.ocv.api.exception;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * ErrorResponse includes all error parameters
 * 
 * @author geraa
 *
 */
@Setter
@Getter
public class ErrorResponse {

    private int httpCode;
    private String httpMessage;
    private String moreInformation;
    private List<Error> errors;

}
