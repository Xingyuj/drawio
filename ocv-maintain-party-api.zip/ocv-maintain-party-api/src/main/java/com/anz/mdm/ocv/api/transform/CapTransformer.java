package com.anz.mdm.ocv.api.transform;

import static com.anz.mdm.ocv.api.constants.CAPConstants.MAX_ADDRESS_LENGTH;
import static com.anz.mdm.ocv.api.constants.CAPConstants.SLASH;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.anz.mdm.ocv.api.constants.CAPConstants;
import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.dto.AddressDTO;
import com.anz.mdm.ocv.api.dto.CapProfileDTO;
import com.anz.mdm.ocv.api.dto.CapProfileDTOV2;
import com.anz.mdm.ocv.api.mapper.cap.CapProfileMapTargetValue;
import com.anz.mdm.ocv.api.mapper.cap.CapProfileMapper;
import com.anz.mdm.ocv.api.util.CapTransformerUtil;
import com.anz.mdm.ocv.api.util.LogUtil;
import com.anz.mdm.ocv.api.util.StreetSuffixConfig;
import com.anz.mdm.ocv.api.validator.APIRequest;
import com.anz.mdm.ocv.cap.v1.CapProfile;
import com.anz.mdm.ocv.cap.v2.AdditionalAttribDetails;
import com.anz.mdm.ocv.cap.v2.EmploymentDetails;
import com.anz.mdm.ocv.common.v1.Address;
import com.anz.mdm.ocv.common.v1.Name;
import com.anz.mdm.ocv.party.v1.Party;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CapTransformer {

    public CapProfile transformAPIRequest(final APIRequest<Party> apiRequest,
                                          StreetSuffixConfig streetSuffixCfg) throws Exception {

        Party partAPIRequest = apiRequest.getRequestBody();
        CapProfileDTO capDTO = new CapProfileDTO();
        populateNameDOBFromParty(capDTO, partAPIRequest);
        capDTO.setGender(getEmptyIfNull(partAPIRequest.getGender()));
        capDTO.setMaritalStatus(getEmptyIfNull(partAPIRequest.getMaritalStatus()));
        populateEmailFromParty(capDTO, partAPIRequest);
        populateAddressFromParty(capDTO, partAPIRequest, streetSuffixCfg);
        populateEmploymentDetails(capDTO, partAPIRequest);
        populateBranch(capDTO);
        Optional.ofNullable(partAPIRequest.getEmployeeIndicator()).ifPresent(isANZEmployee -> {
            capDTO.setANZEmployee((isANZEmployee.equals(CAPConstants.STRING_Y) ? true : false));
        });
        capDTO.setCustomerStatus(getEmptyIfNull(partAPIRequest.getStatus()));
        capDTO.setBankruptDate(getFormattedDate(getEmptyIfNull(partAPIRequest.getBankruptDate())));
        capDTO.setDateBusinessEstablished(getFormattedDate(getEmptyIfNull(partAPIRequest.getEstablishmentDate())));
        Optional.ofNullable(partAPIRequest.getIndustry()).ifPresent(g -> {
            Optional.ofNullable(g.getCode()).ifPresent(code -> {
                capDTO.setSicCode(code);
            });
        });

        transformCapProfile(capDTO);
        CapProfileMapper targetMap = new CapProfileMapTargetValue();
        return targetMap.map(capDTO);
    }

    public com.anz.mdm.ocv.cap.v2.CapProfile fromApiRequest(final APIRequest<Party> apiRequest,
                                                            StreetSuffixConfig streetSuffixCfg) throws Exception {

        Party partAPIRequest = apiRequest.getRequestBody();
        CapProfileDTOV2 capDTO = new CapProfileDTOV2();
        populateNameDOBFromParty(capDTO, partAPIRequest);
        capDTO.setGender(getEmptyIfNull(partAPIRequest.getGender()));
        capDTO.setMaritalStatus(getEmptyIfNull(partAPIRequest.getMaritalStatus()));
        populateEmailFromParty(capDTO, partAPIRequest);
        populateAddressFromParty(capDTO, partAPIRequest, streetSuffixCfg);
        populateEmploymentDetails(capDTO, partAPIRequest);
        populateBranch(capDTO);
        Optional.ofNullable(partAPIRequest.getEmployeeIndicator()).ifPresent(isANZEmployee -> {
            capDTO.setANZEmployee((isANZEmployee.equals(CAPConstants.STRING_Y) ? true : false));
        });
        capDTO.setCustomerStatus(getEmptyIfNull(partAPIRequest.getStatus()));
        capDTO.setBankruptDate(getEmptyIfNull(partAPIRequest.getBankruptDate()));
        capDTO.setDateBusinessEstablished(getEmptyIfNull(partAPIRequest.getEstablishmentDate()));
        Optional.ofNullable(partAPIRequest.getIndustry()).ifPresent(g -> {
            Optional.ofNullable(g.getCode()).ifPresent(code -> {
                capDTO.setSicCode(code);
            });
        });

        transformCapProfile(capDTO);
        return fromDto(capDTO);
    }

    private com.anz.mdm.ocv.cap.v2.CapProfile fromDto(CapProfileDTOV2 capDTO) {
        com.anz.mdm.ocv.cap.v2.CapProfile capProfileV2 = new com.anz.mdm.ocv.cap.v2.CapProfile();
        capProfileV2.setName(capDTO.getName());
        capProfileV2.setTitle(capDTO.getTitle());
        capProfileV2.setSalutation(capDTO.getSalutation());
        capProfileV2.setBirthDate(capDTO.getBirthDate());
        capProfileV2.setGender(capDTO.getGender());
        capProfileV2.setMaritalStatus(capDTO.getMaritalStatus());
        capProfileV2.setEmail(capDTO.getEmail());

        EmploymentDetails employmentDetails = new EmploymentDetails();
        employmentDetails.setEmploymentType(capDTO.getEmploymentType());
        employmentDetails.setEmployer(capDTO.getEmployer());
        employmentDetails.setOccupationCode(capDTO.getOccupationCode());
        employmentDetails.setCountryExempt(capDTO.getCountryExempt());
        employmentDetails.setSsnTaxId(capDTO.getSsnTaxId());
        capProfileV2.setEmployment(employmentDetails);

        capProfileV2.setAddresses(CapTransformerUtil.getCapV2Address(capDTO));

        capProfileV2.setIsANZEmployee(capDTO.isANZEmployee());
        capProfileV2.setCustomerType(capDTO.getCustomerType());
        capProfileV2.setCustomerStatus(capDTO.getCustomerStatus());
        capProfileV2.setOpenedDate(capDTO.getOpenedDate());
        capProfileV2.setSecurityCode(capDTO.getSecurityCode());
        capProfileV2.setBankruptDate(capDTO.getBankruptDate());
        capProfileV2.setOperatorLastMaintained(capDTO.getOperatorLastMaintained());
        capProfileV2.setLastContact(capDTO.getLastContact());
        AdditionalAttribDetails additionalDetails = new AdditionalAttribDetails();
        additionalDetails.setCompanyId(capDTO.getCompanyId());
        additionalDetails.setAcceptsAdvertisements(capDTO.isAcceptsAdvertisements());
        additionalDetails.setAgreeToDisclosure(capDTO.isAgreeToDisclosure());
        additionalDetails.setSelfCertIndicator(capDTO.getSelfCertIndicator());
        additionalDetails.setBranch(capDTO.getBranch());
        additionalDetails.setDateBusinessEstablished(capDTO.getDateBusinessEstablished());
        additionalDetails.setSicCode(capDTO.getSicCode());
        additionalDetails.setGovtRefType(capDTO.getGovtRefType());
        additionalDetails.setGovtRefNumber(capDTO.getGovtRefNumber());
        additionalDetails.setSecurityIndicator(capDTO.getSecurityIndicator());
        additionalDetails.setOrgContactPhone(capDTO.getOrgContactPhone());
        additionalDetails.setOrgContactFaxNumber(capDTO.getOrgContactFaxNumber());
        additionalDetails.setOrgContactName(capDTO.getOrgContactName());
        additionalDetails.setOrgContactTitle(capDTO.getOrgContactTitle());
        additionalDetails.setOrgContactMobile(capDTO.getOrgContactMobile());
        // V2 CAP Customer Create API changed ContactPreferredIndicator from string to
        // boolean
        additionalDetails.setOrgContactPreferred(capDTO.isContactPreferredIndicator());
        additionalDetails.setDateSelfCertification(capDTO.getDateSelfCertification());
        additionalDetails.setControllingPostId(capDTO.getControllingPostId());
        additionalDetails.setControllingPostId2(capDTO.getControllingPostId2());
        capProfileV2.setAdditionalDetails(additionalDetails);

        return capProfileV2;
    }

    public CapProfileDTO populateEmailFromParty(CapProfileDTO capDTO, final Party partyAPI) {

        Optional.ofNullable(partyAPI.getEmails()).ifPresent(emailList -> {
            if (emailList.size() > 0) {
                Optional.ofNullable(emailList.get(0)).ifPresent(email -> {
                    String emailID = email.getEmail().trim();
                    capDTO.setEmail(emailID.length() > 120 ? emailID.substring(0, 120) : emailID);
                });
            }
        });
        return capDTO;
    }

    private void populateBranch(CapProfileDTO capDTO) {
        capDTO.setBranch(OCVConstants.BRANCH_ID);
    }

    public CapProfileDTO populateNameDOBFromParty(CapProfileDTO capDTO, final Party partyAPI) {

        List<Name> nameList = Optional.ofNullable(partyAPI.getNames()).get();
        nameList.forEach(nameObject -> {
            Optional.ofNullable(nameObject).ifPresent(availableNameObject -> {
                getNameDOB(availableNameObject, partyAPI, capDTO);
            });
        });
        return capDTO;
    }

    private CapProfileDTO getNameDOB(final Name nameObject, final Party partyAPI, CapProfileDTO capDTO) {

        Optional.ofNullable(nameObject.getNameUsageType()).ifPresent(nameUsage -> {
            if (nameUsage.contains(CAPConstants.LEGAL_PREFIX)) {
                populateNameDOB(nameObject, partyAPI, capDTO);
            }
        });
        return capDTO;
    }

    public CapProfileDTO populateNameDOB(final Name nameObject, final Party partyAPI, CapProfileDTO capDTO) {

        String firstName = getEmptyIfNull(nameObject.getFirstName());
        String lastName = getEmptyIfNull(nameObject.getLastName());
        String middleName = getEmptyIfNull(nameObject.getMiddleName());
        String suffix = getEmptyIfNull(nameObject.getSuffix());
        String prefix = getEmptyIfNull(nameObject.getPrefix());
        if (partyAPI.getPartyType().equalsIgnoreCase(OCVConstants.INDIVIDUAL_PARTY_TYPE)) {
            capDTO.setBirthDate(partyAPI.getDateOfBirth());
            getPersonName(firstName, lastName, middleName, suffix, prefix, capDTO);
            getTitle(capDTO, firstName, lastName, middleName, suffix, prefix);
            getSaluation(prefix, firstName, lastName, suffix, capDTO);
        } else {
            String capOrgName = (CAPConstants.CAP_ORG_IND + getEmptyIfNull(nameObject.getName())).trim();
            capOrgName = capOrgName.length() > 40 ? capOrgName.substring(0, 40) : capOrgName;
            capDTO.setName(capOrgName);
            capDTO.setTitle(capOrgName);
            capDTO.setSalutation(capOrgName);
        }
        return capDTO;
    }

    private void getTitle(CapProfileDTO capDTO, String firstName, String lastName, String middleName, String suffix,
                          String prefix) {
        String capTitle = null;
        String capTitleWithoutMiddleName = (prefix + " " + getCharAtZero(firstName) + " " + lastName + " " + suffix)
                .trim();
        if (StringUtils.isNotEmpty(middleName)) {
            capTitle = (prefix + " " + getCharAtZero(firstName) + " " + getCharAtZero(middleName) + " " + lastName + " "
                    + suffix).trim();
        } else {
            capTitle = (prefix + " " + getCharAtZero(firstName) + " " + lastName + " " + suffix).trim();
        }
        capTitle = StringUtils.isNotEmpty(capTitle) && capTitle.length() > 40
                ? (capTitleWithoutMiddleName.length() > 40 ? capTitleWithoutMiddleName.substring(0, 40)
                : capTitleWithoutMiddleName)
                : capTitle;
        capDTO.setTitle(capTitle);
    }

    private char getCharAtZero(String nameStr) {
        return nameStr.length() > 0 ? nameStr.charAt(0) : ' ';
    }

    private CapProfileDTO getSaluation(final String prefix, final String firstName, final String lastName,
                                       final String suffix, CapProfileDTO capDTO) {
        String capSalutation = StringUtils.isNotBlank(prefix) ? ((prefix + " " + lastName + " " + suffix).trim())
                : (getCharAtZero(firstName) + " " + lastName + " " + suffix).trim();
        capDTO.setSalutation(capSalutation.length() > 40 ? capSalutation.substring(0, 40) : capSalutation);
        return capDTO;
    }

    private CapProfileDTO getPersonName(final String firstName, final String lastName, final String middleName,
                                        final String suffix, final String prefix, CapProfileDTO capDTO) {
        String capName = null;
        String capNameWithOutMiddleName = (firstName + " " + lastName + " " + suffix).trim();
        if (StringUtils.isNotEmpty(middleName)) {
            capName = (firstName + " " + middleName + " " + lastName + " " + suffix).trim();
        } else {
            capName = (firstName + " " + lastName + " " + suffix).trim();
        }
        capName = StringUtils.isNotEmpty(capName) && capName.length() > 40
                ? (capNameWithOutMiddleName.length() > 40 ? capNameWithOutMiddleName.substring(0, 40)
                : capNameWithOutMiddleName)
                : capName;
        capDTO.setName(capName);
        return capDTO;
    }

    public CapProfileDTO populateEmploymentDetails(CapProfileDTO capDTO, final Party partyAPI) {

        capDTO.setEmployer(getEmptyIfNull(partyAPI.getEmployerName()));
        Optional.ofNullable(partyAPI.getOccupation()).ifPresent(occuptation -> {
            capDTO.setOccupationCode(getEmptyIfNull(occuptation.getSourceOccupationCode()));
        });
        return capDTO;
    }

    public CapProfileDTO populateAddressFromParty(CapProfileDTO capDTO, final Party partyAPI,
                                                  StreetSuffixConfig streetSuffixCfg) {
        List<AddressDTO> addressDTOList = new ArrayList<AddressDTO>();
        Optional.ofNullable(partyAPI.getAddresses()).ifPresent(addressList -> {
            if (addressList.size() > 0) {
                AddressDTO address1 = new AddressDTO();
                Optional.ofNullable(addressList.get(0)).ifPresent(address -> {
                    getAddressLines(address1, address, streetSuffixCfg);
                    getRemainingAddress(address1, address);
                });
                addressDTOList.add(address1);
            }
            if (addressList.size() > 1) {
                AddressDTO address2 = new AddressDTO();
                Optional.ofNullable(addressList.get(1)).ifPresent(address -> {
                    getAddressLines(address2, address, streetSuffixCfg);
                    getRemainingAddress(address2, address);
                });
                addressDTOList.add(address2);
            }
        });
        if (!CollectionUtils.isEmpty(addressDTOList)) {
            capDTO.setAddresses(addressDTOList);
        }
        return capDTO;
    }

    private AddressDTO getRemainingAddress(AddressDTO addDTO, final Address addressObject) {

        addDTO.setCity(getEmptyIfNull(addressObject.getCity()));
        addDTO.setPostCode(getEmptyIfNull(addressObject.getPostalCode()));
        addDTO.setStateprovince(getEmptyIfNull(addressObject.getState()));
        addDTO.setCountryCode(getEmptyIfNull(addressObject.getCountyCode()));
        addDTO.setCountryName(getEmptyIfNull(addressObject.getCountry()));
        addDTO.setUsage(getSetAddressUsage(getEmptyIfNull(addressObject.getAddressUsageType())));
        addDTO.setDeliveryPointId(getEmptyIfNull(addressObject.getDelInfo()));
        addDTO.setStartDate(getEmptyIfNull(addressObject.getStartDate()));
        addDTO.setEndDate(getEmptyIfNull(addressObject.getEndDate()));
        return addDTO;
    }

    private AddressDTO getAddressLines(AddressDTO addDTO, final Address addressObject,
                                       StreetSuffixConfig streetSuffixCfg) {

        if (StringUtils.isNotBlank(addressObject.getStnInfo())) {
            populatePostalAddress(addDTO, addressObject);
        } else {
            populateBuildingName(addDTO, addressObject);
            populateLevelNumAndResidence(addDTO, addressObject, streetSuffixCfg);
        }
        LogUtil.debug(log, "getAddressLines", "cap profile address line1: " + addDTO.getAddressLine1());
        LogUtil.debug(log, "getAddressLines", "cap profile address line2: " + addDTO.getAddressLine2());
        LogUtil.debug(log, "getAddressLines", "cap profile address line3: " + addDTO.getAddressLine3());
        return addDTO;
    }

    private void populatePostalAddress(AddressDTO addDTO, Address addressObject) {

        LogUtil.debug(log, "populatePostalAddress", "Enter: populatePostalAddress");
        String addressLine1 = "";

        if (StringUtils.isNotBlank(addressObject.getStnInfo())) {
            addressLine1 = addressObject.getStnInfo().trim();
        }
        if (StringUtils.isNotBlank(addressObject.getBoxId())) {
            addressLine1 = addressLine1 + " " + addressObject.getBoxId().trim();
        }
        addDTO.setAddressLine1(addressLine1);
    }

    private void populateBuildingName(AddressDTO addDTO, Address addressObject) {

        LogUtil.debug(log, "populateBuildingName", "Enter: populateBuildingName");

        if (StringUtils.isNotBlank(addressObject.getBuildingName())) {
            addDTO.setAddressLine1(getTruncatedAddress(getEmptyIfNull(addressObject.getBuildingName().trim())));
        }
    }

    private void populateLevelNumAndResidence(AddressDTO addDTO, Address addressObject,
                                              StreetSuffixConfig streetSuffixCfg) {

        LogUtil.debug(log, "populateResidence", "Enter: populateResidence");
        // residenceType + " " + residenceNumber
        String resTypeAndNumber = concatenateString(addressObject.getResidenceType(),
                addressObject.getResidenceNumber());
        // LevelNumber + " " + residenceType + " " + residenceNumber
        String levelResType = concatenateString(addressObject.getLevelNumber(), resTypeAndNumber);

        if (StringUtils.isNotBlank(levelResType) && levelResType.contains(SLASH)) {
            concatenateWithLevelNumAndResWithoutSlash(addDTO, addressObject, streetSuffixCfg);
        } else if (StringUtils.isNotBlank(levelResType) && !levelResType.contains(SLASH)) {
            concatenationWithLevelNumAndResidenceWithSlash(addDTO, addressObject, streetSuffixCfg);
        } else {
            populateStreetDetails(addDTO, addressObject, streetSuffixCfg);
        }

    }

    private void concatenateWithLevelNumAndResWithoutSlash(AddressDTO addDTO, Address addressObject,
                                                           StreetSuffixConfig streetSuffixCfg) {

        LogUtil.debug(log, "addressConcatenationWithResidenceContainsSlash",
                "Enter: addressConcatenationWithResidenceContainsSlash");

        String concatenatedStreetDetails = concatenateStreetDetails(addressObject, streetSuffixCfg);
        // residenceType + " " + residenceNumber
        String resTypeAndNumber = concatenateString(addressObject.getResidenceType(),
                addressObject.getResidenceNumber());
        // LevelNumber + " " + residenceType + " " + residenceNumber
        String levelResType = concatenateString(addressObject.getLevelNumber(), resTypeAndNumber);

        if (addDTO.getAddressLine1().isEmpty()) {
            addDTO.setAddressLine1(levelResType);
            addDTO.setAddressLine2(concatenatedStreetDetails);
        } else {
            addDTO.setAddressLine2(levelResType);
            addDTO.setAddressLine3(concatenatedStreetDetails);
        }

    }

    private void concatenationWithLevelNumAndResidenceWithSlash(AddressDTO addDTO, Address addressObject,
                                                                StreetSuffixConfig streetSuffixCfg) {

        LogUtil.debug(log, "addressConcatenationWithResidenceContainsNoSlash",
                "Enter: addressConcatenationWithResidenceContainsNoSlash");

        // residenceType + " " + residenceNumber
        String resTypeAndNumber = concatenateString(addressObject.getResidenceType(),
                addressObject.getResidenceNumber());
        // LevelNumber + " " + residenceType + " " + residenceNumber
        String levelResType = concatenateString(addressObject.getLevelNumber(), resTypeAndNumber);
        // Street Number + " " + Street Name + " " + street type + " " + post
        // directional
        String concatenatedStreetDetails = concatenateStreetDetails(addressObject, streetSuffixCfg);
        String addressLine = levelResType + SLASH + concatenatedStreetDetails;
        if (addDTO.getAddressLine1().isEmpty()) {
            if (addressLine.length() > MAX_ADDRESS_LENGTH) {
                addDTO.setAddressLine1(levelResType);
                addDTO.setAddressLine2(concatenatedStreetDetails);
            } else {
                addDTO.setAddressLine1(addressLine);
            }
        } else {
            if (addressLine.length() > MAX_ADDRESS_LENGTH) {
                addDTO.setAddressLine2(levelResType);
                addDTO.setAddressLine3(concatenatedStreetDetails);
            } else {
                addDTO.setAddressLine2(addressLine);
            }
        }
    }

    private void populateStreetDetails(AddressDTO addDTO, Address addressObject,
                                       StreetSuffixConfig streetSuffixCfg) {

        LogUtil.debug(log, "addressConcatenationWithNoResidence", "Enter: addressConcatenationWithNoResidence");
        String concatenatedStreetDetails = concatenateStreetDetails(addressObject, streetSuffixCfg);
        if (addDTO.getAddressLine1().isEmpty()) {
            addDTO.setAddressLine1(concatenatedStreetDetails);
        } else {
            addDTO.setAddressLine2(concatenatedStreetDetails);
        }
    }

    /*private String concatenateStreetDetails(Address addressObject,StreetSuffixConfig streetSuffixCfg) {
        String streetNumber = getEmptyIfNull(addressObject.getStreetNumber()).replaceAll(" ", "");
        String streetName = getEmptyIfNull(addressObject.getStreetName());
        //String streetSuffix = getEmptyIfNull(addressObject.getStreetSuffix());
        String streetSuffix = streetSuffixCfg.getPropertyValue(StringUtils.isNotBlank(addressObject.getStreetSuffix())
                ? addressObject.getStreetSuffix() : "");
        String postDirectional = getEmptyIfNull(addressObject.getPostDirectional());
        String addressLine = (streetNumber + " " + streetName + " " + streetSuffix + " " + postDirectional).trim(); // A
        return addressLine;
    }*/

    public String concatenateStreetDetails(Address requestAddress, StreetSuffixConfig streetSuffixCfg) {

        String concatenatedStreetDetails = "";

        if (requestAddress.getStreetNumber() != null && StringUtils.isNotBlank(requestAddress.getStreetNumber())) {
            concatenatedStreetDetails = requestAddress.getStreetNumber();
        }
        if (requestAddress.getStreetName() != null && StringUtils.isNotBlank(requestAddress.getStreetName())) {
            concatenatedStreetDetails = concatenateString(concatenatedStreetDetails, requestAddress.getStreetName());
        }
        concatenatedStreetDetails = convertStreetType(requestAddress, streetSuffixCfg, concatenatedStreetDetails);

        if (StringUtils.isNotBlank(requestAddress.getPostDirectional())) {
            concatenatedStreetDetails = concatenateString(concatenatedStreetDetails,
                    requestAddress.getPostDirectional());
        }
        return concatenatedStreetDetails;

    }

    private String convertStreetType(Address requestAddress, StreetSuffixConfig streetSuffixCfg,
                                     String concatenatedStreetDetails) {
        String finalStr = "";

        if (requestAddress.getStreetSuffix() != null && StringUtils.isNotBlank(requestAddress.getStreetSuffix())) {
            String streetSuffix = streetSuffixCfg.getPropertyValue(StringUtils.isNotBlank(
                    requestAddress.getStreetSuffix()) ? requestAddress.getStreetSuffix() : "");
            finalStr = concatenateString(concatenatedStreetDetails, streetSuffix);
        } else {
            finalStr = concatenatedStreetDetails;
        }
        return finalStr;
    }


    private String concatenateString(String str1, String str2) {

        String str3 = "";
        if (StringUtils.isNotBlank(str1) && StringUtils.isNotBlank(str2)) {
            str3 = str1.trim() + " " + str2.trim();
        } else if (StringUtils.isBlank(str1) && StringUtils.isNotBlank(str2)) {
            str3 = str2.trim();
        } else if (StringUtils.isBlank(str2) && StringUtils.isNotBlank(str1)) {
            str3 = str1.trim();
        }
        return str3;
    }

    private AddressDTO getAddressForDTO(final String buildingName, final String residenceNumber, String addressLine,
                                        AddressDTO addDTO) {

        boolean isBuildNameAvailable = checkBuildName(buildingName);
        boolean isResidenceNumberAvailable = checkResidenceNumber(residenceNumber);

        if (!isResidenceNumberAvailable) { // A & B
            getAddressForBlankResidenceNumber(isBuildNameAvailable, buildingName, addressLine, addDTO);
        } else {
            if (!isBuildNameAvailable) { // C & D & E
                getAddressForResidenceNumber(residenceNumber, addressLine, addDTO);
            } else { // F
                addDTO.setAddressLine1(getTruncatedAddress(buildingName.trim()));
                addDTO.setAddressLine2(getTruncatedAddress(isResidenceNumberAvailable ? residenceNumber : "").trim());
                addDTO.setAddressLine3(getTruncatedAddress(addressLine));
            }
        }
        return addDTO;
    }

    private boolean checkBuildName(String buildingName) {
        return StringUtils.isNotBlank(buildingName) ? true : false;
    }

    private boolean checkResidenceNumber(String number) {
        return StringUtils.isNotBlank(number) ? true : false;
    }

    private AddressDTO getAddressForBlankResidenceNumber(final boolean isBuildNameAvailable,
                                                         final String buildingName, final String addressLine,
                                                         AddressDTO addDTO) {

        if (!isBuildNameAvailable) { // A
            addDTO.setAddressLine1(getTruncatedAddress(addressLine));
            // report to data steward if length>40
        } else { // B
            addDTO.setAddressLine1(getTruncatedAddress(buildingName.trim()));
            addDTO.setAddressLine2(getTruncatedAddress(addressLine));
        }
        return addDTO;
    }

    private String getTruncatedAddress(String addLine) {
        return addLine.length() > 40 ? addLine.substring(0, 40) : addLine;
    }

    private AddressDTO getAddressForResidenceNumber(final String residenceNumber, String addressLine,
                                                    AddressDTO addDTO) {
        boolean isResidenceNumberAvailable = checkResidenceNumber(residenceNumber);

        if (isResidenceNumberAvailable) { // C,D,E
            String finalAddrLine = (residenceNumber + CAPConstants.SLASH + addressLine).trim();
            String addrLine1 = (residenceNumber).trim();
            getAddressToFitLength(finalAddrLine, addrLine1, addressLine, addDTO);
        }
        return addDTO;
    }

    private AddressDTO getAddressToFitLength(String totalAdd, String line1, String line2, AddressDTO addDTO) {
        if (totalAdd.length() > 40) {
            addDTO.setAddressLine1(getTruncatedAddress(line1));
            addDTO.setAddressLine2(getTruncatedAddress(line2));
        } else {
            addDTO.setAddressLine1(totalAdd);
        }
        return addDTO;
    }

    private String getFormattedDate(String date) {

        if (StringUtils.isNotBlank(date)) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate localDate = LocalDate.parse(date, formatter);
            return localDate.format(DateTimeFormatter.BASIC_ISO_DATE);
        } else {
            return "";
        }
    }

    public CapProfileDTO transformCapProfile(CapProfileDTO capDTO) {
        if (capDTO.getMaritalStatus().contains(CAPConstants.STRING_MARRIED)) {
            capDTO.setMaritalStatus(CAPConstants.CAP_MARRIED_DEFACTO);
        }
        return capDTO;
    }

    public String getEmptyIfNull(String str) {
        return StringUtils.isNotBlank(str) ? str : "";
    }

    public String getSetAddressUsage(String addressUsage) {
        if (addressUsage.toLowerCase(Locale.ENGLISH).contains(CAPConstants.STRING_MAILING_LOWERCASE)) {
            return CAPConstants.STRING_MAILING;
        } else {
            return CAPConstants.STRING_RESIDENTIAL;
        }
    }
}
