package com.anz.mdm.ocv.api.converter;

import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.anz.mdm.ocv.api.dto.APIResponse;
import com.anz.mdm.ocv.api.util.LogUtil;
import com.ibm.mdm.schema.TCRMPersonBObjType;

import lombok.extern.slf4j.Slf4j;

/**
 * Serves as a converter to transform the Person details from MDM TCRMService
 * object to Party object
 *
 */

@Slf4j
@Component(value = "personObjectConverter")
public class PersonObjectConverter {

    private PartyIdentifierConverter identifierConverter = new PartyIdentifierConverter();
    private PartySourceSystemConverter sourceSystemConverter = new PartySourceSystemConverter();

    public APIResponse convertPersonDetails(TCRMPersonBObjType tcrmPersonObject, String traceId) {
        APIResponse apiResponse = new APIResponse();
        Long startTime = System.currentTimeMillis();
        LogUtil.debug(log, "convertPersonDetails", traceId, "starting person details transformation ");
        identifierConverter.convertIdentifierDetails(apiResponse, tcrmPersonObject.getTCRMPartyIdentificationBObj(),
                traceId);
        if (!CollectionUtils.isEmpty(tcrmPersonObject.getTCRMAdminContEquivBObj())) {
            sourceSystemConverter.convertSourceSystems(apiResponse, tcrmPersonObject.getTCRMAdminContEquivBObj(),
                    traceId);
        }
        Long endTime = System.currentTimeMillis();
        LogUtil.debug(log, "convertPersonDetails", traceId, "finishing person details transformation ",
                endTime - startTime);
        return apiResponse;

    }
}
