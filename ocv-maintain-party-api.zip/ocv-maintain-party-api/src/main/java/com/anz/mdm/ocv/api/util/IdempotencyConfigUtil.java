package com.anz.mdm.ocv.api.util;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;
import java.time.temporal.ChronoUnit;



import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.exception.BadRequestException;
import com.anz.mdm.ocv.api.exception.IdempotencyTimeOutException;
import com.anz.mdm.ocv.api.validator.APIRequest;
import com.anz.mdm.ocv.api.validator.ValidationResult;
import com.anz.mdm.ocv.party.v1.Party;

import lombok.extern.slf4j.Slf4j;

@Component
@Qualifier(value = "idempotencyConfigUtil")
@Slf4j
public class IdempotencyConfigUtil {

    @Value("${idempotent.channels}")
    private String idempotentChannels;

    @Value("${idempotent.request-modes}")
    private String fenergoanzxRequestMode;
    
    @Value("${idempotent.expiryTimeWindow}")
    private String idempotencyExpiryTimeWindow;



    public String getIdempotencyExpiryTimeWindow() {
        return idempotencyExpiryTimeWindow;
    }
    
    public String[] getFenergoanzxRequestMode() {
        String[] requestModeFenergoAnzx = fenergoanzxRequestMode.split(",");
        return requestModeFenergoAnzx;
    }

    public String[] getIdempotentChannels() {
        String[] channels = this.idempotentChannels.split(",");
        return channels;
    }



    // Util method to check if channel is included in the config map
    public boolean isChannelIncluded(String channel, String traceId) {
        LogUtil.debug(log, "isChannelIncluded", traceId,
                "Entering: isChannelIncluded method in IdempotencyConfigUtil");
        for (String string : getIdempotentChannels()) {
            if (channel.equalsIgnoreCase(string)) {
                LogUtil.debug(log, "isChannelIncluded", traceId,
                        "Exit: isChannelIncluded method in IdempotencyConfigUtil : true");
                return true;
            }
        }
        
        LogUtil.debug(log, "isChannelIncluded", traceId,
                "Exit: isChannelIncluded method in IdempotencyConfigUtil : false");
        return false;
    }

    // Takes in channel and request mode to check if a request mode in present
    // for a channel
    public boolean isRequestModeIncluded(boolean isChannelIncluded,
            String channel, String requestMode, String traceId) {
        LogUtil.debug(log, "isRequestModeIncluded", traceId,
                "Entering: isRequestModeIncluded method in isRequestModeIncluded");

        if (isChannelIncluded && null != requestMode
                && (channel.equalsIgnoreCase(OCVConstants.FENERGO_SOURCE)
                        || channel.equalsIgnoreCase(OCVConstants.CRM))) {
            for (String reqMode : getFenergoanzxRequestMode()) {

                if (reqMode.equalsIgnoreCase(requestMode)) {
                    LogUtil.debug(log, "isRequestModeIncluded", traceId,
                            "Exit: isRequestModeIncluded method in isRequestModeIncluded : true");
                    return true;
                }
            }
            LogUtil.debug(log, "isRequestModeIncluded", traceId,
                    "Exit: isRequestModeIncluded method in isRequestModeIncluded : false");
            return false;
        }
        LogUtil.debug(log, "isRequestModeIncluded", traceId,
                "Exit: isRequestModeIncluded method in isRequestModeIncluded : false");
        return false;
    }

    public LocalDateTime parseDateFromString(String dateString) {
        if (null != dateString && !dateString.isEmpty()) {
            final DateTimeFormatter formatter = new DateTimeFormatterBuilder()
                    .appendPattern("yyyy-MM-dd[[ ]['T']HH:mm[:ss][.SSS][.SS][.S][SSSSS][XXX]]").optionalStart()
                    .appendPattern(".").appendFraction(ChronoField.MICRO_OF_SECOND, 1, 6, false).optionalEnd()
                    .toFormatter();
            LocalDateTime localDateTime = LocalDateTime.parse(dateString, formatter);
            return localDateTime;
        }
        return null;
    }

    public LocalDateTime millsToLocalDateTime(long millis) {
        // LocalDateTime parseDateFromString = parseDateFromString("2018-11-05
        // 19:07:01.123");
        Instant instant = Instant.ofEpochMilli(millis);
        LocalDateTime date = instant.atZone(ZoneId.systemDefault()).toLocalDateTime();

        return date;
    }

    public boolean isWithinExpiryTime(String idempotencyFirstSent) {
        LocalDateTime firstSentDateTime = parseDateFromString(idempotencyFirstSent);
        LocalDateTime millsCurrentLocalDateTime = millsToLocalDateTime(System.currentTimeMillis());
        long intervalDuration = ChronoUnit.SECONDS.between(firstSentDateTime, millsCurrentLocalDateTime);
        float intervalDurationHour = (float) intervalDuration / 3600;
        if (intervalDurationHour > Float.parseFloat(getIdempotencyExpiryTimeWindow())) {
            return false;
        }
        return true;
    }

    public boolean validateTime(String idempotencyFirstSent) {
        try {
            parseDateFromString(idempotencyFirstSent);
        } catch (Exception e) {
            return false;
        }
        return true;
    }
    
    public void validate(APIRequest<Party> validatedApiRequest, APIRequest<Party> apiRequest, String traceId)
            throws IdempotencyTimeOutException, BadRequestException {

        LogUtil.debug(log, "validate", traceId,
                "Entering: validate method in IdempotencyConfigUtil");
        
        ValidationResult idempotentValidation = idempotencyValidator(validatedApiRequest, apiRequest,traceId);

        if (!idempotentValidation.isValid()) {
            LogUtil.debug(log, "maintainPartyV2", traceId,
                    "Idempotent Request Validation failed with error code :" + idempotentValidation.getErrorCode());
            if (idempotentValidation.getErrorCode().equals(OCVConstants.IDEMPOTENT_TIME_LIMIT_EXPIRED)  
                    || idempotentValidation.getErrorCode().equals(OCVConstants.IDEMPOTENT_FIRST_SENT_WRONG_FORMAT)) {
                throw new IdempotencyTimeOutException(idempotentValidation.getErrorCode(), "Expired or Invalid Time");
            } else {
                throw new BadRequestException(idempotentValidation.getErrorCode(), idempotentValidation.getStatus());
            }

        }
        
        LogUtil.debug(log, "validate", traceId,
                "Exit: validate method in IdempotencyConfigUtil");
    }
    
    public ValidationResult idempotencyValidator(APIRequest<Party> validatedApiRequest, APIRequest<Party> apiRequest,
            String traceId) {

        LogUtil.debug(log, "idempotencyValidator", traceId,
                "Entering: idempotencyValidator method in IdempotencyConfigUtil");

        String channel = apiRequest.getChannel();
        String requestMode = apiRequest.getRequestMode();

        boolean isChannelIncluded = isChannelIncluded(channel, traceId);
        boolean isRequestModeIncluded = false;

        isRequestModeIncluded = isRequestModeIncluded(isChannelIncluded, channel, requestMode, traceId);

        ValidationResult validationResult = new ValidationResult();

        // If idempotent channel is included in request check for
        // idempotent key and idempotentfirstsent - If it is valid
        // If valid : Go ahead with the request
        // Invalid : Return Error
        if (isChannelIncluded && isRequestModeIncluded) {

            if (! isNotValidHeaders(apiRequest, validationResult).isValid()) {
                return validationResult;
            }
        }

        if (isChannelIncluded && isRequestModeIncluded
                && !isWithinExpiryTime(validatedApiRequest.getHeaders().get(OCVConstants.IDEMPOTENCY_FIRST_SENT))) {
            validationResult.setErrorCode(OCVConstants.IDEMPOTENT_TIME_LIMIT_EXPIRED);
        }

        LogUtil.debug(log, "idempotencyValidator", traceId,
                "Exit: idempotencyValidator method in IdempotencyConfigUtil");

        return validationResult;

    }
    
    public ValidationResult isNotValidHeaders(APIRequest<Party> apiRequest,
            ValidationResult validationResult) {

        LogUtil.debug(log, "isNotValidHeaders", apiRequest.getTraceId(),
                "Entering: isNotValidHeaders method in IdempotencyConfigUtil");

        if (null == apiRequest.getIdempotentFirstSent()
                || StringUtils.isBlank(apiRequest.getIdempotentFirstSent()
                        .trim()) || null == apiRequest.getIdempotentKey()
                || StringUtils.isBlank(apiRequest.getIdempotentKey().trim())) {
            validationResult
                    .setErrorCode(OCVConstants.MANDATORY_HEADER_MISSING_ERROR_CODE);
            return validationResult;
        }

        if (!validateTime(apiRequest.getIdempotentFirstSent())) {
            validationResult
                    .setErrorCode(OCVConstants.IDEMPOTENT_FIRST_SENT_WRONG_FORMAT);

        }

        return validationResult;
    }      

}
