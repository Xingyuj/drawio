package com.anz.mdm.ocv.api;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.SSLContext;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.TransformerFactory;

import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.ssl.SSLContextBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.boot.web.embedded.undertow.UndertowDeploymentInfoCustomizer;
import org.springframework.boot.web.embedded.undertow.UndertowServletWebServerFactory;
import org.springframework.boot.web.servlet.server.ServletWebServerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.xml.MarshallingHttpMessageConverter;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.util.ResourceUtils;
import org.springframework.web.client.RestTemplate;

import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.exception.InitializationException;
import com.anz.mdm.ocv.api.util.LogUtil;
import com.ibm.mdm.schema.TCRMService;

import io.undertow.server.handlers.DisallowedMethodsHandler;
import io.undertow.servlet.api.DeploymentInfo;
import io.undertow.util.HttpString;
import lombok.extern.slf4j.Slf4j;

/**
 * Serves as configuration class to instantiate beans in application context
 * 
 * @author Deepika Handa
 */

@Slf4j
@Configuration
public class APIConfiguration {
    @Value("${mdmEndpoint.username}")
    private String user;

    @Value("${mdmEndpoint.password}")
    private String password;

    @Value("${server.ssl.trust-store}")
    private String keystore;

    @Value("${server.ssl.trust-store-password}")
    private String keystorePassword;

    @Value("${httpConnectionPool.maxTotal}")
    private Integer maxTotal;

    @Value("${httpConnectionPool.defaultMaxPerRoute}")
    private Integer defaultMaxPerRoute;

    @Value("${backend.connect-timeout}")
    private int connectTimeOut;

    @Value("${backend.maintainParty-read-timeout}")
    private int maintainPartyReadTimeOut;

    @Value("${backend.deleteParty-read-timeout}")
    private int deletePartyReadTimeOut;

    @Value("${backend.retrieve-api-read-timeout}")
    private int retrievePartyReadTimeOut;

    @Value("${server.ssl.key-store}")
    private String keystoreforhealtcheck;

    @Value("${server.ssl.key-store-password}")
    private String keystorePasswordforhealthcheck;


    
    @Bean(name = "MaintainPartyServiceMDMRestTemplate")
    public RestTemplate getRestTemplateForMdm(RestTemplateBuilder restTemplateBuilder,
            PoolingHttpClientConnectionManager poolingHttpClientConnectionManager) throws InitializationException {
        RestTemplate restTemplate = restTemplateBuilder.basicAuthentication(user, password).build();
        HttpComponentsClientHttpRequestFactory cl = clientHttpRequestFactory(poolingHttpClientConnectionManager);
        cl.setReadTimeout(maintainPartyReadTimeOut);
        restTemplate.setRequestFactory(cl);
        return restTemplate;
    }
    
    @Bean(name = "MaintainPartyMDMRestTemplate")
    public RestTemplate getRestTemplateForMdmMaintainParty(
            RestTemplateBuilder restTemplateBuilder,
            PoolingHttpClientConnectionManager poolingHttpClientConnectionManager) throws InitializationException {

        List<HttpMessageConverter<?>> messageConverters = new ArrayList<>();
        messageConverters.add(getMarshallingHttpMessageConverter());

        RestTemplate restTemplate = restTemplateBuilder.additionalMessageConverters(messageConverters)
                .basicAuthentication(user, password).build();

        HttpComponentsClientHttpRequestFactory cl = clientHttpRequestFactory(poolingHttpClientConnectionManager);
        cl.setReadTimeout(maintainPartyReadTimeOut);
        restTemplate.setRequestFactory(cl);
        return restTemplate;
    }
    
    @Bean(name = "marshallingHttpMessageConverter")
    public MarshallingHttpMessageConverter getMarshallingHttpMessageConverter() {

        MarshallingHttpMessageConverter marshallingHttpMessageConverter = new MarshallingHttpMessageConverter();
        marshallingHttpMessageConverter.setMarshaller(getJaxb2Marshaller());
        marshallingHttpMessageConverter.setUnmarshaller(getJaxb2Marshaller());
        return marshallingHttpMessageConverter;
    }
    
    @Bean(name = "jaxb2Marshaller")
    public Jaxb2Marshaller getJaxb2Marshaller() {
        Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
        jaxb2Marshaller.setClassesToBeBound(TCRMService.class);
        return jaxb2Marshaller;
    }

    @Bean(name = "DeletePartyServiceMDMRestTemplate")
    public RestTemplate getRestTemplateForMdmPurge(RestTemplateBuilder restTemplateBuilder,
            PoolingHttpClientConnectionManager poolingHttpClientConnectionManager) throws InitializationException {
        RestTemplate restTemplate = restTemplateBuilder.basicAuthentication(user, password).build();
        HttpComponentsClientHttpRequestFactory cl = clientHttpRequestFactory(poolingHttpClientConnectionManager);
        cl.setReadTimeout(deletePartyReadTimeOut);
        restTemplate.setRequestFactory(cl);
        return restTemplate;
    }

    @Bean(name = "DataStandardisationRestTemplate")
    public RestTemplate getRestTemplateForDataStandardisation(final RestTemplateBuilder restTemplateBuilder,
            PoolingHttpClientConnectionManager poolingHttpClientConnectionManager) throws InitializationException {
        final RestTemplate restTemplate = restTemplateBuilder.build();
        restTemplate.setRequestFactory(clientHttpRequestFactory(poolingHttpClientConnectionManager));
        return restTemplate;
    }

    @Bean(name = "DataValidationRestTemplate")
    public RestTemplate getRestTemplateForDataValidation(final RestTemplateBuilder restTemplateBuilder,
            PoolingHttpClientConnectionManager poolingHttpClientConnectionManager) throws InitializationException {
        final RestTemplate restTemplate = restTemplateBuilder.build();
        restTemplate.setRequestFactory(clientHttpRequestFactory(poolingHttpClientConnectionManager));
        return restTemplate;
    }

    @Bean(name = "CapProfileRestTemplate")
    public RestTemplate getRestTemplateForCapProfile(final RestTemplateBuilder restTemplateBuilder,
            PoolingHttpClientConnectionManager poolingHttpClientConnectionManager) throws InitializationException {
        final RestTemplate restTemplate = restTemplateBuilder.build();
        restTemplate.setRequestFactory(clientHttpRequestFactory(poolingHttpClientConnectionManager));
        return restTemplate;
    }

 // CHECKSTYLE:OFF - checkstyle considers this as utility class
    @Bean
    public PoolingHttpClientConnectionManager poolingHttpClientConnectionManager() throws InitializationException {
        String method = "poolingHttpClientConnectionManager";
        PoolingHttpClientConnectionManager poolingHttpClientConnectionManager = null;
        try {
            // SSLContext sslContext = SSLContextBuilder.create()
            // .loadTrustMaterial(ResourceUtils.getFile(keystore),
            // keystorePassword.toCharArray())
            // .setProtocol(OCVConstants.SSL_VERSION).build();
            SSLContext sslContext = SSLContextBuilder.create()
                    .loadKeyMaterial(ResourceUtils.getFile(keystoreforhealtcheck),
                            keystorePasswordforhealthcheck.toCharArray(), keystorePasswordforhealthcheck.toCharArray())
                    .setProtocol(OCVConstants.SSL_VERSION)
                    .loadTrustMaterial(ResourceUtils.getFile(keystore), keystorePassword.toCharArray()).build();
            SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslContext, new NoopHostnameVerifier());
            Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder.<ConnectionSocketFactory>create()
                    .register("https", sslsf).build();
            poolingHttpClientConnectionManager = new PoolingHttpClientConnectionManager(socketFactoryRegistry);
            poolingHttpClientConnectionManager.setMaxTotal(maxTotal);
            poolingHttpClientConnectionManager.setDefaultMaxPerRoute(defaultMaxPerRoute);

        } catch (KeyManagementException | UnrecoverableKeyException | KeyStoreException | NoSuchAlgorithmException
                | CertificateException | IOException e) {
            LogUtil.debug(log, "clientHttpRequestFactory", "Error initialising request factory",
                    "Exiting: clientHttpRequestFactory method in APIConfiguration");
            throw new InitializationException(e);
        }
        return poolingHttpClientConnectionManager;
    }
 // CHECKSTYLE:ON
    public HttpComponentsClientHttpRequestFactory clientHttpRequestFactory(
            PoolingHttpClientConnectionManager poolingHttpClientConnectionManager) throws InitializationException {
        LogUtil.debug(log, "clientHttpRequestFactory", null,
                "Entering: clientHttpRequestFactory method in APIConfiguration");
        HttpComponentsClientHttpRequestFactory httpclientHttpRequestFactory;
        try {
            SSLContext sslContext = SSLContextBuilder.create()
                    .loadTrustMaterial(ResourceUtils.getFile(keystore), keystorePassword.toCharArray())
                    .setProtocol(OCVConstants.SSL_VERSION).build();
            SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext, new NoopHostnameVerifier());
            CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(csf)
                    .setConnectionManager(poolingHttpClientConnectionManager).build();
            httpclientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory();
            httpclientHttpRequestFactory.setConnectTimeout(connectTimeOut);
            httpclientHttpRequestFactory.setHttpClient(httpClient);
        } catch (KeyManagementException | KeyStoreException | NoSuchAlgorithmException | CertificateException
                | IOException e) {
            LogUtil.debug(log, "clientHttpRequestFactory", "Error initialising request factory",
                    "Exiting: clientHttpRequestFactory method in APIConfiguration");
            throw new InitializationException(e);
        }
        return httpclientHttpRequestFactory;
    }

    @Bean
    public ResourceLoader getResourceLoader(ResourceLoader resourceLoader) {
        return resourceLoader;
    }

    @Bean
    public TransformerFactory getTransformerFactory() {
        return TransformerFactory.newInstance();
    }

    @Bean
    public DocumentBuilderFactory getDocumentBuilderFactory() {
        return DocumentBuilderFactory.newInstance();
    }

    /**
     * Factory to configure blocking of any HTTP method other than GET, POST, PUT
     * and DELETE methods
     * 
     * @return ServletWebServerFactory the socketfactory
     */
    @Bean
    public ServletWebServerFactory servletContainer() {
        UndertowServletWebServerFactory factory = new UndertowServletWebServerFactory();

        factory.addDeploymentInfoCustomizers(new APIUndertowDeploymentInfoCustomizer());
        return factory;
    }

    static class APIUndertowDeploymentInfoCustomizer implements UndertowDeploymentInfoCustomizer {
        @Override
        public void customize(DeploymentInfo deploymentInfo) {
            deploymentInfo.addInitialHandlerChainWrapper(handler -> {
                HttpString[] disallowedHttpMethods = { HttpString.tryFromString("TRACE"),
                        HttpString.tryFromString("OPTIONS"), HttpString.tryFromString("HEAD"),
                        HttpString.tryFromString("PATCH"), HttpString.tryFromString("PROPFIND"),
                        HttpString.tryFromString("LOCK"), HttpString.tryFromString("UNLOCK"),
                        HttpString.tryFromString("COPY"), HttpString.tryFromString("PURGE") };
                return new DisallowedMethodsHandler(handler, disallowedHttpMethods);
            });
        }

    }

    // CHECKSTYLE:OFF - checkstyle considers this as utility class
    @Bean(name = "ApiRestTemplate")
    public RestTemplate getApiRestTemplate(final RestTemplateBuilder restTemplateBuilder,
            PoolingHttpClientConnectionManager poolingHttpClientConnectionManager) throws InitializationException {
        String method = "getApiRestTemplate";
        SSLContext sslContext = null;
        HttpComponentsClientHttpRequestFactory httpclientHttpRequestFactory;
        try {
            sslContext = SSLContextBuilder.create()
                    .loadKeyMaterial(ResourceUtils.getFile(keystoreforhealtcheck),
                            keystorePasswordforhealthcheck.toCharArray(), keystorePasswordforhealthcheck.toCharArray())
                    .setProtocol(OCVConstants.SSL_VERSION)
                    .loadTrustMaterial(ResourceUtils.getFile(keystore), keystorePassword.toCharArray()).build();
            SSLConnectionSocketFactory sslConnectionSocketFactory = new SSLConnectionSocketFactory(sslContext,
                    new NoopHostnameVerifier());
            CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(sslConnectionSocketFactory)
                    .setConnectionManager(poolingHttpClientConnectionManager).build();
            httpclientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory();
            httpclientHttpRequestFactory.setConnectTimeout(connectTimeOut);
            httpclientHttpRequestFactory.setHttpClient(httpClient);
            httpclientHttpRequestFactory.setReadTimeout(retrievePartyReadTimeOut);
        } catch (KeyManagementException e) {
            LogUtil.error(log, method, null,
                    "KeyManagementException in getHealthCheckrestTemplate method in APIConfiguration");
            throw new InitializationException(e);
        } catch (UnrecoverableKeyException e) {
            LogUtil.error(log, method, null,
                    "UnrecoverableKeyException in getHealthCheckrestTemplate method in APIConfiguration");
            throw new InitializationException(e);
        } catch (NoSuchAlgorithmException e) {
            LogUtil.error(log, method, null,
                    "NoSuchAlgorithmException in getHealthCheckrestTemplate method in APIConfiguration");
            throw new InitializationException(e);
        } catch (KeyStoreException e) {
            LogUtil.error(log, method, null,
                    "KeyStoreException in getHealthCheckrestTemplate method in APIConfiguration");
            throw new InitializationException(e);
        } catch (CertificateException e) {
            LogUtil.error(log, method, null,
                    "CertificateException in getHealthCheckrestTemplate method in APIConfiguration");
            throw new InitializationException(e);
        } catch (FileNotFoundException e) {
            LogUtil.error(log, method, null,
                    "FileNotFoundException in getHealthCheckrestTemplate method in APIConfiguration");
            throw new InitializationException(e);
        } catch (IOException e) {
            LogUtil.error(log, method, null, "IOException in getHealthCheckrestTemplate method in APIConfiguration");
            throw new InitializationException(e);
        }

        return new RestTemplate(httpclientHttpRequestFactory);

    }

    @Bean(name = "tokenRestTemplate")
    public RestTemplate getRestTemplateForVault(final RestTemplateBuilder restTemplateBuilder)
            throws InitializationException {
        String method = "tokenRestTemplate";
        SSLContext sslContext = null;
        try {
            sslContext = SSLContextBuilder.create()
                    .loadKeyMaterial(ResourceUtils.getFile(keystoreforhealtcheck),
                            keystorePasswordforhealthcheck.toCharArray(), keystorePasswordforhealthcheck.toCharArray())
                    .setProtocol(OCVConstants.SSL_VERSION)
                    .loadTrustMaterial(ResourceUtils.getFile(keystore), keystorePassword.toCharArray()).build();

        } catch (KeyManagementException e) {
            LogUtil.error(log, method, null,
                    "KeyManagementException in tokenRestTemplate method in ApiConfiguration");
            throw new InitializationException(e);
        } catch (UnrecoverableKeyException e) {
            LogUtil.error(log, method, null,
                    "UnrecoverableKeyException in tokenRestTemplate method in ApiConfiguration");
            throw new InitializationException(e);
        } catch (NoSuchAlgorithmException e) {
            LogUtil.error(log, method, null,
                    "NoSuchAlgorithmException in tokenRestTemplate method in ApiConfiguration");
            throw new InitializationException(e);
        } catch (KeyStoreException e) {
            LogUtil.error(log, method, null,
                    "KeyStoreException in tokenRestTemplate method in ApiConfiguration");
            throw new InitializationException(e);
        } catch (CertificateException e) {
            LogUtil.error(log, method, null,
                    "CertificateException in tokenRestTemplate method in ApiConfiguration");
            throw new InitializationException(e);
        } catch (FileNotFoundException e) {
            LogUtil.error(log, method, null,
                    "FileNotFoundException in tokenRestTemplate method in ApiConfiguration");
            throw new InitializationException(e);
        } catch (IOException e) {
            LogUtil.error(log, method, null, "IOException in tokenRestTemplate method in ApiConfiguration");
            throw new InitializationException(e);
        }

        SSLConnectionSocketFactory sslConnectionSocketFactory = new SSLConnectionSocketFactory(sslContext,
                new NoopHostnameVerifier());

        CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(sslConnectionSocketFactory).build();

        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);

        return new RestTemplate(requestFactory);

    }

    @Bean(name = "RedhatRuleEngineServiceRestTemplate")
    public RestTemplate getRestTemplateForPhoneStandardisation(final RestTemplateBuilder restTemplateBuilder,
            PoolingHttpClientConnectionManager poolingHttpClientConnectionManager) throws InitializationException {
        final RestTemplate restTemplate = restTemplateBuilder.build();
        restTemplate.setRequestFactory(clientHttpRequestFactory(poolingHttpClientConnectionManager));
        return restTemplate;
    }

 // CHECKSTYLE:ON
}