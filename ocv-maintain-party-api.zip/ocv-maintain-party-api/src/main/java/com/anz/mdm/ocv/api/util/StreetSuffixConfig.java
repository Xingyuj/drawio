package com.anz.mdm.ocv.api.util;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Setter
@Getter
@Configuration
@ConfigurationProperties(prefix = "streetsuffix")
public class StreetSuffixConfig {

    private Map<String, String> map = new HashMap<String, String>();

    public String getPropertyValue(String key) {
        String value = StringUtils.upperCase(map.get(StringUtils.lowerCase(key)));
        if (StringUtils.isNotBlank(value)) {
            return value;
        } else {
            return key;
        }

    }
}
