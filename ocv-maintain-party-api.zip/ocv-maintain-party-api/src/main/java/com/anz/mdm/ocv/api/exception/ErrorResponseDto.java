package com.anz.mdm.ocv.api.exception;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * ErrorResponseDto used to transform error response from downstream service
 * 
 * @author handad
 *
 */
@Setter
@Getter
public class ErrorResponseDto {

    private int httpCode;
    private String httpMessage;
    private String moreInformation;
    private List<Error> errors;
    private String error;
    private String message;
    private String path;
    private String timestamp;
    private String status;
}
