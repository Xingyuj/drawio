package com.anz.mdm.ocv.api.validator;

import static org.springframework.util.StringUtils.isEmpty;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.interceptor.UAMInterceptor;
import com.anz.mdm.ocv.api.util.LogUtil;
import com.anz.mdm.ocv.common.v1.Address;
import com.anz.mdm.ocv.common.v1.Email;
import com.anz.mdm.ocv.common.v1.KYCVerification;
import com.anz.mdm.ocv.common.v1.Name;
import com.anz.mdm.ocv.common.v1.Phone;
import com.anz.mdm.ocv.party.v1.Party;

import lombok.extern.slf4j.Slf4j;

/**
 * MaintainCapPartyValidator class validates the mandatory attributes in API
 * request required by CAP*
 *
 * @author junejak
 */

@Slf4j
@Component
public class MaintainCapPartyValidator extends AbstractValidator<Party> {

    @Autowired
    private UAMInterceptor uamInterceptor;

    @Override
    public ValidationResult validateRequest(APIRequest<Party> apiRequest1) {
        ValidationResult result = super.validateRequest(apiRequest1);
        result = validateSecureHeaders(apiRequest1, result);

        result = validateANZXRequest(apiRequest1, result);
        if (result.isValid()) {
            // OCT-23700 - for validating JWT Token Scope
            validateJWTScopes(apiRequest1, result);
        }
        return result;
    }

    public ValidationResult validateANZXRequest(APIRequest<Party> apiRequest1, ValidationResult result) {
        if (result.isValid() && isEmpty(apiRequest1.getRequestMode())) {
            result.setStatus(OCVConstants.MISSING_REQUESTMODE);
            result.setErrorCode(OCVConstants.MANDATORY_HEADER_MISSING_ERROR_CODE);
        }
        return result;
    }

    private void validateJWTScopes(APIRequest<Party> apiRequest, ValidationResult validationResult) {
        String application = apiRequest.getApplication();

        if (validationResult.isValid() && (application == null || !application.equalsIgnoreCase("OCV"))) {
            uamInterceptor.validateJWTTokenScope(apiRequest, validationResult);
        }
        LogUtil.debug(log, "validateJWTScopes", apiRequest.getTraceId(),
                "JWT Scope validation check passed: " + validationResult.isValid());
    }

    @Override
    protected ValidationResult validateBody(APIRequest<Party> apiRequest) {

        Party requestBody = apiRequest.getRequestBody();
        String traceId = apiRequest.getTraceId();
        String requestMode = apiRequest.getRequestMode();
        LogUtil.debug(log, "MaintainCapPartyValidator.validateBody", traceId,
                "Entering: MaintainCapPartyValidator.validateBody");
        ValidationResult validationResult = new ValidationResult();
        List<String> missingAttrList = new ArrayList<>();
        if (isEmpty(requestBody.getPartyType())) {
            missingAttrList.add(OCVConstants.PARTY_TYPE_ATTR);
        }
        validateNameAndAddress(requestBody, requestMode, missingAttrList);
        if (!CollectionUtils.isEmpty(missingAttrList)) {
            List<String> distinctList = missingAttrList.stream().distinct().collect(Collectors.toList());
            String uniqueAttrs = distinctList.stream().collect(Collectors.joining(OCVConstants.COMMA_OPERATOR + " "));
            validationResult.setErrorCode(OCVConstants.MANDATORY_ATTRIBUTES_MISSING);
            validationResult.setStatus(OCVConstants.MISSING_MANDATORY_ATTRIBUTES_ERROR_MESSAGE + uniqueAttrs);
        }
        LogUtil.debug(log, "validateRequest", traceId,
                "mandatory attributes check passed: " + validationResult.isValid());
        if (Boolean.TRUE.equals(validationResult.isValid())) {
            StringBuilder errorMessage = new StringBuilder();
            List<Email> emails = requestBody.getEmails();
            List<Phone> phones = requestBody.getPhones();

            validateEmail(emails, validationResult, errorMessage, requestMode);
            validateMobile(phones, validationResult, errorMessage, requestMode);
        }
        validateKycVerification(validationResult, requestBody.getKycVerifications());
        LogUtil.debug(log, "MaintainCapPartyValidator.validateBody", traceId,
                "Exit: MaintainCapPartyValidator.validateBody");
        return validationResult;
    }

    private void validateKycVerification(ValidationResult validationResult, List<KYCVerification> kycVerifications) {
        StringBuilder errorMessage = new StringBuilder();
        if (Boolean.TRUE.equals(validationResult.isValid())
                && ((!CollectionUtils.isEmpty(kycVerifications)) && kycVerifications.size() > 1)) {
            errorMessage.append(OCVConstants.KYCVERIFICATION_ERROR_MESSAGE);
            validationResult.setErrorCode(OCVConstants.KYCVERIFICATION_ERROR_CODE);
            validationResult.setStatus(errorMessage.toString());
        }
    }

    private void validateNameAndAddress(Party requestBody, String requestMode, List<String> missingAttrList) {
        if (OCVConstants.REQUEST_MODE_CREATE_CUSTOMER.equalsIgnoreCase(requestMode)
                || OCVConstants.REQUEST_MODE_UPDATEKYC.equalsIgnoreCase(requestMode)) {
            validateName(requestBody, missingAttrList);
            List<Address> addresses = requestBody.getAddresses();
            validateAddress(addresses, missingAttrList);
        }
    }

    private void validateEmail(List<Email> emails, ValidationResult validationResult, StringBuilder errorMessage,
                               String requestMode) {
        if (!CollectionUtils.isEmpty(emails)) {
            if (!(emails.size() == 1
                    && OCVConstants.SECURITY_EMAIL.equalsIgnoreCase(emails.get(0).getEmailUsageType()))) {
                errorMessage.append(OCVConstants.SECURITY_EMAIL_ERROR_MESSAGE);
                validationResult.setErrorCode(OCVConstants.SECURITY_EMAIL_MOB_ERROR_CODE);
                validationResult.setStatus(errorMessage.toString());
            } else {
                checkEmailSource(emails, validationResult, errorMessage, requestMode);
            }
        }
    }

    private void checkEmailSource(List<Email> emails, ValidationResult validationResult, StringBuilder errorMessage,
                                  String requestMode) {
        if (OCVConstants.REQUEST_MODE_CREATE_CUSTOMER.equalsIgnoreCase(requestMode)
                || OCVConstants.REQUEST_MODE_UPDATEKYC.equalsIgnoreCase(requestMode)) {
            if (!(OCVConstants.FENERGO_SOURCE.equalsIgnoreCase(emails.get(0).getSource()))) {
                errorMessage.append(OCVConstants.SEC_EMAIL_INT_1_SRC_ERR_MSG);
                validationResult.setErrorCode(OCVConstants.SECURITY_EMAIL_MOB_ERROR_CODE);
                validationResult.setStatus(errorMessage.toString());
            }
        } else if (OCVConstants.REQUEST_MODE_UPDATE_ANZX.equalsIgnoreCase(requestMode)) {
            if (!(OCVConstants.FENERGO_SOURCE.equalsIgnoreCase(emails.get(0).getSource())
                    || OCVConstants.AEGIS_SOURCE.equalsIgnoreCase(emails.get(0).getSource()))) {
                errorMessage.append(OCVConstants.SEC_EMAIL_INT_1_2_SRC_ERR_MSG);
                validationResult.setErrorCode(OCVConstants.SECURITY_EMAIL_MOB_ERROR_CODE);
                validationResult.setStatus(errorMessage.toString());
            }
        }
    }

    private void validateMobile(List<Phone> phones, ValidationResult validationResult, StringBuilder errorMessage,
                                String requestMode) {
        if (!CollectionUtils.isEmpty(phones)) {
            if (!(phones.size() == 1
                    && OCVConstants.SECURITY_MOBILE.equalsIgnoreCase(phones.get(0).getPhoneUsageType()))) {
                validationResult.setErrorCode(OCVConstants.SECURITY_EMAIL_MOB_ERROR_CODE);
                validationResult.setStatus(StringUtils.isNotEmpty(errorMessage)
                        ? errorMessage.append(OCVConstants.COMMA_OPERATOR).append(OCVConstants.SPACE_OPERATOR)
                        .append(OCVConstants.SECURITY_MOBILE_ERROR_MESSAGE).toString()
                        : OCVConstants.SECURITY_MOBILE_ERROR_MESSAGE);
            } else {
                checkMobileSource(phones, validationResult, errorMessage, requestMode);
            }
        }
    }

    private void checkMobileSource(List<Phone> phones, ValidationResult validationResult, StringBuilder errorMessage,
                                   String requestMode) {
        if (OCVConstants.REQUEST_MODE_CREATE_CUSTOMER.equalsIgnoreCase(requestMode)
                || OCVConstants.REQUEST_MODE_UPDATEKYC.equalsIgnoreCase(requestMode)) {
            if (!OCVConstants.FENERGO_SOURCE.equalsIgnoreCase(phones.get(0).getSource())) {
                errorMessage.append(OCVConstants.SEC_MOBILE_INT_1_SRC_ERR_MSG);
                validationResult.setErrorCode(OCVConstants.SECURITY_EMAIL_MOB_ERROR_CODE);
                validationResult.setStatus(errorMessage.toString());
            }
        } else if (OCVConstants.REQUEST_MODE_UPDATE_ANZX.equalsIgnoreCase(requestMode)) {
            if (!(OCVConstants.FENERGO_SOURCE.equalsIgnoreCase(phones.get(0).getSource())
                    || OCVConstants.AEGIS_SOURCE.equalsIgnoreCase(phones.get(0).getSource()))) {
                errorMessage.append(OCVConstants.SEC_MOBILE_INT_1_2_SRC_ERR_MSG);
                validationResult.setErrorCode(OCVConstants.SECURITY_EMAIL_MOB_ERROR_CODE);
                validationResult.setStatus(errorMessage.toString());
            }
        }
    }

    public void validateName(Party requestBody, List<String> missingAttrList) {
        List<Name> names = requestBody.getNames();
        Boolean flag = Boolean.FALSE;
        String partyType = requestBody.getPartyType();
        if (CollectionUtils.isEmpty(names)) {
            missingAttrList.add(OCVConstants.NAME);
        } else {
            for (Name name : names) {
                flag = checkNameUsageType(flag, partyType, name);
                checkName(missingAttrList, partyType, name);
            }
            if (Boolean.FALSE.equals(flag)) {
                missingAttrList.add(OCVConstants.LEGAL_NAME_USAGE_TYPE);
            }
        }
    }

    private void checkName(List<String> missingAttrList, String partyType, Name name) {
        if (OCVConstants.INDIVIDUAL_PARTY_TYPE.equals(partyType)) {
            validateNames(missingAttrList, name);
        } else if (OCVConstants.NON_INDIVIDUAL_PARTY_TYPE.equals(partyType) && StringUtils.isEmpty(name.getName())) {
            missingAttrList.add(OCVConstants.NAME);
        }
    }

    private void validateNames(List<String> missingAttrList, Name name) {
        if (StringUtils.isEmpty(name.getLastName())) {
            missingAttrList.add(OCVConstants.LAST_NAME);
        }
        if (StringUtils.isEmpty(name.getFirstName())) {
            missingAttrList.add(OCVConstants.FIRST_NAME);
        }
    }

    private Boolean checkNameUsageType(Boolean flag, String partyType, Name name) {
        Boolean result = flag;
        if (OCVConstants.INDIVIDUAL_PARTY_TYPE.equals(partyType)
                && OCVConstants.LEGAL_NAME.equals(name.getNameUsageType())) {
            result = Boolean.TRUE;
        }
        return result;
    }

    private void validateAddress(List<Address> addresses, List<String> missingAttrList) {
        if (CollectionUtils.isEmpty(addresses)) {
            missingAttrList.add(OCVConstants.ADDRESS);
        } else {
            addresses.stream().forEach(address -> {
                validateAddressUsageType(missingAttrList, address);
                validateCountry(missingAttrList, address);
                validateState(missingAttrList, address);
                validateCity(missingAttrList, address);
                validatePostalCode(missingAttrList, address);
            });
        }
    }

    private void validatePostalCode(List<String> missingAttrList, Address address) {
        if (StringUtils.isBlank(address.getPostalCode())) {
            missingAttrList.add(OCVConstants.POSTAL_CODE);
        }
    }

    private void validateCity(List<String> missingAttrList, Address address) {
        if (StringUtils.isBlank(address.getCity())) {
            missingAttrList.add(OCVConstants.CITY);
        }
    }

    private void validateState(List<String> missingAttrList, Address address) {
        if (StringUtils.isBlank(address.getState())) {
            missingAttrList.add(OCVConstants.STATE);
        }
    }

    private void validateCountry(List<String> missingAttrList, Address address) {
        if (StringUtils.isBlank(address.getCountry())) {
            missingAttrList.add(OCVConstants.COUNTRY);
        }
    }

    private void validateAddressUsageType(List<String> missingAttrList, Address address) {
        if (StringUtils.isBlank(address.getAddressUsageType())) {
            missingAttrList.add(OCVConstants.ADDRESS_USAGE_TYPE);
        }
    }

    @Override
    protected ValidationResult validateQueryParameters(APIRequest<Party> apiRequest) {
        LogUtil.debug(log, "MaintainCapPartyValidator.validateQueryParameters", apiRequest.getTraceId(),
                "Exit: MaintainCapPartyValidator.validateQueryParameters");
        ValidationResult validationResult = new ValidationResult();
        LogUtil.debug(log, "MaintainCapPartyValidator.validateQueryParameters", apiRequest.getTraceId(),
                "Exit: MaintainCapPartyValidator.validateQueryParameters");
        return validationResult;
    }

    // Below method is for JUNIT purpose
    public void setUamInterceptor(UAMInterceptor uamInterceptor) {
        this.uamInterceptor = uamInterceptor;
    }
}
