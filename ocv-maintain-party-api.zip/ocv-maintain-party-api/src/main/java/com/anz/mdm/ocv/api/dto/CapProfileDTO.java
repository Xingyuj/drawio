package com.anz.mdm.ocv.api.dto;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Getter
@Setter
@Slf4j
@Component
public class CapProfileDTO {

    private String name = "";
    private String title = "";
    private String salutation = "";
    private String birthDate = "";
    private String gender = "";
    private String maritalStatus = "";
    private boolean isANZEmployee = false;
    private String customerType = "";
    private String customerStatus = "";
    private String openedDate = "";
    private String securityCode = "";
    private String bankruptDate = "";
    private String operatorLastMaintained = "";
    private String lastContact = "";
    private String email = "";
    private String employmentType = "";
    private String employer = "";
    private String employerType = "";
    private String occupationCode = "";
    private String countryExempt = "";
    private String ssnTaxId = "";
    private String companyId = "";
    private boolean acceptsAdvertisements = false;
    private boolean agreeToDisclosure = false;
    private List<String> customerBankingServices;
    private String selfCertIndicator = "";
    private String branch = "";
    private String dateBusinessEstablished = "";
    private String sicCode = "";
    private String govtRefType = "";
    private String govtRefNumber = "";
    private String securityIndicator = "";
    private String orgContactPhone = "";
    private String orgContactFaxNumber = "";
    private String orgContactName = "";
    private String orgContactTitle = "";
    private String orgContactMobile = "";
    private String contactPreferredIndicator = "";
    private String controllingPostId = "";
    private String controllingPostId2 = "";
    private String dateSelfCertification = "";
    private List<AddressDTO> addresses;

    public List<AddressDTO> getAddresses() {
        if (addresses == null) {
            addresses = new ArrayList<AddressDTO>();
        }
        return this.addresses;
    }

    public void setAddresses(List<AddressDTO> addresses) {
        this.addresses = addresses;
    }

    public void setANZEmployee(boolean anzEmployeeInd) {
        this.isANZEmployee = anzEmployeeInd;
    }

    public boolean isAcceptsAdvertisements() {
        return acceptsAdvertisements;
    }

    public void setAcceptsAdvertisements(boolean acceptsAdvertisements) {
        this.acceptsAdvertisements = acceptsAdvertisements;
    }

    public boolean isAgreeToDisclosure() {
        return agreeToDisclosure;
    }

    public void setAgreeToDisclosure(boolean agreeToDisclosure) {
        this.agreeToDisclosure = agreeToDisclosure;
    }

    public boolean isANZEmployee() {
        return isANZEmployee;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    public String getOpenedDate() {
        return openedDate;
    }

    public void setOpenedDate(String openedDate) {
        this.openedDate = openedDate;
    }

    public String getBankruptDate() {
        return bankruptDate;
    }

    public void setBankruptDate(String bankruptDate) {
        this.bankruptDate = bankruptDate;
    }

    public String getLastContact() {
        return lastContact;
    }

    public void setLastContact(String lastContact) {
        this.lastContact = lastContact;
    }

    public String getDateBusinessEstablished() {
        return dateBusinessEstablished;
    }

    public void setDateBusinessEstablished(String dateBusinessEstablished) {
        this.dateBusinessEstablished = dateBusinessEstablished;
    }

    public String getDateSelfCertification() {
        return dateSelfCertification;
    }

    public void setDateSelfCertification(String dateSelfCertification) {
        this.dateSelfCertification = dateSelfCertification;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSalutation() {
        return salutation;
    }

    public void setSalutation(String salutation) {
        this.salutation = salutation;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getMaritalStatus() {
        return maritalStatus;
    }

    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    public String getCustomerType() {
        return customerType;
    }

    public void setCustomerType(String customerType) {
        this.customerType = customerType;
    }

    public String getCustomerStatus() {
        return customerStatus;
    }

    public void setCustomerStatus(String customerStatus) {
        this.customerStatus = customerStatus;
    }

    public String getSecurityCode() {
        return securityCode;
    }

    public void setSecurityCode(String securityCode) {
        this.securityCode = securityCode;
    }

    public String getOperatorLastMaintained() {
        return operatorLastMaintained;
    }

    public void setOperatorLastMaintained(String operatorLastMaintained) {
        this.operatorLastMaintained = operatorLastMaintained;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmploymentType() {
        return employmentType;
    }

    public void setEmploymentType(String employmentType) {
        this.employmentType = employmentType;
    }

    public String getEmployer() {
        return employer;
    }

    public void setEmployer(String employer) {
        this.employer = employer;
    }

    public String getEmployerType() {
        return employerType;
    }

    public void setEmployerType(String employerType) {
        this.employerType = employerType;
    }

    public String getOccupationCode() {
        return occupationCode;
    }

    public void setOccupationCode(String occupationCode) {
        this.occupationCode = occupationCode;
    }

    public String getCountryExempt() {
        return countryExempt;
    }

    public void setCountryExempt(String countryExempt) {
        this.countryExempt = countryExempt;
    }

    public String getSsnTaxId() {
        return ssnTaxId;
    }

    public void setSsnTaxId(String ssnTaxId) {
        this.ssnTaxId = ssnTaxId;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getSelfCertIndicator() {
        return selfCertIndicator;
    }

    public void setSelfCertIndicator(String selfCertIndicator) {
        this.selfCertIndicator = selfCertIndicator;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getSicCode() {
        return sicCode;
    }

    public void setSicCode(String sicCode) {
        this.sicCode = sicCode;
    }

    public String getGovtRefType() {
        return govtRefType;
    }

    public void setGovtRefType(String govtRefType) {
        this.govtRefType = govtRefType;
    }

    public String getGovtRefNumber() {
        return govtRefNumber;
    }

    public void setGovtRefNumber(String govtRefNumber) {
        this.govtRefNumber = govtRefNumber;
    }

    public String getSecurityIndicator() {
        return securityIndicator;
    }

    public void setSecurityIndicator(String securityIndicator) {
        this.securityIndicator = securityIndicator;
    }

    public String getOrgContactPhone() {
        return orgContactPhone;
    }

    public void setOrgContactPhone(String orgContactPhone) {
        this.orgContactPhone = orgContactPhone;
    }

    public String getOrgContactFaxNumber() {
        return orgContactFaxNumber;
    }

    public void setOrgContactFaxNumber(String orgContactFaxNumber) {
        this.orgContactFaxNumber = orgContactFaxNumber;
    }

    public String getOrgContactName() {
        return orgContactName;
    }

    public void setOrgContactName(String orgContactName) {
        this.orgContactName = orgContactName;
    }

    public String getOrgContactTitle() {
        return orgContactTitle;
    }

    public void setOrgContactTitle(String orgContactTitle) {
        this.orgContactTitle = orgContactTitle;
    }

    public String getOrgContactMobile() {
        return orgContactMobile;
    }

    public void setOrgContactMobile(String orgContactMobile) {
        this.orgContactMobile = orgContactMobile;
    }

    public String getContactPreferredIndicator() {
        return contactPreferredIndicator;
    }

    public void setContactPreferredIndicator(String contactPreferredIndicator) {
        this.contactPreferredIndicator = contactPreferredIndicator;
    }

    public String getControllingPostId() {
        return controllingPostId;
    }

    public void setControllingPostId(String controllingPostId) {
        this.controllingPostId = controllingPostId;
    }

    public String getControllingPostId2() {
        return controllingPostId2;
    }

    public void setControllingPostId2(String controllingPostId2) {
        this.controllingPostId2 = controllingPostId2;
    }

}
