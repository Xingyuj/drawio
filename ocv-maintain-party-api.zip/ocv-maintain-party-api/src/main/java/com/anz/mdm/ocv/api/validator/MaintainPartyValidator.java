package com.anz.mdm.ocv.api.validator;

import static org.springframework.util.StringUtils.isEmpty;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.interceptor.UAMInterceptor;
import com.anz.mdm.ocv.api.util.LogUtil;
import com.anz.mdm.ocv.common.v1.NoTaxReason;
import com.anz.mdm.ocv.common.v1.TaxCountry;
import com.anz.mdm.ocv.party.v1.Party;

import lombok.extern.slf4j.Slf4j;

/**
 * MaintainPartyValidator class validates the PSOT API request *
 * 
 * @author Naresh Surakarapu
 *
 */

@Slf4j
@Component
public class MaintainPartyValidator extends AbstractValidator<Party> {

    @Autowired
    private UAMInterceptor uamInterceptor;  

    @Override
    public ValidationResult validateBody(APIRequest<Party> apiRequest) {

        Party requestBody = apiRequest.getRequestBody();
        String traceId = apiRequest.getTraceId();
        LogUtil.debug(log, "MaintainPartyValidator.validateBody", traceId,
                "Entering: MaintainPartyValidator.validateBody");
        ValidationResult validationResult = new ValidationResult();
        // partyType is mandatory
        if (isEmpty(requestBody.getPartyType())) {
            LogUtil.debug(log, "validateBody", "setting error code 4004");
            validationResult.setErrorCode(OCVConstants.MANDATORY_ATTRIBUTES_MISSING);
        }
        if (OCVConstants.REQUEST_MODE_UPDATE_ANZX.equalsIgnoreCase(apiRequest.getRequestMode())) {
            List<TaxCountry> taxCountryList = apiRequest.getRequestBody().getTaxCountries();
            validateSourceSystemForTaxCountry(validationResult, taxCountryList);
        }
        /*
         * if ((requestBody.getSourceSystems().size() == 0) ||
         * (isEmpty(requestBody.getSourceSystems().get(0).getSourceSystemId()) ||
         * isEmpty(requestBody.getSourceSystems().get(0).getSourceSystemName())) ) {
         * LogUtil.debug(log, "validateBody", "setting error code 4004");
         * validationResult.setErrorCode(OCVConstants. MANDATORY_ATTRIBUTES_MISSING); }
         */
        LogUtil.debug(log, "MaintainPartyValidator.validateBody", traceId, "Exit: MaintainPartyValidator.validateBody");
        return validationResult;
    }

    @Override
    public ValidationResult validateQueryParameters(APIRequest<Party> apiRequest) {
        LogUtil.debug(log, "MaintainPartyValidator.validateQueryParameters", apiRequest.getTraceId(),
                "Exit: MaintainPartyValidator.validateQueryParameters");
        ValidationResult validationResult = new ValidationResult();
        LogUtil.debug(log, "MaintainPartyValidator.validateQueryParameters", apiRequest.getTraceId(),
                "Exit: MaintainPartyValidator.validateQueryParameters");
        return validationResult;
    }

    @Override
    public ValidationResult validateRequest(APIRequest<Party> apiRequest) {
        Long startTime = System.currentTimeMillis();
        String traceId = apiRequest.getTraceId();
        LogUtil.debug(log, "maintainParty", traceId, "Entering: validateRequest method in AbstractValidator");
        ValidationResult validationResult = new ValidationResult();
        boolean areHeadersOK = apiRequest.areMandatoryHeadersPresent() && !isEmpty(apiRequest.getRequestTimestamp())
                && !isEmpty(apiRequest.getUserId());

        if (!areHeadersOK) {

            String validationStatus = checkValidationStatus(apiRequest);
            validationResult.setStatus(validationStatus);
            validationResult.setErrorCode(OCVConstants.MANDATORY_HEADER_MISSING_ERROR_CODE);

        }

        validationResult = validateSecureHeaders(apiRequest, validationResult);

        LogUtil.debug(log, "validateRequest", traceId, "mandatory headers check passed: " + validationResult.isValid());

        if (validationResult.isValid()) {
            validationResult = validateQueryParameters(apiRequest);
        }
        LogUtil.debug(log, "validateRequest", traceId, "query parameters check passed: " + validationResult.isValid());

        if (validationResult.isValid()) {
            validationResult = validateBody(apiRequest);
        }
        LogUtil.debug(log, "validateRequest", traceId, "body check passed: " + validationResult.isValid());
        
        //OCT-23700 - for validating JWT Token Scope
        validateJWTScopes(apiRequest, validationResult);
        
        Long endTime = System.currentTimeMillis();
        LogUtil.debug(log, "validateRequest", traceId, "Exiting: validateRequest method in AbstractValidator.",
                (endTime - startTime));
        return validationResult;
    }

    private String checkValidationStatus(APIRequest<Party> apiRequest) {

        String validationStatus = apiRequest.checkMandatoryHeaders();
        if (validationStatus == null) {
            validationStatus = checkMandatoryHeadersForMaintainParty(apiRequest);
        }
        return validationStatus;

    }
    
    private void validateJWTScopes(APIRequest<Party> apiRequest, ValidationResult validationResult) {
        String application = apiRequest.getApplication();

        if (validationResult.isValid()
                && (application == null || !application.equalsIgnoreCase("OCV"))) {
            uamInterceptor.validateJWTTokenScope(apiRequest, validationResult);
        }
        LogUtil.debug(log, "validateJWTScopes", 
                apiRequest.getTraceId(), "JWT Scope validation check passed: " + validationResult.isValid());
    }
    public String checkMandatoryHeadersForMaintainParty(APIRequest<Party> apiRequest) {
        if (isEmpty(apiRequest.getRequestTimestamp())) {
            return OCVConstants.REQUEST_TIME;
        } else if (isEmpty(apiRequest.getUserId())) {
            return OCVConstants.USER_ID;
        }
        return null;
    }

    private void validateSourceSystemForTaxCountry(ValidationResult validationResult, List<TaxCountry> taxCountryList) {
        if (Boolean.TRUE.equals(validationResult.isValid())
                && (null != taxCountryList && !(taxCountryList.isEmpty()))) {
            for (TaxCountry taxCountry : taxCountryList) {
                if (StringUtils.isBlank(taxCountry.getSource())) {
                    validationResult.setErrorCode(OCVConstants.SOURCE_IS_EMPTY);
                    validationResult.setStatus(OCVConstants.MANDATORY_ATTRIBUTES_MISSING);
                    break;
                }
                List<NoTaxReason> lisNoTaxReasons = taxCountry.getNoTaxReasons();
                if (null != lisNoTaxReasons && !(lisNoTaxReasons.isEmpty())) {
                    validateNoTinReasonSource(validationResult, lisNoTaxReasons);
                }
            }

        }
    }

    private void validateNoTinReasonSource(ValidationResult validationResult, List<NoTaxReason> lisNoTaxReasons) {
        for (NoTaxReason noTaxReason : lisNoTaxReasons) {
            if (StringUtils.isBlank(noTaxReason.getSource())) {
                validationResult.setErrorCode(OCVConstants.SOURCE_IS_EMPTY);
                validationResult.setStatus(OCVConstants.MANDATORY_ATTRIBUTES_MISSING);
                break;
            }
        }
    }
    
    // Below method is for JUNIT purpose
    public void setUamInterceptor(UAMInterceptor uamInterceptor) {
        this.uamInterceptor = uamInterceptor;
    }

}