package com.anz.mdm.ocv.api.exception;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.anz.mdm.ocv.api.util.LogUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * This class is to catch all exceptions that occur before entering into API
 * controller
 * 
 * @author surakarn
 *
 */
@Slf4j
@Order(Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice
public class RestExceptionHandler extends ResponseEntityExceptionHandler {

    @Override
    public ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex, HttpHeaders headers,
            HttpStatus status, WebRequest request) {
        ErrorResponse response = new ErrorResponse();
        response.setHttpCode(400);
        Error error = new Error();
        error.setStatusCode("4005");
        error.setStatusMessage("Input format is not correct");
        List<Error> errors = new ArrayList<Error>();
        errors.add(error);
        response.setErrors(errors);
        LogUtil.error(log, "handleHttpMessageNotReadable ", request.getHeader("x-b3-traceid"),
                "HttpMessageNotReadableException Exception",  request.getHeader("channel"));
        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.set("x-b3-traceid", request.getHeader("x-b3-traceid"));
        responseHeaders.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains;");

        return new ResponseEntity(response, responseHeaders, HttpStatus.BAD_REQUEST);
    }

}