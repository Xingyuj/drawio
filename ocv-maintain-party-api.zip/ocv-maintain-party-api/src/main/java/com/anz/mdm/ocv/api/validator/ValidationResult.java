package com.anz.mdm.ocv.api.validator;

import org.springframework.http.HttpEntity;

import com.ibm.mdm.schema.TCRMService;

/**
 * Class to encapsulate API request validation results.
 * 
 * @author Amit Gera
 */
public class ValidationResult {

    private String errorCode = "";

    private boolean isValid = true;

    private String status = "";

    private HttpEntity<TCRMService> xmlResponse = null;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    private static ValidationResult isOK = new ValidationResult();

    public ValidationResult() {

    }

    public ValidationResult(String errorCode) {
        this.setErrorCode(errorCode);
    }

    public boolean isValid() {
        return isValid;
    }

    public String getErrorCode() {
        return this.errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
        isValid = false;
    }

    public HttpEntity<TCRMService> getXmlResponse() {
        return xmlResponse;
    }

    public void setXmlResponse(HttpEntity<TCRMService> xmlResponse) {
        this.xmlResponse = xmlResponse;
    }

    public static ValidationResult getValidationResult() {
        return isOK;
    }
}
