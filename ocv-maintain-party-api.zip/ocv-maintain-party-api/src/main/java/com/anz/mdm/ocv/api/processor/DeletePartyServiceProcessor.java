/**
 * 
 */
package com.anz.mdm.ocv.api.processor;

import java.util.List;

import com.anz.mdm.ocv.api.util.LogUtil;
import com.anz.mdm.ocv.api.util.RequestTransfomerUtil;
import com.anz.mdm.ocv.api.validator.APIRequest;
import com.anz.mdm.ocv.common.v1.SourceSystem;
import com.anz.mdm.ocv.party.v1.Party;

import lombok.extern.slf4j.Slf4j;

/**
 * @author kukatlar
 *
 */

@Slf4j
public class DeletePartyServiceProcessor {

    public StringBuilder prepareDeletePartyRequest(StringBuilder request, APIRequest<Party> apiRequest) {
        LogUtil.debug(log, "prepareDeletePartyRequest", apiRequest.getTraceId(),
                "Entering: prepareDeletePartyRequest method in DeletePartyServiceProcessor");
        prepareControlObject(request, apiRequest.getRequestBody(), apiRequest.getRequestTimestamp(),
                apiRequest.getTraceId(), apiRequest.getChannel(), apiRequest.getUserId());
        StringBuilder mdmRequest = prepareDeleteRequest(request, apiRequest.getRequestBody(), apiRequest.getTraceId());
        LogUtil.debug(log, "prepareDeletePartyRequest", apiRequest.getTraceId(),
                "Exit: prepareDeletePartyRequest method in DeletePartyServiceProcessor");
        return mdmRequest;
    }

    public void prepareControlObject(StringBuilder request, Party party, String requestTime, String traceId,
            String channel, String userId) {
        LogUtil.debug(log, "prepareControlObject", traceId,
                "Entering: prepareControlObject method in DeletePartyServiceProcessor");
        Long startTime = System.currentTimeMillis();
        String requestIdValue = Long.toString(startTime);
        RequestTransfomerUtil.modifyTemplate(request, "@requesterName@", userId, traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@requestID@", requestIdValue, traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@transactionCorrelatorId@", traceId, traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@requestTime@", requestTime, traceId);
        RequestTransfomerUtil.modifyTemplate(request, "@clientSystemName@", channel, traceId);
        LogUtil.debug(log, "prepareControlObject", traceId,
                "Exit: prepareControlObject method in DeletePartyServiceProcessor");
        LogUtil.debug(log, "prepareControlObject", traceId, "value of request prepareControlObject" + request);
    }

    public StringBuilder prepareDeleteRequest(StringBuilder request, Party party, String traceId) {
        LogUtil.debug(log, "prepareDeleteRequest", traceId,
                "Entering: prepareDeleteRequest method in DeletePartyServiceProcessor");
        PartyInternalObjectsProcessor childObjProcessor = new PartyInternalObjectsProcessor();
        List<SourceSystem> sourceSystems = party.getSourceSystems();
        childObjProcessor.prepareContEquivs(request, sourceSystems, party.getPartyType(), traceId);
        return request;
    }

}