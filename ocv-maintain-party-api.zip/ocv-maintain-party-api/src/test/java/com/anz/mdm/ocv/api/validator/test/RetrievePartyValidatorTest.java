package com.anz.mdm.ocv.api.validator.test;

import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.validator.APIRequest;
import com.anz.mdm.ocv.api.validator.RetrievePartyValidator;
import com.anz.mdm.ocv.party.v1.Party;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@RunWith(SpringRunner.class)
public class RetrievePartyValidatorTest {
    RetrievePartyValidator partyValidator = new RetrievePartyValidator();
    final String acn = "87493580478";
    final String abn = "874935804";

    // Dummy test
    @Test
    public void validateBody_Success() throws Exception {
        final Party party = setParameterisedBody(abn, acn);
        final APIRequest<Party> apiRequest = new APIRequest<>(prepareRequestHeaders(), new HashMap<String, String>(),
                party);
        partyValidator.validateBody(apiRequest);
    }

    // Dummy test
    @Test
    public void validateQueryParameters_Success() throws Exception {
        final Party party = setParameterisedBody(abn, acn);
        final APIRequest<Party> apiRequest = new APIRequest<>(prepareRequestHeaders(), new HashMap<String, String>(),
                party);
        Map<String, String> queryParameters = new HashMap<String, String>();
        partyValidator.validateQueryParameters(apiRequest);
    }

    private Map<String, String> prepareRequestHeaders() {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put(OCVConstants.ACCEPT_HEADER, "application/json");
        headers.put(OCVConstants.TRACE_ID_HEADER, "abc123");
        headers.put(OCVConstants.AUTHORIZATION_HEADER, "5237vxhsfdfyif");
        return headers;
    }

    private Party setParameterisedBody(final String abn, final String acn)
            throws JsonParseException, JsonMappingException, IOException {

        String jsonString = "{\r\n" + "\"partyType\" : \"Non individual\",\r\n" + "\"identifiers\" : [{\r\n"
                + "\"identifierUsageType\" : \"ABN\",\r\n" + "\"identifier\" : \"" + abn + "\"\r\n" + "},{\r\n"
                + "\"identifierUsageType\" : \"ACN\",\r\n" + "\"identifier\" : \"" + acn + "\"\r\n" + "}],\r\n"
                + "\"names\":[{\"name\":\"ANZ\"}\r\n" + "    ]\r\n" + "}";
        Party party = new ObjectMapper().readValue(jsonString, Party.class);
        return party;
    }

}
