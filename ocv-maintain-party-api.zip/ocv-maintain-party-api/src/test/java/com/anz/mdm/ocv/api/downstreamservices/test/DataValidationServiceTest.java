package com.anz.mdm.ocv.api.downstreamservices.test;

import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.ResourceUtils;
import org.springframework.web.client.RestTemplate;

import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.downsteamservices.DataValidationService;
import com.anz.mdm.ocv.api.downsteamservices.ValidatedParty;
import com.anz.mdm.ocv.api.exception.ServiceUnavailableException;
import com.anz.mdm.ocv.api.exception.UnauthorizedException;
import com.anz.mdm.ocv.api.validator.APIRequest;
import com.anz.mdm.ocv.party.v1.Party;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import static org.junit.Assert.assertTrue;

@RunWith(SpringRunner.class)
public class DataValidationServiceTest {

    @InjectMocks
    DataValidationService dataValidationService;

    @Mock(name = "DataValidationRestTemplate")
    RestTemplate restTemplate;

    final String uri = "http://mockserver/party";

    final String traceID = "12345";
    
    @Captor
    private ArgumentCaptor<HttpEntity<Party>> captor;
    
    @Before
    public void init() {
        dataValidationService.setUri(uri);
    }

    @Test
    public void testSuccess() throws Exception {

        final Party party = setParameterisedBody();

        final APIRequest<Party> apiRequest = new APIRequest<>(prepareRequestHeaders(), new HashMap<String, String>(),
                party);

        ResponseEntity<Party> response = new ResponseEntity<>(setParameterisedBody(),
                HttpStatus.OK);

        when(restTemplate.exchange(any(String.class), any(), any(HttpEntity.class), any(Class.class)))
                .thenReturn(response);

        final ValidatedParty validatedParty = dataValidationService.validateParty(apiRequest);
        verify(restTemplate).exchange(any(String.class), any(), captor.capture(), any(Class.class));

        final HttpEntity<Party> request = captor.getValue();

        assertEquals(party, request.getBody());
        assertNotEquals(party, validatedParty.getParty());
        assertEquals(request.getHeaders().get(OCVConstants.TRACE_ID_HEADER).get(0), traceID);
        assertEquals(request.getHeaders().get(OCVConstants.CONTENT_TYPE).get(0), MediaType.APPLICATION_JSON_VALUE);
        assertEquals(request.getHeaders().get(OCVConstants.ACCEPT_HEADER).get(0), MediaType.APPLICATION_JSON_VALUE);
       

    }
    
    @Test
    public void testFailure() throws Exception {

        final Party party = setParameterisedBody();

        final APIRequest<Party> apiRequest = new APIRequest<>(prepareRequestHeaders(), new HashMap<String, String>(),
                party);

        ResponseEntity<Party> response = new ResponseEntity<>(setParameterisedBody(),
                HttpStatus.OK);

        when(restTemplate.exchange(any(String.class), any(), any(HttpEntity.class), any(Class.class)))
        .thenThrow(new ServiceUnavailableException("UnAuthorizedMDMException: 5006"));
        try {
            final ValidatedParty validatedParty = dataValidationService.validateParty(apiRequest);
        }catch(Exception ex) {
            String message = ex.getMessage();
            //assertTrue(message.contains("UnAuthorizedMDMException: 5006"));
        }
              

    }

    private Party setParameterisedBody()
            throws JsonParseException, JsonMappingException, IOException {

        Party person = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:SamplePersonInput.json"),
                Party.class);
        return person;
    }

    private Map<String, String> prepareRequestHeaders() {
        final Map<String, String> headers = new HashMap<String, String>();
        headers.put(OCVConstants.ACCEPT_HEADER, "application/json");
        headers.put(OCVConstants.TRACE_ID_HEADER, "12345");
        headers.put(OCVConstants.AUTHORIZATION_HEADER, "5237vxhsfdfyif");
        return headers;
    }
}
