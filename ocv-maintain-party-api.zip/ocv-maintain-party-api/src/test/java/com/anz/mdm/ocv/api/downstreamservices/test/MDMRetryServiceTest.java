package com.anz.mdm.ocv.api.downstreamservices.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.doNothing;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.http.HttpException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.ResourceUtils;
import org.springframework.web.client.RestTemplate;

import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.downsteamservices.MDMRetryService;
import com.anz.mdm.ocv.api.downsteamservices.MaintainPartyService;
import com.anz.mdm.ocv.api.dto.APIResponse;
import com.anz.mdm.ocv.api.processor.MaintainPartyServiceProcessor;
import com.anz.mdm.ocv.api.util.IdempotencyConfigUtil;
import com.anz.mdm.ocv.api.util.LogRequestModel;
import com.anz.mdm.ocv.api.util.LogUtil;
import com.anz.mdm.ocv.api.util.RequestTransfomerUtil;
import com.anz.mdm.ocv.api.util.StreetSuffixConfig;
import com.anz.mdm.ocv.api.validator.APIRequest;
import com.anz.mdm.ocv.api.validator.MaintainPartyValidator;
import com.anz.mdm.ocv.common.v1.SourceSystem;
import com.anz.mdm.ocv.party.v1.Party;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.mdm.schema.CommonBObjType;
import com.ibm.mdm.schema.DWLError;
import com.ibm.mdm.schema.ResponseObject;
import com.ibm.mdm.schema.TCRMAdminContEquivBObjType;
import com.ibm.mdm.schema.TCRMPersonBObjType;
import com.ibm.mdm.schema.TCRMService;
import com.ibm.mdm.schema.TxResponse;
import com.ibm.mdm.schema.TxResult;


/*@PrepareForTest({ MaintainPartyValidator.class, MaintainPartyServiceProcessor.class, MaintainPartyService.class,
        RecordNotFoundException.class })*/
@RunWith(SpringRunner.class)
public class MDMRetryServiceTest {

    @InjectMocks
    @Spy
    MaintainPartyService maintainPartyService;

    MaintainPartyServiceProcessor maintainPartyServiceProcessor;

    RequestTransfomerUtil requestTransfomer;

    MaintainPartyValidator maintainPartyValidator;

    @Spy
    RestTemplate restTemplate;

    @Mock
    private LogRequestModel logAttributes;

    @Captor
    private ArgumentCaptor<HttpEntity<Party>> captor;

    final String uri = "https://localhost:8443/com.ibm.mdm.server.ws.restful/resources/MDMWSRESTful";
    
    @Spy
    MDMRetryService mdmRetryService;
    
    @Mock 
    StreetSuffixConfig streetConfig;
    
    @Mock
    private IdempotencyConfigUtil idempotencyConfigUtil;
    

@Before
public void setUp() throws IOException {

    MaintainPartyValidator maintainPartyValidator = new MaintainPartyValidator();
    maintainPartyValidator = spy(maintainPartyValidator);

    maintainPartyService.setUrl(uri);
    
    idempotencyConfigUtil = new IdempotencyConfigUtil();
    idempotencyConfigUtil = spy(idempotencyConfigUtil); 

    maintainPartyServiceProcessor = new MaintainPartyServiceProcessor();

    maintainPartyServiceProcessor = spy(maintainPartyServiceProcessor);
    
    streetConfig = new StreetSuffixConfig();
    streetConfig = spy(streetConfig);
    
    MockitoAnnotations.initMocks(this);
    Mockito.when(streetConfig.getPropertyValue("street")).thenReturn("ST");
    Mockito.when(streetConfig.getPropertyValue("street highway")).thenReturn("sthwy");

    doReturn(idempotencyConfigUtil).when(maintainPartyService).getIdempotencyUtil();
    doReturn(false).when(idempotencyConfigUtil).isChannelIncluded(Mockito.anyString(),Mockito.anyString());
    
}

    /**
     * Race Condition
     * 
     * @throws HttpException
     * @throws Exception
     */
    @Test
    public void maintainPartyV2RaceCondition() throws HttpException, Exception {
        Map<String, String> headers = prepareRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();
        String requestTime = "2018-10-01 10:02:00.0";
        Party party = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:SamplePersonInputANZX.json"), Party.class);
        APIRequest<Party> partyObject = new APIRequest<>(headers, queryParameters, party);

        HttpEntity<TCRMService> response = getResponse();
        
        HttpEntity<TCRMService> sucessResponse = setMDMResponse_Person();
        
        doReturn(response).doReturn(sucessResponse).when(maintainPartyService).invokeMdmBackend(any(String.class), any(String.class));
        doReturn(getApiResponse()).when(maintainPartyService).transformMdmResponse(any(),any(),any());
        APIResponse apiResponse = maintainPartyService.createOrUpdateParty(partyObject, requestTime, "1234", "9898", false);
        System.out.println("apiResponse : " + apiResponse);
        assertNotNull(apiResponse.getOcvId());
    }
    
    private APIResponse getApiResponse() {
        APIResponse apiResponse = new APIResponse();
        apiResponse.setOcvId("7666565");
        List<SourceSystem> sourceSystems = new ArrayList<>();
        SourceSystem sourceSystem = new SourceSystem();
        sourceSystem.setSourceSystemId("898989889");
        sourceSystem.setSourceSystemName("CAP-CIS");
        sourceSystems.add(sourceSystem);
        apiResponse.setSourceSystems(sourceSystems);
        return apiResponse;
    }
    
    private Map<String, String> prepareRequestHeaders() {

        Map<String, String> headers = new HashMap<String, String>();
        headers.put(OCVConstants.ACCEPT_HEADER, "application/json");
        headers.put(OCVConstants.TRACE_ID_HEADER, "6846gjfj-fgdjg-afas");
        headers.put(OCVConstants.AUTHORIZATION_HEADER,
                "Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImFwaWRldnRva2VuLmNvcnAuZGV2LmFueiJ9.eyJpc3MiOiJodHRwczovL2RhdGFwb3dlci1zdHMuYW56LmNvbSIsImF1ZCI6IlRlc3RVc2VyIiwic3ViIjoiVGVzdFVzZXIiLCJpYXQiOjE1ODgwNTAwMjMzODQsImV4cCI6MTU4ODA1MDkyMy4zODQsInNjb3BlcyI6WyJBVS5BTlpfSU5URVJOQUwuT0NWLk1NTE8uQUNDRVNTLlJFQUQiXSwiYW1yIjpbInBvcCJdLCJhY3IiOiJJQUwyLkFBTDEuRkFMMSJ9.MVN9DXoByov2ln4znQXmYk6IVIk1k7Gd3e3eqIJTfB0hgGs2xdAD2q73xMLjr22BgeylsrFdMV5PTFBhte8Wetgdyzyj7a1AuD4CJXFQ3dA0johCxS90g9qddhJhfJALVWsKtrVm86yMyvDT9mreIgVWnshiaD7ZLwrO9DxYQlqDdeJyH_RZWdFHMUMsECysF1psUDEZ8k3juEKeVNE0cM2QUBYxkvchU3hJUnrt2IpFmnf1d30Ksdyt1aqZIcN6y00qSm4LGI5OPVIm5ltF3TO2B9puZxSrBvn7NIjH6Xe2ocSzFagPctL_opzCwO0PnyOpeykmdReKfUNX8VkjaQ");
        headers.put(OCVConstants.CHANNEL, "FENERGOANZX");
        headers.put(OCVConstants.USER_ID_HEADER, "shgfjsf");
        headers.put(OCVConstants.REQUEST_TIMESTAMP, "2021-03-10 16:05:00.29");
        headers.put(OCVConstants.USER_ID, "5465465464");
        headers.put(OCVConstants.REQUEST_MODE_HEADER, "updateCustomerKYC");
        return headers;
    }

    private HttpEntity<TCRMService> getResponse() {
        TCRMService mdmResponse = new TCRMService();;
        TxResult result = new TxResult();
        TxResponse txResponse = new TxResponse();
        result.setResultCode("FATAL");
        DWLError error = new DWLError();
        error.setReasonCode(OCVConstants.ERROR_REASON_CODE_DUPLICATE);
        error.setErrorType(OCVConstants.ERROR_TYPE_DUPLICATE);
        error.setErrorMessage("Duplicate primary key already exists.");
        error.setThrowable("com.dwl.tcrm.exception.TCRMDuplicateKeyException: [Exception_Common_DuplicateKey:] CDKCS0001E:The object cannot be created due to duplicate primary key. Primary key = null; object = com.dwl.tcrm.coreParty.component.TCRMAdminContEquivBObj; exception = ORA-00001: unique constraint (MDM.I3_CONTEQUIV) violated");
        result.getDWLError().add(error);
        txResponse.setTxResult(result);
        mdmResponse.setTxResponse(txResponse);
        HttpEntity<TCRMService> response = new HttpEntity<TCRMService>(mdmResponse);
        return response;

    }
    
    private HttpEntity<TCRMService> setMDMResponse_Person() {

        TCRMService tcrmService = new TCRMService();
        TxResult txResult = new TxResult();
        txResult.setResultCode("SUCCESS");
        TxResponse txResponse = new TxResponse();
        txResponse.setTxResult(txResult);
        ResponseObject resObject = new ResponseObject();
        TCRMAdminContEquivBObjType adminContequiv = new TCRMAdminContEquivBObjType();
        adminContequiv.setAdminPartyId("11111");
        adminContequiv.setAdminSystemValue("CAP-CIS");
        TCRMPersonBObjType person = new TCRMPersonBObjType();
        person.getTCRMAdminContEquivBObj().add(adminContequiv);

        person.setPartyId("222222");

        CommonBObjType common = (CommonBObjType) person;
        JAXBElement<TCRMPersonBObjType> jaxbElement = new JAXBElement(
                new QName(TCRMPersonBObjType.class.getSimpleName()), TCRMPersonBObjType.class, common);
        resObject.getCommonBObj().add(jaxbElement);
        txResponse.setResponseObject(resObject);
        tcrmService.setTxResponse(txResponse);
        HttpEntity<TCRMService> response = new HttpEntity<TCRMService>(tcrmService);

        return response;
    }
}
