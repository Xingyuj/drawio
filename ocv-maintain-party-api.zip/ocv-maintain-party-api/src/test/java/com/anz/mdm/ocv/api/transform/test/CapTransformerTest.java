package com.anz.mdm.ocv.api.transform.test;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.spy;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.ResourceUtils;

import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.transform.CapTransformer;
import com.anz.mdm.ocv.api.util.StreetSuffixConfig;
import com.anz.mdm.ocv.api.validator.APIRequest;
import com.anz.mdm.ocv.cap.v1.AddressDetails;
import com.anz.mdm.ocv.cap.v1.CapProfile;
import com.anz.mdm.ocv.common.v1.Address;
import com.anz.mdm.ocv.common.v1.CodeDescription;
import com.anz.mdm.ocv.common.v1.Email;
import com.anz.mdm.ocv.common.v1.Name;
import com.anz.mdm.ocv.common.v1.Phone;
import com.anz.mdm.ocv.party.v1.Party;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
public class CapTransformerTest {

    @InjectMocks
    private CapTransformer capTransformer;

    private Party ocvParty = new Party();
    
    @Mock 
    StreetSuffixConfig streetConfig;

    @Before
    public void setup() {
        Name nameObj = new Name();
        nameObj.setFirstName("First Name");
        nameObj.setMiddleName("Middle Name");
        nameObj.setLastName("Last Name");
        nameObj.setPrefix("Prefix");
        nameObj.setSuffix("Suffix");
        nameObj.setNameUsageType("Legal Name");
        ocvParty.getNames().add(0, nameObj);
        ocvParty.setDateOfBirth("1986-09-07");
        ocvParty.setPartyType("P");
        ocvParty.setGender("M");
        ocvParty.setMaritalStatus("Single");
        Phone mobphoneObj = new Phone();
        mobphoneObj.setPhoneUsageType("Mobile Telephone");
        mobphoneObj.setPhone("+097323232");
        mobphoneObj.setPreferred("Y");
        Phone workphoneObj = new Phone();
        workphoneObj.setPhoneUsageType("Work Telephone");
        workphoneObj.setPhone("+097322222");
        workphoneObj.setPreferred("");
        ocvParty.getPhones().add(mobphoneObj);
        ocvParty.getPhones().add(workphoneObj);
        Address addObj = new Address();
        addObj.setBuildingName("Emerald House");
        addObj.setLevelNumber("21");
        addObj.setResidenceType("Level");
        addObj.setResidenceNumber("10");
        addObj.setStreetNumber("833");
        addObj.setStreetName("Collins");
        addObj.setStreetSuffix("street");
        addObj.setPostDirectional("Left");
        addObj.setCountry("AUS");
        addObj.setState("VIC");
        addObj.setPostalCode("3000");
        addObj.setCity("Melbourne");
        addObj.setRegion("VIC");
        addObj.setAddressUsageType("Mailing");
        Address addObj1 = new Address();
        addObj1.setBuildingName("VICTOR House");
        addObj1.setLevelNumber("26");
        addObj1.setResidenceType("Level 6");
        addObj1.setResidenceNumber("12");
        addObj1.setStreetNumber("839");
        addObj1.setStreetName("Collins");
        addObj1.setStreetSuffix("st");
        addObj1.setPostDirectional("lf");
        addObj1.setCountry("AUS");
        addObj1.setState("VIC");
        addObj1.setPostalCode("3000");
        addObj1.setCity("Melbourne");
        addObj1.setRegion("VIC");
        addObj1.setAddressUsageType("Residential");
        ocvParty.getAddresses().add(addObj);
        ocvParty.getAddresses().add(addObj1);
        Email emailObj = new Email();
        emailObj.setEmailUsageType("Email");
        emailObj.setEmail("test@anz.com");
        ocvParty.getEmails().add(emailObj);
        ocvParty.setEmployeeIndicator("Y");
        ocvParty.setEmployerName("ANZ");
        CodeDescription occCode = new CodeDescription();
        occCode.setCode("0065");
        ocvParty.setOccupation(occCode);
        ocvParty.setStatus("Active");
        
        streetConfig = new StreetSuffixConfig();
        streetConfig = spy(streetConfig);
        
        MockitoAnnotations.initMocks(this);
        Mockito.when(streetConfig.getPropertyValue("street")).thenReturn("ST");
        Mockito.when(streetConfig.getPropertyValue("street highway")).thenReturn("sthwy");
    }

    @Test
    public void testGetPersonName() throws Exception {
        final APIRequest<Party> apiRequest = new APIRequest<>(prepareRequestHeaders(), new HashMap<String, String>(),
                ocvParty);
        CapProfile capProfile = capTransformer.transformAPIRequest(apiRequest,streetConfig);
        assertEquals("Single", capProfile.getMaritalStatus());
        // assertEquals("test@anz.com",
        // capProfile.getEmailAddress().getEmail());
        assertEquals("", capProfile.getLastContact());
        /*
         * String json = ""; ObjectMapper mapper = new ObjectMapper(); try {
         * json = mapper.writeValueAsString(capProfile);
         * System.out.println("ResultingJSONstring = " + json); } catch
         * (JsonProcessingException e) { e.printStackTrace(); }
         */
    }

    @Test
    public void testGetAddress() throws Exception {
        final APIRequest<Party> apiRequest = new APIRequest<>(prepareRequestHeaders(), new HashMap<String, String>(),
                ocvParty);
        CapProfile capProfile = capTransformer.transformAPIRequest(apiRequest,streetConfig);
        List<AddressDetails> addresses = capProfile.getAddresses();
        assertEquals("Address Line 1 is not matching", "Emerald House", addresses.get(0).getAddressLine1());
        assertEquals("Address Line 2 is not matching", "21 Level 10/833 Collins ST Left",
                addresses.get(0).getAddressLine2());
        assertEquals("Address Line 3 is not matching", "", addresses.get(0).getAddressLine3());
    }

    @Test
    public void testGetAddressWithStationInfo() throws Exception {
        Address addObj = new Address();
        addObj.setStnInfo("station");
        addObj.setBoxId("2314");
        addObj.setCountry("AUS");
        addObj.setState("VIC");
        addObj.setPostalCode("3000");
        addObj.setCity("Melbourne");
        addObj.setRegion("VIC");
        addObj.setAddressUsageType("Mailing");
        ocvParty.getAddresses().remove(1);
        ocvParty.getAddresses().remove(0);
        ocvParty.getAddresses().add(addObj);
        final APIRequest<Party> apiRequest = new APIRequest<>(prepareRequestHeaders(), new HashMap<String, String>(),
                ocvParty);
        CapProfile capProfile = capTransformer.transformAPIRequest(apiRequest,streetConfig);
        List<AddressDetails> addresses = capProfile.getAddresses();
        assertEquals("Address Line 1 is not matching", "station 2314", addresses.get(0).getAddressLine1());
        assertEquals("Address Line 2 is not matching", "", addresses.get(0).getAddressLine2());
        assertEquals("Address Line 3 is not matching", "", addresses.get(0).getAddressLine3());
    }

    @Test
    public void testGetAddressWithOutSlashLength42() throws Exception {
        Address addObj = new Address();
        addObj.setBuildingName("Emerald House");
        addObj.setLevelNumber("21");
        addObj.setResidenceType("Level");
        addObj.setResidenceNumber("10");
        addObj.setStreetNumber("833");
        addObj.setStreetName("Collins");
        addObj.setStreetSuffix("street");
        addObj.setPostDirectional("This is increased to test more than 40 characters");
        addObj.setCountry("AUS");
        addObj.setState("VIC");
        addObj.setPostalCode("3000");
        addObj.setCity("Melbourne");
        addObj.setRegion("VIC");
        addObj.setAddressUsageType("Mailing");
        ocvParty.getAddresses().remove(1);
        ocvParty.getAddresses().remove(0);
        ocvParty.getAddresses().add(addObj);
        final APIRequest<Party> apiRequest = new APIRequest<>(prepareRequestHeaders(), new HashMap<String, String>(),
                ocvParty);
        CapProfile capProfile = capTransformer.transformAPIRequest(apiRequest,streetConfig);
        List<AddressDetails> addresses = capProfile.getAddresses();
        assertEquals("Address Line 1 is not matching", "Emerald House", addresses.get(0).getAddressLine1());
        assertEquals("Address Line 2 is not matching", "21 Level 10", addresses.get(0).getAddressLine2());
        assertEquals("Address Line 3 is not matching",
                "833 Collins ST This is increased to test more than 40 characters",
                addresses.get(0).getAddressLine3());
    }

    @Test
    public void testGetAddressWithSlashLength36() throws Exception {
        Address addObj = new Address();
        addObj.setBuildingName("Emerald House");
        addObj.setLevelNumber("21");
        addObj.setResidenceType("Level/");
        addObj.setResidenceNumber("10");
        addObj.setStreetNumber("833");
        addObj.setStreetName("Collins");
        addObj.setStreetSuffix("street");
        addObj.setPostDirectional("Le");
        addObj.setCountry("AUS");
        addObj.setState("VIC");
        addObj.setPostalCode("3000");
        addObj.setCity("Melbourne");
        addObj.setRegion("VIC");
        addObj.setAddressUsageType("Mailing");
        ocvParty.getAddresses().remove(1);
        ocvParty.getAddresses().remove(0);
        ocvParty.getAddresses().add(addObj);
        final APIRequest<Party> apiRequest = new APIRequest<>(prepareRequestHeaders(), new HashMap<String, String>(),
                ocvParty);
        CapProfile capProfile = capTransformer.transformAPIRequest(apiRequest,streetConfig);
        List<AddressDetails> addresses = capProfile.getAddresses();
        assertEquals("Address Line 1 is not matching", "Emerald House", addresses.get(0).getAddressLine1());
        assertEquals("Address Line 2 is not matching", "21 Level/ 10", addresses.get(0).getAddressLine2());
        assertEquals("Address Line 3 is not matching", "833 Collins ST Le", addresses.get(0).getAddressLine3());
    }

    @Test
    public void testGetAddressWithSlashLength42() throws Exception {
        Address addObj = new Address();
        addObj.setBuildingName("Emerald House");
        addObj.setLevelNumber("21");
        addObj.setResidenceType("Level/");
        addObj.setResidenceNumber("10");
        addObj.setStreetNumber("833");
        addObj.setStreetName("Collins");
        addObj.setStreetSuffix("street");
        addObj.setPostDirectional("This is increased to test more than 40 characters");
        addObj.setCountry("AUS");
        addObj.setState("VIC");
        addObj.setPostalCode("3000");
        addObj.setCity("Melbourne");
        addObj.setRegion("VIC");
        addObj.setAddressUsageType("Mailing");
        ocvParty.getAddresses().remove(1);
        ocvParty.getAddresses().remove(0);
        ocvParty.getAddresses().add(addObj);
        final APIRequest<Party> apiRequest = new APIRequest<>(prepareRequestHeaders(), new HashMap<String, String>(),
                ocvParty);
        CapProfile capProfile = capTransformer.transformAPIRequest(apiRequest,streetConfig);
        List<AddressDetails> addresses = capProfile.getAddresses();
        assertEquals("Address Line 1 is not matching", "Emerald House", addresses.get(0).getAddressLine1());
        assertEquals("Address Line 2 is not matching", "21 Level/ 10", addresses.get(0).getAddressLine2());
        assertEquals("Address Line 3 is not matching",
                "833 Collins ST This is increased to test more than 40 characters",
                addresses.get(0).getAddressLine3());
    }

    @Test
    public void testGetAddressNoBuildingWithOutSlashLength36() throws Exception {
        Address addObj = new Address();
        addObj.setLevelNumber("21");
        addObj.setResidenceType("Level");
        addObj.setResidenceNumber("10");
        addObj.setStreetNumber("833");
        addObj.setStreetName("Collins");
        addObj.setStreetSuffix("street");
        addObj.setPostDirectional("Left");
        addObj.setCountry("AUS");
        addObj.setState("VIC");
        addObj.setPostalCode("3000");
        addObj.setCity("Melbourne");
        addObj.setRegion("VIC");
        addObj.setAddressUsageType("Mailing");
        ocvParty.getAddresses().remove(1);
        ocvParty.getAddresses().remove(0);
        ocvParty.getAddresses().add(addObj);
        final APIRequest<Party> apiRequest = new APIRequest<>(prepareRequestHeaders(), new HashMap<String, String>(),
                ocvParty);
        CapProfile capProfile = capTransformer.transformAPIRequest(apiRequest,streetConfig);
        List<AddressDetails> addresses = capProfile.getAddresses();
        assertEquals("Address Line 2 is not matching", "", addresses.get(0).getAddressLine2());
        assertEquals("Address Line 1 is not matching", "21 Level 10/833 Collins ST Left",
                addresses.get(0).getAddressLine1());
        assertEquals("Address Line 3 is not matching", "", addresses.get(0).getAddressLine3());
    }

    @Test
    public void testGetAddressNoBuildingWithOutSlashLength42() throws Exception {
        Address addObj = new Address();
        addObj.setLevelNumber("21");
        addObj.setResidenceType("Level");
        addObj.setResidenceNumber("10");
        addObj.setStreetNumber("833");
        addObj.setStreetName("Collins");
        addObj.setStreetSuffix("street");
        addObj.setPostDirectional("This is increased to test more than 40 characters");
        addObj.setCountry("AUS");
        addObj.setState("VIC");
        addObj.setPostalCode("3000");
        addObj.setCity("Melbourne");
        addObj.setRegion("VIC");
        addObj.setAddressUsageType("Mailing");
        ocvParty.getAddresses().remove(1);
        ocvParty.getAddresses().remove(0);
        ocvParty.getAddresses().add(addObj);
        final APIRequest<Party> apiRequest = new APIRequest<>(prepareRequestHeaders(), new HashMap<String, String>(),
                ocvParty);
        CapProfile capProfile = capTransformer.transformAPIRequest(apiRequest,streetConfig);
        List<AddressDetails> addresses = capProfile.getAddresses();
        assertEquals("Address Line 3 is not matching", "", addresses.get(0).getAddressLine3());
        assertEquals("Address Line 1 is not matching", "21 Level 10", addresses.get(0).getAddressLine1());
        assertEquals("Address Line 2 is not matching",
                "833 Collins ST This is increased to test more than 40 characters",
                addresses.get(0).getAddressLine2());
    }

    @Test
    public void testGetAddressNoBuildingWithSlashLength36() throws Exception {
        Address addObj = new Address();
        addObj.setLevelNumber("21");
        addObj.setResidenceType("Level/");
        addObj.setResidenceNumber("10");
        addObj.setStreetNumber("833");
        addObj.setStreetName("Collins");
        addObj.setStreetSuffix("street");
        addObj.setPostDirectional("Le");
        addObj.setCountry("AUS");
        addObj.setState("VIC");
        addObj.setPostalCode("3000");
        addObj.setCity("Melbourne");
        addObj.setRegion("VIC");
        addObj.setAddressUsageType("Mailing");
        ocvParty.getAddresses().remove(1);
        ocvParty.getAddresses().remove(0);
        ocvParty.getAddresses().add(addObj);
        final APIRequest<Party> apiRequest = new APIRequest<>(prepareRequestHeaders(), new HashMap<String, String>(),
                ocvParty);
        CapProfile capProfile = capTransformer.transformAPIRequest(apiRequest,streetConfig);
        List<AddressDetails> addresses = capProfile.getAddresses();
        assertEquals("Address Line 3 is not matching", "", addresses.get(0).getAddressLine3());
        assertEquals("Address Line 1 is not matching", "21 Level/ 10", addresses.get(0).getAddressLine1());
        assertEquals("Address Line 2 is not matching", "833 Collins ST Le", addresses.get(0).getAddressLine2());
    }

    @Test
    public void testGetAddressNoBuildingWithSlashLength42() throws Exception {
        Address addObj = new Address();
        addObj.setLevelNumber("21");
        addObj.setResidenceType("Level/");
        addObj.setResidenceNumber("10");
        addObj.setStreetNumber("833");
        addObj.setStreetName("Collins");
        addObj.setStreetSuffix("street");
        addObj.setPostDirectional("This is increased to test more than 40 characters");
        addObj.setCountry("AUS");
        addObj.setState("VIC");
        addObj.setPostalCode("3000");
        addObj.setCity("Melbourne");
        addObj.setRegion("VIC");
        addObj.setAddressUsageType("Mailing");
        ocvParty.getAddresses().remove(1);
        ocvParty.getAddresses().remove(0);
        ocvParty.getAddresses().add(addObj);
        final APIRequest<Party> apiRequest = new APIRequest<>(prepareRequestHeaders(), new HashMap<String, String>(),
                ocvParty);
        CapProfile capProfile = capTransformer.transformAPIRequest(apiRequest,streetConfig);
        List<AddressDetails> addresses = capProfile.getAddresses();
        assertEquals("Address Line 3 is not matching", "", addresses.get(0).getAddressLine3());
        assertEquals("Address Line 1 is not matching", "21 Level/ 10", addresses.get(0).getAddressLine1());
        assertEquals("Address Line 2 is not matching",
                "833 Collins ST This is increased to test more than 40 characters",
                addresses.get(0).getAddressLine2());
    }

    @Test
    public void testGenerateCapProfileV2() throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();
        Map<String, String> headers = prepareRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();
        Party party = objectMapper.readValue(ResourceUtils.getFile("classpath:cap/sample-party.json"), Party.class);
        com.anz.mdm.ocv.cap.v2.CapProfile capProfileShouldBe = objectMapper.readValue(
                ResourceUtils.getFile("classpath:cap/sample-capv2request-payload.json"),
                com.anz.mdm.ocv.cap.v2.CapProfile.class);
        APIRequest<Party> apiRequest = new APIRequest<>(headers, queryParameters, party);
        com.anz.mdm.ocv.cap.v2.CapProfile capProfileV2 = capTransformer.fromApiRequest(apiRequest,streetConfig);

        System.out.println(objectMapper.writeValueAsString(capProfileV2));
        assertEquals("capProfileV2 is not match the sample request payload",
                objectMapper.writeValueAsString(capProfileV2), objectMapper.writeValueAsString(capProfileShouldBe));
    }

    private Map<String, String> prepareRequestHeaders() {
        final Map<String, String> headers = new HashMap<String, String>();
        headers.put(OCVConstants.ACCEPT_HEADER, "application/json");
        headers.put(OCVConstants.TRACE_ID_HEADER, "12345");
        headers.put(OCVConstants.AUTHORIZATION_HEADER, "5237vxhsfdfyif");
        return headers;
    }

}
