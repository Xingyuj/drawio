package com.anz.mdm.ocv.api.util;

import static org.junit.Assert.*;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.ResourceUtils;

import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.exception.BadRequestException;
import com.anz.mdm.ocv.api.exception.IdempotencyTimeOutException;
import com.anz.mdm.ocv.api.processor.MaintainPartyServiceProcessor;
import com.anz.mdm.ocv.api.validator.APIRequest;
import com.anz.mdm.ocv.api.validator.MaintainPartyValidator;
import com.anz.mdm.ocv.api.validator.ValidationResult;
import com.anz.mdm.ocv.party.v1.Party;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;

@RunWith(SpringRunner.class)
public class IdempotencyConfigUtilTest {

    @InjectMocks
    @Spy
    private IdempotencyConfigUtil idemUtil;
    
    
    @Test
    public void isChannelIncluded() {
        String traceId = "test_id_12345";
        String[] channel = new String[]{"abc"};
        doReturn(channel).when(idemUtil).getIdempotentChannels();
        boolean channelIncluded = idemUtil.isChannelIncluded("abc",traceId);
        assertTrue(channelIncluded);
    }
    
    @Test
    public void isChannelIncludedFalse() {
        String traceId = "test_id_12345";
        String[] channel = new String[]{"abcd"};
        doReturn(channel).when(idemUtil).getIdempotentChannels();
        boolean channelIncluded = idemUtil.isChannelIncluded("abc",traceId);
        assertFalse(channelIncluded);
    }
    
    @Test
    public void isRequestModeIncludedTrue() {
        String traceId = "test_id_12345";
        String[] requestMode = new String[]{"xyz"};
        doReturn(requestMode).when(idemUtil).getFenergoanzxRequestMode();
        boolean requestModeIncluded = idemUtil.isRequestModeIncluded(true, "FENERGOANZX", "xyz", traceId);
        System.out.println(requestModeIncluded);
        assertTrue(requestModeIncluded);
    }
    
    @Test
    public void isRequestModeIncludedFalse() {
        String traceId = "test_id_12345";
        String[] requestMode = new String[]{"xyz"};
        doReturn(requestMode).when(idemUtil).getFenergoanzxRequestMode();
        boolean requestModeIncluded = idemUtil.isRequestModeIncluded(true, "abcd", "xyza", traceId);
        assertFalse(requestModeIncluded);
    }
    
    @Test
    public void isWithinExpiryTime() {
        doReturn("72").when(idemUtil).getIdempotencyExpiryTimeWindow();
        String millis = "1636543520102";
        LocalDateTime millsCurrentLocalDateTime = idemUtil.millsToLocalDateTime(Long.parseLong(millis));
        doReturn(millsCurrentLocalDateTime).when(idemUtil).millsToLocalDateTime(Mockito.anyLong());
        String idempotencyFirstSent = "2021-11-10 16:10:58.123";
        boolean withinExpiryTime = idemUtil.isWithinExpiryTime(idempotencyFirstSent);
        assertTrue(withinExpiryTime);
    }
    
    @Test
    public void isWithinExpiryTimeFalse() {
        doReturn("72").when(idemUtil).getIdempotencyExpiryTimeWindow();
        String millis = "1636543520102";
        LocalDateTime millsCurrentLocalDateTime = idemUtil.millsToLocalDateTime(Long.parseLong(millis));
        doReturn(millsCurrentLocalDateTime).when(idemUtil).millsToLocalDateTime(Mockito.anyLong());
        String idempotencyFirstSent = "2021-11-07 16:10:58.123";
        boolean withinExpiryTime = idemUtil.isWithinExpiryTime(idempotencyFirstSent);
        assertFalse(withinExpiryTime);
    }

    @Test
    public void validTimeFalse(){
        String idempotencyFirstSent = "2021-11-7 16:10:58.123";
        boolean validateTime = idemUtil.validateTime(idempotencyFirstSent);
        assertFalse(validateTime);
    }
    
    @Test
    public void validTimeTrue(){
        String idempotencyFirstSent = "2021-11-07 16:10:58.123";
        boolean validateTime = idemUtil.validateTime(idempotencyFirstSent);
        assertTrue(validateTime);
        
        idemUtil.validateTime(idempotencyFirstSent);
        
    }
    
    @Test(expected = IdempotencyTimeOutException.class)
    public void validateOne() throws JsonParseException, JsonMappingException, FileNotFoundException, IOException{
        Map<String, String> headers = prepareANZXRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();
        Party person = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:SamplePersonInput.json"),
                Party.class);
        
        ValidationResult result = new ValidationResult();
        result.setErrorCode(OCVConstants.IDEMPOTENT_TIME_LIMIT_EXPIRED);
        String traceId = "test_id_12345";
       
        doReturn(result).when(idemUtil).idempotencyValidator(Mockito.any(), Mockito.any(), Mockito.any());
        APIRequest<Party> apiRequest = new APIRequest<Party>(headers, queryParameters, person);
        APIRequest<Party> apiRequest2 = new APIRequest<Party>(headers, queryParameters, person);
        idemUtil.validate(apiRequest , apiRequest2, traceId);
        
    }

    @Test(expected = BadRequestException.class)
    public void validateTwo() throws JsonParseException, JsonMappingException, FileNotFoundException, IOException{
        Map<String, String> headers = prepareANZXRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();
        Party person = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:SamplePersonInput.json"),
                Party.class);
        
        ValidationResult result = new ValidationResult();
        result.setErrorCode(OCVConstants.MANDATORY_HEADER_MISSING_ERROR_CODE);
        String traceId = "test_id_12345";
       
        doReturn(result).when(idemUtil).idempotencyValidator(Mockito.any(), Mockito.any(), Mockito.any());
        APIRequest<Party> apiRequest = new APIRequest<Party>(headers, queryParameters, person);
        APIRequest<Party> apiRequest2 = new APIRequest<Party>(headers, queryParameters, person);
        idemUtil.validate(apiRequest , apiRequest2, traceId);
        
    }

    @Test
    public void idempotencyValidatorOne() throws JsonParseException, JsonMappingException, FileNotFoundException, IOException {
        String traceId = "test_id_12345";
        String[] requestMode = new String[]{"xyz"};

        
        Map<String, String> headers = prepareANZXRequestHeadersWI();
        Map<String, String> queryParameters = new HashMap<String, String>();
        Party person = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:SamplePersonInput.json"),
                Party.class);
        
        
        APIRequest<Party> apiRequest = new APIRequest<Party>(headers, queryParameters, person);
        APIRequest<Party> apiRequest2 = new APIRequest<Party>(headers, queryParameters, person);
        
        doReturn(false).when(idemUtil).isChannelIncluded(Mockito.any(),
                Mockito.any());
        doReturn(requestMode).when(idemUtil).getFenergoanzxRequestMode();

       idemUtil.idempotencyValidator(apiRequest , apiRequest2, "12345");
    
    }
    
    @Test
    public void idempotencyValidatorTwo() throws JsonParseException, JsonMappingException, FileNotFoundException, IOException {
        String traceId = "test_id_12345";
        String[] requestMode = new String[]{"createCustomer"};
        Map<String, String> headers = prepareANZXRequestHeadersIdempotent();
        Map<String, String> queryParameters = new HashMap<String, String>();
        Party person = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:SamplePersonInput.json"),
                Party.class);
        
        
        APIRequest<Party> apiRequest = new APIRequest<Party>(headers, queryParameters, person);
        APIRequest<Party> apiRequest2 = new APIRequest<Party>(headers, queryParameters, person);
        
        doReturn(true).when(idemUtil).isChannelIncluded(Mockito.any(),
                Mockito.any());

        doReturn(true).when(idemUtil).validateTime(Mockito.any());
        doReturn(true).when(idemUtil).isWithinExpiryTime(Mockito.any());
        doReturn(requestMode).when(idemUtil).getFenergoanzxRequestMode();
        
        ValidationResult idempotencyValidator = idemUtil.idempotencyValidator(apiRequest , apiRequest2, "12345");
        boolean valid = idempotencyValidator.isValid();
        assertTrue(valid);
    }

    @Test
    public void idempotencyValidatorThree() throws JsonParseException, JsonMappingException, FileNotFoundException, IOException {
        String traceId = "test_id_12345";
        String[] requestMode = new String[]{"createCustomer"};
        Map<String, String> headers = prepareANZXRequestHeadersIdempotent();
        Map<String, String> queryParameters = new HashMap<String, String>();
        Party person = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:SamplePersonInput.json"),
                Party.class);
        
        
        APIRequest<Party> apiRequest = new APIRequest<Party>(headers, queryParameters, person);
        APIRequest<Party> apiRequest2 = new APIRequest<Party>(headers, queryParameters, person);
        
        doReturn(true).when(idemUtil).isChannelIncluded(Mockito.any(),
                Mockito.any());

        doReturn(false).when(idemUtil).validateTime(Mockito.any());
        doReturn(true).when(idemUtil).isWithinExpiryTime(Mockito.any());
        doReturn(requestMode).when(idemUtil).getFenergoanzxRequestMode();
        
        ValidationResult idempotencyValidator = idemUtil.idempotencyValidator(apiRequest , apiRequest2, "12345");
        boolean valid = idempotencyValidator.isValid();
        assertFalse(valid);
    }
    
    @Test
    public void idempotencyValidatorFour() throws JsonParseException, JsonMappingException, FileNotFoundException, IOException {
        String traceId = "test_id_12345";
        String[] requestMode = new String[]{"createCustomer"};
        Map<String, String> headers = prepareANZXRequestHeadersIdempotent();
        Map<String, String> queryParameters = new HashMap<String, String>();
        Party person = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:SamplePersonInput.json"),
                Party.class);
        
        
        APIRequest<Party> apiRequest = new APIRequest<Party>(headers, queryParameters, person);
        APIRequest<Party> apiRequest2 = new APIRequest<Party>(headers, queryParameters, person);
        
        doReturn(true).when(idemUtil).isChannelIncluded(Mockito.any(),
                Mockito.any());

        doReturn(true).when(idemUtil).validateTime(Mockito.any());
        doReturn(false).when(idemUtil).isWithinExpiryTime(Mockito.any());
        doReturn(requestMode).when(idemUtil).getFenergoanzxRequestMode();
        
        ValidationResult idempotencyValidator = idemUtil.idempotencyValidator(apiRequest , apiRequest2, "12345");
        boolean valid = idempotencyValidator.isValid();
        assertFalse(valid);
    }
    
    
    private Map<String, String> prepareANZXRequestHeaders() {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put(OCVConstants.ACCEPT_HEADER, "application/json");
        headers.put(OCVConstants.TRACE_ID_HEADER, "6846gjfj-fgdjg-afas");
        headers.put(OCVConstants.AUTHORIZATION_HEADER,
                "Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImFwaWRldnRva2VuLmNvcnAuZGV2LmFueiJ9.eyJpc3MiOiJodHRwczovL2RhdGFwb3dlci1zdHMuYW56LmNvbSIsImF1ZCI6IlRlc3RVc2VyIiwic3ViIjoiVGVzdFVzZXIiLCJpYXQiOjE1ODgwNTAwMjMzODQsImV4cCI6MTU4ODA1MDkyMy4zODQsInNjb3BlcyI6WyJBVS5BTlpfSU5URVJOQUwuT0NWLk1NTE8uQUNDRVNTLlJFQUQiXSwiYW1yIjpbInBvcCJdLCJhY3IiOiJJQUwyLkFBTDEuRkFMMSJ9.MVN9DXoByov2ln4znQXmYk6IVIk1k7Gd3e3eqIJTfB0hgGs2xdAD2q73xMLjr22BgeylsrFdMV5PTFBhte8Wetgdyzyj7a1AuD4CJXFQ3dA0johCxS90g9qddhJhfJALVWsKtrVm86yMyvDT9mreIgVWnshiaD7ZLwrO9DxYQlqDdeJyH_RZWdFHMUMsECysF1psUDEZ8k3juEKeVNE0cM2QUBYxkvchU3hJUnrt2IpFmnf1d30Ksdyt1aqZIcN6y00qSm4LGI5OPVIm5ltF3TO2B9puZxSrBvn7NIjH6Xe2ocSzFagPctL_opzCwO0PnyOpeykmdReKfUNX8VkjaQ");
        headers.put(OCVConstants.CHANNEL, "FENERGOANZX");
        headers.put(OCVConstants.USER_ID_HEADER, "shgfjsf");
        headers.put(OCVConstants.REQUEST_TIMESTAMP, "2021-03-10 16:05:00.29");
        headers.put(OCVConstants.USER_ID, "5465465464");
        headers.put(OCVConstants.REQUEST_MODE_HEADER, "createCustomer");

        return headers;
    }

    private Map<String, String> prepareANZXRequestHeadersWI() {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put(OCVConstants.ACCEPT_HEADER, "application/json");
        headers.put(OCVConstants.TRACE_ID_HEADER, "6846gjfj-fgdjg-afas");
        headers.put(OCVConstants.AUTHORIZATION_HEADER,
                "Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImFwaWRldnRva2VuLmNvcnAuZGV2LmFueiJ9.eyJpc3MiOiJodHRwczovL2RhdGFwb3dlci1zdHMuYW56LmNvbSIsImF1ZCI6IlRlc3RVc2VyIiwic3ViIjoiVGVzdFVzZXIiLCJpYXQiOjE1ODgwNTAwMjMzODQsImV4cCI6MTU4ODA1MDkyMy4zODQsInNjb3BlcyI6WyJBVS5BTlpfSU5URVJOQUwuT0NWLk1NTE8uQUNDRVNTLlJFQUQiXSwiYW1yIjpbInBvcCJdLCJhY3IiOiJJQUwyLkFBTDEuRkFMMSJ9.MVN9DXoByov2ln4znQXmYk6IVIk1k7Gd3e3eqIJTfB0hgGs2xdAD2q73xMLjr22BgeylsrFdMV5PTFBhte8Wetgdyzyj7a1AuD4CJXFQ3dA0johCxS90g9qddhJhfJALVWsKtrVm86yMyvDT9mreIgVWnshiaD7ZLwrO9DxYQlqDdeJyH_RZWdFHMUMsECysF1psUDEZ8k3juEKeVNE0cM2QUBYxkvchU3hJUnrt2IpFmnf1d30Ksdyt1aqZIcN6y00qSm4LGI5OPVIm5ltF3TO2B9puZxSrBvn7NIjH6Xe2ocSzFagPctL_opzCwO0PnyOpeykmdReKfUNX8VkjaQ");
        headers.put(OCVConstants.CHANNEL, "FENERGOANZX");
        headers.put(OCVConstants.USER_ID_HEADER, "shgfjsf");
        headers.put(OCVConstants.REQUEST_TIMESTAMP, "2021-03-10 16:05:00.29");
        headers.put(OCVConstants.USER_ID, "5465465464");
        headers.put(OCVConstants.REQUEST_MODE_HEADER, "createCustomer");

        return headers;
    }
    
    private Map<String, String> prepareANZXRequestHeadersIdempotent() {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put(OCVConstants.ACCEPT_HEADER, "application/json");
        headers.put(OCVConstants.TRACE_ID_HEADER, "6846gjfj-fgdjg-afas");
        headers.put(OCVConstants.AUTHORIZATION_HEADER,
                "Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImFwaWRldnRva2VuLmNvcnAuZGV2LmFueiJ9.eyJpc3MiOiJodHRwczovL2RhdGFwb3dlci1zdHMuYW56LmNvbSIsImF1ZCI6IlRlc3RVc2VyIiwic3ViIjoiVGVzdFVzZXIiLCJpYXQiOjE1ODgwNTAwMjMzODQsImV4cCI6MTU4ODA1MDkyMy4zODQsInNjb3BlcyI6WyJBVS5BTlpfSU5URVJOQUwuT0NWLk1NTE8uQUNDRVNTLlJFQUQiXSwiYW1yIjpbInBvcCJdLCJhY3IiOiJJQUwyLkFBTDEuRkFMMSJ9.MVN9DXoByov2ln4znQXmYk6IVIk1k7Gd3e3eqIJTfB0hgGs2xdAD2q73xMLjr22BgeylsrFdMV5PTFBhte8Wetgdyzyj7a1AuD4CJXFQ3dA0johCxS90g9qddhJhfJALVWsKtrVm86yMyvDT9mreIgVWnshiaD7ZLwrO9DxYQlqDdeJyH_RZWdFHMUMsECysF1psUDEZ8k3juEKeVNE0cM2QUBYxkvchU3hJUnrt2IpFmnf1d30Ksdyt1aqZIcN6y00qSm4LGI5OPVIm5ltF3TO2B9puZxSrBvn7NIjH6Xe2ocSzFagPctL_opzCwO0PnyOpeykmdReKfUNX8VkjaQ");
        headers.put(OCVConstants.CHANNEL, "FENERGOANZX");
        headers.put(OCVConstants.USER_ID_HEADER, "shgfjsf");
        headers.put(OCVConstants.REQUEST_TIMESTAMP, "2021-03-10 16:05:00.29");
        headers.put(OCVConstants.USER_ID, "5465465464");
        headers.put(OCVConstants.REQUEST_MODE_HEADER, "createCustomer");
        headers.put(OCVConstants.IDEMPOTENCY_KEY, "12345");
        headers.put(OCVConstants.IDEMPOTENCY_FIRST_SENT, "2021-03-10 16:05:00.29");
        return headers;
    }
    
}
