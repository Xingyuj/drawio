package com.anz.mdm.ocv.api.downstreamservices.test;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.doReturn;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.HttpEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.downsteamservices.CapTransformationService;
import com.anz.mdm.ocv.api.downsteamservices.DataStandardisationService;
import com.anz.mdm.ocv.api.downsteamservices.DataValidationService;
import com.anz.mdm.ocv.api.downsteamservices.MaintainPartyService;
import com.anz.mdm.ocv.api.downsteamservices.OnboardService;
import com.anz.mdm.ocv.api.downsteamservices.RetrievePartyService;
import com.anz.mdm.ocv.api.downsteamservices.StandardisedParty;
import com.anz.mdm.ocv.api.downsteamservices.ValidatedParty;
import com.anz.mdm.ocv.api.dto.APIResponse;
import com.anz.mdm.ocv.api.model.CAPParty;
import com.anz.mdm.ocv.api.validator.APIRequest;
import com.anz.mdm.ocv.common.v1.SourceSystem;
import com.anz.mdm.ocv.party.v1.Party;
import com.anz.mdm.ocv.party.v1.SearchPartyResultWrapper;
import com.ibm.mdm.schema.TCRMService;

@RunWith(SpringRunner.class)
public class OnboardServiceTest {
    @Mock
    private RetrievePartyService retrievePartyService;

    @Mock
    private CapTransformationService capTransformationService;

    @Mock
    private DataStandardisationService dataStandardisationService;

    @Mock
    private DataValidationService dataValidationService;

    @Mock
    private MaintainPartyService maintainPartyService;

    @InjectMocks
    private OnboardService onboardService;

    @Test
    public void givenPartyWithCapCisId_whenRetrieveCapCisId_thenReturnFalseWithSourceSystem() throws Exception {
        String capSampleCisId = "Cap-192387a";
        Map<String, String> headers = new HashMap<>();
        Map<String, String> queryParameters = new HashMap<>();
        Map<String, Party> idMap = new HashMap<>();
        Party party = new Party();
        SourceSystem sourceSystem = new SourceSystem();
        sourceSystem.setSourceSystemName(OCVConstants.CAP_CIS_SOURCE);
        sourceSystem.setSourceSystemId(capSampleCisId);
        idMap.put(OCVConstants.CAP_CIS_SOURCE, party);
        party.getSourceSystems().add(sourceSystem);
        APIRequest<Party> request = new APIRequest<>(headers, queryParameters, party);
        doReturn(idMap).when(capTransformationService).getIdMap(any());
        boolean generatedCapCisId = onboardService.retrieveOrGenerateCapCisId(request, request, "traceId");
        SourceSystem retrievedPartySourceSystem = request.getRequestBody().getSourceSystems().get(0);

        assertFalse("should return false for retrieved cap cis id", generatedCapCisId);
        assertEquals(OCVConstants.CAP_CIS_SOURCE, retrievedPartySourceSystem.getSourceSystemName());
        assertEquals(capSampleCisId, retrievedPartySourceSystem.getSourceSystemId());
    }

    @Test
    public void givenSearchPartyResultWithoutParty_whenGenerateCapCisId_thenReturnTrueWithCapCisId() throws Exception {
        String capSampleCisId = "Cap-192387a";
        Map<String, String> headers = new HashMap<>();
        Map<String, String> queryParameters = new HashMap<>();
        Party party = new Party();
        SourceSystem sourceSystem = new SourceSystem();
        sourceSystem.setSourceSystemName(OCVConstants.CAP_CIS_SOURCE);
        sourceSystem.setSourceSystemId(capSampleCisId);
        party.getSourceSystems().add(sourceSystem);

        APIRequest<Party> preRequest = new APIRequest<>(headers, queryParameters, new Party());
        APIRequest<Party> postRequest = new APIRequest<>(headers, queryParameters, party);
        CAPParty capParty = new CAPParty(postRequest, true);
        SearchPartyResultWrapper searchPartyResultWrapper = new SearchPartyResultWrapper();
        doReturn(searchPartyResultWrapper).when(retrievePartyService).getResponse(any(), anyString());
        doReturn(capParty).when(capTransformationService).createCapProfileV2(any(), any(), anyString());

        boolean generatedCapCisId = onboardService.retrieveOrGenerateCapCisId(preRequest, preRequest, "traceId");
        SourceSystem retrievedPartySourceSystem = preRequest.getRequestBody().getSourceSystems().get(0);

        assertTrue("should return true for generated cap cis id", generatedCapCisId);
        assertEquals(OCVConstants.CAP_CIS_SOURCE, retrievedPartySourceSystem.getSourceSystemName());
        assertEquals(capSampleCisId, retrievedPartySourceSystem.getSourceSystemId());
    }

    @Test
    public void givenValidatedParty_whenGetPartyAPIRequestWithValidatedParty_thenReturnValid() throws Exception {
        Map<String, String> headers = new HashMap<>();
        Map<String, String> queryParameters = new HashMap<>();
        Party party = new Party();
        Party postParty = new Party();

        APIRequest<Party> request = new APIRequest<>(headers, queryParameters, party);
        ValidatedParty validatedParty = new ValidatedParty(postParty, true);
        StandardisedParty standardisedParty = new StandardisedParty(party, true);

        doReturn(standardisedParty).when(dataStandardisationService).standardiseParty(any());
        doReturn(validatedParty).when(dataStandardisationService).standardisePhoneWithRHDM(any(), any(), any());

        APIRequest<Party> postRequest = onboardService.getPartyAPIRequestWithValidatedParty(headers, queryParameters,
                request, 0L);
        assertNotNull(postRequest.getRequestBody());
        assertEquals(postRequest.getRequestBody(), postParty);
    }

    @Test
    public void givenXmlResponse_whenCreateOrUpdateProspectPartyTest_thenReturnValid() throws Exception {
        Map<String, String> headers = new HashMap<>();
        Map<String, String> queryParameters = new HashMap<>();
        Party party = new Party();
        APIRequest<Party> preRequest = new APIRequest<>(headers, queryParameters, party);
        Boolean createCustomerModeWithCAPCISID = true;
        boolean isGoldenProfile = true;

        String requestMDMXml = "<requestTime>2022-02-02</requestTime>";
        TCRMService tcrmService = new TCRMService();
        HttpEntity<TCRMService> xmlResponse = new HttpEntity<>(tcrmService, null);
        APIResponse response = new APIResponse();
        doReturn(requestMDMXml).when(maintainPartyService).transformPartyRequest(any(), anyBoolean(), any());
        doReturn(xmlResponse).when(maintainPartyService).invokeMdmBackend(anyString(), anyString());
        doReturn(response).when(maintainPartyService).transformMdmResponse(anyString(), any(), any());

        APIResponse postResponse = onboardService.createOrUpdateProspectParty(preRequest, "sampleTraceId",
                createCustomerModeWithCAPCISID, isGoldenProfile);

        assertNotNull(postResponse);
        assertEquals(response, postResponse);
    }

}