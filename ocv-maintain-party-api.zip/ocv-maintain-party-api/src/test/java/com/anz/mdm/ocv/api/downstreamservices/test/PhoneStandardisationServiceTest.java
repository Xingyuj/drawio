package com.anz.mdm.ocv.api.downstreamservices.test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.ResourceUtils;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.downsteamservices.RedhatRuleEngineService;
import com.anz.mdm.ocv.api.downsteamservices.StandardisedParty;
import com.anz.mdm.ocv.api.validator.APIRequest;
import com.anz.mdm.ocv.party.v1.Party;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
public class PhoneStandardisationServiceTest {

    @InjectMocks
    RedhatRuleEngineService redhatRuleEngineService;

    @Mock(name = "RedhatRuleEngineServiceRestTemplate")
    RestTemplate restTemplate;

    final String phoneStandUri = "http://mockserver/party";

    @Captor
    private ArgumentCaptor<HttpEntity<Party>> captor;

    final String acn = "87493580478";
    final String abn = "874935804";
    final String standardisedAcn = "0087493580478";
    final String standardisedAbn = "00874935804";
    final String traceID = "12345";

    @Before
    public void init() {
        redhatRuleEngineService.setUrl(phoneStandUri);
    }

    @Test
    public void testSuccess() throws Exception {
        Map<String, String> headers = prepareRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();
        String requestTime = "2018-10-01 10:02:00.0";
        Party party = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:SamplePersonInput.json"), Party.class);
        APIRequest<Party> partyObject = new APIRequest<>(headers, queryParameters, party);

        HttpEntity<String> response = getXMLFromFile("classpath:MaintainPartyIndResponse.xml");

        String jsonResponse = new String(
                Files.readAllBytes(ResourceUtils.getFile("classpath:PersonJSONResponse_stndPhone.json").toPath()));
        
        final Party partyRes = new ObjectMapper().readValue(jsonResponse, Party.class);
        
        ResponseEntity<Party> serviceResponse = new ResponseEntity<>(partyRes, HttpStatus.OK);
     
        doReturn(serviceResponse).when(restTemplate).exchange(any(String.class), any(), any(HttpEntity.class),
                any(Class.class));
        
        StandardisedParty standardisedParty = (StandardisedParty)redhatRuleEngineService.invokeRedHatRuleEngine(partyObject);
        System.out.println("apiResponse : " + standardisedParty.getParty().getPhones().get(0).getPhone());
        System.out.println("apiResponse : " + standardisedParty.getParty().getPhones().get(0).getStandardisedPhone());
        System.out.println("jsonResponse : " + jsonResponse);
        //assertEquals("Comparison", apiResponse, jsonResponse);
    }
    
    @Test
    public void verifyRecovery() {
        byte[] bytes = null;
        try {
            Map<String, String> headers = prepareRequestHeaders();
            Map<String, String> queryParameters = new HashMap<String, String>();
            String requestTime = "2018-10-01 10:02:00.0";
            Party party = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:SamplePersonInput.json"), Party.class);
            APIRequest<Party> partyObject = new APIRequest<>(headers, queryParameters, party);
            redhatRuleEngineService.retryFromRecover(new ResourceAccessException("Others"), partyObject);
            assertFalse(false);
        } catch (Exception ex) {
            String message = ex.getMessage();
            assertTrue(true);
        }        
    }
    
    @Test
    public void testFailure() throws Exception {
        Map<String, String> headers = prepareRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();
        String requestTime = "2018-10-01 10:02:00.0";
        Party party = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:SamplePersonInput.json"), Party.class);
        APIRequest<Party> partyObject = new APIRequest<>(headers, queryParameters, party);

        HttpEntity<String> response = getXMLFromFile("classpath:MaintainPartyIndResponse.xml");

        String jsonResponse = new String(
                Files.readAllBytes(ResourceUtils.getFile("classpath:PersonJSONResponse_stndPhone.json").toPath()));
        
        final Party partyRes = new ObjectMapper().readValue(jsonResponse, Party.class);
        
        ResponseEntity<Party> serviceResponse = new ResponseEntity<>(partyRes, HttpStatus.OK);

        when(restTemplate.exchange(any(String.class), any(), any(HttpEntity.class), any(Class.class)))
        .thenThrow(new ResourceAccessException("SocketTimeoutException: 5005"));
        try {
            final StandardisedParty standardisedParty = (StandardisedParty)redhatRuleEngineService.invokeRedHatRuleEngine(partyObject);
        }catch(Exception ex) {
            String message = ex.getMessage();
            assertTrue(message.contains("5005"));
        }
              

    }

    private Party setParameterisedBody(final String abn, final String acn)
            throws JsonParseException, JsonMappingException, IOException {

        final String jsonString = "{\r\n" + "\"partyType\" : \"Non individual\",\r\n" + "\"identifiers\" : [{\r\n"
                + "\"identifierUsageType\" : \"ABN\",\r\n" + "\"identifier\" : \"" + abn + "\"\r\n" + "},{\r\n"
                + "\"identifierUsageType\" : \"ACN\",\r\n" + "\"identifier\" : \"" + acn + "\"\r\n" + "}],\r\n"
                + "\"names\":[{\"name\":\"ANZ\"}\r\n" + "    ]\r\n" + "}";
        final Party party = new ObjectMapper().readValue(jsonString, Party.class);
        return party;
    }

    private Map<String, String> prepareRequestHeaders() {
        final Map<String, String> headers = new HashMap<String, String>();
        headers.put(OCVConstants.ACCEPT_HEADER, "application/json");
        headers.put(OCVConstants.TRACE_ID_HEADER, "12345");
        headers.put(OCVConstants.AUTHORIZATION_HEADER, "5237vxhsfdfyif");
        return headers;
    }

    private HttpEntity<String> getXMLFromFile(String path) {
        String mdmResponse = "";
        try {
            File resource = ResourceUtils.getFile(path);
            mdmResponse = new String(Files.readAllBytes(resource.toPath()));
        } catch (IOException e) {

            e.printStackTrace();
        }
        HttpEntity<String> response = new HttpEntity<String>(mdmResponse);
        return response;

    }

}