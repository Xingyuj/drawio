package com.anz.mdm.ocv.api.test;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.anz.mdm.ocv.api.UAMAccessConfiguration;
import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.controller.APIController;
import com.anz.mdm.ocv.api.downsteamservices.CapTransformationService;
import com.anz.mdm.ocv.api.downsteamservices.DataStandardisationService;
import com.anz.mdm.ocv.api.downsteamservices.DataValidationService;
import com.anz.mdm.ocv.api.downsteamservices.DeletePartyService;
import com.anz.mdm.ocv.api.downsteamservices.JWTService;
import com.anz.mdm.ocv.api.downsteamservices.MaintainPartyService;
import com.anz.mdm.ocv.api.downsteamservices.RetrievePartyService;
import com.anz.mdm.ocv.api.downsteamservices.StandardisedParty;
import com.anz.mdm.ocv.api.downsteamservices.ValidatedParty;
import com.anz.mdm.ocv.api.exception.GlobalExceptionHandler;
import com.anz.mdm.ocv.api.interceptor.JWTInterceptor;
import com.anz.mdm.ocv.api.util.IdempotencyConfigUtil;
import com.anz.mdm.ocv.api.util.LogRequestModel;
import com.anz.mdm.ocv.api.validator.APIRequest;
import com.anz.mdm.ocv.api.validator.MaintainPartyValidator;
import com.anz.mdm.ocv.api.validator.ValidationResult;
import com.anz.mdm.ocv.common.v1.SourceSystem;
import com.anz.mdm.ocv.jwt.validator.impl.JWTSignatureValidatorServiceImpl;
import com.anz.mdm.ocv.party.v1.Party;
import com.anz.mdm.ocv.party.v1.SearchPartyResultWrapper;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
public class MatchingAPITest {
	
	@InjectMocks
    private APIController apiController;

    private DataStandardisationService dataStandardisationService;
    private MaintainPartyService maintainPartyService;
    private DeletePartyService deletePartyService;
    private DataValidationService dataValidationService;
    private MockMvc mockmvc;
    private RetrievePartyService retrievePartyService;
    private LogRequestModel logAttributes;
    private CapTransformationService capTransformationService;
    private JWTInterceptor jwtInterceptor;

    private JWTService theJWTService;

    private UAMAccessConfiguration uamConfiguration;

    private JWTSignatureValidatorServiceImpl signatureValidationImpl;

    private GlobalExceptionHandler exceptionHandler;
    
    @Mock
    private IdempotencyConfigUtil idempotencyConfigUtil;
    
    @Mock
    private MaintainPartyValidator maintainPartyValidator;

    @Before
    public void setup() {
        logAttributes = new LogRequestModel();
        logAttributes = spy(logAttributes);

        maintainPartyService = new MaintainPartyService();
        dataStandardisationService = new DataStandardisationService();
        deletePartyService = new DeletePartyService();
        retrievePartyService = new RetrievePartyService();
        capTransformationService = new CapTransformationService();
        // elasticSearchPartyService = new ElasticSearchPartyService();

        maintainPartyService = spy(maintainPartyService);
        dataStandardisationService = spy(dataStandardisationService);
        deletePartyService = spy(deletePartyService);
        dataValidationService = new DataValidationService();
        dataValidationService = spy(dataValidationService);

        retrievePartyService = spy(retrievePartyService);
        capTransformationService = spy(capTransformationService);

        jwtInterceptor = new JWTInterceptor(theJWTService, uamConfiguration);
        jwtInterceptor = spy(jwtInterceptor);
        
        idempotencyConfigUtil = new IdempotencyConfigUtil();
        idempotencyConfigUtil = spy(idempotencyConfigUtil);

        apiController = new APIController(dataStandardisationService, maintainPartyService, deletePartyService,
                logAttributes, dataValidationService, retrievePartyService, capTransformationService, jwtInterceptor, idempotencyConfigUtil);
        MockitoAnnotations.initMocks(this);
        exceptionHandler = new GlobalExceptionHandler();
        exceptionHandler.setLogAttributes(logAttributes);
        mockmvc = MockMvcBuilders.standaloneSetup(exceptionHandler, apiController).build();
    }

    // @Test
    // public void searchParties_ServerException() throws Exception {
    // HttpHeaders headers = prepareRequestHeaders();
    // String jsonString = "{\r\n" + "\"partyType\" : \"Non individual\",\r\n" +
    // "\"identifiers\" : [{\r\n"
    // + "\"identifierUsageType\" : \"ABN\",\r\n" + "\"identifier\" :
    // \"874935804\"\r\n" + "},{\r\n"
    // + "\"identifierUsageType\" : \"ACN\",\r\n" + "\"identifier\" :
    // \"87493580478\"\r\n" + "}],\r\n"
    // + "\"names\":[{\"name\":\"ANZ\"}\r\n" + " ]\r\n" + "}";
    //
    // Party party = new ObjectMapper().readValue(jsonString, Party.class);
    //
    // MultiValueMap<String, String> params = new LinkedMultiValueMap<String,
    // String>();
    // params.add(OCVConstants.SEARCH_TYPE_PARAMETER,
    // OCVConstants.CERTIFIED_SEARCH_TYPE);
    // RequestBuilder request =
    // MockMvcRequestBuilders.post("/parties/search").contentType("application/json")
    // .content(jsonString).headers(headers).params(params);
    // ValidationResult validationResult = new ValidationResult();
    // doReturn(validationResult).when(maintainPartyValidator).validateAPIRequest(any(APIRequest.class));
    // doReturn(new StandardisedParty(party,
    // true)).when(dataStandardisationService)
    // .standardiseParty(any(APIRequest.class));
    // doThrow(ServerException.class).when(interceptor).interceptRequest(any(APIRequest.class));
    // MvcResult rs = mockmvc.perform(request).andReturn();
    // assertTrue((rs.getResolvedException()) instanceof ServerException);
    // }

    private HttpHeaders prepareRequestHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.add(OCVConstants.ACCEPT_HEADER, "application/json");
        headers.add(OCVConstants.TRACE_ID_HEADER, "abc123");
        headers.add(OCVConstants.AUTHORIZATION_HEADER, "5237vxhsfdfyif");
        return headers;
    }

    // @Test
    // public void InitializationException() throws Exception {
    // HttpHeaders headers = prepareRequestHeaders();
    // String jsonString = "{\r\n" + "\"partyType\" : \"Non individual\",\r\n" +
    // "\"identifiers\" : [{\r\n"
    // + "\"identifierUsageType\" : \"ABN\",\r\n" + "\"identifier\" :
    // \"874935804\"\r\n" + "},{\r\n"
    // + "\"identifierUsageType\" : \"ACN\",\r\n" + "\"identifier\" :
    // \"87493580478\"\r\n" + "}],\r\n"
    // + "\"names\":[{\"name\":\"ANZ\"}\r\n" + " ]\r\n" + "}";
    //
    // Party party = new ObjectMapper().readValue(jsonString, Party.class);
    //
    // MultiValueMap<String, String> params = new LinkedMultiValueMap<String,
    // String>();
    // params.add(OCVConstants.SEARCH_TYPE_PARAMETER,
    // OCVConstants.CERTIFIED_SEARCH_TYPE);
    // RequestBuilder request =
    // MockMvcRequestBuilders.post("/parties/search").contentType("application/json")
    // .content(jsonString).headers(headers).params(params);
    // ValidationResult validationResult = new ValidationResult();
    // doReturn(validationResult).when(searchPartyValidator).validateAPIRequest(any(APIRequest.class));
    // doReturn(new StandardisedParty(party,
    // true)).when(dataStandardisationService)
    // .standardiseParty(any(APIRequest.class));
    // doThrow(InitializationException.class).when(interceptor).interceptRequest(any(APIRequest.class));
    // MvcResult rs = mockmvc.perform(request).andReturn();
    // assertTrue((rs.getResolvedException()) instanceof
    // InitializationException);
    // }

    @Test
    public void MaintainParties_Success() throws Exception {
        HttpHeaders headers = prepareRequestHeaders();
        headers.add(OCVConstants.REQUEST_TIMESTAMP, "2018-10-09 10:02:00.0");
        headers.add(OCVConstants.USER_ID_HEADER, "87595870");
        headers.add(OCVConstants.CHANNEL, "CAP-CIS");
        headers.add(OCVConstants.REQUEST_MODE_HEADER, "updateCustomer");

        String jsonString = "{\r\n" + "\"partyType\" : \"Non individual\",\r\n" + "\"source\" : \"CAP-CIS\",\r\n"
                + "\"identifiers\" : [{\r\n" + "\"identifierUsageType\" : \"ABN\",\r\n"
                + "\"identifier\" : \"874935804\"\r\n" + "},{\r\n" + "\"identifierUsageType\" : \"ACN\",\r\n"
                + "\"identifier\" : \"87493580478\"\r\n" + "}],\r\n" + "\"names\":[{\"name\":\"ANZ\"}\r\n" + "    ]\r\n"
                + "}";
        String responseJsonString = "[{\r\n" + "\"partyType\" : \"Individual\",\r\n" + "\"identifiers\" : [\r\n"
                + "{\r\n" + "\"identifierUsageType\" : \"Drivers Licence\",\r\n" + "\"identifier\" : \"221321312\"\r\n"
                + "},\r\n" + "{\r\n" + "\"identifierUsageType\" : \"ACN\",\r\n" + "\"identifier\" : \"4795945\"\r\n"
                + "}\r\n" + "],\r\n" + "\"names\":[\r\n" + "{\r\n" + "\"firstName\":\"AMP\",\r\n"
                + "\"lastName\" : \"XYZ\"\r\n" + "}\r\n" + "],\r\n" + "\"addresses\" : [\r\n" + "{\r\n"
                + "\"addressLineOne\" : \"abc\",\r\n" + "\"addressLineTwo\" : \"def\",\r\n" + "\"city\" : \"gjh\",\r\n"
                + "\"postalCode\" : \"784794\"\r\n" + "},\r\n" + "{\r\n" + "\"addressLineOne\" : \"123\",\r\n"
                + "\"addressLineTwo\" : \"34565\",\r\n" + "\"city\" : \"98484\",\r\n" + "\"postalCode\" : \"dhjd\"\r\n"
                + "}\r\n" + "],\r\n" + "\"dateOfBirth\" : \"07-12-1990\",\r\n" + "\"emails\" : [\r\n" + "{\r\n"
                + "\"email\":\"deepika.xyz@gmail.com\"\r\n" + "},\r\n" + "{\r\n" + "\"email\":\"abc.xyz@gmail.com\"\r\n"
                + "}\r\n" + "]\r\n" + "}]";

        Party party = new ObjectMapper().readValue(jsonString, Party.class);

        MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
        // params.add(OCVConstants.SEARCH_TYPE_PARAMETER,
        // OCVConstants.CERTIFIED_SEARCH_TYPE);
        
        // OCT-23700 - for validating JWT Token Scope - Start
        ValidationResult validationResult = new ValidationResult();
        doReturn(validationResult).when(maintainPartyValidator).validateRequest(any());
        //OCT-23700 - for validating JWT Token Scope - End

        RequestBuilder request = MockMvcRequestBuilders.post("/parties").contentType("application/json")
                .content(jsonString).headers(headers);
        // ValidationResult validationResult = new ValidationResult();
        // doReturn(validationResult).when(searchPartyValidator).validateAPIRequest(any(APIRequest.class));
        doReturn(responseJsonString).when(maintainPartyService).processParty(any(APIRequest.class), any(String.class),
                any(String.class), any(boolean.class));
        doReturn(new StandardisedParty(party, true)).when(dataStandardisationService)
                .standardiseParty(any(APIRequest.class));
        doReturn(true).when(jwtInterceptor).validateJWT(any(APIRequest.class));
        doReturn(new ValidatedParty(party, true)).when(dataValidationService)
                .validateParty(Mockito.any(APIRequest.class));
        MvcResult rs = mockmvc.perform(request).andReturn();
        assertEquals(200, rs.getResponse().getStatus());
    }

    @Test
    public void deletePartySuccess() throws Exception {
        HttpHeaders headers = prepareRequestHeaders();
        headers.add(OCVConstants.REQUEST_TIMESTAMP, "2018-10-09 10:02:00.0");
        headers.add(OCVConstants.USER_ID_HEADER, "87595870");
        headers.add(OCVConstants.CHANNEL, "CAP-CIS");
        String responseJsonString = "[{\r\n" + "\"partyType\" : \"Individual\",\r\n" + "\"identifiers\" : [\r\n"
                + "{\r\n" + "\"identifierUsageType\" : \"Drivers Licence\",\r\n" + "\"identifier\" : \"221321312\"\r\n"
                + "},\r\n" + "{\r\n" + "\"identifierUsageType\" : \"ACN\",\r\n" + "\"identifier\" : \"4795945\"\r\n"
                + "}\r\n" + "],\r\n" + "\"names\":[\r\n" + "{\r\n" + "\"firstName\":\"AMP\",\r\n"
                + "\"lastName\" : \"XYZ\"\r\n" + "}\r\n" + "],\r\n" + "\"addresses\" : [\r\n" + "{\r\n"
                + "\"addressLineOne\" : \"abc\",\r\n" + "\"addressLineTwo\" : \"def\",\r\n" + "\"city\" : \"gjh\",\r\n"
                + "\"postalCode\" : \"784794\"\r\n" + "},\r\n" + "{\r\n" + "\"addressLineOne\" : \"123\",\r\n"
                + "\"addressLineTwo\" : \"34565\",\r\n" + "\"city\" : \"98484\",\r\n" + "\"postalCode\" : \"dhjd\"\r\n"
                + "}\r\n" + "],\r\n" + "\"dateOfBirth\" : \"07-12-1990\",\r\n" + "\"emails\" : [\r\n" + "{\r\n"
                + "\"email\":\"deepika.xyz@gmail.com\"\r\n" + "},\r\n" + "{\r\n" + "\"email\":\"abc.xyz@gmail.com\"\r\n"
                + "}\r\n" + "]\r\n" + "}]";

        RequestBuilder request = MockMvcRequestBuilders.delete("/parties/65867567").contentType("application/json")
                .param("idType", "ocvId").headers(headers);
        // ValidationResult validationResult = new ValidationResult();
        // doReturn(validationResult).when(searchPartyValidator).validateAPIRequest(any(APIRequest.class));
        doReturn(responseJsonString).when(deletePartyService).processDeleteParty(any(APIRequest.class),
                any(String.class), any(String.class));
        doReturn(true).when(jwtInterceptor).validateJWT(any(APIRequest.class));
        MvcResult rs = mockmvc.perform(request).andReturn();
        assertEquals(200, rs.getResponse().getStatus());
    }

    @Test
    public void health() throws Exception {
        RequestBuilder request = MockMvcRequestBuilders.get("/health").contentType("application/json");
        // ValidationResult validationResult = new ValidationResult();
        // doReturn(validationResult).when(searchPartyValidator).validateAPIRequest(any(APIRequest.class));
        MvcResult rs = mockmvc.perform(request).andReturn();
        assertEquals(200, rs.getResponse().getStatus());
    }

    public Map<String, String> prepareHeadersForApi() {

        Map<String, String> headers = new HashMap<String, String>();
        headers.put(OCVConstants.ACCEPT_HEADER, "application/json");
        headers.put(OCVConstants.TRACE_ID_HEADER, "6846gjfj-fgdjg-afas");
        headers.put(OCVConstants.AUTHORIZATION_HEADER,
                "Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImFwaWRldnRva2VuLmNvcnAuZGV2LmFueiJ9.eyJpc3MiOiJodHRwczovL2RhdGFwb3dlci1zdHMuYW56LmNvbSIsImF1ZCI6IlRlc3RVc2VyIiwic3ViIjoiVGVzdFVzZXIiLCJpYXQiOjE1ODgwNTAwMjMzODQsImV4cCI6MTU4ODA1MDkyMy4zODQsInNjb3BlcyI6WyJBVS5BTlpfSU5URVJOQUwuT0NWLk1NTE8uQUNDRVNTLlJFQUQiXSwiYW1yIjpbInBvcCJdLCJhY3IiOiJJQUwyLkFBTDEuRkFMMSJ9.MVN9DXoByov2ln4znQXmYk6IVIk1k7Gd3e3eqIJTfB0hgGs2xdAD2q73xMLjr22BgeylsrFdMV5PTFBhte8Wetgdyzyj7a1AuD4CJXFQ3dA0johCxS90g9qddhJhfJALVWsKtrVm86yMyvDT9mreIgVWnshiaD7ZLwrO9DxYQlqDdeJyH_RZWdFHMUMsECysF1psUDEZ8k3juEKeVNE0cM2QUBYxkvchU3hJUnrt2IpFmnf1d30Ksdyt1aqZIcN6y00qSm4LGI5OPVIm5ltF3TO2B9puZxSrBvn7NIjH6Xe2ocSzFagPctL_opzCwO0PnyOpeykmdReKfUNX8VkjaQ");
        headers.put(OCVConstants.CHANNEL, "MMLO");
        headers.put(OCVConstants.USER_ID_HEADER, "shgfjsf");

        return headers;
    }

    // private Map<String, String> createQueryParams() {
    // Map<String, String> params = new HashMap<String, String>();
    // params.put(OCVConstants.SEARCH_TYPE_PARAMETER,
    // OCVConstants.FUZZY_SEARCH_TYPE);
    // return params;
    //
    // }

    private Party CreateDummyParty(String PartyType, String sourceSystem) {
        Party party = new Party();
        party.setPartyType(PartyType);
        SourceSystem s = new SourceSystem();
        s.setSourceSystemName(sourceSystem);
        s.setSourceSystemId("5836598503");
        party.getSourceSystems().add(s);
        party.setDateOfBirth("07-12-1990");
        party.setGender("F");
        return party;

    }

    static class PartyReference extends TypeReference<SearchPartyResultWrapper> {

    }

}