package com.anz.mdm.ocv.api.util.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.anz.mdm.ocv.api.transform.XMLParser;
import com.anz.mdm.ocv.api.util.StringEscaper;

public class StringEscaperTest {

    @Test
    /*
     * Test to verify that the control characters are stripped off
     */
    public void testJsonEncodeMessage() {
        String xmlStr = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><arcwpd:PartyDetails xmlns:arcwpd=\"http://www.anz.com/integration/australiarcw/partydetails0206/v2.06\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><MessageHeader><sourceSystemMessageID>20190924125935409</sourceSystemMessageID><sourceSystemCreationDateTime>2019-09-24T12:59:35.080</sourceSystemCreationDateTime><resultOfBusinessEventType><name>UpdateParty</name></resultOfBusinessEventType><basedOnMessageForm><name>PartySyncMasterOCV</name><version>05</version></basedOnMessageForm><emittedBySourceSystemInstance><countryCode>AU</countryCode><name>CAP</name></emittedBySourceSystemInstance><requestingUserDetails><ID>SADMIN</ID></requestingUserDetails><sourceSystemUpdateDateTime>2019-09-24T12:59:35.085663</sourceSystemUpdateDateTime></MessageHeader><Party><partyName><personName><lastName>&quot;ONE1&quot;</lastName><prefixTitle>MR</prefixTitle><salutation>MR</salutation><fullName>&quot;ONE1&apos;</fullName></personName></partyName><taxInformation><taxIDSupplied>0</taxIDSupplied><lastUpdatedDate>2015-09-22T00:00:00</lastUpdatedDate><taxIdentifier><ID>NO TFN</ID></taxIdentifier></taxInformation><contactPoint><contactPreference><allowedPurposes>Advertising</allowedPurposes></contactPreference></contactPoint><partyIdentifier><ID>4025062183</ID><IDType>CIS Secondary ID</IDType><anzSystem><shortName>CAP</shortName></anzSystem></partyIdentifier><partyIdentifier><ID>&quot;ONE11.0.</ID><IDType>CIS Primary ID</IDType><anzSystem><shortName>CAP</shortName></anzSystem></partyIdentifier><partyIdentifier><ID>1</ID><IDType>PartyTieBreak</IDType></partyIdentifier><partyIdentifier><ID>10&quot;ONE11.0.1</ID><IDType>CAP System Identifier</IDType></partyIdentifier><partyRole><customer><establishedDate>2015-09-22T00:00:00</establishedDate><lastUpdatedDate>2015-09-22T00:00:00</lastUpdatedDate><status>01</status><disclosureAllowed>true</disclosureAllowed></customer></partyRole><arrangementRole><arrangement><accountArrangement><bankBranch><branchID>3026</branchID></bankBranch></accountArrangement></arrangement></arrangementRole><eventRole><event><channelPoint><ID>IKW</ID></channelPoint></event></eventRole><originatingAnzSystem><shortName>IKW</shortName></originatingAnzSystem><person><employment><ANZEmployeePosition>false</ANZEmployeePosition></employment><KYCVerificationLevel>VE</KYCVerificationLevel><KYCVerificationStatus>PC</KYCVerificationStatus></person></Party></arcwpd:PartyDetails>";
        String jsonEncodedString = StringEscaper.escapeXMLForJSON(xmlStr);
        XMLParser xmlParser = new XMLParser(jsonEncodedString, "1234");
        String personName = xmlParser.evaluate("/PartyDetails/Party/partyName/personName/fullName/text()", "1234");
        // Assert that the single quote and double quotes in the name attribute
        // were
        // escaped
        assertTrue(personName.contains("'"));
        assertTrue(personName.contains("\""));

    }
}
