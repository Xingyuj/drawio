package com.anz.mdm.ocv.api.downstreamservices.test;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import com.anz.mdm.ocv.api.constants.CAPConstants;
import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.downsteamservices.CapTransformationService;
import com.anz.mdm.ocv.api.dto.CapErrorResponseDTO;
import com.anz.mdm.ocv.api.dto.ErrorReferenceDTO;
import com.anz.mdm.ocv.api.exception.AvailabilityServiceDownException;
import com.anz.mdm.ocv.api.model.CAPParty;
import com.anz.mdm.ocv.api.transform.CapTransformer;
import com.anz.mdm.ocv.api.util.StreetSuffixConfig;
import com.anz.mdm.ocv.api.validator.APIRequest;
import com.anz.mdm.ocv.cap.v1.CapProfile;
import com.anz.mdm.ocv.cap.v1.CapResponse;
import com.anz.mdm.ocv.common.v1.Address;
import com.anz.mdm.ocv.common.v1.CodeDescription;
import com.anz.mdm.ocv.common.v1.Email;
import com.anz.mdm.ocv.common.v1.Identifier;
import com.anz.mdm.ocv.common.v1.Name;
import com.anz.mdm.ocv.common.v1.Phone;
import com.anz.mdm.ocv.common.v1.SourceSystem;
import com.anz.mdm.ocv.party.v1.Party;
import com.anz.mdm.ocv.party.v1.SearchPartyResultWrapper;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
public class CapTransformationServiceTest {

    @InjectMocks
    private CapTransformationService capTransformationService;

    @Mock(name = "CapProfileRestTemplate")
    RestTemplate restTemplate;

    final String uri = "http://mockserver/capprofile";

    @Captor
    private ArgumentCaptor<HttpEntity<CapProfile>> captor;

    private Party ocvParty = new Party();

    private SearchPartyResultWrapper resultwrapper = new SearchPartyResultWrapper();
    private Party certParty1 = new Party();
    private Party certParty2 = new Party();

    @Mock
    private CapTransformer capTransformer;

    @Mock
    StreetSuffixConfig streetConfig;

    @Before
    public void setup() {
        Name nameObj = new Name();
        nameObj.setFirstName("First Name");
        nameObj.setMiddleName("Middle Name");
        nameObj.setLastName("Last Name");
        nameObj.setPrefix("Prefix");
        nameObj.setSuffix("Suffix");
        nameObj.setNameUsageType("Legal Name");
        ocvParty.getNames().add(0, nameObj);
        ocvParty.setDateOfBirth("1986-09-07");
        ocvParty.setPartyType("P");
        ocvParty.setGender("M");
        ocvParty.setMaritalStatus("Single");
        Phone mobphoneObj = new Phone();
        mobphoneObj.setPhoneUsageType("Mobile Telephone");
        mobphoneObj.setPhone("+097323232");
        mobphoneObj.setPreferred("Y");
        Phone workphoneObj = new Phone();
        workphoneObj.setPhoneUsageType("Work Telephone");
        workphoneObj.setPhone("+097322222");
        workphoneObj.setPreferred("");
        ocvParty.getPhones().add(mobphoneObj);
        ocvParty.getPhones().add(workphoneObj);
        Address addObj = new Address();
        addObj.setBuildingName("Emerald House");
        addObj.setResidenceNumber("Level 4");
        addObj.setStreetNumber("833");
        addObj.setStreetName("Collins");
        addObj.setStreetSuffix("Street");
        addObj.setPostDirectional("Left");
        ocvParty.getAddresses().add(addObj);
        Email emailObj = new Email();
        emailObj.setEmailUsageType("Email");
        emailObj.setEmail("test@anz.com");
        ocvParty.getEmails().add(emailObj);
        ocvParty.setEmployeeIndicator("Y");
        ocvParty.setEmployerName("ANZ");
        CodeDescription occCode = new CodeDescription();
        occCode.setCode("0065");
        ocvParty.setOccupation(occCode);
        ocvParty.setStatus("Active");
        Identifier id = new Identifier();
        id.setIdentifierUsageType("Driving License");
        id.setIdentifier("133577");
        Identifier id1 = new Identifier();
        id1.setIdentifierUsageType("One Customer ID");
        id1.setIdentifier("1000174658");
        List<Identifier> idList = new ArrayList<Identifier>();
        idList.add(id);
        idList.add(id1);
        ocvParty.getIdentifiers().addAll(idList);
        SourceSystem src = new SourceSystem();
        src.setSourceSystemName("FENERGOANZX");
        src.setSourceSystemId("2377577");
        ocvParty.getSourceSystems().add(src);
        capTransformationService.setUri(uri);
        resultwrapper.setTotalCount("2");
        SourceSystem src1 = new SourceSystem();
        src1.setSourceSystemName("CAP-CIS");
        src1.setSourceSystemId("2377577");
        certParty1.getSourceSystems().add(src1);
        certParty1.setPartyType("P");
        certParty2.setPartyType("P");
        certParty1.setPartyId("12345");
        certParty2.setPartyId("12346");
        resultwrapper.getCertifiedResults().add(certParty1);
        resultwrapper.getCertifiedResults().add(certParty2);

        streetConfig = new StreetSuffixConfig();
        streetConfig = spy(streetConfig);

        MockitoAnnotations.initMocks(this);
        Mockito.when(streetConfig.getPropertyValue("street")).thenReturn("ST");
        Mockito.when(streetConfig.getPropertyValue("street highway")).thenReturn("sthwy");
    }

    @Test
    public void testSuccess() throws Exception {

        final APIRequest<Party> apiRequest = new APIRequest<>(prepareRequestHeaders(), new HashMap<String, String>(),
                ocvParty);

        ResponseEntity<CapResponse> response = new ResponseEntity<>(getParameterisedBody(), HttpStatus.OK);

        when(restTemplate.exchange(any(String.class), any(), any(HttpEntity.class), any(Class.class)))
                .thenReturn(response);
        when(capTransformer.transformAPIRequest(apiRequest, streetConfig)).thenReturn(new CapProfile());
        final CAPParty capParty = capTransformationService.createCapProfile(apiRequest, apiRequest, "12345");
        verify(restTemplate).exchange(any(String.class), any(), captor.capture(), any(Class.class));

        final HttpEntity<CapProfile> request = captor.getValue();

        assertEquals(request.getHeaders().get(OCVConstants.TRACE_ID_HEADER).get(0), "12345");
        assertEquals(request.getHeaders().get(OCVConstants.CONTENT_TYPE).get(0), MediaType.APPLICATION_JSON_VALUE);
        assertEquals(request.getHeaders().get(OCVConstants.ACCEPT_HEADER).get(0), MediaType.APPLICATION_JSON_VALUE);

    }

    @Test
    public void testFailure() throws Exception {

        final APIRequest<Party> apiRequest = new APIRequest<>(prepareRequestHeaders(), new HashMap<String, String>(),
                ocvParty);

        ResponseEntity<Object> response = new ResponseEntity<>(getErrorResponseBody(), HttpStatus.BAD_REQUEST);

        when(restTemplate.exchange(any(String.class), any(), any(HttpEntity.class), any(Class.class)))
                .thenReturn(response);
        when(capTransformer.transformAPIRequest(apiRequest, streetConfig)).thenReturn(new CapProfile());

        try {
            final CAPParty capParty = capTransformationService.createCapProfile(apiRequest, apiRequest, "12345");
            verify(restTemplate).exchange(any(String.class), any(), captor.capture(), any(Class.class));
        } catch (AvailabilityServiceDownException e) {
            assertEquals(e.getMessage(), OCVConstants.CAP_SERVICE_UNAVAILABLE);
            assertEquals(e.getErrorCode(), OCVConstants.CAP_UNAVAILABLE_ERROR_CODE);
        }

    }

    private CapResponse getParameterisedBody() throws JsonParseException, JsonMappingException, IOException {

        final String jsonString = "{\r\n" + "\"customerID\" : \"4029093809\"\r\n" + "}";
        final CapResponse capResponse = new ObjectMapper().readValue(jsonString, CapResponse.class);
        return capResponse;
    }

    private Map<String, String> prepareRequestHeaders() {
        final Map<String, String> headers = new HashMap<String, String>();
        headers.put(OCVConstants.ACCEPT_HEADER, "application/json");
        headers.put(OCVConstants.TRACE_ID_HEADER, "12345");
        headers.put(OCVConstants.AUTHORIZATION_HEADER, "5237vxhsfdfyif");
        headers.put(CAPConstants.CAP_X_IDEMPOTENCY_KEY, "5237vxhsfdfyif");
        return headers;
    }

    @Test
    public void testGetRetrieveRequest() throws IllegalAccessException, InvocationTargetException {
        final APIRequest<Party> apiRequest = new APIRequest<>(prepareRequestHeaders(), new HashMap<String, String>(),
                ocvParty);
        APIRequest<Party> validatedApiRequest = capTransformationService.getRetrieveRequest(apiRequest);
        assertEquals(validatedApiRequest.getRequestBody().getIdentifiers().get(0).getIdentifier(), "1000174658");
    }

    @Test
    public void testGetIdMapRequest() {
        Map<String, Party> idMap = capTransformationService.getIdMap(resultwrapper);
        assertEquals(idMap.get(OCVConstants.FENERGO_SOURCE).getPartyId(), "12346");
    }

    @Test
    public void givenInvalidUUID_whenGetOrGenerateUUIDV4_thenReturnGeneratedUUID() {
        final String uuidInput = "5237vxhsfdfyif";
        Map<String, String> headers = new HashMap<String, String>();
        headers.put(OCVConstants.IDEMPOTENCY_KEY, uuidInput);
        final APIRequest<Party> apiRequest = new APIRequest<>(headers, new HashMap<String, String>(), ocvParty);
        String uuidGenerated = capTransformationService.getOrGenerateUUIDV4(apiRequest);
        assertNotEquals(uuidGenerated, uuidInput);
        UUID uuid = UUID.fromString(uuidGenerated);
        assertEquals(uuid.version(), 4);
    }

    @Test
    public void givenValidUUID_whenGetOrGenerateUUIDV4_thenReturnOriginalUUID() {
        final String uuidInput = "40d17b80-6ea4-46fd-95c5-df3ac2288e00";
        final Map<String, String> headers = new HashMap<String, String>();
        headers.put(OCVConstants.IDEMPOTENCY_KEY, uuidInput);
        final APIRequest<Party> apiRequest = new APIRequest<>(headers, new HashMap<String, String>(), ocvParty);
        assertEquals(capTransformationService.getOrGenerateUUIDV4(apiRequest), uuidInput);
    }

    @Test
    public void givenInvalidDatetime_whenGetOrGenerateInstantNow_thenReturnGenerateInstantNow() {
        final String datetime = "2022-07-15";
        String dateTimeGenerated = capTransformationService.getOrGenerateInstantNow(datetime);
        assertNotEquals(dateTimeGenerated, datetime);
        LocalDateTime capFormatDatetimeGenerated = capTransformationService.getLocalDateTimeIfValid(
                DateTimeFormatter.ofPattern(CapTransformationService.CAP_DATETIME_FORMATTER), dateTimeGenerated);
        assertNotNull(capFormatDatetimeGenerated);
    }

    @Test
    public void givenValidOCVFormateDatetime_whenGetOrGenerateInstantNow_thenReturnCAPFormateDatetime() {
        final String datetime = "2022-07-15 12:00:10.01";
        final String expectedDatetime = "2022-07-15T12:00:10Z";
        String dateTimeGenerated = capTransformationService.getOrGenerateInstantNow(datetime);
        assertEquals(dateTimeGenerated, expectedDatetime);
    }

    @Test
    public void givenValidCAPFormateDatetime_whenGetOrGenerateInstantNow_thenReturnOriginalDatetime() {
        final String datetime = "2022-07-15T12:00:10Z";
        final String expectedDatetime = "2022-07-15T12:00:10Z";
        String dateTimeGenerated = capTransformationService.getOrGenerateInstantNow(datetime);
        assertEquals(dateTimeGenerated, expectedDatetime);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void givenSuccessResponse_whenCreateProfileInCapV2_thenReturnCAPPartyWithCapCisId() throws Exception {
        final String capcisId = "sample-cis-id-4029093809";
        final String jsonString = "{\"capcisId\":\"" + capcisId + "\",\"customerId\":\"sample-cust-id-9093809\"}";
        final com.anz.mdm.ocv.cap.v2.CapResponse capResponse = new ObjectMapper().readValue(jsonString,
                com.anz.mdm.ocv.cap.v2.CapResponse.class);

        ResponseEntity<com.anz.mdm.ocv.cap.v2.CapResponse> response = new ResponseEntity<>(capResponse, HttpStatus.OK);
        doReturn(response).when(restTemplate).exchange(any(String.class), any(), any(HttpEntity.class),
                any(Class.class));
        APIRequest<Party> request = new APIRequest<>(prepareRequestHeaders(), new HashMap<String, String>(), ocvParty);
        CAPParty party = capTransformationService.createProfileInCapV2(new com.anz.mdm.ocv.cap.v2.CapProfile(), request,
                request);
        APIRequest<Party> partyRequest = party.getPartyApiReq();
        assertNotNull(partyRequest.getRequestBody().getSourceSystems());
        assertEquals(partyRequest.getRequestBody().getSourceSystems().size(), 1);
        SourceSystem sourceSys = partyRequest.getRequestBody().getSourceSystems().get(0);
        assertEquals(OCVConstants.CAP_CIS_SOURCE, sourceSys.getSourceSystemName());
        assertEquals(capcisId, sourceSys.getSourceSystemId());
    }

    private Object getErrorResponseBody() throws JsonParseException, JsonMappingException, IOException {

        final String jsonString = "{\r\n" + "   \"httpCode\": \"400\",\r\n" + "   \"httpMessage\": \"\",\r\n"
                + "   \"errors\": [   {\r\n" + "      \"code\": \"53\",\r\n" + "      \"type\": \"ProviderError\",\r\n"
                + "      \"message\": \"Non zero RESULT_CODE '999' from provider\",\r\n"
                + "      \"description\": \"NOTIFICATION_MSG: TRANSACTION UNAVAILABLE (CONDITION_CODE: ${JSON.stringify(condCode)})\",\r\n"
                + "      \"severity\": \"Fatal\",\r\n" + "      \"location\": \"CAP\"\r\n" + "   }]\r\n" + "}";
        final CapErrorResponseDTO capResponse = new ObjectMapper().readValue(jsonString, new ErrorReferenceDTO());
        return capResponse;
    }
}
