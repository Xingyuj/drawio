package com.anz.mdm.ocv.api.validator.test;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.spy;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.interceptor.UAMInterceptor;
import com.anz.mdm.ocv.api.validator.APIRequest;
import com.anz.mdm.ocv.api.validator.AbstractValidator;
import com.anz.mdm.ocv.api.validator.MaintainPartyValidator;
import com.anz.mdm.ocv.party.v1.Party;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class MaintainPartyValidatorTest {
    AbstractValidator abstractValidator = new MaintainPartyValidator();
    
    private UAMInterceptor uamInterceptor;

    @Test
    public void validateRequestTest() throws JsonParseException, JsonMappingException, IOException {
        Map<String, String> headers = prepareRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();
        // queryParameters.put(OCVConstants.SEARCH_TYPE_PARAMETER,
        // OCVConstants.CERTIFIED_SEARCH_TYPE);
        Party party = setRequestBody();
        APIRequest<Party> apiRequest = new APIRequest(headers, queryParameters, party);
        
        // OCT-23700 - for validating JWT Token Scope - Start
        uamInterceptor = new UAMInterceptor(null);
        uamInterceptor = spy(uamInterceptor);
        ((MaintainPartyValidator) abstractValidator).setUamInterceptor(uamInterceptor);
        //OCT-23700 - for validating JWT Token Scope - End
        
        assertTrue(abstractValidator.validateRequest(apiRequest).isValid());
    }

    private Party setRequestBody() throws JsonParseException, JsonMappingException, IOException {

        String jsonString = "{\r\n" + "\"partyType\" : \"Non individual\",\r\n" + "\"identifiers\" : [{\r\n"
                + "\"identifierUsageType\" : \"ABN\",\r\n" + "\"identifier\" : \"874935804\"\r\n" + "},{\r\n"
                + "\"identifierUsageType\" : \"ACN\",\r\n" + "\"identifier\" : \"87493580478\"\r\n" + "}],\r\n"
                + "\"names\":[{\"name\":\"ANZ\"}\r\n" + "    ]\r\n" + "}";
        Party party = new ObjectMapper().readValue(jsonString, Party.class);
        return party;
    }

    private Map<String, String> prepareRequestHeaders() {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put(OCVConstants.ACCEPT_HEADER, "application/json");
        headers.put(OCVConstants.TRACE_ID_HEADER, "abc123");
        headers.put(OCVConstants.AUTHORIZATION_HEADER, "5237vxhsfdfyif");
        headers.put(OCVConstants.CHANNEL, "CAP");
        headers.put(OCVConstants.USER_ID_HEADER, "57346846");
        headers.put(OCVConstants.REQUEST_TIMESTAMP, "2018-10-09 10:02:00.0");
        headers.put(OCVConstants.APPLICATION, "OCV");
        return headers;
    }

}