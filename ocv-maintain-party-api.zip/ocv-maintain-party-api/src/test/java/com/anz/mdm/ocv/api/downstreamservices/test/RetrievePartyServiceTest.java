package com.anz.mdm.ocv.api.downstreamservices.test;

import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.downsteamservices.RetrievePartyService;
import com.anz.mdm.ocv.api.exception.BackendServiceException;
import com.anz.mdm.ocv.api.exception.BadRequestException;
import com.anz.mdm.ocv.api.exception.DuplicateRecordException;
import com.anz.mdm.ocv.api.exception.Error;
import com.anz.mdm.ocv.api.exception.ErrorResponse;
import com.anz.mdm.ocv.api.exception.RecordNotFoundException;
import com.anz.mdm.ocv.api.exception.ServiceUnavailableException;
import com.anz.mdm.ocv.api.validator.APIRequest;
import com.anz.mdm.ocv.api.validator.SearchResponseFilter;
import com.anz.mdm.ocv.party.v1.Party;
import com.anz.mdm.ocv.party.v1.SearchPartyResultWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@RunWith(SpringRunner.class)
public class RetrievePartyServiceTest {

    @InjectMocks
    RetrievePartyService retrievePartyService;

    @Mock
    SearchResponseFilter filter;

    @Mock(name = "ApiRestTemplate")
    RestTemplate restTemplate;

    @Test
    public void getResponse200Test() throws IOException {
        retrievePartyService = spy(retrievePartyService);
        filter = spy(filter);
        String traceId = "89803-fhdgf-53468";
        String requestString = "{ \"partyType\" : \"P\",\r\n" + "        \"sourceSystems\": [\r\n"
                + "               {\r\n" + "               \"sourceSystemId\": \"4012977562\",               \r\n"
                + "               \"sourceSystemName\": \"CAP-CIS\"         \r\n" + "               }\r\n"
                + "        ]\r\n" + "        \r\n" + "} ";

        String response = "{ \"partyType\": \"P\", \"source\": \"CAP-CIS\", \"sourceEstablishedDate\": \"2005-11-10\", \"sourceClosedDate\": \"2015-11-10\", \"status\": \"Active\", \"dateOfBirth\": \"1969-11-06\", \"gender\": \"N\", \"maritalStatus\": \"Married/De Facto\", \"deceasedDate\": \"2000-01-01\", \"bankruptDate\": \"2019-03-15\", \"employeeIndicator\": \"Y\", \"employerName\": \"ANZ\", \"kycDetails\": { \"status\": \"CO\", \"verificationLevel\": \"NM\" }, \"occupation\": { \"code\": \"111200\" }, \"addresses\": [ { \"addressUsageType\": \"Primary Residential\", \"addressLineOne\": \"(LOT) YORK RD\", \"city\": \"POPANYINNING\", \"postalCode\": \"6309\", \"state\": \"SA\", \"country\": \"AUS\", \"region\": \"\", \"deliveryId\": \"80941156\", \"source\": \"CAP-CIS\", \"startDate\": \"1901-01-01\", \"endDate\": \"9999-12-31\" }, { \"addressUsageType\": \"Primary Mailing\", \"addressLineOne\": \"PO BOX 147\", \"city\": \"CAMBERWELL\", \"postalCode\": \"3124\", \"state\": \"VIC\", \"country\": \"DZA\", \"region\": \"VIC\", \"deliveryId\": \"69775498\", \"source\": \"CAP-CIS\", \"startDate\": \"2014-05-29\", \"endDate\": \"9999-12-31\" } ], \"phones\": [ { \"phoneUsageType\": \"Mobile Telephone\", \"phone\": \"+610422591580\", \"preferred\": \"\", \"source\": \"CAP-CIS\", \"sequence\": \"3\", \"startDate\": \"1901-01-01\", \"endDate\": \"9999-12-31\" }, { \"phoneUsageType\": \"Primary Home Telephone\", \"phone\": \"+61386549523\", \"preferred\": \"Y\", \"source\": \"CAP-CIS\", \"sequence\": \"1\", \"startDate\": \"1901-01-01\", \"endDate\": \"9999-12-31\" }, { \"phoneUsageType\": \"Secondary Home Telephone\", \"phone\": \"+613865675234\", \"preferred\": \"Y\", \"source\": \"CAP-CIS\", \"sequence\": \"2\", \"startDate\": \"1901-01-01\", \"endDate\": \"2019-12-31\" } ], \"emails\": [ { \"emailUsageType\": \"Email\", \"email\": \"damian@trecose.com\", \"preferred\": \"\", \"source\": \"CAP-CIS\", \"startDate\": \"1901-01-01\", \"endDate\": \"\" } ], \"identifiers\": [ { \"identifierUsageType\": \"Drivers License\", \"identifier\": \"5642341\", \"identificationIssueLocation\": \"VIC\", \"source\": \"CAP-CIS\", \"sequence\": \"1\", \"startDate\": \"1901-01-01\", \"expiryDate\": \"9999-12-31\" } ], \"preferences\": [ { \"preferenceType\": \"Disclosure Indicator\", \"preferenceValue\": \"N\", \"preferenceReason\": \"Not Allowed\", \"source\": \"CAP-CIS\", \"startDate\": \"1901-01-01\", \"endDate\": \"\" }, { \"preferenceType\": \"Primary Preferred Contact Day and Time\", \"preferenceValue\": \"000000000000NNNNNNN\", \"preferenceReason\": \"Not Interested\", \"source\": \"CAP-CIS\", \"startDate\": \"2018-08-31\", \"endDate\": \"9999-12-31\" }, { \"preferenceType\": \"Secondary Preferred Contact Day and Time\", \"preferenceValue\": \"000000000000YYYYYYY\", \"preferenceReason\": \"Interested\", \"source\": \"CAP-CIS\", \"startDate\": \"2018-08-31\", \"endDate\": \"9999-12-31\" }, { \"preferenceType\": \"Advertising Indicator\", \"preferenceValue\": \"Y\", \"preferenceReason\": \"Allowed\", \"source\": \"CAP-CIS\", \"startDate\": \"9999-12-01\", \"endDate\": \"9999-12-31\" } ], \"bankingServices\": [ { \"key\": \"DNC\", \"value\": \"Y\" }, { \"key\": \"NVE\", \"value\": \"Y\" } ], \"names\": [ { \"firstName\": \"Abhishek\", \"lastName\": \"DAMIAN M PHELAN\" }, { \"nameUsageType\": \"Mailing Name\", \"lastName\": \"MR D PHELAN\", \"startDate\": \"1901-01-01\", \"source\": \"CAP-CIS\" } ], \"sourceSystems\": [ { \"sourceSystemId\": \"4012977562\", \"sourceSystemName\": \"CAP-CIS\" } ] }";
        Party requestparty = new ObjectMapper().readValue(requestString, Party.class);
        Party responseParty = new ObjectMapper().readValue(response, Party.class);
        ArrayList<Party> parties = new ArrayList<Party>();
        parties.add(responseParty);
        Map<String, String> headers = new HashMap<String, String>();
        Map<String, String> queryParameters = new HashMap<String, String>();
        headers.put("x-b3-traceid", traceId);
        headers.put("channel", "MMLO");
        APIRequest<Party> request = new APIRequest<Party>(headers, queryParameters, requestparty);
        ResponseEntity<Object> apiresponse = new ResponseEntity<Object>(parties, HttpStatus.OK);
        doReturn(apiresponse).when(retrievePartyService).invokeDownStreamService(request, traceId);

        assertTrue(retrievePartyService.getResponse(request, traceId) instanceof SearchPartyResultWrapper);

    }

    @Test(expected = RecordNotFoundException.class)
    public void getResponse404Test() throws IOException {
        retrievePartyService = spy(retrievePartyService);
        filter = spy(filter);
        String traceId = "89803-fhdgf-53468";
        String requestString = "{ \"partyType\" : \"P\",\r\n" + "        \"sourceSystems\": [\r\n"
                + "               {\r\n" + "               \"sourceSystemId\": \"4012977562\",               \r\n"
                + "               \"sourceSystemName\": \"CAP-CIS\"         \r\n" + "               }\r\n"
                + "        ]\r\n" + "        \r\n" + "} ";

        Party requestparty = new ObjectMapper().readValue(requestString, Party.class);
        Map<String, String> headers = new HashMap<String, String>();
        Map<String, String> queryParameters = new HashMap<String, String>();
        headers.put("x-b3-traceid", traceId);
        headers.put("channel", "MMLO");
        APIRequest<Party> request = new APIRequest<Party>(headers, queryParameters, requestparty);
        Error error = new Error();
        error.setStatusCode("404");
        error.setStatusMessage("Record Not Found");
        ArrayList<Error> errors = new ArrayList<Error>();
        errors.add(error);
        ErrorResponse response = new ErrorResponse();
        response.setErrors(errors);
        ResponseEntity<Object> apiresponse = new ResponseEntity<Object>(response, HttpStatus.NOT_FOUND);
        doReturn(apiresponse).when(retrievePartyService).invokeDownStreamService(request, traceId);

        assertTrue(retrievePartyService.getResponse(request, traceId) instanceof SearchPartyResultWrapper);

    }

    @Test(expected = BadRequestException.class)
    public void getResponse400Test() throws IOException {
        retrievePartyService = spy(retrievePartyService);
        filter = spy(filter);
        String traceId = "89803-fhdgf-53468";
        String requestString = "{ \"partyType\" : \"P\",\r\n" + "        \"sourceSystems\": [\r\n"
                + "               {\r\n" + "               \"sourceSystemId\": \"4012977562\",               \r\n"
                + "               \"sourceSystemName\": \"CAP-CIS\"         \r\n" + "               }\r\n"
                + "        ]\r\n" + "        \r\n" + "} ";

        Party requestparty = new ObjectMapper().readValue(requestString, Party.class);
        Map<String, String> headers = new HashMap<String, String>();
        Map<String, String> queryParameters = new HashMap<String, String>();
        headers.put("x-b3-traceid", traceId);
        headers.put("channel", "MMLO");
        APIRequest<Party> request = new APIRequest<Party>(headers, queryParameters, requestparty);
        Error error = new Error();
        error.setStatusCode("40011");
        error.setStatusMessage("bad request");
        ArrayList<Error> errors = new ArrayList<Error>();
        errors.add(error);
        ErrorResponse response = new ErrorResponse();
        response.setErrors(errors);

        ResponseEntity<Object> apiresponse = new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
        doReturn(apiresponse).when(retrievePartyService).invokeDownStreamService(request, traceId);

        retrievePartyService.getResponse(request, traceId);

    }

    @Test(expected = ServiceUnavailableException.class)
    public void test_for_500_error() throws IOException {
        retrievePartyService = spy(retrievePartyService);
        filter = spy(filter);
        String traceId = "89803-fhdgf-53468";
        String requestString = "{ \"partyType\" : \"P\",\r\n" + "        \"sourceSystems\": [\r\n"
                + "               {\r\n" + "               \"sourceSystemId\": \"4012977562\",               \r\n"
                + "               \"sourceSystemName\": \"CAP-CIS\"         \r\n" + "               }\r\n"
                + "        ]\r\n" + "        \r\n" + "} ";

        Party requestparty = new ObjectMapper().readValue(requestString, Party.class);
        Map<String, String> headers = new HashMap<String, String>();
        Map<String, String> queryParameters = new HashMap<String, String>();
        headers.put("x-b3-traceid", traceId);
        headers.put("channel", "MMLO");
        APIRequest<Party> request = new APIRequest<Party>(headers, queryParameters, requestparty);
        Error error = new Error();
        error.setStatusCode("5003");
        error.setStatusMessage("Service Unavailable");
        ArrayList<Error> errors = new ArrayList<Error>();
        errors.add(error);
        ErrorResponse response = new ErrorResponse();
        response.setErrors(errors);

        ResponseEntity<Object> apiresponse = new ResponseEntity<Object>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        doReturn(apiresponse).when(retrievePartyService).invokeDownStreamService(request, traceId);

        retrievePartyService.getResponse(request, traceId);

    }

    @Test(expected = ServiceUnavailableException.class)
    public void test_for_500_error_with_message() throws IOException {
        retrievePartyService = spy(retrievePartyService);
        filter = spy(filter);
        String traceId = "89803-fhdgf-53468";
        String requestString = "{ \"partyType\" : \"P\",\r\n" + "        \"sourceSystems\": [\r\n"
                + "               {\r\n" + "               \"sourceSystemId\": \"4012977562\",               \r\n"
                + "               \"sourceSystemName\": \"CAP-CIS\"         \r\n" + "               }\r\n"
                + "        ]\r\n" + "        \r\n" + "} ";

        Party requestparty = new ObjectMapper().readValue(requestString, Party.class);
        Map<String, String> headers = new HashMap<String, String>();
        Map<String, String> queryParameters = new HashMap<String, String>();
        headers.put("x-b3-traceid", traceId);
        headers.put("channel", "MMLO");
        APIRequest<Party> request = new APIRequest<Party>(headers, queryParameters, requestparty);
        Error error = new Error();
        error.setStatusCode("5003");
        error.setStatusMessage("Service Unavailable");
        ArrayList<Error> errors = new ArrayList<Error>();
        errors.add(error);
        ErrorResponse response = new ErrorResponse();
        response.setErrors(errors);

        ResponseEntity<Object> apiresponse = new ResponseEntity<Object>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        doReturn(apiresponse).when(retrievePartyService).invokeDownStreamService(request, traceId);

        retrievePartyService.getResponse(request, traceId);

    }

    @Test
    public void test_for_invoking_downstream() throws JsonProcessingException {
        retrievePartyService = spy(retrievePartyService);
        ReflectionTestUtils.setField(retrievePartyService, "goodStatuses",
                "OK,NOT_FOUND,BAD_REQUEST,INTERNAL_SERVER_ERROR");
        ReflectionTestUtils.setField(retrievePartyService, "url", "http://mockserver.test/parties/retrieve");
        filter = spy(filter);
        String traceId = "89803-fhdgf-53468";
        String requestString = "{ \"partyType\" : \"P\",\r\n" + "        \"sourceSystems\": [\r\n"
                + "               {\r\n" + "               \"sourceSystemId\": \"4012977562\",               \r\n"
                + "               \"sourceSystemName\": \"CAP-CIS\"         \r\n" + "               }\r\n"
                + "        ]\r\n" + "        \r\n" + "} ";

        String response = "{ \"partyType\": \"P\", \"source\": \"CAP-CIS\", \"sourceEstablishedDate\": \"2005-11-10\", \"sourceClosedDate\": \"2015-11-10\", \"status\": \"Active\", \"dateOfBirth\": \"1969-11-06\", \"gender\": \"N\", \"maritalStatus\": \"Married/De Facto\", \"deceasedDate\": \"2000-01-01\", \"bankruptDate\": \"2019-03-15\", \"employeeIndicator\": \"Y\", \"employerName\": \"ANZ\", \"kycDetails\": { \"status\": \"CO\", \"verificationLevel\": \"NM\" }, \"occupation\": { \"code\": \"111200\" }, \"addresses\": [ { \"addressUsageType\": \"Primary Residential\", \"addressLineOne\": \"(LOT) YORK RD\", \"city\": \"POPANYINNING\", \"postalCode\": \"6309\", \"state\": \"SA\", \"country\": \"AUS\", \"region\": \"\", \"deliveryId\": \"80941156\", \"source\": \"CAP-CIS\", \"startDate\": \"1901-01-01\", \"endDate\": \"9999-12-31\" }, { \"addressUsageType\": \"Primary Mailing\", \"addressLineOne\": \"PO BOX 147\", \"city\": \"CAMBERWELL\", \"postalCode\": \"3124\", \"state\": \"VIC\", \"country\": \"DZA\", \"region\": \"VIC\", \"deliveryId\": \"69775498\", \"source\": \"CAP-CIS\", \"startDate\": \"2014-05-29\", \"endDate\": \"9999-12-31\" } ], \"phones\": [ { \"phoneUsageType\": \"Mobile Telephone\", \"phone\": \"+610422591580\", \"preferred\": \"\", \"source\": \"CAP-CIS\", \"sequence\": \"3\", \"startDate\": \"1901-01-01\", \"endDate\": \"9999-12-31\" }, { \"phoneUsageType\": \"Primary Home Telephone\", \"phone\": \"+61386549523\", \"preferred\": \"Y\", \"source\": \"CAP-CIS\", \"sequence\": \"1\", \"startDate\": \"1901-01-01\", \"endDate\": \"9999-12-31\" }, { \"phoneUsageType\": \"Secondary Home Telephone\", \"phone\": \"+613865675234\", \"preferred\": \"Y\", \"source\": \"CAP-CIS\", \"sequence\": \"2\", \"startDate\": \"1901-01-01\", \"endDate\": \"2019-12-31\" } ], \"emails\": [ { \"emailUsageType\": \"Email\", \"email\": \"damian@trecose.com\", \"preferred\": \"\", \"source\": \"CAP-CIS\", \"startDate\": \"1901-01-01\", \"endDate\": \"\" } ], \"identifiers\": [ { \"identifierUsageType\": \"Drivers License\", \"identifier\": \"5642341\", \"identificationIssueLocation\": \"VIC\", \"source\": \"CAP-CIS\", \"sequence\": \"1\", \"startDate\": \"1901-01-01\", \"expiryDate\": \"9999-12-31\" } ], \"preferences\": [ { \"preferenceType\": \"Disclosure Indicator\", \"preferenceValue\": \"N\", \"preferenceReason\": \"Not Allowed\", \"source\": \"CAP-CIS\", \"startDate\": \"1901-01-01\", \"endDate\": \"\" }, { \"preferenceType\": \"Primary Preferred Contact Day and Time\", \"preferenceValue\": \"000000000000NNNNNNN\", \"preferenceReason\": \"Not Interested\", \"source\": \"CAP-CIS\", \"startDate\": \"2018-08-31\", \"endDate\": \"9999-12-31\" }, { \"preferenceType\": \"Secondary Preferred Contact Day and Time\", \"preferenceValue\": \"000000000000YYYYYYY\", \"preferenceReason\": \"Interested\", \"source\": \"CAP-CIS\", \"startDate\": \"2018-08-31\", \"endDate\": \"9999-12-31\" }, { \"preferenceType\": \"Advertising Indicator\", \"preferenceValue\": \"Y\", \"preferenceReason\": \"Allowed\", \"source\": \"CAP-CIS\", \"startDate\": \"9999-12-01\", \"endDate\": \"9999-12-31\" } ], \"bankingServices\": [ { \"key\": \"DNC\", \"value\": \"Y\" }, { \"key\": \"NVE\", \"value\": \"Y\" } ], \"names\": [ { \"firstName\": \"Abhishek\", \"lastName\": \"DAMIAN M PHELAN\" }, { \"nameUsageType\": \"Mailing Name\", \"lastName\": \"MR D PHELAN\", \"startDate\": \"1901-01-01\", \"source\": \"CAP-CIS\" } ], \"sourceSystems\": [ { \"sourceSystemId\": \"4012977562\", \"sourceSystemName\": \"CAP-CIS\" } ] }";
        Party requestparty = new ObjectMapper().readValue(requestString, Party.class);
        Party responseParty = new ObjectMapper().readValue(response, Party.class);
        ArrayList<Party> parties = new ArrayList<Party>();
        parties.add(responseParty);
        Map<String, String> headers = new HashMap<String, String>();
        Map<String, String> queryParameters = new HashMap<String, String>();
        headers.put("x-b3-traceid", traceId);
        headers.put("channel", "MMLO");
        APIRequest<Party> request = new APIRequest<Party>(headers, queryParameters, requestparty);
        ResponseEntity<Object> apiresponse = new ResponseEntity<Object>(parties, HttpStatus.OK);
        when(restTemplate.exchange(any(String.class), any(), any(HttpEntity.class), any(Class.class)))
                .thenReturn(apiresponse);
        ResponseEntity<Object> actualResponse = retrievePartyService.invokeDownStreamService(request, "traceId");
        assertEquals(200, actualResponse.getStatusCodeValue());
    }
    
    @Test(expected = DuplicateRecordException.class)
    public void testDuplicateCustomerProfile() throws IOException {
        retrievePartyService = spy(retrievePartyService);
        filter = spy(filter);
        String traceId = "89803-fhdgf-53468";
        String requestString = "{ \"partyType\" : \"P\",\r\n" + "        \"identifiers\": [\r\n"
                + "               {\r\n" + "               \"identifier\": \"4012977562\",               \r\n"
                + "               \"identifierUsageType\": \"One Customer ID\"         \r\n" + "               }\r\n"
                + "        ]\r\n" + "        \r\n" + "} ";

        Party requestparty = new ObjectMapper().readValue(requestString, Party.class);
        Map<String, String> headers = new HashMap<String, String>();
        Map<String, String> queryParameters = new HashMap<String, String>();
        headers.put("x-b3-traceid", traceId);
        headers.put("channel", "FENERGOANZX");
        headers.put("requestMode", "updateCustomerKYC");
        APIRequest<Party> request = new APIRequest<Party>(headers, queryParameters, requestparty);
        Error error = new Error();
        error.setStatusCode(OCVConstants.DUPLICATE_RECORD_FOUND_ERROR);
        error.setMoreInformation(OCVConstants.KYC_COMPLETED_MESSAGE);
        ArrayList<Error> errors = new ArrayList<Error>();
        errors.add(error);
        ErrorResponse response = new ErrorResponse();
        response.setErrors(errors);

        ResponseEntity<Object> apiresponse = new ResponseEntity<Object>(response, HttpStatus.CONFLICT);
        doReturn(apiresponse).when(retrievePartyService).invokeDownStreamService(request, traceId);

        retrievePartyService.getResponse(request, traceId);

    }
    
    @Test
    public void testOCVIDUnderReviewCustomerProfile() throws IOException {
        retrievePartyService = spy(retrievePartyService);
        filter = spy(filter);
        String traceId = "89803-fhdgf-53468";
        String requestString = "{ \"partyType\" : \"P\",\r\n" + "        \"identifiers\": [\r\n"
                + "               {\r\n" + "               \"identifier\": \"4012977562\",               \r\n"
                + "               \"identifierUsageType\": \"One Customer ID\"         \r\n" + "               }\r\n"
                + "        ]\r\n" + "        \r\n" + "} ";

        Party requestparty = new ObjectMapper().readValue(requestString, Party.class);
        Map<String, String> headers = new HashMap<String, String>();
        Map<String, String> queryParameters = new HashMap<String, String>();
        headers.put("x-b3-traceid", traceId);
        headers.put("channel", "FENERGOANZX");
        headers.put("requestMode", "updateCustomerKYC");
        APIRequest<Party> request = new APIRequest<Party>(headers, queryParameters, requestparty);
        Error error = new Error();
        error.setStatusCode(OCVConstants.OCV_ID_UNDER_REVEIEW);
        error.setMoreInformation("One of more parties in the OCV Id group is under review");
        ArrayList<Error> errors = new ArrayList<Error>();
        errors.add(error);
        ErrorResponse response = new ErrorResponse();
        response.setErrors(errors);

        ResponseEntity<Object> apiresponse = new ResponseEntity<Object>(response, HttpStatus.CONFLICT);
        doReturn(apiresponse).when(retrievePartyService).invokeDownStreamService(request, traceId);

        retrievePartyService.getResponse(request, traceId);

    }
    
    @Test(expected = BackendServiceException.class)
    public void testAnyConflictErrorCustomerProfile() throws IOException {
        retrievePartyService = spy(retrievePartyService);
        filter = spy(filter);
        String traceId = "89803-fhdgf-53468";
        String requestString = "{ \"partyType\" : \"P\",\r\n" + "        \"identifiers\": [\r\n"
                + "               {\r\n" + "               \"identifier\": \"4012977562\",               \r\n"
                + "               \"identifierUsageType\": \"One Customer ID\"         \r\n" + "               }\r\n"
                + "        ]\r\n" + "        \r\n" + "} ";

        Party requestparty = new ObjectMapper().readValue(requestString, Party.class);
        Map<String, String> headers = new HashMap<String, String>();
        Map<String, String> queryParameters = new HashMap<String, String>();
        headers.put("x-b3-traceid", traceId);
        headers.put("channel", "FENERGOANZX");
        headers.put("requestMode", "updateCustomerKYC");
        APIRequest<Party> request = new APIRequest<Party>(headers, queryParameters, requestparty);
        Error error = new Error();
        error.setStatusCode(OCVConstants.DUPLICATE_ANZX_CUSTOMER_FOUND_ERROR);
        error.setMoreInformation("One of more parties in the OCV Id group is under review");
        ArrayList<Error> errors = new ArrayList<Error>();
        errors.add(error);
        ErrorResponse response = new ErrorResponse();
        response.setErrors(errors);
        
        ResponseEntity<Object> apiresponse = new ResponseEntity<Object>(response, HttpStatus.CONFLICT);
        doReturn(apiresponse).when(retrievePartyService).invokeDownStreamService(request, traceId);

        retrievePartyService.getResponse(request, traceId);

    }

    @Test
    public void prepareHeaderTest() {
        Map<String, String> RequestHeaders = prepareRequestHeaders();
        Map<String, String> queryparams = new HashMap();
        Party party = new Party();
        APIRequest<Party> request = new APIRequest<Party>(RequestHeaders, queryparams, party);
        HttpHeaders headers = retrievePartyService.prepareHeadersForApi(request, "684932");
        assertTrue(headers.containsKey(OCVConstants.ACCEPT_HEADER));
        assertTrue(headers.containsKey(OCVConstants.TRACE_ID_HEADER));
        assertTrue(headers.containsKey(OCVConstants.AUTHORIZATION_HEADER));
        assertTrue(headers.containsKey(OCVConstants.CHANNEL));
        assertTrue(headers.containsKey(OCVConstants.USER_ID_HEADER));

    }

    private Map<String, String> prepareRequestHeaders() {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put(OCVConstants.ACCEPT_HEADER, "application/json");
        headers.put(OCVConstants.TRACE_ID_HEADER, "abc123");
        headers.put(OCVConstants.AUTHORIZATION_HEADER, "5237vxhsfdfyif");
        headers.put(OCVConstants.CHANNEL, "MMLO");
        headers.put(OCVConstants.USER_ID_HEADER, "ABC User");
        return headers;
    }
}
