package com.anz.mdm.ocv.api.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.Mockito.doReturn;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.downsteamservices.OnboardService;
import com.anz.mdm.ocv.api.dto.APIResponse;
import com.anz.mdm.ocv.api.interceptor.JWTInterceptor;
import com.anz.mdm.ocv.api.util.IdempotencyConfigUtil;
import com.anz.mdm.ocv.api.util.LogRequestModel;
import com.anz.mdm.ocv.api.validator.APIRequest;
import com.anz.mdm.ocv.common.v1.SourceSystem;
import com.anz.mdm.ocv.party.v1.Party;

@RunWith(SpringRunner.class)
public class OnboardControllerTest {

    @InjectMocks
    private OnboardController onboardController;

    @Mock
    private LogRequestModel logAttributes;

    @Mock
    private JWTInterceptor jwtInterceptor;

    @Mock
    private OnboardService onboardService;

    @Mock
    private IdempotencyConfigUtil idempotencyUtil;

    @Test
    public void givenResponseFromIdempotency_whenMaintainPartyV3_thenReturnValid() throws Exception {
        Map<String, String> headers = new HashMap<>();
        Map<String, String> queryParameters = new HashMap<>();
        Party party = new Party();
        String sampleCapCisId = "sample-capCisId-112a86";
        String sampleProfileId = "sample-profile-id-12aa980c21";
        String sampleOcvId = "sample-ocv-id-e123f1a231";

        APIResponse responseCreateProfileInMDM = new APIResponse();
        List<SourceSystem> sourceSystems = new ArrayList<>();
        SourceSystem sourceSystem = new SourceSystem();
        sourceSystem.setSourceSystemId(sampleCapCisId);
        sourceSystem.setSourceSystemName(OCVConstants.CAP_CIS_SOURCE);
        sourceSystems.add(sourceSystem);

        List<String> profiles = new ArrayList<>();
        profiles.add(sampleProfileId);

        responseCreateProfileInMDM.setProfileIds(profiles);
        responseCreateProfileInMDM.setOcvId(sampleOcvId);
        responseCreateProfileInMDM.setSourceSystems(sourceSystems);
        responseCreateProfileInMDM.setResponseFromIdempotency(false);
        APIRequest<Party> validatedRequest = new APIRequest<>(headers, queryParameters, party);

        doReturn(true).when(jwtInterceptor).validateJWT(any());
        doReturn(validatedRequest).when(onboardService).getPartyAPIRequestWithValidatedParty(any(), any(), any(),
                any());
        doReturn(responseCreateProfileInMDM).when(onboardService).createOrUpdateProspectParty(any(), any(), any(),
                anyBoolean());

        ResponseEntity<Object> response = onboardController.maintainPartyV3(headers, queryParameters, party);
        APIResponse output = (APIResponse) response.getBody();

        assert output != null;
        assertEquals(sampleOcvId, output.getOcvId());
        assertNotNull("profiles should not be null", output.getProfileIds());
        assertEquals(sampleProfileId, output.getProfileIds().get(0));
        assertNotNull("SourceSystem should not be null", output.getSourceSystems());
        assertEquals(sampleCapCisId, output.getSourceSystems().get(0).getSourceSystemId());
    }

}