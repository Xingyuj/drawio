//package com.anz.mdm.ocv.api.validator.test;
//
//import static org.junit.Assert.assertEquals;
//import static org.junit.Assert.assertFalse;
//import static org.junit.Assert.assertTrue;
//
//import java.io.IOException;
//import java.util.HashMap;
//import java.util.Map;
//
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.test.context.junit4.SpringRunner;
//
//import com.anz.mdm.ocv.api.constants.OCVConstants;
//import com.anz.mdm.ocv.api.validator.APIRequest;
//import com.anz.mdm.ocv.api.validator.AbstractValidator;
//import com.anz.mdm.ocv.api.validator.SearchPartyValidator;
//import com.anz.mdm.ocv.party.v1.Party;
//import com.fasterxml.jackson.core.JsonParseException;
//import com.fasterxml.jackson.databind.JsonMappingException;
//import com.fasterxml.jackson.databind.ObjectMapper;
//
//@RunWith(SpringRunner.class)
//public class AbstractValidatorTest {
//
//    AbstractValidator abstractValidator = new SearchPartyValidator();
//
//    @Test
//    public void validateRequestTest() throws JsonParseException, JsonMappingException, IOException {
//        Map<String, String> headers = prepareRequestHeaders();
//        Map<String, String> queryParameters = new HashMap<String, String>();
//        queryParameters.put(OCVConstants.SEARCH_TYPE_PARAMETER, OCVConstants.CERTIFIED_SEARCH_TYPE);
//        Party party = setRequestBody();
//        APIRequest<Party> apiRequest = new APIRequest(headers, queryParameters, party);
//        assertTrue(abstractValidator.validateRequest(apiRequest).isValid());
//    }
//
//    @Test
//    public void validateRequestHeaderNoOk() throws JsonParseException, JsonMappingException, IOException {
//        Map<String, String> headers = new HashMap();
//        Map<String, String> queryParameters = new HashMap<String, String>();
//        queryParameters.put(OCVConstants.SEARCH_TYPE_PARAMETER, OCVConstants.CERTIFIED_SEARCH_TYPE);
//        Party party = setRequestBody();
//        APIRequest<Party> apiRequest = new APIRequest(headers, queryParameters, party);
//        assertFalse(abstractValidator.validateRequest(apiRequest).isValid());
//        assertEquals("4001", abstractValidator.validateRequest(apiRequest).getErrorCode());
//    }
//
//    private Party setRequestBody() throws JsonParseException, JsonMappingException, IOException {
//
//        String jsonString = "{\r\n" + "\"partyType\" : \"Non individual\",\r\n" + "\"identifiers\" : [{\r\n"
//                + "\"identifierUsageType\" : \"ABN\",\r\n" + "\"identifier\" : \"874935804\"\r\n" + "},{\r\n"
//                + "\"identifierUsageType\" : \"ACN\",\r\n" + "\"identifier\" : \"87493580478\"\r\n" + "}],\r\n"
//                + "\"names\":[{\"name\":\"ANZ\"}\r\n" + "    ]\r\n" + "}";
//        Party party = new ObjectMapper().readValue(jsonString, Party.class);
//        return party;
//    }
//
//    private Map<String, String> prepareRequestHeaders() {
//        Map<String, String> headers = new HashMap<String, String>();
//        headers.put(OCVConstants.ACCEPT_HEADER, "application/json");
//        headers.put(OCVConstants.TRACE_ID_HEADER, "abc123");
//        headers.put(OCVConstants.AUTHORIZATION_HEADER, "5237vxhsfdfyif");
//        headers.put(OCVConstants.CHANNEL, "CAP");
//        return headers;
//    }
//}
