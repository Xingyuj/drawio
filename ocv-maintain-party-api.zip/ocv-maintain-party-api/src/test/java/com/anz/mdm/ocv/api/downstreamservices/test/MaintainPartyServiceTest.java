package com.anz.mdm.ocv.api.downstreamservices.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.http.HttpException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.ResourceUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.downsteamservices.MaintainPartyService;
import com.anz.mdm.ocv.api.downsteamservices.StandardisedParty;
import com.anz.mdm.ocv.api.downsteamservices.ValidatedParty;
import com.anz.mdm.ocv.api.processor.MaintainPartyServiceProcessor;
import com.anz.mdm.ocv.api.processor.PartyInternalObjectsProcessor;
import com.anz.mdm.ocv.api.util.APIServiceUtil;
import com.anz.mdm.ocv.api.util.IdempotencyConfigUtil;
import com.anz.mdm.ocv.api.util.LogRequestModel;
import com.anz.mdm.ocv.api.util.RequestTransfomerUtil;
import com.anz.mdm.ocv.api.util.StreetSuffixConfig;
import com.anz.mdm.ocv.api.validator.APIRequest;
import com.anz.mdm.ocv.api.validator.MaintainPartyValidator;
import com.anz.mdm.ocv.party.v1.Party;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/*@PrepareForTest({ MaintainPartyValidator.class, MaintainPartyServiceProcessor.class, MaintainPartyService.class,
        RecordNotFoundException.class })*/
@RunWith(SpringRunner.class)
public class MaintainPartyServiceTest {

    @InjectMocks
    @Spy
    MaintainPartyService maintainPartyService;

    MaintainPartyServiceProcessor maintainPartyServiceProcessor;

    RequestTransfomerUtil requestTransfomer;

    MaintainPartyValidator maintainPartyValidator;

    @Spy
    RestTemplate restTemplate;
    
    @Mock 
    StreetSuffixConfig streetConfig;
    
    @Mock
    private LogRequestModel logAttributes;
    
    @Mock
    private PartyInternalObjectsProcessor partyInternalObj;

    @Mock
    private IdempotencyConfigUtil idempotencyConfigUtil;
    
    @Captor
    private ArgumentCaptor<HttpEntity<Party>> captor;

    final String uri = "https://localhost:8443/com.ibm.mdm.server.ws.restful/resources/MDMWSRESTful";

    @Before
    public void setUp() throws IOException {

        MaintainPartyValidator maintainPartyValidator = new MaintainPartyValidator();
        maintainPartyValidator = spy(maintainPartyValidator);

        maintainPartyService.setUrl(uri);

        maintainPartyServiceProcessor = new MaintainPartyServiceProcessor();

        maintainPartyServiceProcessor = spy(maintainPartyServiceProcessor);
        
        streetConfig = new StreetSuffixConfig();
        streetConfig = spy(streetConfig);
        
        MockitoAnnotations.initMocks(this);
        Mockito.when(streetConfig.getPropertyValue("street")).thenReturn("ST");
        Mockito.when(streetConfig.getPropertyValue("street highway")).thenReturn("sthwy");

    }
    
    /**
     * This test is for the following scenario(s): 1.) Conversion of MDM
     * Response XML to JSON.
     * 
     * @throws HttpException
     * @throws Exception
     */
    @Test
    public void maintainPartyOrgMDMResponseTranformationTest() throws HttpException, Exception {
        Map<String, String> headers = prepareRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();
        String requestTime = "2018-10-01 10:02:00.0";
        Party party = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:SampleOrgInput.json"), Party.class);
        APIRequest<Party> partyObject = new APIRequest<>(headers, queryParameters, party);

        HttpEntity<String> response = getXMLFromFile("classpath:MaintainPartyNonIndResponse.xml");

        String jsonResponse = new String(
                Files.readAllBytes(ResourceUtils.getFile("classpath:OrgResponseJurisdiction.json").toPath()));

        ResponseEntity<String> serviceResponse = new ResponseEntity<>(response.getBody(), HttpStatus.OK);

        doReturn(serviceResponse).when(restTemplate).exchange(any(String.class), any(), any(HttpEntity.class),
                any(Class.class));

        doReturn(jsonResponse).when(maintainPartyService).transformMDMResponse((HttpEntity<String>) any(Object.class),
                any(String.class));

        String apiResponse = maintainPartyService.processParty(partyObject, requestTime, "1234", false);
        System.out.println("apiResponse : " + apiResponse);
        System.out.println("jsonResponse : " + jsonResponse);
        assertEquals("Comparison", apiResponse, jsonResponse);
    }

    /**
     * This test is for the following scenario(s): 1.) Conversion of JSON
     * Request to MDM XML for Org
     * 
     * @throws HttpException
     * @throws Exception
     */
    @Test
    public void maintainPartyMDMORGRequestJSONTransform() throws Exception {

        Map<String, String> headers = prepareRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();
        // Org
        Party org = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:org-files/MainParty_Org_BKRE.json"),
                Party.class);
        APIRequest<Party> orgObject = new APIRequest<>(headers, queryParameters, org);
        String orgRequest_xml = maintainPartyService.transformPartyRequest(orgObject, null, false);
        System.err.println("orgRequest_xml : " + orgRequest_xml);
        assertTrue(orgRequest_xml.contains("BKRE"));

    }

    /**
     * This test is for the following scenario(s): 1.) Conversion of JSON
     * Request to MDM XML for Org
     * 
     * @throws HttpException
     * @throws Exception
     */
    @Test
    public void maintainPartyMDMRequestPersonJSONTransform() throws Exception {

        Map<String, String> headers = prepareRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();
        // Person
        Party person = new ObjectMapper().readValue(
                ResourceUtils.getFile("classpath:person-files/SamplePersonInput_withBKRE.json"), Party.class);

        APIRequest<Party> personObject = new APIRequest<>(headers, queryParameters, person);
        String samplePerson_xml = maintainPartyService.transformPartyRequest(personObject, null, false);
        System.err.println("sb : " + samplePerson_xml);
        assertTrue(samplePerson_xml.contains("BKRE"));
    }

    /**
     * This test is for the following scenario(s): 1.) Assert if escape
     * characters introduced for Org 2.) Assert if escape characters introduced
     * for Person
     * 
     * @throws Exception
     */
    @Test
    public void maintainPartyRequestEscapeChar() throws Exception {
        Map<String, String> headers = prepareRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();
        Party org = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:SampleOrgInputInvalidChar.json"),
                Party.class);
        APIRequest<Party> orgObject = new APIRequest<>(headers, queryParameters, org);
        String sb = maintainPartyService.transformPartyRequest(orgObject, null, false);
        // assertTrue(sb.contains("33 &amp; 5 Street"));

        Party person = new ObjectMapper()
                .readValue(ResourceUtils.getFile("classpath:SamplePersonInputInvalidChar.json"), Party.class);
        APIRequest<Party> personObject = new APIRequest<>(headers, queryParameters, person);
        String sb1 = maintainPartyService.transformPartyRequest(personObject, null, false);
        System.err.println("sb : " + sb1);
        assertTrue(sb1.contains("33 &amp;Street"));

    }

    /**
     * This test is for the following scenario(s): 1.) End to End Maintain Party
     * for Non-Individual
     * 
     * @throws Exception
     */
    @Test
    public void maintainPartyForOrgSuccess() throws HttpException, Exception {
        Map<String, String> headers = prepareRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();
        String requestTime = "2018-10-01 10:02:00.0";
        Party org = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:SampleOrgInputMaintainParty.json"),
                Party.class);
        APIRequest<Party> partyObject = new APIRequest<>(headers, queryParameters, org);
        HttpEntity<String> response = getXMLFromFile("classpath:MaintainPartyNonIndResponse.xml");

        String jsonResponse = new String(
                Files.readAllBytes(ResourceUtils.getFile("classpath:OrgJSONResponse.json").toPath()));
        // String jsonResponse = getOrgJSONResponse();
        // String apiResponse = maintainPartyService.processParty(partyObject,
        // requestTime, "1234");
        doReturn(response).when(maintainPartyService).invokeBackend(any(String.class), any(String.class));
        doReturn(jsonResponse).when(maintainPartyService).transformMDMResponse((HttpEntity<String>) any(Object.class),
                any(String.class));
        String apiResponse = maintainPartyService.processParty(partyObject, requestTime, "1234", false);
        assertEquals("Comparison", apiResponse, jsonResponse);

    }

    /**
     * This test is for the following scenario(s): 1.) End to End Maintain Party
     * for Individual
     * 
     * @throws Exception
     */
    @Test
    public void maintainPartyForPersonSuccess() throws HttpException, Exception {
        Map<String, String> headers = prepareRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();
        String requestTime = "2018-10-01 10:02:00.0";
        Party person = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:SamplePersonInput.json"),
                Party.class);
        APIRequest<Party> partyObject = new APIRequest<>(headers, queryParameters, person);
        HttpEntity<String> xmlResponse = getXMLFromFile("classpath:MaintainPartyIndResponse.xml");

        String jsonResponse = new String(
                Files.readAllBytes(ResourceUtils.getFile("classpath:PersonJSONResponse.json").toPath()));

        doReturn(xmlResponse).when(maintainPartyService).invokeBackend(any(String.class), any(String.class));
        doReturn(jsonResponse).when(maintainPartyService).transformMDMResponse((HttpEntity<String>) any(Object.class),
                any(String.class));

        String apiResponse = maintainPartyService.processParty(partyObject, requestTime, "1234", false);
        doReturn(jsonResponse).when(maintainPartyService).transformMDMResponse((HttpEntity<String>) any(Object.class),
                any(String.class));
        assertEquals("Comparison", apiResponse, jsonResponse);
        System.err.println("apiResponse : " + apiResponse);
        System.err.println("jsonResponse  : " + jsonResponse);

    }
    
    
    /**
     * This test is for the following scenario(s): 1.) Checking if the
     * Verification and Validation objects are not passed
     * and not breaking existing functions.
     * 
     * @throws Exception
     */
    @Test
    public void maintainPartyValidationVerficationNone() throws HttpException,
            Exception {
        Map<String, String> headers = prepareRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();
        String requestTime = "2018-10-01 10:02:00.0";
        Party person = new ObjectMapper().readValue(
                ResourceUtils.getFile("classpath:SamplePersonWithoutVerValANZX.json"),
                Party.class);
        APIRequest<Party> partyObject = new APIRequest<>(headers,
                queryParameters, person);

        String xmlExpected = new String(Files.readAllBytes(ResourceUtils
                .getFile("classpath:MaintainPartyVerValExistingFunction.xml")
                .toPath()));
        String verValXmlExpected = xmlExpected.substring(
                xmlExpected.indexOf("</ConsentBObj>"),
                xmlExpected.indexOf("</PartyWrapperBObj>")).replaceAll("\\s",
                "");
        String xmlBuilt = maintainPartyService.transformPartyRequest(
                partyObject, null, false).toString();
        String verValBuiltXml = xmlBuilt.substring(
                xmlBuilt.indexOf("</ConsentBObj>"),
                xmlBuilt.indexOf("</PartyWrapperBObj>")).replaceAll("\\s", "");
        
        System.out.println(xmlBuilt);
        assertEquals("Comparison", verValXmlExpected, verValBuiltXml);

    }

    /**
     * This test is for the following scenario(s): 1.) Checking if the
     * Verification and Validation objects are populated correctly
     * 
     * @throws Exception
     */
    @Test
    public void maintainPartyIndValidationVerficationNonAnx() throws HttpException,
            Exception {
        Map<String, String> headers = prepareRequestHeaders();
        headers.put("Channel", "ANZXDELTE");
        Map<String, String> queryParameters = new HashMap<String, String>();
        String requestTime = "2018-10-01 10:02:00.0";
        Party person = new ObjectMapper().readValue(
                ResourceUtils.getFile("classpath:SamplePersonVerValANZX.json"),
                Party.class);
        APIRequest<Party> partyObject = new APIRequest<>(headers,
                queryParameters, person);

        String xmlExpected = new String(Files.readAllBytes(ResourceUtils
                .getFile("classpath:MaintainPartyValidationVerification.xml")
                .toPath()));
        String verValXmlExpected = xmlExpected.substring(
                xmlExpected.indexOf("<XAttrValidationBObj>"),
                xmlExpected.indexOf("</PartyWrapperBObj>")).replaceAll("\\s",
                "");
        
        String xmlBuilt = maintainPartyService.transformPartyRequest(
                partyObject, null, false).toString();
//        String verValBuiltXml = xmlBuilt.substring(
//                xmlBuilt.indexOf("<XAttrValidationBObj>"),
//                xmlBuilt.indexOf("</PartyWrapperBObj>")).replaceAll("\\s", "");
        
        System.out.println(xmlBuilt);
//        assertEquals("Comparison", verValXmlExpected, verValBuiltXml);

    }
    
    /**
     * This test is for the following scenario(s): 1.) Checking if the
     * Verification and Validation objects are not populated 
     * if its not of type Security Mobile/Email
     * 
     * @throws Exception
     */
    @Test
    public void maintainPartyIndValidationVerfication() throws HttpException,
            Exception {
        Map<String, String> headers = prepareRequestHeaders();
        headers.put("Channel", "FENERGOANZX");
        Map<String, String> queryParameters = new HashMap<String, String>();
        String requestTime = "2018-10-01 10:02:00.0";
        Party person = new ObjectMapper().readValue(
                ResourceUtils.getFile("classpath:SamplePersonVerValNonAnzx.json"),
                Party.class);
        APIRequest<Party> partyObject = new APIRequest<>(headers,
                queryParameters, person);

        String xmlExpected = new String(Files.readAllBytes(ResourceUtils
                .getFile("classpath:MaintainPartyValidationVerification.xml")
                .toPath()));
        String verValXmlExpected = xmlExpected.substring(
                xmlExpected.indexOf("<XAttrValidationBObj>"),
                xmlExpected.indexOf("</PartyWrapperBObj>")).replaceAll("\\s",
                "");
        
        String xmlBuilt = maintainPartyService.transformPartyRequest(
                partyObject, null, false).toString();
//        String verValBuiltXml = xmlBuilt.substring(
//                xmlBuilt.indexOf("<XAttrValidationBObj>"),
//                xmlBuilt.indexOf("</PartyWrapperBObj>")).replaceAll("\\s", "");
        
        System.out.println(xmlBuilt);
        assertTrue(!(xmlBuilt.contains("<XAttrValidationBObj>")));

    }

    /**
     * This test is for the following scenario(s): 1.) Checking if the
     * Validation object is populated
     * 2.) checking if Address obj ref id = Validation obj ref id
     *
     * @throws Exception
     */

    @Test
    public void maintainPartyAddressValidation() throws HttpException, Exception {

        Map<String, String> headers = prepareRequestHeaders();
        headers.put("Channel", "FENERGOANZX");
        Map<String, String> queryParameters = new HashMap<String, String>();
        String requestTime = "2018-10-01 10:02:00.0";
        Party person = new ObjectMapper().readValue(
                ResourceUtils.getFile("classpath:SamplePersonAddValANZX.json"),
                Party.class);
        APIRequest<Party> partyObject = new APIRequest<>(headers,
                queryParameters, person);

        String xmlExpected = new String(Files.readAllBytes(ResourceUtils
                .getFile("classpath:MaintainPartyAddresssValidation.xml")
                .toPath()));

        String xmlBuilt = maintainPartyService.transformPartyRequest(
                partyObject, null, false).toString();

        String verValAddRefId = xmlBuilt.substring(xmlBuilt.indexOf("<TCRMPartyAddressBObj>"),xmlBuilt.indexOf("</ObjectReferenceId>"));

        verValAddRefId = verValAddRefId.substring(verValAddRefId.indexOf("ObjectReferenceId")+"ObjectReferenceId".length()+1);

        String verValRefId = xmlBuilt.substring(
                xmlBuilt.indexOf("<XAttrValidationBObj>"));
        verValRefId = verValRefId.substring(verValRefId.indexOf("ObjectReferenceId")+"ObjectReferenceId".length()+1,
                verValRefId.indexOf("</ObjectReferenceId>"));

        assertTrue((xmlBuilt.contains("<XAttrValidationBObj>")));
        //To check if the address ref id is same as Validation ref id
        assertTrue(verValAddRefId.equals(verValRefId));

    }

    /**
     * This test is for the following scenario(s): 1.) Checking if the
     * Verification and Validation objects are not populated 
     * if its not of type Security Mobile/Email
     * 
     * @throws Exception
     */
    @Test
    public void maintainPartyIndValidationVerficationOne() throws HttpException,
            Exception {
        Map<String, String> headers = prepareRequestHeaders();
        headers.put("Channel", "FENERGOANZX");
        Map<String, String> queryParameters = new HashMap<String, String>();
        String requestTime = "2018-10-01 10:02:00.0";
        Party person = new ObjectMapper().readValue(
                ResourceUtils.getFile("classpath:SamplePersonVerValANZX.json"),
                Party.class);
        APIRequest<Party> partyObject = new APIRequest<>(headers,
                queryParameters, person);

        String xmlExpected = new String(Files.readAllBytes(ResourceUtils
                .getFile("classpath:MaintainPartyValidationVerification.xml")
                .toPath()));
        String verValXmlExpected = xmlExpected.substring(
                xmlExpected.indexOf("<XAttrValidationBObj>"),
                xmlExpected.indexOf("</PartyWrapperBObj>")).replaceAll("\\s",
                "");
        
        String xmlBuilt = maintainPartyService.transformPartyRequest(
                partyObject, null, false).toString();
//        String verValBuiltXml = xmlBuilt.substring(
//                xmlBuilt.indexOf("<XAttrValidationBObj>"),
//                xmlBuilt.indexOf("</PartyWrapperBObj>")).replaceAll("\\s", "");
        
        System.out.println(xmlBuilt);
//        assertTrue(!(xmlBuilt.contains("<XAttrValidationBObj>")));

    }
    

    

    /**
     * This test is for the following scenario(s): 1). Response object doesn't
     * contain Jurisdiction
     * 
     * @throws Exception
     */
    @Test
    public void maintainPartyOrgWithJurisdictionTranformToJson() throws HttpException, Exception {

        Map<String, String> headers = prepareRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();

        HttpEntity<String> response = getXMLFromFile("classpath:MaintainOrgJurisdictionResponse.xml");

        InputStream ss = new ByteArrayInputStream(getRequestXslFull().getBytes(StandardCharsets.UTF_8));
        StreamSource stylesource = new StreamSource(ss);

        StreamSource xmlsource = new StreamSource(new StringReader(response.getBody()));
        Transformer transformer = TransformerFactory.newInstance().newTransformer(stylesource);
        StringWriter outWriter = new StringWriter();
        StreamResult result = new StreamResult(outWriter);
        // Transform the document and store it in a file
        transformer.transform(xmlsource, result);
        StringBuffer sb = outWriter.getBuffer();

        String jsonResponse = sb.toString();
        System.out.println(jsonResponse);
        assertFalse(jsonResponse.contains("jurisdiction"));
    }

    /**
     * This test is for the following scenario: End to End Maintain Party for
     * Non-Individual for BVD source on EntityStatus field
     * 
     * @throws Exception
     */
    @Test
    public void maintainPartyForEntityStatus() throws HttpException, Exception {
        Map<String, String> headers = prepareRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();
        String requestTime = "2018-10-01 10:02:00.0";

        Party org = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:MaintainPartyEntitySatusValid.json"),
                Party.class);
        APIRequest<Party> partyObject = new APIRequest<>(headers, queryParameters, org);
        HttpEntity<String> response = getXMLFromFile("classpath:MaintainPartyBVDEntityStatusResponse.xml");

        String jsonResponse = new String(Files.readAllBytes(
                ResourceUtils.getFile("classpath:BVDOrgEntityStatusMaintainPartyValidResponse.json").toPath()));
        // String jsonResponse = getOrgJSONResponse();

        doReturn(response).when(maintainPartyService).invokeBackend(any(String.class), any(String.class));
        doReturn(jsonResponse).when(maintainPartyService).transformMDMResponse((HttpEntity<String>) any(Object.class),
                any(String.class));
        String apiResponse = maintainPartyService.processParty(partyObject, requestTime, "1234", false);
        assertEquals("Comparison", apiResponse, jsonResponse);

    }

    private String getRequestXslFull() throws JsonParseException, JsonMappingException, IOException {

        String xslRequest = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n" + "<xsl:stylesheet version=\"2.0\"\r\n"
                + "    xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\" xmlns:fo=\"http://www.w3.org/1999/XSL/Format\"\r\n"
                + "    xmlns:xs=\"http://www.w3.org/2001/XMLSchema\" xmlns:fn=\"http://www.w3.org/2005/xpath-functions\"\r\n"
                + "    xmlns:mdm=\"http://www.ibm.com/mdm/schema\"\r\n"
                + "    xmlns:cc=\"http://www.anz.com/cm/data/specs/CommercialContact/internal/00000001\"\r\n"
                + "    exclude-result-prefixes=\"fo fn xs mdm cc\">\r\n"
                + "    <xsl:output method=\"text\" encoding=\"UTF-8\" indent=\"yes\" />\r\n"
                + "    <xsl:template match=\"/\">\r\n"
                + "        <xsl:apply-templates select=\"mdm:TCRMService/mdm:TxResponse/mdm:ResponseObject/mdm:TCRMPersonBObj\" mode=\"map\"/>\r\n"
                + "        <xsl:apply-templates select=\"mdm:TCRMService/mdm:TxResponse/mdm:ResponseObject/mdm:TCRMOrganizationBObj\" mode=\"map\"/>\r\n"
                + "    </xsl:template>\r\n" + "                            \r\n"
                + "    <xsl:template name=\"PersonES\" match=\"mdm:TCRMPersonBObj\" mode=\"map\">\r\n" + "{\r\n"
                + "    <xsl:apply-templates select=\"mdm:TCRMPartyIdentificationBObj[mdm:IdentificationValue='One Customer ID']\" mode=\"ocvId\"/>\r\n"
                + "    \"partyType\": \"P\",\r\n"
                + "    <xsl:if test=\"mdm:BirthDate !=''\">\"dateOfBirth\": \"<xsl:value-of select=\"substring-before(mdm:BirthDate, ' ')\" />\",</xsl:if>\r\n"
                + "    \"status\": \"<xsl:value-of select=\"mdm:ClientStatusValue\"/>\",\r\n"
                + "    \"source\": \"<xsl:value-of select=\"mdm:SourceIdentifierValue\"/>\", \r\n"
                + "\"kycDetails\":   {\r\n"
                + "    \"status\": \"<xsl:value-of select=\"mdm:TCRMExtension/mdm:XPersonBObjExt/mdm:XKycStatusValue\"/>\",\r\n"
                + "    \"verificationLevel\": \"<xsl:value-of select=\"mdm:TCRMExtension/mdm:XPersonBObjExt/mdm:XKycVerificationLevelValue\"/>\"\r\n"
                + "    },\r\n" + "    \"gender\": \"<xsl:value-of select=\"mdm:GenderType\" />\",\r\n"
                + "    \"maritialStatus\": \"<xsl:value-of select=\"mdm:MaritalStatusValue\" />\",\r\n"
                + "    <xsl:if test=\"mdm:DeceasedDate !=''\">\"deceasedDate\": \"<xsl:value-of select=\"substring-before(mdm:DeceasedDate, ' ')\" />\",</xsl:if>\r\n"
                + "    \"employeeIndicator\": \"<xsl:value-of select=\"mdm:TCRMExtension/mdm:XPersonBObjExt/mdm:XEmployeeIndicator\" />\",\r\n"
                + "    \"employerName\": \"<xsl:value-of select=\"mdm:TCRMExtension/mdm:XPersonBObjExt/mdm:XEmployerName\" />\",\r\n"
                + "\"occupation\":   {\r\n"
                + "    \"code\": \"<xsl:value-of select=\"mdm:TCRMExtension/mdm:XPersonBObjExt/mdm:XOccupationValue\"/>\",\r\n"
                + "    \"description\": \"To be populated\"\r\n" + "    },\r\n" + "\"addresses\":    [\r\n"
                + "    <xsl:apply-templates select=\"mdm:TCRMPartyAddressBObj\" mode=\"map\"/>\r\n" + "],\r\n"
                + "\"phones\": [\r\n"
                + "    <xsl:apply-templates select=\"mdm:TCRMPartyContactMethodBObj[mdm:TCRMContactMethodBObj/mdm:ContactMethodValue='Telephone Number']\" mode=\"phone\" />\r\n"
                + "],\r\n" + "<!-- <xsl:if test=\"not(emails)\">  -->\r\n" + "\"emails\":   [\r\n"
                + "    <xsl:apply-templates select=\"mdm:TCRMPartyContactMethodBObj[mdm:TCRMContactMethodBObj/mdm:ContactMethodValue='Email Address']\" mode=\"email\" />\r\n"
                + "],\r\n" + "<!-- </xsl:if>  -->\r\n" + "\"identifiers\": [\r\n"
                + "    <xsl:apply-templates select=\"mdm:TCRMPartyIdentificationBObj\" mode=\"map\"/>\r\n" + "],\r\n"
                + "\"names\": [\r\n" + "    <xsl:apply-templates select=\"mdm:TCRMPersonNameBObj\" mode=\"name\"/>\r\n"
                + "],\r\n" + "<!-- \"qualifiedNames\": [\r\n"
                + "    <xsl:apply-templates select=\"mdm:TCRMPersonNameBObj\" mode=\"qname\"/>\r\n" + "], -->\r\n"
                + "\"preferences\":  [\r\n"
                + "    <xsl:apply-templates select=\"mdm:TCRMPartyPrivPrefBObj\" mode=\"map\"/>\r\n" + "],\r\n"
                + "\"sourceSystems\": {\r\n"
                + "    \"sourceSystemId\": \"<xsl:value-of select=\"mdm:TCRMAdminContEquivBObj/mdm:AdminPartyId\"/>\",\r\n"
                + "    \"sourceSystemName\": \"<xsl:value-of select=\"mdm:TCRMAdminContEquivBObj/mdm:AdminSystemValue\"/>\"\r\n"
                + "    }\r\n" + "}\r\n" + "    </xsl:template>\r\n" + "    \r\n"
                + "    <xsl:template name=\"OrganizationES\" match=\"mdm:TCRMOrganizationBObj\" mode=\"map\">\r\n"
                + "{\r\n"
                + "    <!-- <xsl:apply-templates select=\"mdm:TCRMOrganizationBObj[mdm:IdentificationValue='One Customer ID']\" mode=\"ocvId\"/> -->\r\n"
                + "    \"partyType\": \"O\",\r\n"
                + "    <xsl:if test=\"mdm:EstablishedDate !=''\">\"establishmentDate\": \"<xsl:value-of select=\"substring-before(mdm:EstablishedDate, ' ')\" />\",</xsl:if>\r\n"
                + "    \"organisationType\": \"<xsl:value-of select=\"mdm:OrganizationValue\"/>\",\r\n"
                + "    \"status\": \"<xsl:value-of select=\"mdm:ClientStatusValue\" />\",\r\n"
                + "    \"source\": \"<xsl:value-of select=\"mdm:SourceIdentifierValue\" />\",\r\n"
                + "\"kycDetails\":   {\r\n"
                + "    \"status\": \"<xsl:value-of select=\"mdm:TCRMExtension/mdm:XOrganizationBObjExt/mdm:XKycStatusValue\"/>\",\r\n"
                + "    \"verificationLevel\": \"<xsl:value-of select=\"mdm:TCRMExtension/mdm:XOrganizationBObjExt/mdm:XKycVerificationLevelValue\"/>\"\r\n"
                + "    },\r\n" + "\"industry\": {\r\n"
                + "    \"code\": \"<xsl:value-of select=\"mdm:IndustryType\"/>\",\r\n"
                + "    \"description\": \"<xsl:value-of select=\"mdm:IndustryValue\"/>\"\r\n" + "    },\r\n"
                + "    <xsl:if test=\"mdm:TCRMExtension/mdm:XOrganizationBObjExt/mdm:XBankruptDate !=''\">\"bankruptDate\": \"<xsl:value-of select=\"substring-before(mdm:TCRMExtension/mdm:XOrganizationBObjExt/mdm:XBankruptDate, ' ' )\" />\",</xsl:if>\r\n"
                + "\"addresses\": [\r\n"
                + "    <xsl:apply-templates select=\"mdm:TCRMPartyAddressBObj\" mode=\"map\"/>\r\n" + "],\r\n"
                + "\"phones\": [\r\n"
                + "    <xsl:apply-templates select=\"mdm:TCRMPartyContactMethodBObj[mdm:TCRMContactMethodBObj/mdm:ContactMethodValue='Telephone Number']\" mode=\"phone\" />\r\n"
                + "],\r\n" + "\"emails\": [\r\n"
                + "    <xsl:apply-templates select=\"mdm:TCRMPartyContactMethodBObj[mdm:TCRMContactMethodBObj/mdm:ContactMethodValue='Email Address']\" mode=\"email\" />\r\n"
                + "],\r\n" + "\"identifiers\": [\r\n"
                + "    <xsl:apply-templates select=\"mdm:TCRMPartyIdentificationBObj\" mode=\"map\"/>\r\n" + "],\r\n"
                + "\"names\": [\r\n"
                + "    <xsl:apply-templates select=\"mdm:TCRMOrganizationNameBObj\" mode=\"name\"/>\r\n" + "],\r\n"
                + "<!-- \"qualifiedNames\": [\r\n"
                + "    <xsl:apply-templates select=\"mdm:TCRMOrganizationNameBObj\" mode=\"qname\"/>\r\n" + "], -->\r\n"
                + "\"preferences\": [\r\n"
                + "    <xsl:apply-templates select=\"mdm:TCRMPartyPrivPrefBObj\" mode=\"map\"/>\r\n" + "],\r\n"
                + "\"commercialContacts\": [\r\n"
                + "    <xsl:apply-templates select=\"mdm:TCRMPartyDemographicsBObj\" mode=\"map\"/>\r\n" + "],\r\n"
                + "\"sourceSystems\": {\r\n"
                + "    \"sourceSystemId\": \"<xsl:value-of select=\"mdm:TCRMAdminContEquivBObj/mdm:AdminPartyId\"/>\",\r\n"
                + "    \"sourceSystemName\": \"<xsl:value-of select=\"mdm:TCRMAdminContEquivBObj/mdm:AdminSystemValue\"/>\"\r\n"
                + "    }\r\n" + "}\r\n" + "    </xsl:template>\r\n"
                + "    <xsl:template name=\"AddressES\" match=\"mdm:TCRMPartyAddressBObj\" mode=\"map\">\r\n" + "{\r\n"
                + "    \"addressUsageType\": \"<xsl:value-of select=\"mdm:AddressUsageValue\" />\",\r\n"
                + "    \"addressLineOne\": \"<xsl:value-of select=\"mdm:TCRMAddressBObj/mdm:AddressLineOne\" />\",\r\n"
                + "    \"addressLineTwo\": \"<xsl:value-of select=\"mdm:TCRMAddressBObj/mdm:AddressLineTwo\" />\",\r\n"
                + "    \"addressLineThree\": \"<xsl:value-of select=\"mdm:TCRMAddressBObj/mdm:AddressLineThree\" />\",\r\n"
                + "    \"city\": \"<xsl:value-of select=\"mdm:TCRMAddressBObj/mdm:City\" />\",\r\n"
                + "    \"postalCode\": \"<xsl:value-of select=\"mdm:TCRMAddressBObj/mdm:ZipPostalCode\" />\",\r\n"
                + "    \"state\": \"<xsl:value-of select=\"mdm:TCRMAddressBObj/mdm:ProvinceStateValue\" />\",\r\n"
                + "    \"country\": \"<xsl:value-of select=\"mdm:TCRMAddressBObj/mdm:CountryValue\" />\",\r\n"
                + "    \"streetName\": \"<xsl:value-of select=\"mdm:TCRMAddressBObj/mdm:StreetName\" />\",\r\n"
                + "    \"streetNumber\": \"<xsl:value-of select=\"mdm:TCRMAddressBObj/mdm:StreetNumber\" />\",\r\n"
                + "    \"streetPrefix\": \"<xsl:value-of select=\"mdm:TCRMAddressBObj/mdm:StreetPrefix\" />\",\r\n"
                + "    \"streetSuffix\": \"<xsl:value-of select=\"mdm:TCRMAddressBObj/mdm:StreetSuffix\" />\",\r\n"
                + "    \"region\": \"<xsl:value-of select=\"mdm:TCRMAddressBObj/mdm:Region\" />\",\r\n"
                + "    \"deliveryId\": \"<xsl:value-of select=\"mdm:TCRMAddressBObj/mdm:DelId\" />\",\r\n"
                + "    \"source\": \"<xsl:value-of select=\"mdm:SourceIdentifierValue\" />\",\r\n"
                + "    <xsl:if test=\"mdm:StartDate !=''\">\"startDate\": \"<xsl:value-of select=\"substring-before(mdm:StartDate, ' ')\" />\"</xsl:if><xsl:if test=\"mdm:EndDate !=''\">,</xsl:if>\r\n"
                + "    <xsl:if test=\"mdm:EndDate !=''\">\"endDate\": \"<xsl:value-of select=\"substring-before(mdm:EndDate, ' ')\" />\"</xsl:if>\r\n"
                + "}<xsl:if test=\"position() &gt; 0 and position() != last()\">,</xsl:if>       \r\n"
                + "    </xsl:template>\r\n"
                + "    <xsl:template name=\"PartyPrivPreferenceES\" match=\"mdm:TCRMPartyPrivPrefBObj\" mode=\"map\">\r\n"
                + "{\r\n" + "    \"preferenceUsageType\": \"<xsl:value-of select=\"mdm:PrivPrefValue\" />\",\r\n"
                + "    \"preferenceValue\": \"<xsl:value-of select=\"mdm:ValueString\" />\",\r\n"
                + "    \"preferenceReason\": \"<xsl:value-of select=\"mdm:PrivPrefReasonValue\" />\",\r\n"
                + "    \"source\": \"<xsl:value-of select=\"mdm:SourceIdentValue\" />\"\r\n"
                + "}<xsl:if test=\"position() &gt; 0 and position() != last()\">,</xsl:if>\r\n"
                + "    </xsl:template>\r\n"
                + "    <xsl:template name=\"IdentifierES\" match=\"mdm:TCRMPartyIdentificationBObj\" mode=\"map\">\r\n"
                + "{\r\n" + "    \"identifierUsageType\": \"<xsl:value-of select=\"mdm:IdentificationValue\" />\",\r\n"
                + "    \"identifier\": \"<xsl:value-of select=\"mdm:IdentificationNumber\" />\",\r\n"
                + "    \"identificationIssueLocation\": \"<xsl:value-of select=\"mdm:IdentificationIssueLocation\" />\",\r\n"
                + "    \"source\": \"<xsl:value-of select=\"mdm:SourceIdentifierValue\" />\",\r\n"
                + "    <xsl:if test=\"mdm:StartDate !=''\">\"startDate\": \"<xsl:value-of select=\"substring-before(mdm:StartDate, ' ')\" />\"</xsl:if><xsl:if test=\"mdm:EndDate !=''\">,</xsl:if>\r\n"
                + "    <xsl:if test=\"mdm:EndDate !=''\">\"endDate\": \"<xsl:value-of select=\"substring-before(mdm:EndDate, ' ')\" />\"</xsl:if><xsl:if test=\"mdm:IdentificationExpiryDate !=''\">,</xsl:if>\r\n"
                + "    <xsl:if test=\"mdm:IdentificationExpiryDate !=''\">\"expiryDate\": \"<xsl:value-of select=\"substring-before(mdm:IdentificationExpiryDate, ' ')\" />\"</xsl:if>\r\n"
                + "}<xsl:if test=\"position() &gt; 0 and position() != last()\">,</xsl:if>\r\n"
                + "    </xsl:template>\r\n"
                + "    <xsl:template name=\"CommercialContactES\" match=\"mdm:TCRMPartyDemographicsBObj\" mode=\"map\">\r\n"
                + "{\r\n"
                + "    \"name\": \"<xsl:value-of select=\"mdm:TCRMDemographicsSpecValueBObj/mdm:AttributeValueBObj/mdm:SpecValueXML/cc:CommercialContactList/cc:CommercialContact/cc:Name\" />\",\r\n"
                + "    \"title\": \"<xsl:value-of select=\"mdm:TCRMDemographicsSpecValueBObj/mdm:AttributeValueBObj/mdm:SpecValueXML/cc:CommercialContactList/cc:CommercialContact/cc:Title\" />\",\r\n"
                + "    \"phone\": \"<xsl:value-of select=\"mdm:TCRMDemographicsSpecValueBObj/mdm:AttributeValueBObj/mdm:SpecValueXML/cc:CommercialContactList/cc:CommercialContact/cc:Phone\" />\",\r\n"
                + "    \"fax\": \"<xsl:value-of select=\"mdm:TCRMDemographicsSpecValueBObj/mdm:AttributeValueBObj/mdm:SpecValueXML/cc:CommercialContactList/cc:CommercialContact/cc:Fax\" />\",\r\n"
                + "    \"mobile\": \"<xsl:value-of select=\"mdm:TCRMDemographicsSpecValueBObj/mdm:AttributeValueBObj/mdm:SpecValueXML/cc:CommercialContactList/cc:CommercialContact/cc:Mobile\" />\",\r\n"
                + "    \"preferred\": \"<xsl:value-of select=\"mdm:TCRMDemographicsSpecValueBObj/mdm:AttributeValueBObj/mdm:SpecValueXML/cc:CommercialContactList/cc:CommercialContact/cc:PreferredIndicator\" />\"\r\n"
                + "}<xsl:if test=\"position() &gt; 0 and position() != last()\">,</xsl:if>\r\n"
                + "    </xsl:template>\r\n"
                + "    <xsl:template name=\"PhoneES\" match=\"mdm:TCRMPartyContactMethodBObj\" mode=\"phone\">\r\n"
                + "{\r\n" + "    \"phoneUsageType\": \"<xsl:value-of select=\"mdm:ContactMethodUsageValue\" />\",\r\n"
                + "    \"phone\": \"<xsl:value-of select=\"mdm:TCRMContactMethodBObj/mdm:ReferenceNumber\" />\",\r\n"
                + "    \"preferred\": \"<xsl:value-of select=\"mdm:PreferredContactMethodIndicator\" />\",\r\n"
                + "    \"source\": \"<xsl:value-of select=\"mdm:SourceIdentifierValue\" />\",\r\n"
                + "    <xsl:if test=\"mdm:StartDate !=''\">\"startDate\": \"<xsl:value-of select=\"substring-before(mdm:StartDate, ' ')\" />\"</xsl:if><xsl:if test=\"mdm:EndDate !=''\">,</xsl:if>\r\n"
                + "    <xsl:if test=\"mdm:EndDate !=''\">\"endDate\": \"<xsl:value-of select=\"substring-before(mdm:EndDate, ' ')\" />\"</xsl:if>\r\n"
                + "}<xsl:if test=\"position() &gt; 0 and position() != last()\">,</xsl:if>\r\n"
                + "    </xsl:template>\r\n"
                + "    <xsl:template name=\"EmailES\" match=\"mdm:TCRMPartyContactMethodBObj\" mode=\"email\">\r\n"
                + "{\r\n" + "    \"emailUsageType\": \"<xsl:value-of select=\"mdm:ContactMethodUsageValue\" />\",\r\n"
                + "    \"email\": \"<xsl:value-of select=\"mdm:TCRMContactMethodBObj/mdm:ReferenceNumber\" />\",\r\n"
                + "    \"preferred\": \"<xsl:value-of select=\"mdm:PreferredContactMethodIndicator\" />\",\r\n"
                + "    \"source\": \"<xsl:value-of select=\"mdm:SourceIdentifierValue\" />\",\r\n"
                + "    <xsl:if test=\"mdm:StartDate !=''\">\"startDate\": \"<xsl:value-of select=\"substring-before(mdm:StartDate, ' ')\" />\"</xsl:if><xsl:if test=\"mdm:EndDate !=''\">,</xsl:if>\r\n"
                + "    <xsl:if test=\"mdm:EndDate !=''\">\"endDate\": \"<xsl:value-of select=\"substring-before(mdm:EndDate, ' ')\" />\"</xsl:if>\r\n"
                + "}<xsl:if test=\"position() &gt; 0 and position() != last()\">,</xsl:if>\r\n"
                + "    </xsl:template>\r\n"
                + "    <xsl:template name=\"OCVId\" match=\"mdm:TCRMPartyIdentificationBObj\" mode=\"ocvId\">\r\n"
                + "    \"ocvId\": \"<xsl:value-of select=\"mdm:IdentificationNumber\"/>\",\r\n"
                + "    </xsl:template>\r\n"
                + "    <xsl:template name=\"PersonNameES\" match=\"mdm:TCRMPersonNameBObj\" mode=\"name\">\r\n"
                + "{\r\n" + "    \"nameUsageType\": \"<xsl:value-of select=\"mdm:NameUsageValue\" />\",\r\n"
                + "    \"name\": \"<xsl:value-of select=\"mdm:LastName\" />\",\r\n"
                + "    \"prefix\": \"<xsl:value-of select=\"mdm:prefixValue\" />\",\r\n"
                + "    \"title\": \"<xsl:value-of select=\"mdm:prefixDescription\" />\",\r\n"
                + "    \"firstName\": \"<xsl:value-of select=\"mdm:givenNameOne\" />\",\r\n"
                + "    \"middleName\": \"<xsl:value-of select=\"mdm:givenNameTwo\" />\",\r\n"
                + "    \"lastName\": \"<xsl:value-of select=\"mdm:lastName\" />\",\r\n"
                + "    \"suffix\": \"<xsl:value-of select=\"mdm:suffix\" />\",\r\n"
                + "    \"source\": \"<xsl:value-of select=\"mdm:SourceIdentifierValue\" />\",\r\n"
                + "    <xsl:if test=\"mdm:StartDate !=''\">\"startDate\": \"<xsl:value-of select=\"substring-before(mdm:StartDate, ' ')\" />\"</xsl:if><xsl:if test=\"mdm:EndDate !=''\">,</xsl:if>\r\n"
                + "    <xsl:if test=\"mdm:EndDate !=''\">\"endDate\": \"<xsl:value-of select=\"substring-before(mdm:EndDate, ' ')\" />\"</xsl:if>\r\n"
                + "}<xsl:if test=\"position() &gt; 0 and position() != last()\">,</xsl:if>\r\n"
                + "    </xsl:template>\r\n"
                + "    <xsl:template name=\"PersonQualifiedNameES\" match=\"mdm:TCRMPersonNameBObj\" mode=\"qname\">\r\n"
                + "{\r\n" + "    \"preferenceUsageType\": \"To be populated\",\r\n"
                + "    \"preferenceValue\": \"To be populated\",\r\n"
                + "    \"preferenceReason\": \"To be populated\",\r\n" + "    \"source\": \"To be populated\"\r\n"
                + "}<xsl:if test=\"position() &gt; 0 and position() != last()\">,</xsl:if>\r\n"
                + "    </xsl:template>\r\n"
                + "    <xsl:template name=\"OrgNameES\" match=\"mdm:TCRMOrganizationNameBObj\" mode=\"name\">\r\n"
                + "{\r\n" + "    \"nameUsageType\": \"<xsl:value-of select=\"mdm:NameUsageValue\" />\",\r\n"
                + "    \"name\": \"<xsl:value-of select=\"mdm:OrganizationName\" />\",\r\n"
                + "    \"source\": \"<xsl:value-of select=\"mdm:SourceIdentifierValue\" />\",\r\n"
                + "    <xsl:if test=\"mdm:StartDate !=''\">\"startDate\": \"<xsl:value-of select=\"substring-before(mdm:StartDate, ' ')\" />\"</xsl:if><xsl:if test=\"mdm:EndDate !=''\">,</xsl:if>\r\n"
                + "    <xsl:if test=\"mdm:EndDate !=''\">\"endDate\": \"<xsl:value-of select=\"substring-before(mdm:EndDate, ' ')\" />\"</xsl:if>\r\n"
                + "}<xsl:if test=\"position() &gt; 0 and position() != last()\">,</xsl:if>\r\n"
                + "    </xsl:template>\r\n"
                + "    <xsl:template name=\"OrgQualifiedNameES\" match=\"mdm:TCRMOrganizationNameBObj\" mode=\"qname\">\r\n"
                + "{\r\n" + "    \"preferenceUsageType\": \"To be populated\",\r\n"
                + "    \"preferenceValue\": \"To be populated\",\r\n"
                + "    \"preferenceReason\": \"To be populated\",\r\n" + "    \"source\": \"To be populated\"\r\n"
                + "}<xsl:if test=\"position() &gt; 0 and position() != last()\">,</xsl:if>\r\n"
                + "    </xsl:template>\r\n"
                + " <xsl:template name=\"BankingService\" match=\"mdm:KeyValueBObjType\" mode=\"name\">\r\n" + "{\r\n"
                + "    \"key\": \"To be populated\",\r\n" + "    \"value\": \"To be populated\",\r\n"
                + "}<xsl:if test=\"position() &gt; 0 and position() != last()\">,</xsl:if>\r\n"
                + "    </xsl:template>\r\n" + "</xsl:stylesheet>";

        return xslRequest;
    }

    private Map<String, String> prepareRequestHeaders() {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put(OCVConstants.ACCEPT_HEADER, "application/json");
        headers.put(OCVConstants.TRACE_ID_HEADER, "abc123");
        headers.put(OCVConstants.AUTHORIZATION_HEADER, "5237vxhsfdfyif");
        headers.put(OCVConstants.REQUEST_TIMESTAMP, "2018-09-09");
        headers.put(OCVConstants.USER_ID_HEADER, "tester");
        return headers;
    }

    private HttpEntity<String> getXMLFromFile(String path) {
        String mdmResponse = "";
        try {
            File resource = ResourceUtils.getFile(path);
            mdmResponse = new String(Files.readAllBytes(resource.toPath()));
        } catch (IOException e) {

            e.printStackTrace();
        }
        HttpEntity<String> response = new HttpEntity<String>(mdmResponse);
        return response;

    }

    @Test
    public void createMDMOrgRequestXML() throws JsonParseException, JsonMappingException, IOException {

        Party party = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:org-files/MainParty_Org_BKRE.json"),
                Party.class);
        Map<String, String> headers = new HashMap<String, String>();
        Map<String, String> queryParameters = new HashMap<String, String>();
        queryParameters.put(OCVConstants.OFFSET_PARAMETER, "2");
        queryParameters.put(OCVConstants.LIMIT_PARAMETER, "10");
        headers.put(OCVConstants.TRACE_ID_HEADER, "Abc5376482");
        headers.put(OCVConstants.USER_ID_HEADER, "Abc5376482");
        APIRequest<Party> apiRequest = new APIRequest<Party>(headers, queryParameters, party);
        String xmlResult = maintainPartyService.createMDMOrgRequestXML(apiRequest);
        System.out.println(xmlResult);
    }

    @Test
    public void validateMaintainPartyFailed() throws Exception {
        Map<String, String> headers = prepareRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();
        Party person = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:SamplePersonInput.json"),
                Party.class);
        String requestTime = "2018-10-01 10:02:00.0";
           File responseXml = ResourceUtils.getFile("classpath:MaintainPartyFailedResponse.xml");
           StreamSource xmlsource = new StreamSource(responseXml);
           StringWriter writer = new StringWriter();
           StreamResult result = new StreamResult(writer);
           TransformerFactory tFactory = TransformerFactory.newInstance();
           Transformer transformer = tFactory.newTransformer();
           transformer.transform(xmlsource, result);
           String strResult = writer.toString();
           HttpEntity<String> response = new HttpEntity<String>(strResult);         
           APIRequest<Party> partyObject = new APIRequest<>(headers, queryParameters, person);
          
           doReturn(response).when(maintainPartyService).invokeBackend(Mockito.any(String.class), Mockito.any(String.class));
          
           String jsonResponse = new String(
                   Files.readAllBytes(ResourceUtils.getFile("classpath:SamplePersonInput.json").toPath()));
           doReturn(jsonResponse).when(maintainPartyService).transformMDMResponse((HttpEntity<String>) any(Object.class),
                   any(String.class));
           try {
               String apiResponse = maintainPartyService.processParty(partyObject, requestTime, "1234", false);
           } catch (Exception ex) {
               String message = ex.getMessage();
               assertTrue(message.contains("5003"));
           }
         
    }
    
    @Test
    public void maintainPartyMDMORGRequestJSONTransformAggregator() throws Exception {

        Map<String, String> headers = prepareRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();
        // Org
        //here---
        doReturn(false).when(idempotencyConfigUtil).isChannelIncluded(any(String.class),Mockito.anyString());
        Party org = new ObjectMapper().readValue(
                ResourceUtils.getFile("classpath:org-files/MainParty_Org_Aggregator.json"),
                Party.class);
        APIRequest<Party> orgObject = new APIRequest<>(headers, queryParameters, org);
        String orgRequest_xml = maintainPartyService.transformPartyRequest(orgObject, null, false);
        System.err.println("orgRequest_xml Aggregator : " + orgRequest_xml);
        assertTrue(orgRequest_xml.contains("Broker - Aggregator"));
        assertTrue(orgRequest_xml.contains("Commercial TPMI"));
        assertTrue(orgRequest_xml.contains("CSP Commercial Broker"));
    }
    
    @Test
    public void maintainPartyForOrgSuccessAggregator() throws HttpException, Exception {
        Map<String, String> headers = prepareRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();
        String requestTime = "2018-10-01 10:02:00.0";
        Party org = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:SampleOrgInputMaintainPartyAggregator.json"),
                Party.class);
        APIRequest<Party> partyObject = new APIRequest<>(headers, queryParameters, org);
        HttpEntity<String> response = getXMLFromFile("classpath:MaintainPartyNonIndResponse.xml");

        String jsonResponse = new String(
                Files.readAllBytes(ResourceUtils.getFile("classpath:OrgJSONResponseAggregator.json").toPath()));
        doReturn(response).when(maintainPartyService).invokeBackend(any(String.class), any(String.class));
        doReturn(jsonResponse).when(maintainPartyService).transformMDMResponse((HttpEntity<String>) any(Object.class),
                any(String.class));
        String apiResponse = maintainPartyService.processParty(partyObject, requestTime, "1234", false);
        assertEquals("Comparison", apiResponse, jsonResponse);
        System.err.println("apiResponse: "+apiResponse);
        System.err.println("jsonResponse: "+jsonResponse);
    }
    
    @Test
    public void maintainPartyMDMRequestPersonJSONTransformIntroducer() throws Exception {
        Map<String, String> headers = prepareRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();
        // Person
        Party person = new ObjectMapper().readValue(
                ResourceUtils.getFile("classpath:person-files/SamplePersonInput_Introducer.json"),
                Party.class);
        APIRequest<Party> personObject = new APIRequest<>(headers, queryParameters, person);
        String samplePerson_xml = maintainPartyService.transformPartyRequest(personObject, null, false);
        System.err.println("sb : " + samplePerson_xml);
        assertTrue(samplePerson_xml.contains("Broker - Introducer"));
        assertTrue(samplePerson_xml.contains("Commercial TPMI-SAO"));
        assertTrue(samplePerson_xml.contains("CSP Commercial Broker"));
    }
    
    @Test
    public void maintainPartyForPersonSuccessIntroducer() throws HttpException, Exception {
        Map<String, String> headers = prepareRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();
        String requestTime = "2018-10-01 10:02:00.0";
        Party person = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:SamplePersonInputIntroducer.json"),
                Party.class);
        APIRequest<Party> partyObject = new APIRequest<>(headers, queryParameters, person);
        HttpEntity<String> xmlResponse = getXMLFromFile("classpath:MaintainPartyIndResponse.xml");

        String jsonResponse = new String(
                Files.readAllBytes(ResourceUtils.getFile("classpath:PersonJSONResponseIntroducer.json").toPath()));

        doReturn(xmlResponse).when(maintainPartyService).invokeBackend(any(String.class), any(String.class));
        doReturn(jsonResponse).when(maintainPartyService).transformMDMResponse((HttpEntity<String>) any(Object.class),
                any(String.class));

        String apiResponse = maintainPartyService.processParty(partyObject, requestTime, "1234", false);
        doReturn(jsonResponse).when(maintainPartyService).transformMDMResponse((HttpEntity<String>) any(Object.class),
                any(String.class));
        assertEquals("Comparison", apiResponse, jsonResponse);
        System.err.println("apiResponse : " + apiResponse);
        System.err.println("jsonResponse  : " + jsonResponse);

    }
    
    /**
     * This test is for the following scenario(s): 1. Checking if the
     * Verification and Validation objects are Passed and transformed correctly
     * 2. Checking Tax-country and No-Tin-Reason object transformed correctly
     * 
     * @throws Exception
     */
    @Test
    public void maintainIndPartyValidationVerficationForTFN() throws HttpException,
            Exception {
        Map<String, String> headers = prepareRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();
        Party person = new ObjectMapper().readValue(
                ResourceUtils.getFile("classpath:TFN-CAP-to-OCV-Ind-with-ValidationVerification.json"),
                Party.class);
        APIRequest<Party> partyObject = new APIRequest<>(headers,
                queryParameters, person);

        
        String xmlBuilt = maintainPartyService.transformPartyRequest(
                partyObject, null, false).toString();
        String verValTaxCountryBuiltXml = xmlBuilt.substring(
                xmlBuilt.indexOf("</KeyValueBObj>"),
                xmlBuilt.indexOf("</PartyWrapperBObj>")).replaceAll("\\s", "");
        
        System.out.println(xmlBuilt);
        assertTrue(xmlBuilt.contains("<IdentificationValue>TIN</IdentificationValue>"));
        assertNotNull(verValTaxCountryBuiltXml);
        assertTrue(verValTaxCountryBuiltXml.contains("XAttrValidationBObj"));
        assertTrue(verValTaxCountryBuiltXml.contains("XAttrVerificationBObj"));
        assertTrue(verValTaxCountryBuiltXml.contains("XContTaxCountryBObj"));
        assertFalse(verValTaxCountryBuiltXml.contains("XNoTinReasonBObj"));

    }
    
    /**
     * This test is for the following scenario(s): 1. Checking if the
     * Verification and Validation objects are Passed and transformed correctly
     * 2. Checking Tax-country and No-Tin-Reason object transformed correctly
     * 
     * @throws Exception
     */
    @Test
    public void maintainIndPartyValidationVerficationForWithoutTFN() throws HttpException,
            Exception {
        Map<String, String> headers = prepareRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();
        Party person = new ObjectMapper().readValue(
                ResourceUtils.getFile("classpath:TFN-CAP-to-OCV-Ind-without-ValidationVerification.json"),
                Party.class);
        APIRequest<Party> partyObject = new APIRequest<>(headers,
                queryParameters, person);
        
        String xmlBuilt = maintainPartyService.transformPartyRequest(
                partyObject, null, false).toString();
        String verValTaxCountryBuiltXml = xmlBuilt.substring(
                xmlBuilt.indexOf("</KeyValueBObj>"),
                xmlBuilt.indexOf("</PartyWrapperBObj>")).replaceAll("\\s", "");
        
        System.out.println(xmlBuilt);
        assertFalse(xmlBuilt.contains("<IdentificationValue>TIN</IdentificationValue>"));
        assertNotNull(verValTaxCountryBuiltXml);
        assertFalse(verValTaxCountryBuiltXml.contains("XAttrValidationBObj"));
        assertFalse(verValTaxCountryBuiltXml.contains("XAttrVerificationBObj"));
        assertTrue(verValTaxCountryBuiltXml.contains("XContTaxCountryBObj"));
        assertTrue(verValTaxCountryBuiltXml.contains("XNoTinReasonBObj"));

    }
    
    /**
     * This test is for the following scenario(s): 1. Checking if the
     * Verification and Validation objects are Passed and transformed correctly
     * 2. Checking Tax-country and No-Tin-Reason object transformed correctly
     * 
     * @throws Exception
     */
    @Test
    public void maintainNonIndPartyValidationVerficationForTFN() throws HttpException,
            Exception {
        Map<String, String> headers = prepareRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();
        Party person = new ObjectMapper().readValue(
                ResourceUtils.getFile("classpath:TFN-CAP-to-OCV-NonInd-with-ValidationVerification.json"),
                Party.class);
        APIRequest<Party> partyObject = new APIRequest<>(headers,
                queryParameters, person);

        String xmlBuilt = maintainPartyService.transformPartyRequest(
                partyObject, null, false).toString();
        String verValTaxCountryBuiltXml = xmlBuilt.substring(
                xmlBuilt.indexOf("</KeyValueBObj>"),
                xmlBuilt.indexOf("</PartyWrapperBObj>")).replaceAll("\\s", "");
        
        System.out.println(xmlBuilt);
        assertTrue(xmlBuilt.contains("<IdentificationValue>TIN</IdentificationValue>"));
        assertNotNull(verValTaxCountryBuiltXml);
        assertTrue(verValTaxCountryBuiltXml.contains("XAttrValidationBObj"));
        assertTrue(verValTaxCountryBuiltXml.contains("XAttrVerificationBObj"));
        assertTrue(verValTaxCountryBuiltXml.contains("XContTaxCountryBObj"));
        assertFalse(verValTaxCountryBuiltXml.contains("XNoTinReasonBObj"));

    }
    
    /**
     * This test is for the following scenario(s): 1. Checking if the
     * Verification and Validation objects are Passed and transformed correctly
     * 2. Checking Tax-country and No-Tin-Reason object transformed correctly
     * 
     * @throws Exception
     */
    @Test
    public void maintainNonIndPartyValidationVerficationForWithoutTFN() throws HttpException,
            Exception {
        Map<String, String> headers = prepareRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();
        Party person = new ObjectMapper().readValue(
                ResourceUtils.getFile("classpath:TFN-CAP-to-OCV-NonInd-without-ValidationVerification.json"),
                Party.class);
        APIRequest<Party> partyObject = new APIRequest<>(headers,
                queryParameters, person);

        
        String xmlBuilt = maintainPartyService.transformPartyRequest(
                partyObject, null, false).toString();
        String verValTaxCountryBuiltXml = xmlBuilt.substring(
                xmlBuilt.indexOf("</KeyValueBObj>"),
                xmlBuilt.indexOf("</PartyWrapperBObj>")).replaceAll("\\s", "");
        
        System.out.println(xmlBuilt);
        assertFalse(xmlBuilt.contains("<IdentificationValue>TIN</IdentificationValue>"));
        assertNotNull(verValTaxCountryBuiltXml);
        assertFalse(verValTaxCountryBuiltXml.contains("XAttrValidationBObj"));
        assertFalse(verValTaxCountryBuiltXml.contains("XAttrVerificationBObj"));
        assertTrue(verValTaxCountryBuiltXml.contains("XContTaxCountryBObj"));
        assertTrue(verValTaxCountryBuiltXml.contains("XNoTinReasonBObj"));

    }


    @Test
    public void maintainPartyForcitizenshipCountry() throws HttpException, Exception {

        Map<String, String> headers = prepareRequestHeaders();
        headers.put("Channel", "FENERGOANZX");
        Map<String, String> queryParameters = new HashMap<String, String>();
        String requestTime = "2018-10-01 10:02:00.0";
        Party person = new ObjectMapper().readValue(
                ResourceUtils.getFile("classpath:SamplePersonAddValANZX.json"),
                Party.class);
        APIRequest<Party> partyObject = new APIRequest<>(headers,
                queryParameters, person);

        String xmlExpected = new String(Files.readAllBytes(ResourceUtils
                .getFile("classpath:MaintainPartyAddresssValidation.xml")
                .toPath()));

        String verValXmlExpected = xmlExpected.substring(
                xmlExpected.indexOf("</XContCitizenshipBObj>"),
                xmlExpected.indexOf("</PartyWrapperBObj>")).replaceAll("\\s",
                "");

        String xmlBuilt = maintainPartyService.transformPartyRequest(
                partyObject, null, false).toString();

        String verValBuiltXml = xmlBuilt.substring(
                xmlBuilt.indexOf("</XContCitizenshipBObj>"),
                xmlBuilt.indexOf("</PartyWrapperBObj>")).replaceAll("\\s", "");


        assertTrue((xmlBuilt.contains("<XContCitizenshipBObj>")));
        assertEquals("Comparison", verValXmlExpected, verValBuiltXml);

    }

    @Test
    public void maintainPartyForcitizenshipTIN() throws HttpException, Exception {

        Map<String, String> headers = prepareRequestHeaders();
        headers.put("Channel", "FENERGOANZX");
        Map<String, String> queryParameters = new HashMap<String, String>();
        String requestTime = "2018-10-01 10:02:00.0";
        Party person = new ObjectMapper().readValue(
                ResourceUtils.getFile("classpath:SamplePersonCombinedANZX.json"),
                Party.class);
        APIRequest<Party> partyObject = new APIRequest<>(headers,
                queryParameters, person);


        String xmlBuilt = maintainPartyService.transformPartyRequest(
                partyObject, null, false).toString();


        assertTrue((xmlBuilt.contains("<XContCitizenshipBObj>")));
        assertTrue(xmlBuilt.contains("<XContTaxCountryBObj>"));

    }


    @Test
    public void createKYCVerificationDeatils() throws Exception {
        Map<String, String> headers = prepareRequestHeaders();
        headers.put(OCVConstants.CHANNEL, "FENERGOANZX");
        Map<String, String> queryParameters = new HashMap<String, String>();
        Party person = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:SampleAssistedVerification.json"),
                Party.class);
        String requestTime = "2018-10-01 10:02:00.0";
        File responseXml = ResourceUtils.getFile("classpath:AssistedVerificationResponse.xml");
        StreamSource xmlsource = new StreamSource(responseXml);
        StringWriter writer = new StringWriter();
        StreamResult result = new StreamResult(writer);
        TransformerFactory tFactory = TransformerFactory.newInstance();
        Transformer transformer = tFactory.newTransformer();
        transformer.transform(xmlsource, result);
        String strResult = writer.toString();
        HttpEntity<String> response = new HttpEntity<String>(strResult);
        APIRequest<Party> partyObject = new APIRequest<>(headers, queryParameters, person);

        doReturn(response).when(maintainPartyService).invokeBackend(Mockito.any(String.class), Mockito.any(String.class));

        String jsonResponse = new String(
                Files.readAllBytes(ResourceUtils.getFile("classpath:SampleAssistedVerification.json").toPath()));
        doReturn(jsonResponse).when(maintainPartyService).transformMDMResponse((HttpEntity<String>) any(Object.class),
                any(String.class));

        String xmlBuilt = maintainPartyService.transformPartyRequest(
                partyObject,null, false).toString();

        assertNotEquals(xmlBuilt.indexOf("<XKycVerificationBObj>"),-1);

        assertTrue(xmlBuilt.contains("XEIDVerificationBObj"));
        assertTrue(xmlBuilt.contains("XEVMatchStatusBObj"));
        //MDM does not want KycDOCObj as it forms from the identifier
        //assertTrue(xmlBuilt.contains("XKycVerificationDocBObj"));


    }

    @Test
    public void maintainPartyMDMRequestPersonJSONTransformPhone() throws Exception {
        Map<String, String> headers = prepareRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();
        // Person
        Party person = new ObjectMapper().readValue(
                ResourceUtils.getFile("classpath:PersonJSONResponse_stndPhone.json"),
                Party.class);
        APIRequest<Party> personObject = new APIRequest<>(headers, queryParameters, person);
        ValidatedParty validatedParty = new ValidatedParty(person,true);
        boolean phoneExits = new APIServiceUtil().isPhoneExists(validatedParty);
        assertTrue(phoneExits);
        
        String samplePerson_xml = maintainPartyService.transformPartyRequest(personObject, null, false);
        System.out.println("samplePerson_xml : " + samplePerson_xml);
        assertNotEquals(samplePerson_xml.indexOf("<PhoneNumber>"),-1);
    }
    
    @Test
    public void maintainPartyMDMRequestOrgJSONTransformPhone() throws Exception {
        Map<String, String> headers = prepareRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();
        // Org
        Party org = new ObjectMapper().readValue(
                ResourceUtils.getFile("classpath:OrgJSONResponse_stdnPhone.json"),
                Party.class);
        APIRequest<Party> orgObject = new APIRequest<>(headers, queryParameters, org);
        ValidatedParty validatedParty = new ValidatedParty(org,true);
        boolean phoneExits = new APIServiceUtil().isPhoneExists(validatedParty);
        
        assertTrue(phoneExits);
        
        String sampleOrg_xml = maintainPartyService.transformPartyRequest(orgObject, null, false);
        System.out.println("sampleOrg_xml : " + sampleOrg_xml);
        assertNotEquals(sampleOrg_xml.indexOf("<PhoneNumber>"),-1);
        assertNotEquals(sampleOrg_xml.indexOf(OCVConstants.COMMERCIAL_MOBILE),-1);
        assertNotEquals(sampleOrg_xml.indexOf(OCVConstants.COMMERCIAL_PHONE),-1);
        assertNotEquals(sampleOrg_xml.indexOf(OCVConstants.COMMERCIAL_FAX),-1);        
        assertEquals(3,StringUtils.countOccurrencesOf(sampleOrg_xml,"<XContactName>"));
        assertEquals(3,StringUtils.countOccurrencesOf(sampleOrg_xml,"<XContactTitle>"));
        assertEquals(3,StringUtils.countOccurrencesOf(sampleOrg_xml,"<XPreferredContactInd>"));
    }

	
	
	@Test
    public void maintainPartyDLCardNumber() throws Exception {
        Map<String, String> headers = prepareRequestHeaders();
        headers.put(OCVConstants.CHANNEL, "FENERGOANZX");
        Map<String, String> queryParameters = new HashMap<String, String>();
        Party person = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:interaction2DLCardNumberVerification.json"),
                Party.class);
        String requestTime = "2018-10-01 10:02:00.0";
        headers.put(OCVConstants.REQUEST_TIMESTAMP, requestTime);
        headers.put("requestMode", "updateCustomerKYC");
        File responseXml = ResourceUtils.getFile("classpath:DLCardNoResponse.xml");
        StreamSource xmlsource = new StreamSource(responseXml);
        StringWriter writer = new StringWriter();
        StreamResult result = new StreamResult(writer);
        TransformerFactory tFactory = TransformerFactory.newInstance();
        Transformer transformer = tFactory.newTransformer();
        transformer.transform(xmlsource, result);
        String strResult = writer.toString();
        HttpEntity<String> response = new HttpEntity<String>(strResult);
        APIRequest<Party> partyObject = new APIRequest<>(headers, queryParameters, person);

        doReturn(response).when(maintainPartyService).invokeBackend(Mockito.any(String.class), Mockito.any(String.class));

        String jsonResponse = new String(
                Files.readAllBytes(ResourceUtils.getFile("classpath:interaction2DLCardNumber.json").toPath()));
        doReturn(jsonResponse).when(maintainPartyService).transformMDMResponse((HttpEntity<String>) any(Object.class),
                any(String.class));

        String xmlBuilt = maintainPartyService.transformPartyRequest(
                partyObject,null, false).toString();
        assertTrue(xmlBuilt.contains("<XIdentifierRelationshipBObj>"));
        assertTrue(xmlBuilt.contains("<XAttrVerificationBObj>"));


    }
    @Test
    public void maintainPartyDLCardNumberInt1() throws Exception {
        Map<String, String> headers = prepareRequestHeaders();
        headers.put(OCVConstants.CHANNEL, "FENERGOANZX");
        Map<String, String> queryParameters = new HashMap<String, String>();
        Party person = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:interaction1DLCardNumber.json"),
                Party.class);
        String requestTime = "2018-10-01 10:02:00.0";
        File responseXml = ResourceUtils.getFile("classpath:DLCardNoResponse.xml");
        StreamSource xmlsource = new StreamSource(responseXml);
        StringWriter writer = new StringWriter();
        StreamResult result = new StreamResult(writer);
        TransformerFactory tFactory = TransformerFactory.newInstance();
        Transformer transformer = tFactory.newTransformer();
        transformer.transform(xmlsource, result);
        String strResult = writer.toString();
        HttpEntity<String> response = new HttpEntity<String>(strResult);
        APIRequest<Party> partyObject = new APIRequest<>(headers, queryParameters, person);

        doReturn(response).when(maintainPartyService).invokeBackend(Mockito.any(String.class), Mockito.any(String.class));

        String jsonResponse = new String(
                Files.readAllBytes(ResourceUtils.getFile("classpath:interaction1DLCardNumber.json").toPath()));
        doReturn(jsonResponse).when(maintainPartyService).transformMDMResponse((HttpEntity<String>) any(Object.class),
                any(String.class));

        String xmlBuilt = maintainPartyService.transformPartyRequest(
                partyObject,null, false).toString();
        assertTrue(xmlBuilt.contains("<XIdentifierRelationshipBObj>"));


    }

}