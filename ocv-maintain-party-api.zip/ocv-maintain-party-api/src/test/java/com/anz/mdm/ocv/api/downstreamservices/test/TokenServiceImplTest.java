package com.anz.mdm.ocv.api.downstreamservices.test;

import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.downsteamservices.TokenServiceImpl;
import com.anz.mdm.ocv.api.exception.VaultBatchInputException;
import com.anz.mdm.ocv.api.model.BatchInput;
import com.anz.mdm.ocv.api.model.BatchResult;
import com.anz.mdm.ocv.api.model.VaultRequest;
import com.anz.mdm.ocv.api.util.VaultUtil;
import com.anz.mdm.ocv.api.validator.APIRequest;
import com.anz.mdm.ocv.party.v1.Party;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.ResourceUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(SpringRunner.class)
@TestPropertySource(properties = {"tokenise.identifierUsageType=TIN,CRN,PersonalTaxNumber,TaxNumber,One Customer ID,DriversLicense,DLCardNumber"})
public class TokenServiceImplTest {

    @Value("${tokenise.identifierUsageType}")
    private String identifierUsageType;

    @Mock
    private RestTemplate tokenRestTemplate;

    @InjectMocks
    private TokenServiceImpl tokenService;

    @Spy
    @InjectMocks
    private VaultUtil vaultUtil;

    final String vaultEndpoint = "http://mock-ocv-vault-endpoint";

    private String traceId = "1234";

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        vaultUtil.setIdentifiers(identifierUsageType);
        tokenService.setMockUtils(vaultEndpoint, vaultUtil);
    }

    @Test
    public void checkVaultTokensInRequest() throws Exception {

        String mockResponseJson = getJsonFromFile("classpath:vault/ocvVaultDeTokens.json");
        ObjectMapper mapper = new ObjectMapper();
        List<BatchResult> mockResponse = mapper.readValue(mockResponseJson, new TypeReference<List<BatchResult>>() {
        });

        ResponseEntity<List<BatchResult>> responseEntity = new ResponseEntity<>(mockResponse, HttpStatus.OK);

        when(tokenRestTemplate.exchange(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(HttpEntity.class),
                ArgumentMatchers.<ParameterizedTypeReference<List<BatchResult>>>any()))
                .thenReturn(responseEntity);

        Party mockParty = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:vault/PartyEncrypt.json"), Party.class);

        ArrayList<Party> parties = new ArrayList<Party>();
        parties.add(mockParty);
        Map<String, String> headers = new HashMap<String, String>();
        Map<String, String> queryParameters = new HashMap<String, String>();
        headers.put("x-b3-traceid", traceId);
        headers.put("channel", "ANZX");
        APIRequest<Party> request = new APIRequest<Party>(headers, queryParameters, mockParty);

        tokenService.decryptSensitiveAttributes(request);

        assertEquals(mockParty.getIdentifiers().get(3).getIdentifier(), "000000045648000031003701");
        assertEquals(mockParty.getIdentifiers().get(3).getRelatedIdentifiers().get(0).getIdentifier(), "000000045648000031003702");

    }

    @Test(expected = VaultBatchInputException.class)
    public void testHitVaultWithADPBatchError() throws Exception {

        String mockRequestJson = getJsonFromFile("classpath:ocvVaultTokensBatchErrorRequest.json");
        String mockResponseJson = getJsonFromFile("classpath:ocvVaultTokensBatchError.json");

        VaultRequest vaultRequest = new ObjectMapper().readValue(mockRequestJson, VaultRequest.class);
        List<BatchInput> batchInputs = vaultRequest.getBatch_input();

        HttpClientErrorException httpClientErrorException = new HttpClientErrorException(HttpStatus.BAD_REQUEST,
                HttpStatus.BAD_REQUEST.name(), mockResponseJson.getBytes(StandardCharsets.UTF_8),
                StandardCharsets.UTF_8);

        when(tokenRestTemplate.exchange(any(String.class), any(), any(),
                Matchers.<ParameterizedTypeReference<List<BatchResult>>>any()))
                .thenThrow(httpClientErrorException);

        List<BatchResult> batchResults = tokenService.hitOCVVaultService(batchInputs, traceId);

        verify(tokenRestTemplate).exchange(any(String.class), any(), any(), any(Class.class));
    }

    private String getJsonFromFile(String path) {
        String mdmResponse = "";
        try {
            File resource = ResourceUtils.getFile(path);
            mdmResponse = new String(Files.readAllBytes(resource.toPath()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return mdmResponse;
    }

}
