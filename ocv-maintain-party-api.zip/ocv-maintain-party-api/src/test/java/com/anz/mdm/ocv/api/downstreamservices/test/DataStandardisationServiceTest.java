package com.anz.mdm.ocv.api.downstreamservices.test;

import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.downsteamservices.DataStandardisationService;
import com.anz.mdm.ocv.api.downsteamservices.StandardisedParty;
import com.anz.mdm.ocv.api.exception.ServiceUnavailableException;
import com.anz.mdm.ocv.api.validator.APIRequest;
import com.anz.mdm.ocv.party.v1.Party;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
public class DataStandardisationServiceTest {

    @InjectMocks
    DataStandardisationService dataStandardisationService;

    @Mock(name = "DataStandardisationRestTemplate")
    RestTemplate restTemplate;

    final String uri = "http://mockserver/party";

    @Captor
    private ArgumentCaptor<HttpEntity<Party>> captor;

    final String acn = "87493580478";
    final String abn = "874935804";
    final String standardisedAcn = "0087493580478";
    final String standardisedAbn = "00874935804";
    final String traceID = "12345";

    @Before
    public void init() {
        dataStandardisationService.setUri(uri);
    }

    @Test
    public void testSuccess() throws Exception {

        final Party party = setParameterisedBody(abn, acn);

        final APIRequest<Party> apiRequest = new APIRequest<>(prepareRequestHeaders(), new HashMap<String, String>(),
                party);

        ResponseEntity<Party> response = new ResponseEntity<>(setParameterisedBody(standardisedAbn, standardisedAcn),
                HttpStatus.OK);

        when(restTemplate.exchange(any(String.class), any(), any(HttpEntity.class), any(Class.class)))
                .thenReturn(response);

        final StandardisedParty standardisedParty = dataStandardisationService.standardiseParty(apiRequest);
        verify(restTemplate).exchange(any(String.class), any(), captor.capture(), any(Class.class));

        final HttpEntity<Party> request = captor.getValue();

        assertEquals(party, request.getBody());
        assertNotEquals(party, standardisedParty.getParty());
        assertEquals(request.getHeaders().get(OCVConstants.TRACE_ID_HEADER).get(0), traceID);
        assertEquals(request.getHeaders().get(OCVConstants.CONTENT_TYPE).get(0), MediaType.APPLICATION_JSON_VALUE);
        assertEquals(request.getHeaders().get(OCVConstants.ACCEPT_HEADER).get(0), MediaType.APPLICATION_JSON_VALUE);
        assertTrue(standardisedParty.getParty().getIdentifiers().get(0).getIdentifier().startsWith("00"));
        assertTrue(standardisedParty.getParty().getIdentifiers().get(1).getIdentifier().startsWith("00"));

    }
    
    @Test
    public void testFailure() throws Exception {

        final Party party = setParameterisedBody(abn, acn);

        final APIRequest<Party> apiRequest = new APIRequest<>(prepareRequestHeaders(), new HashMap<String, String>(),
                party);

        ResponseEntity<Party> response = new ResponseEntity<>(setParameterisedBody(standardisedAbn, standardisedAcn),
                HttpStatus.OK);

        when(restTemplate.exchange(any(String.class), any(), any(HttpEntity.class), any(Class.class)))
        .thenThrow(new ServiceUnavailableException("UnAuthorizedMDMException: 5006"));
        try {
            final StandardisedParty standardisedParty = dataStandardisationService.standardiseParty(apiRequest);
        }catch(Exception ex) {
            String message = ex.getMessage();
            //assertTrue(message.contains("UnAuthorizedMDMException: 5006"));
        }
              

    }

    private Party setParameterisedBody(final String abn, final String acn)
            throws JsonParseException, JsonMappingException, IOException {

        final String jsonString = "{\r\n" + "\"partyType\" : \"Non individual\",\r\n" + "\"identifiers\" : [{\r\n"
                + "\"identifierUsageType\" : \"ABN\",\r\n" + "\"identifier\" : \"" + abn + "\"\r\n" + "},{\r\n"
                + "\"identifierUsageType\" : \"ACN\",\r\n" + "\"identifier\" : \"" + acn + "\"\r\n" + "}],\r\n"
                + "\"names\":[{\"name\":\"ANZ\"}\r\n" + "    ]\r\n" + "}";
        final Party party = new ObjectMapper().readValue(jsonString, Party.class);
        return party;
    }

    private Map<String, String> prepareRequestHeaders() {
        final Map<String, String> headers = new HashMap<String, String>();
        headers.put(OCVConstants.ACCEPT_HEADER, "application/json");
        headers.put(OCVConstants.TRACE_ID_HEADER, "12345");
        headers.put(OCVConstants.AUTHORIZATION_HEADER, "5237vxhsfdfyif");
        return headers;
    }

}
