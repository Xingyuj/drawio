package com.anz.mdm.ocv.api.downstreamservices.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.http.HttpException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.ResourceUtils;
import org.springframework.web.client.RestTemplate;

import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.downsteamservices.MaintainPartyService;
import com.anz.mdm.ocv.api.downsteamservices.DeletePartyService;
import com.anz.mdm.ocv.api.exception.RecordNotFoundException;
import com.anz.mdm.ocv.api.processor.MaintainPartyServiceProcessor;
import com.anz.mdm.ocv.api.processor.DeletePartyServiceProcessor;
import com.anz.mdm.ocv.api.util.RequestTransfomerUtil;
import com.anz.mdm.ocv.api.validator.APIRequest;
import com.anz.mdm.ocv.api.validator.MaintainPartyValidator;
import com.anz.mdm.ocv.api.validator.DeletePartyValidator;
import com.anz.mdm.ocv.api.validator.ValidationResult;
import com.anz.mdm.ocv.common.v1.SourceSystem;
import com.anz.mdm.ocv.party.v1.Party;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@PrepareForTest({ DeletePartyValidator.class, DeletePartyServiceProcessor.class, DeletePartyService.class,
        RecordNotFoundException.class })
@RunWith(SpringRunner.class)
public class DeletePartyServiceTest {

    @InjectMocks
    @Spy
    DeletePartyService deletePartyService;

    DeletePartyServiceProcessor deletePartyServiceProcessor;

    RequestTransfomerUtil requestTransfomer;

    DeletePartyValidator deletePartyValidator;
    
    @Mock(name = "DeletePartyServiceMDMRestTemplate")
    RestTemplate restTemplate;
    
    final String uri = "https://localhost:8443/com.ibm.mdm.server.ws.restful/resources/MDMWSRESTful";

    @Before
    public void setUp() throws IOException {

        deletePartyValidator = new DeletePartyValidator();
        deletePartyValidator = spy(deletePartyValidator);
        
        deletePartyService.setUrl(uri);

       

        deletePartyServiceProcessor = new DeletePartyServiceProcessor();
        deletePartyServiceProcessor = spy(deletePartyServiceProcessor);

    }

    /**
     * This test is for the following scenario(s): 1.) Conversion of JSON Request to
     * MDM XML for Delete
     * 
     * @throws HttpException
     * @throws Exception
     */
    @Test
    public void deletePartyMDMRequestTransform() throws Exception {

        Map<String, String> headers = prepareRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();
        String sourceSytemID = "430";
        String sourceSytemName = "CAP-CIS";
        Party party = new Party();
        SourceSystem sourceSystem = new SourceSystem();
        sourceSystem.setSourceSystemId(sourceSytemID);
        sourceSystem.setSourceSystemName(sourceSytemName);
        party.getSourceSystems().add(sourceSystem);
        APIRequest<Party> orgObject = new APIRequest<>(headers, queryParameters, party);
        String sb = deletePartyService.transformDeletePartyRequest(orgObject); // Delete Party XML returning
        System.out.println("sb ---->: " + sb);
        assertTrue(sb.contains("AdminPartyId"));
        assertTrue(sb.contains("AdminSystemValue"));
    }

    /**
     * This test is for the following scenario(s): 1.) End to End Delete Party
     * 
     * @throws Exception
     */
    @Test
    public void deletePartySuccess() throws HttpException, Exception {
        Map<String, String> headers = prepareRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();
        String requestTime = "2018-10-01 10:02:00.0";
        String sourceSytemID = "430";
        String sourceSytemName = "CAP-CIS";
        String message = "The party history record for the party was successfully deleted";
        Party party = new Party();
        SourceSystem sourceSystem = new SourceSystem();
        sourceSystem.setSourceSystemId(sourceSytemID);
        sourceSystem.setSourceSystemName(sourceSytemName);
        party.getSourceSystems().add(sourceSystem);
        APIRequest<Party> apiRequest = new APIRequest<>(headers, queryParameters, party);
        HttpEntity<String> response = getXMLFromFile("classpath:PurgePartyResponse.xml");
        String jsonResponse = new String(
                Files.readAllBytes(ResourceUtils.getFile("classpath:SamplePurgePartyResponse.json").toPath()));
        
        ResponseEntity<String> serviceResponse = new ResponseEntity<>(response.getBody(),
                HttpStatus.OK);
        doReturn(serviceResponse).when(restTemplate).exchange(any(String.class), any(), any(HttpEntity.class),
                any(Class.class));
        doReturn(jsonResponse).when(deletePartyService).transformMDMResponse((HttpEntity<String>) any(Object.class),
                any(String.class));
        String apiResponse = deletePartyService.processDeleteParty(apiRequest, requestTime, "1234"); // JSON response
                                                                                                     // returning
        assertEquals("Purge Response from MDM Validation", apiResponse, jsonResponse);
        assertEquals("purge Success Message:", jsonResponse.contains(message), apiResponse.contains(message));
    }

    private Map<String, String> prepareRequestHeaders() {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put(OCVConstants.ACCEPT_HEADER, "application/json");
        headers.put(OCVConstants.TRACE_ID_HEADER, "abc123");
        headers.put(OCVConstants.AUTHORIZATION_HEADER, "5237vxhsfdfyif");
        headers.put(OCVConstants.REQUEST_TIMESTAMP, "2018-09-09");
        headers.put(OCVConstants.USER_ID_HEADER, "tester");
        return headers;
    }

    private HttpEntity<String> getXMLFromFile(String path) {
        String mdmResponse = "";
        try {
            File resource = ResourceUtils.getFile(path);
            mdmResponse = new String(Files.readAllBytes(resource.toPath()));
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        HttpEntity<String> response = new HttpEntity<String>(mdmResponse);
        return response;

    }

    @Test
    public void deletePartyFailedForTimestamp() throws HttpException, Exception {
        Map<String, String> headers = prepareRequestTimestampForFailure();
        Map<String, String> queryParameters = new HashMap<String, String>();
        String sourceSytemID = "430";
        String sourceSytemName = "CAP-CIS";
        Party party = new Party();
        SourceSystem sourceSystem = new SourceSystem();
        sourceSystem.setSourceSystemId(sourceSytemID);
        sourceSystem.setSourceSystemName(sourceSytemName);
        party.getSourceSystems().add(sourceSystem);
        APIRequest<Party> apiRequest = new APIRequest<>(headers, queryParameters, party);
        assertEquals("Validation Failed due to Timestamp in Header missing",
                deletePartyValidator.validateRequest(apiRequest).getErrorCode(),
                OCVConstants.MANDATORY_HEADER_MISSING_ERROR_CODE);
    }

    @Test
    public void deletePartyFailedForAcceptHeader() throws HttpException, Exception {
        Map<String, String> headers = prepareRequestAcceptHeaderForFailure();
        Map<String, String> queryParameters = new HashMap<String, String>();
        String sourceSytemID = "430";
        String sourceSytemName = "CAP-CIS";
        Party party = new Party();
        SourceSystem sourceSystem = new SourceSystem();
        sourceSystem.setSourceSystemId(sourceSytemID);
        sourceSystem.setSourceSystemName(sourceSytemName);
        party.getSourceSystems().add(sourceSystem);
        APIRequest<Party> apiRequest = new APIRequest<>(headers, queryParameters, party);
        assertEquals("Validation Failed due to AcceptHeader missing",
                deletePartyValidator.validateRequest(apiRequest).getErrorCode(),
                OCVConstants.MANDATORY_HEADER_MISSING_ERROR_CODE);
    }

    @Test
    public void deletePartyFailedForSysID() throws HttpException, Exception {
        Map<String, String> headers = prepareRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();
        String sourceSytemName = "CAP-CIS";
        Party party = new Party();
        SourceSystem sourceSystem = new SourceSystem();
        sourceSystem.setSourceSystemName(sourceSytemName);
        party.getSourceSystems().add(sourceSystem);
        APIRequest<Party> apiRequest = new APIRequest<>(headers, queryParameters, party);
        assertEquals("Validation Failed due to SysID missing",
                deletePartyValidator.validateBody(apiRequest).getErrorCode(),
                OCVConstants.MANDATORY_ATTRIBUTES_MISSING);
    }

    @Test
    public void deletePartyFailedForSysName() throws HttpException, Exception {
        Map<String, String> headers = prepareRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();
        String sourceSytemID = "430";
        Party party = new Party();
        SourceSystem sourceSystem = new SourceSystem();
        sourceSystem.setSourceSystemId(sourceSytemID);
        party.getSourceSystems().add(sourceSystem);
        APIRequest<Party> apiRequest = new APIRequest<>(headers, queryParameters, party);
        assertEquals("Validation Failed due to SysName missing",
                deletePartyValidator.validateBody(apiRequest).getErrorCode(),
                OCVConstants.MANDATORY_ATTRIBUTES_MISSING);
    }

    /**
     * This test is for the following scenario(s): 1.) Delete Party Error for System
     * ID not presents
     * 
     * @throws Exception
     */
    @Test
    public void deletePartyFailed() throws HttpException, Exception {
        HttpEntity<String> response = getXMLFromFile("classpath:PurgeParyFailedResponse.xml");
        String jsonResponse = new String(
                Files.readAllBytes(ResourceUtils.getFile("classpath:PurgePartyFailedResJson.json").toPath()));
        doReturn(jsonResponse).when(deletePartyService).transformMDMResponse((HttpEntity<String>) any(Object.class),
                any(String.class));
        String failedJsonResponse = deletePartyService.transformMDMResponse(response, "123456");
        assertEquals("Failed Purge Response from MDM Validation", jsonResponse, failedJsonResponse);
        assertTrue(failedJsonResponse.contains("Party requested for purge not found."));
    }

    private Map<String, String> prepareRequestTimestampForFailure() {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put(OCVConstants.ACCEPT_HEADER, "application/json");
        headers.put(OCVConstants.TRACE_ID_HEADER, "abc123");
        headers.put(OCVConstants.AUTHORIZATION_HEADER, "5237vxhsfdfyif");
        // headers.put(OCVConstants.REQUEST_TIMESTAMP, "2018-09-09");
        headers.put(OCVConstants.USER_ID_HEADER, "tester");
        return headers;
    }

    private Map<String, String> prepareRequestAcceptHeaderForFailure() {
        Map<String, String> headers = new HashMap<String, String>();
        // headers.put(OCVConstants.ACCEPT_HEADER, "application/json");
        headers.put(OCVConstants.TRACE_ID_HEADER, "abc123");
        headers.put(OCVConstants.AUTHORIZATION_HEADER, "5237vxhsfdfyif");
        headers.put(OCVConstants.REQUEST_TIMESTAMP, "2018-09-09");
        headers.put(OCVConstants.USER_ID_HEADER, "tester");
        return headers;
    }

}