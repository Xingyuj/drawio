
package com.anz.mdm.ocv.api.transform.test;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.nio.file.Files;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.HttpEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.ResourceUtils;

import com.anz.mdm.ocv.api.transform.Context;
import com.anz.mdm.ocv.api.transform.DataTransformer;
import com.anz.mdm.ocv.api.transform.DataTransformerFactory;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

@RunWith(SpringRunner.class)
public class DataTransformerTest {

    TransformerFactory tFactory = TransformerFactory.newInstance();
    DataTransformer dataTransformer = new DataTransformer(tFactory);
    ResourceLoader resourceLoader = new DefaultResourceLoader();

    @Test 
    public void transformXmlResponseToJson_test() throws TransformerException, IOException { 
        File responseXml =  ResourceUtils.getFile("classpath:MaintainPartyIndResponse.xml"); 
        StreamSource  xmlsource = new StreamSource(responseXml); 
        StringWriter writer = new  StringWriter(); 
        StreamResult result = new StreamResult(writer);
        TransformerFactory tFactory = TransformerFactory.newInstance(); 
        Transformer  transformer = tFactory.newTransformer(); 
        transformer.transform(xmlsource,  result); 
        String strResult = writer.toString();
        HttpEntity<String> response =  new HttpEntity<String>(strResult); 
        Resource resource =  resourceLoader.getResource("classpath:templates/maintainPartyTransform.xsl"); 
        String  jsonResponse = new String(  Files.readAllBytes(ResourceUtils.getFile("classpath:MaintainPartyInd.json").toPath())); 
        Gson gson = new Gson(); 
        JsonElement jsonElement =  gson.fromJson(jsonResponse, JsonElement.class); 
        JsonObject jsonObject =  jsonElement.getAsJsonObject();
        // this check is required as part of GSON to  replace json array contains, 
        jsonResponse =  jsonObject.toString().replaceFirst(",null", ""); 
        DataTransformerFactory  factory = DataTransformerFactory.getInstance(); 
        Transformer  transformerInstance = factory.getTransformer(Context.PARTYAPI, "1234");
        String expectedResult = jsonResponse.replaceAll("\\s+", ""); 
        String  actualResult = dataTransformer.transformData(response, transformerInstance,  "Test123", Context.PARTYAPI) .replaceAll("\\s+", "");
  
        System.err.println("Actual: "+ actualResult); 
        JsonElement actualJsonElement =  gson.fromJson(actualResult, JsonElement.class); 
        JsonObject actualJsonObject =  actualJsonElement.getAsJsonObject(); 
        // this check is required as part of  GSON to replace json array contains, 
        actualResult =  actualJsonObject.toString().replaceFirst(",null", "");
        actualResult =  actualResult.replaceAll("\\s+", ""); 
        //System.out.println("Actual: "+  actualResult); 
        System.err.println("Expected: "+ expectedResult);
        assertEquals(expectedResult, actualResult); 
     }
}
