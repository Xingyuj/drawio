package com.anz.mdm.api.interceptor.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.cache.CacheManager;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.ResourceUtils;

import com.anz.mdm.ocv.api.UAMAccessConfiguration;
import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.downsteamservices.JWTService;
import com.anz.mdm.ocv.api.interceptor.JWTInterceptor;
import com.anz.mdm.ocv.api.validator.APIRequest;
import com.anz.mdm.ocv.jwt.exception.EndpointTimeoutException;
import com.anz.mdm.ocv.jwt.validator.impl.JWTKeySourceLoaderImpl;
import com.anz.mdm.ocv.jwt.validator.impl.JWTSignatureValidatorServiceImpl;
import com.anz.mdm.ocv.party.v1.Party;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.jwk.source.ImmutableJWKSet;
import com.nimbusds.jose.jwk.source.JWKSource;
import com.nimbusds.jose.proc.SecurityContext;

@RunWith(SpringRunner.class)
@ContextConfiguration
public class JWTInterceptorTest {

    private JWTInterceptor jwtInterceptor;
    private JWTService jwtService;
    private JWTSignatureValidatorServiceImpl jwtsignatureValidatorServiceImpl;
    private JWTKeySourceLoaderImpl keySourceLoader;
    private UAMAccessConfiguration uamAccessConfiguration;
    CacheManager cacheManager;
    JWKSource<SecurityContext> keySourceFromFile;

    String jwksKeysPathSTI = "https://auth.service.dev/oidc/.well-known/jwks.json";
    String jwksKeysPathANZx = "https://identity-services-sit-int-gw.apps-int.x.gcpnp.anz/am/oauth2/customer/connect/jwk_uri";
    String jwjsKeysPathMMLO = "https://apisittoken.corp.dev.anz:8448/auth/.well-known/jwks.json";

    @Before
    public void setup() throws Exception {
        jwtsignatureValidatorServiceImpl = new JWTSignatureValidatorServiceImpl(keySourceLoader, cacheManager);
        jwtsignatureValidatorServiceImpl = spy(jwtsignatureValidatorServiceImpl);

        uamAccessConfiguration = new UAMAccessConfiguration();
        uamAccessConfiguration = spy(uamAccessConfiguration);

        jwtService = new JWTService(jwtsignatureValidatorServiceImpl);
        jwtService = spy(jwtService);

        jwtInterceptor = new JWTInterceptor(jwtService, uamAccessConfiguration);

        File jwksJson = ResourceUtils.getFile("classpath:keySourceFromFile.json");
        JWKSet jwkSet = JWKSet.load(jwksJson);
        keySourceFromFile = new ImmutableJWKSet<>(jwkSet);
        doReturn(keySourceFromFile).when(jwtsignatureValidatorServiceImpl).fetchKeySource(jwksKeysPathSTI);
        doReturn(keySourceFromFile).when(jwtsignatureValidatorServiceImpl).fetchKeySource(jwksKeysPathANZx);
        doReturn(keySourceFromFile).when(jwtsignatureValidatorServiceImpl).fetchKeySource(jwjsKeysPathMMLO);

        Map<String, String> uamIssuerList = prepareIssuerPropertiesMap();
        Map<String, String> channelList = prepareChannelPropertiesMap();

        doReturn(uamIssuerList).when(uamAccessConfiguration).getIssuer("UAM", "ISSUER");
        doReturn(channelList).when(uamAccessConfiguration).getIssuer("JWT", "VALIDATION");

    }

    @Test
    public void validateJWTTest_STI_validJWT() throws Exception {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put(OCVConstants.TRACE_ID_HEADER, "537647");
        headers.put(OCVConstants.AUTHORIZATION_HEADER,
                "bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Im0xcHdPMHNpTmVIbUJSd2JQZGVMVms3VUtEVTcxOG5ZWVBnUU5oUVRvdzQifQ.eyJzY29wZXMiOlsib3BlbmlkIiwiQVUuQU5aX0lOVEVSTkFMLk9DVi5DRFAuQUNDRVNTLlJFQUQiXSwiZXhwIjoxNjE2NDY2MzE2LCJzdWIiOiJDU1BVc3IyQEdMT0JBTFRFU1QuQU5aLkNPTSIsImF1ZCI6IjhiZjU1NGI1LWJiZjktNDRjMi1hOGI3LTM0ZmNiMmEwYWRhOSIsImlzcyI6Imh0dHBzOlwvXC9hdXRoLnNlcnZpY2UuZGV2XC9vaWRjIiwiaWF0IjoxNjE2NDY1NDE2LCJhY3IiOiJJQUwzLkFBTDEuRkFMMSIsImFtciI6WyJ3aWEiXX0.TDl9XV7jpbzptcThZrEiw0R2pBp91egJlvRN0isScw6MrxZMp-tcvBkqMvB3wUuJjNU_sEdYysvIQrf7YstqhOfIbzr8coD0TndNcFWh-tnuVkzkE56g0JGgsjyhaiCqvN4ZLBdQ2_S_1krV_nF4gKJrHibLTlDnitx2slQJZ9NEJlfebcpLNXCHboKLaWsCdFZA-Gdq613hytRboQiYUPbMUeWoum6mDxBnMUQpRUBu8o8ZOeVgAi9AAux7t-j8hbJ52qoJ1pi271eokQeeYbQSdCSf0hI2X8Ur6NSf7tYCLCeqVvaquCPo4FrP5tJPBBHXmNSBsTJ2mOorvw37Pg");
        headers.put(OCVConstants.ACCEPT_HEADER, "application/json");
        headers.put(OCVConstants.CHANNEL, "CDP");
        String jsonString = "{\r\n" + "\"partyType\" : \"O\",\r\n" + "\"status\" : \"active\",\r\n"
                + "\"organisationType\" : \"CZ\",\r\n" + "\"identifiers\" : [\r\n" + "{\r\n"
                + "\"identifierUsageType\" : \"Drivers Licence\",\r\n" + "\"identifier\" : \"221321312\"\r\n" + "},\r\n"
                + "{\r\n" + "\"identifierUsageType\" : \"CACHE Key\",\r\n" + "\"identifier\" : \"2-CMPRINTER-1\"\r\n"
                + "}\r\n" + "],\r\n" + "\"names\":[\r\n" + "{\r\n" + "\"firstName\":\"CMFR PROPTY LTD\",\r\n"
                + "\"lastName\" : \"CMFR PROPTY LTD\"\r\n" + "}\r\n" + "],\r\n" + "\"addresses\" : [\r\n" + "{\r\n"
                + "\"addressLineOne\" : \"35 GEDDES STREET\"}\r\n" + "]\r\n" + "} ";
        Party party = new ObjectMapper().readValue(jsonString, Party.class);
        Map<String, String> queryParameters = new HashMap<String, String>();
        APIRequest<Party> apiRequest = new APIRequest<Party>(headers, queryParameters, party);

        try {
            jwtInterceptor.validateJWT(apiRequest);
            // fail();
        } catch (Exception e) {
            String exceptionMsg = e.getMessage();
            assertTrue(exceptionMsg.contains("4014"));
        }
    }

    @Test
    public void validateJWTTest_STI_expiredJWT() throws Exception {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put(OCVConstants.TRACE_ID_HEADER, "537647");
        headers.put(OCVConstants.AUTHORIZATION_HEADER,
                "bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Im0xcHdPMHNpTmVIbUJSd2JQZGVMVms3VUtEVTcxOG5ZWVBnUU5oUVRvdzQifQ.eyJzY29wZXMiOlsib3BlbmlkIiwiQVUuUkVUQUlMLkNVU1RPTUVSUFJPRklMRS5SRUFEIl0sImV4cCI6MTU3OTU2MzI3NSwic3ViIjoiQ1NQVXNyMkBHTE9CQUxURVNULkFOWi5DT00iLCJhdWQiOiI4YmY1NTRiNS1iYmY5LTQ0YzItYThiNy0zNGZjYjJhMGFkYTkiLCJpc3MiOiJodHRwczpcL1wvYXV0aC5zZXJ2aWNlLmRldlwvb2lkYyIsImlhdCI6MTU3OTU2MjM3NSwiYWNyIjoiSUFMMy5BQUwxLkZBTDEiLCJhbXIiOlsid2lhIl19.WnSOEoxCcT965IE026GVFH0BTneG7QJ1d-Ou7kHVWezM8EcSLTyAjQ_8ElCP18T3P0tzb4_Detc_sMIqqLa4saCjLfSjbJdP2vi52D9sY6GwoduUrwggOgqfL3lTUDMKlmnZyBTokCmCgr5t85TGNsDWKrHiTxxx67xJhCezB3R7H9eU5QJ501AZeaeovxoS4bMhRuBejXTO4Em46LFS2iKHG8y219Qw01krPbZr2mXg4JJbKIBdFqnV7C1fMi3ANfmXIPC16bxxPROSb8WnOTPitAIdHBe_zAUYTDgYI5q89PiZWnZ8hV11Jwxl3FpI8kf8PjdNCapKlalv04235g");
        headers.put(OCVConstants.ACCEPT_HEADER, "application/json");
        headers.put(OCVConstants.CHANNEL, "CDP");
        String jsonString = "{\r\n" + "\"partyType\" : \"O\",\r\n" + "\"status\" : \"active\",\r\n"
                + "\"organisationType\" : \"CZ\",\r\n" + "\"identifiers\" : [\r\n" + "{\r\n"
                + "\"identifierUsageType\" : \"Drivers Licence\",\r\n" + "\"identifier\" : \"221321312\"\r\n" + "},\r\n"
                + "{\r\n" + "\"identifierUsageType\" : \"CACHE Key\",\r\n" + "\"identifier\" : \"2-CMPRINTER-1\"\r\n"
                + "}\r\n" + "],\r\n" + "\"names\":[\r\n" + "{\r\n" + "\"firstName\":\"CMFR PROPTY LTD\",\r\n"
                + "\"lastName\" : \"CMFR PROPTY LTD\"\r\n" + "}\r\n" + "],\r\n" + "\"addresses\" : [\r\n" + "{\r\n"
                + "\"addressLineOne\" : \"35 GEDDES STREET\"}\r\n" + "]\r\n" + "} ";
        Party party = new ObjectMapper().readValue(jsonString, Party.class);
        Map<String, String> queryParameters = new HashMap<String, String>();
        APIRequest<Party> apiRequest = new APIRequest<Party>(headers, queryParameters, party);

        try {
            jwtInterceptor.validateJWT(apiRequest);
        } catch (Exception e) {
            String exceptionMsg = e.getMessage();
            assertTrue(exceptionMsg.contains("4014"));
        }
    }

    @Test
    public void validateJWTTest_STI_InvalidIssuer() throws Exception {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put(OCVConstants.TRACE_ID_HEADER, "537647");
        headers.put(OCVConstants.AUTHORIZATION_HEADER,
                "bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Im0xcHdPMHNpTmVIbUJSd2JQZGVMVms3VUtEVTcxOG5ZWVBnUU5oUVRvdzQifQ.eyJzY29wZXMiOlsib3BlbmlkIiwiQVUuUkVUQUlMLkNVU1RPTUVSUFJPRklMRS5SRUFEIl0sImV4cCI6MTU3OTU2MzI3NSwic3ViIjoiQ1NQVXNyMkBHTE9CQUxURVNULkFOWi5DT00iLCJhdWQiOiI4YmY1NTRiNS1iYmY5LTQ0YzItYThiNy0zNGZjYjJhMGFkYTkiLCJpc3MiOiJodHRwczpcL1wvYXV0aC5zZXJ2aWNlLmRldlwvb2lkYyIsImlhdCI6MTU3OTU2MjM3NSwiYWNyIjoiSUFMMy5BQUwxLkZBTDEiLCJhbXIiOlsid2lhIl19.WnSOEoxCcT965IE026GVFH0BTneG7QJ1d-Ou7kHVWezM8EcSLTyAjQ_8ElCP18T3P0tzb4_Detc_sMIqqLa4saCjLfSjbJdP2vi52D9sY6GwoduUrwggOgqfL3lTUDMKlmnZyBTokCmCgr5t85TGNsDWKrHiTxxx67xJhCezB3R7H9eU5QJ501AZeaeovxoS4bMhRuBejXTO4Em46LFS2iKHG8y219Qw01krPbZr2mXg4JJbKIBdFqnV7C1fMi3ANfmXIPC16bxxPROSb8WnOTPitAIdHBe_zAUYTDgYI5q89PiZWnZ8hV11Jwxl3FpI8kf8PjdNCapKlalv04235g");
        headers.put(OCVConstants.ACCEPT_HEADER, "application/json");
        headers.put(OCVConstants.CHANNEL, "XYZ");
        String jsonString = "{\r\n" + "\"partyType\" : \"O\",\r\n" + "\"status\" : \"active\",\r\n"
                + "\"organisationType\" : \"CZ\",\r\n" + "\"identifiers\" : [\r\n" + "{\r\n"
                + "\"identifierUsageType\" : \"Drivers Licence\",\r\n" + "\"identifier\" : \"221321312\"\r\n" + "},\r\n"
                + "{\r\n" + "\"identifierUsageType\" : \"CACHE Key\",\r\n" + "\"identifier\" : \"2-CMPRINTER-1\"\r\n"
                + "}\r\n" + "],\r\n" + "\"names\":[\r\n" + "{\r\n" + "\"firstName\":\"CMFR PROPTY LTD\",\r\n"
                + "\"lastName\" : \"CMFR PROPTY LTD\"\r\n" + "}\r\n" + "],\r\n" + "\"addresses\" : [\r\n" + "{\r\n"
                + "\"addressLineOne\" : \"35 GEDDES STREET\"}\r\n" + "]\r\n" + "} ";
        Party party = new ObjectMapper().readValue(jsonString, Party.class);
        Map<String, String> queryParameters = new HashMap<String, String>();
        APIRequest<Party> apiRequest = new APIRequest<Party>(headers, queryParameters, party);

        try {
            jwtInterceptor.validateJWT(apiRequest);
        } catch (EndpointTimeoutException e) {
            String exceptionMsg = e.getMessage();
            assertEquals(exceptionMsg.contains("4013"), "Invalid Issuer");
        } catch (Exception e) {
            String exceptionMsg = e.getMessage();
            assertTrue(exceptionMsg.contains("4014"));
        }
    }

    @Test
    public void validateJWTTest_FR_validJWT() throws Exception {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put(OCVConstants.TRACE_ID_HEADER, "537647");
        headers.put(OCVConstants.AUTHORIZATION_HEADER,
                "bearer eyJ0eXAiOiJKV1QiLCJ4NXQiOiJaMVZoUVdsZlQwUmZMVzl0YWxVeFptRkVVek5wVkROWk0xVk1hSFJVUVdOa1VGOXRYMUJsY205dFRXNVNVVjgyVEV0YVNYZGpUSEpXWVZWWk4zVXpTaTAzVlhFdFVreFBURU5yTkhsa01UTm9aM0JyWVZFIiwia2lkIjoiUkxQTG8ycnNUS2ZESENhcisxODlnM0d0bmxRPSIsImFsZyI6IlJTNTEyIn0.eyJzdWIiOiJlNjA2NWM3Zi04MTU0LTQ3OTUtODRiOC01ZTQ4ZDJjNTMwYWIiLCJjdHMiOiJPQVVUSDJfU1RBVEVMRVNTX0dSQU5UIiwicGVyc29uYSI6eyJfaWQiOiJkOTFhY2Y1NC00Yzg3LTQ4YWEtODVhOS1kZDQxYzcyYzU0Y2QiLCJ0eXBlIjoicmV0YWlsIn0sImFtciI6WyJvdHAiLCJwaW4iXSwiaXNzIjoiaHR0cHM6Ly9pZGVudGl0eS1zZXJ2aWNlcy1zaXQtaW50LWd3LmFwcHMtaW50LnguZ2NwbnAuYW56L2FtL29hdXRoMi9jdXN0b21lciIsInRva2VuTmFtZSI6ImFjY2Vzc190b2tlbiIsImFjdGl2ZSI6dHJ1ZSwidG9rZW5fdHlwZSI6IkJlYXJlciIsIm5vbmNlIjoiNmEyMmNiNjdhZiIsImNsaWVudF9pZCI6ImFtLWludGVybmFsIiwiYXVkIjoiZmVuZXJnbyIsImFjciI6IklBTDMuQUFMMy5GQUwxIiwibmJmIjoxNjE2NDYyNDgxLCJncmFudF90eXBlIjoiYW56OnNzb3Rva2VuIiwic2NvcGUiOlsiYXUucmV0YWlsLmZlbmVyZ28ubGVnYWxlbnRpdHkud3JpdGUiLCJhdS5yZXRhaWwuZmVuZXJnby5sZWdhbGVudGl0eS5yZWFkIiwiYXUucmV0YWlsLmZlbmVyZ28uZm9ybS5yZWFkIiwiYWVnaXMtaW50cm9zcGVjdCJdLCJyZWFsbSI6Ii9jdXN0b21lciIsInNjb3BlcyI6WyJhdS5yZXRhaWwuZmVuZXJnby5sZWdhbGVudGl0eS53cml0ZSIsImF1LnJldGFpbC5mZW5lcmdvLmxlZ2FsZW50aXR5LnJlYWQiLCJhdS5yZXRhaWwuZmVuZXJnby5mb3JtLnJlYWQiLCJhZWdpcy1pbnRyb3NwZWN0Il0sImV4cCI6MTYxNjQ2Mjc4MSwiaWF0IjoxNjE2NDYyNDgxLCJleHBpcmVzX2luIjozMDAsImp0aSI6Ijk5NjIyY2MxLTU0NTAtNDFjNC1iODRmLWY4NDg3MjRjMDkwZiJ9.SprjW0kEGpziNWmmXpui8t1cfroCIp2ccSGoA9lqbOQ2tRXScJRRVu9c0j1nTCYrQoQclBOSZuthqsLMLDbA_mIg3-B34cTJvdRdycs09fqhHAtlHQItLtSAWSvflCV-U_zN9IYtJ7KO3dBuUoIPsGqVmcFIwq4yprEFA5ZbFxYaGbNh5SC4ev867WZvhjxqfyTYAPFBsKgfiHo4hLEOCho5G0myloPBoIlALUTR0rFdnixkF0-LjfDYPNu7zcwf38gS-Hp-Dkzpc1w-zdVI98ZPQlkBPzl-Al87gZzQaY2e7Z_H3YcE8BcZYleLJIN9O2IGpED64NkL_I4sThmjaQ");
        headers.put(OCVConstants.ACCEPT_HEADER, "application/json");
        headers.put(OCVConstants.CHANNEL, "ANZx");
        String jsonString = "{\r\n" + "\"partyType\" : \"O\",\r\n" + "\"status\" : \"active\",\r\n"
                + "\"organisationType\" : \"CZ\",\r\n" + "\"identifiers\" : [\r\n" + "{\r\n"
                + "\"identifierUsageType\" : \"Drivers Licence\",\r\n" + "\"identifier\" : \"221321312\"\r\n" + "},\r\n"
                + "{\r\n" + "\"identifierUsageType\" : \"CACHE Key\",\r\n" + "\"identifier\" : \"2-CMPRINTER-1\"\r\n"
                + "}\r\n" + "],\r\n" + "\"names\":[\r\n" + "{\r\n" + "\"firstName\":\"CMFR PROPTY LTD\",\r\n"
                + "\"lastName\" : \"CMFR PROPTY LTD\"\r\n" + "}\r\n" + "],\r\n" + "\"addresses\" : [\r\n" + "{\r\n"
                + "\"addressLineOne\" : \"35 GEDDES STREET\"}\r\n" + "]\r\n" + "} ";
        Party party = new ObjectMapper().readValue(jsonString, Party.class);
        Map<String, String> queryParameters = new HashMap<String, String>();
        APIRequest<Party> apiRequest = new APIRequest<Party>(headers, queryParameters, party);

        try {
            jwtInterceptor.validateJWT(apiRequest);
            // fail();
        } catch (Exception e) {
            String exceptionMsg = e.getMessage();
            assertTrue(exceptionMsg.contains("4014"));
        }
    }

    @Test
    public void validateJWTTest_FR_expiredJWT() throws Exception {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put(OCVConstants.TRACE_ID_HEADER, "537647");
        headers.put(OCVConstants.AUTHORIZATION_HEADER,
                "bearer eyJ0eXAiOiJKV1QiLCJ4NXQiOiJaMVZoUVdsZlQwUmZMVzl0YWxVeFptRkVVek5wVkROWk0xVk1hSFJVUVdOa1VGOXRYMUJsY205dFRXNVNVVjgyVEV0YVNYZGpUSEpXWVZWWk4zVXpTaTAzVlhFdFVreFBURU5yTkhsa01UTm9aM0JyWVZFIiwia2lkIjoiUkxQTG8ycnNUS2ZESENhcisxODlnM0d0bmxRPSIsImFsZyI6IlJTNTEyIn0.eyJzdWIiOiJlNjA2NWM3Zi04MTU0LTQ3OTUtODRiOC01ZTQ4ZDJjNTMwYWIiLCJjdHMiOiJPQVVUSDJfU1RBVEVMRVNTX0dSQU5UIiwicGVyc29uYSI6eyJfaWQiOiJkOTFhY2Y1NC00Yzg3LTQ4YWEtODVhOS1kZDQxYzcyYzU0Y2QiLCJ0eXBlIjoicmV0YWlsIn0sImFtciI6WyJvdHAiLCJwaW4iXSwiaXNzIjoiaHR0cHM6Ly9pZGVudGl0eS1zZXJ2aWNlcy1zaXQtaW50LWd3LmFwcHMtaW50LnguZ2NwbnAuYW56L2FtL29hdXRoMi9jdXN0b21lciIsInRva2VuTmFtZSI6ImFjY2Vzc190b2tlbiIsImFjdGl2ZSI6dHJ1ZSwidG9rZW5fdHlwZSI6IkJlYXJlciIsIm5vbmNlIjoiNmEyMmNiNjdhZiIsImNsaWVudF9pZCI6ImFtLWludGVybmFsIiwiYXVkIjoiZmVuZXJnbyIsImFjciI6IklBTDMuQUFMMy5GQUwxIiwibmJmIjoxNjE2NDYyNDgxLCJncmFudF90eXBlIjoiYW56OnNzb3Rva2VuIiwic2NvcGUiOlsiYXUucmV0YWlsLmZlbmVyZ28ubGVnYWxlbnRpdHkud3JpdGUiLCJhdS5yZXRhaWwuZmVuZXJnby5sZWdhbGVudGl0eS5yZWFkIiwiYXUucmV0YWlsLmZlbmVyZ28uZm9ybS5yZWFkIiwiYWVnaXMtaW50cm9zcGVjdCJdLCJyZWFsbSI6Ii9jdXN0b21lciIsInNjb3BlcyI6WyJhdS5yZXRhaWwuZmVuZXJnby5sZWdhbGVudGl0eS53cml0ZSIsImF1LnJldGFpbC5mZW5lcmdvLmxlZ2FsZW50aXR5LnJlYWQiLCJhdS5yZXRhaWwuZmVuZXJnby5mb3JtLnJlYWQiLCJhZWdpcy1pbnRyb3NwZWN0Il0sImV4cCI6MTYxNjQ2Mjc4MSwiaWF0IjoxNjE2NDYyNDgxLCJleHBpcmVzX2luIjozMDAsImp0aSI6Ijk5NjIyY2MxLTU0NTAtNDFjNC1iODRmLWY4NDg3MjRjMDkwZiJ9.SprjW0kEGpziNWmmXpui8t1cfroCIp2ccSGoA9lqbOQ2tRXScJRRVu9c0j1nTCYrQoQclBOSZuthqsLMLDbA_mIg3-B34cTJvdRdycs09fqhHAtlHQItLtSAWSvflCV-U_zN9IYtJ7KO3dBuUoIPsGqVmcFIwq4yprEFA5ZbFxYaGbNh5SC4ev867WZvhjxqfyTYAPFBsKgfiHo4hLEOCho5G0myloPBoIlALUTR0rFdnixkF0-LjfDYPNu7zcwf38gS-Hp-Dkzpc1w-zdVI98ZPQlkBPzl-Al87gZzQaY2e7Z_H3YcE8BcZYleLJIN9O2IGpED64NkL_I4sThmjaQ");
        headers.put(OCVConstants.ACCEPT_HEADER, "application/json");
        headers.put(OCVConstants.CHANNEL, "ANZx");
        String jsonString = "{\r\n" + "\"partyType\" : \"O\",\r\n" + "\"status\" : \"active\",\r\n"
                + "\"organisationType\" : \"CZ\",\r\n" + "\"identifiers\" : [\r\n" + "{\r\n"
                + "\"identifierUsageType\" : \"Drivers Licence\",\r\n" + "\"identifier\" : \"221321312\"\r\n" + "},\r\n"
                + "{\r\n" + "\"identifierUsageType\" : \"CACHE Key\",\r\n" + "\"identifier\" : \"2-CMPRINTER-1\"\r\n"
                + "}\r\n" + "],\r\n" + "\"names\":[\r\n" + "{\r\n" + "\"firstName\":\"CMFR PROPTY LTD\",\r\n"
                + "\"lastName\" : \"CMFR PROPTY LTD\"\r\n" + "}\r\n" + "],\r\n" + "\"addresses\" : [\r\n" + "{\r\n"
                + "\"addressLineOne\" : \"35 GEDDES STREET\"}\r\n" + "]\r\n" + "} ";
        Party party = new ObjectMapper().readValue(jsonString, Party.class);
        Map<String, String> queryParameters = new HashMap<String, String>();
        APIRequest<Party> apiRequest = new APIRequest<Party>(headers, queryParameters, party);

        try {
            jwtInterceptor.validateJWT(apiRequest);
        } catch (Exception e) {
            String exceptionMsg = e.getMessage();
            assertTrue(exceptionMsg.contains("4014"));
        }
    }

    @Test
    public void validateJWTTest_B2BDP_validJWT() throws Exception {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put(OCVConstants.TRACE_ID_HEADER, "537647");
        headers.put(OCVConstants.AUTHORIZATION_HEADER,
                "bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImFwaXNpdHRva2VuLmNvcnAuZGV2LmFueiJ9.eyJpc3MiOiJodHRwczovL2RhdGFwb3dlci1zdHMuYW56LmNvbSIsImF1ZCI6IlRlc3RVc2VyIiwic3ViIjoiVGVzdFVzZXIiLCJpYXQiOjE2MTY0NjgzNzEwMjUsImV4cCI6MTYxNjQ2OTI3MS4wMjUsInNjb3BlcyI6WyJBVS5BTlpfSU5URVJOQUwuT0NWLk1NTE8uQUNDRVNTLlJFQUQiLCJBVS5BTlpfSU5URVJOQUwuQ0JJRy5SRUFEIiwiQVUuQU5aX0lOVEVSTkFMLkxPQU5JUS5SRUFEIiwiQVUuQU5aX0lOVEVSTkFMLkVMUy5SRUFEIiwiQVUuQU5aX0lOVEVSTkFMLlZJU0lPTl9NRVJDSEFOVC5SRUFEIiwiQVUuQU5aX0lOVEVSTkFMLk9UTC5SRUFEX0RJU0FCTEVEIiwiQVUuQU5aX0lOVEVSTkFMLk1JREFOWi5SRUFEIiwiQVUuQU5aX0lOVEVSTkFMLk9DVi5NTUxPLkFDQ0VTUy5SRUFEIiwiQVUuQU5aX0lOVEVSTkFMLkJCRC5WSUVXIl0sImFtciI6WyJwb3AiXSwiYWNyIjoiSUFMMi5BQUwxLkZBTDEifQ.lsr8KRmjAY8NF2GRRDiUKfkbiETNnX6x-PlLDBoCtFW34rgJbsGjfPLVr9WjzRBFVhigG9vNR0ZmtEXFbmulyWgUt6SyWIwe2Jkpa2EBgO87iopXpS_ss3nISBQJuHsxa-KjGmaQy10MbMIAbIcBVUt8RyYrugFNz7nEljdw37uK8zQoH8TlUKjbFYmSx_BjLIvuM6olTYqrQiIK2j4MaO7PnRdOwb5ktVxJ9AYsSWX3wq_2UUA4JOGmF9lH3k9zSxpjhS9Ls0jGa2_kUFCLJEhdFZzWBCrizRzTJozGuAy33PnXrm2ol4A3NT6-Ugj0sEb9pRSINqz99cf8qGkdaw");

        headers.put(OCVConstants.ACCEPT_HEADER, "application/json");
        headers.put(OCVConstants.CHANNEL, "MMLO");
        String jsonString = "{\r\n" + "\"partyType\" : \"O\",\r\n" + "\"status\" : \"active\",\r\n"
                + "\"organisationType\" : \"CZ\",\r\n" + "\"identifiers\" : [\r\n" + "{\r\n"
                + "\"identifierUsageType\" : \"Drivers Licence\",\r\n" + "\"identifier\" : \"221321312\"\r\n" + "},\r\n"
                + "{\r\n" + "\"identifierUsageType\" : \"CACHE Key\",\r\n" + "\"identifier\" : \"2-CMPRINTER-1\"\r\n"
                + "}\r\n" + "],\r\n" + "\"names\":[\r\n" + "{\r\n" + "\"firstName\":\"CMFR PROPTY LTD\",\r\n"
                + "\"lastName\" : \"CMFR PROPTY LTD\"\r\n" + "}\r\n" + "],\r\n" + "\"addresses\" : [\r\n" + "{\r\n"
                + "\"addressLineOne\" : \"35 GEDDES STREET\"}\r\n" + "]\r\n" + "} ";
        Party party = new ObjectMapper().readValue(jsonString, Party.class);
        Map<String, String> queryParameters = new HashMap<String, String>();
        APIRequest<Party> apiRequest = new APIRequest<Party>(headers, queryParameters, party);

        try {
            jwtInterceptor.validateJWT(apiRequest);
            // fail();
        } catch (Exception e) {
            String exceptionMsg = e.getMessage();
            assertTrue(exceptionMsg.contains("4014"));
        }
    }

    @Test
    public void validateJWTTest_B2BDP_expiredJWT() throws Exception {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put(OCVConstants.TRACE_ID_HEADER, "537647");
        headers.put(OCVConstants.AUTHORIZATION_HEADER,
                "bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImFwaXNpdHRva2VuLmNvcnAuZGV2LmFueiJ9.eyJpc3MiOiJodHRwczovL2RhdGFwb3dlci1zdHMuYW56LmNvbSIsImF1ZCI6IlRlc3RVc2VyIiwic3ViIjoiVGVzdFVzZXIiLCJpYXQiOjE2MTY0NjgzNzEwMjUsImV4cCI6MTYxNjQ2OTI3MS4wMjUsInNjb3BlcyI6WyJBVS5BTlpfSU5URVJOQUwuT0NWLk1NTE8uQUNDRVNTLlJFQUQiLCJBVS5BTlpfSU5URVJOQUwuQ0JJRy5SRUFEIiwiQVUuQU5aX0lOVEVSTkFMLkxPQU5JUS5SRUFEIiwiQVUuQU5aX0lOVEVSTkFMLkVMUy5SRUFEIiwiQVUuQU5aX0lOVEVSTkFMLlZJU0lPTl9NRVJDSEFOVC5SRUFEIiwiQVUuQU5aX0lOVEVSTkFMLk9UTC5SRUFEX0RJU0FCTEVEIiwiQVUuQU5aX0lOVEVSTkFMLk1JREFOWi5SRUFEIiwiQVUuQU5aX0lOVEVSTkFMLk9DVi5NTUxPLkFDQ0VTUy5SRUFEIiwiQVUuQU5aX0lOVEVSTkFMLkJCRC5WSUVXIl0sImFtciI6WyJwb3AiXSwiYWNyIjoiSUFMMi5BQUwxLkZBTDEifQ.lsr8KRmjAY8NF2GRRDiUKfkbiETNnX6x-PlLDBoCtFW34rgJbsGjfPLVr9WjzRBFVhigG9vNR0ZmtEXFbmulyWgUt6SyWIwe2Jkpa2EBgO87iopXpS_ss3nISBQJuHsxa-KjGmaQy10MbMIAbIcBVUt8RyYrugFNz7nEljdw37uK8zQoH8TlUKjbFYmSx_BjLIvuM6olTYqrQiIK2j4MaO7PnRdOwb5ktVxJ9AYsSWX3wq_2UUA4JOGmF9lH3k9zSxpjhS9Ls0jGa2_kUFCLJEhdFZzWBCrizRzTJozGuAy33PnXrm2ol4A3NT6-Ugj0sEb9pRSINqz99cf8qGkdaw");

        headers.put(OCVConstants.ACCEPT_HEADER, "application/json");
        headers.put(OCVConstants.CHANNEL, "MMLO");
        String jsonString = "{\r\n" + "\"partyType\" : \"O\",\r\n" + "\"status\" : \"active\",\r\n"
                + "\"organisationType\" : \"CZ\",\r\n" + "\"identifiers\" : [\r\n" + "{\r\n"
                + "\"identifierUsageType\" : \"Drivers Licence\",\r\n" + "\"identifier\" : \"221321312\"\r\n" + "},\r\n"
                + "{\r\n" + "\"identifierUsageType\" : \"CACHE Key\",\r\n" + "\"identifier\" : \"2-CMPRINTER-1\"\r\n"
                + "}\r\n" + "],\r\n" + "\"names\":[\r\n" + "{\r\n" + "\"firstName\":\"CMFR PROPTY LTD\",\r\n"
                + "\"lastName\" : \"CMFR PROPTY LTD\"\r\n" + "}\r\n" + "],\r\n" + "\"addresses\" : [\r\n" + "{\r\n"
                + "\"addressLineOne\" : \"35 GEDDES STREET\"}\r\n" + "]\r\n" + "} ";
        Party party = new ObjectMapper().readValue(jsonString, Party.class);
        Map<String, String> queryParameters = new HashMap<String, String>();
        APIRequest<Party> apiRequest = new APIRequest<Party>(headers, queryParameters, party);

        try {
            jwtInterceptor.validateJWT(apiRequest);
        } catch (Exception e) {
            String exceptionMsg = e.getMessage();
            assertTrue(exceptionMsg.contains("4014"));
        }
    }

    @Test
    public void validateJWTTest_withApplicationName() throws Exception {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put(OCVConstants.TRACE_ID_HEADER, "537647");
        headers.put(OCVConstants.AUTHORIZATION_HEADER,
                "bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImFwaXNpdHRva2VuLmNvcnAuZGV2LmFueiJ9.eyJpc3MiOiJodHRwczovL2RhdGFwb3dlci1zdHMuYW56LmNvbSIsImF1ZCI6IlRlc3RVc2VyIiwic3ViIjoiVGVzdFVzZXIiLCJpYXQiOjE2MTY0NjgzNzEwMjUsImV4cCI6MTYxNjQ2OTI3MS4wMjUsInNjb3BlcyI6WyJBVS5BTlpfSU5URVJOQUwuT0NWLk1NTE8uQUNDRVNTLlJFQUQiLCJBVS5BTlpfSU5URVJOQUwuQ0JJRy5SRUFEIiwiQVUuQU5aX0lOVEVSTkFMLkxPQU5JUS5SRUFEIiwiQVUuQU5aX0lOVEVSTkFMLkVMUy5SRUFEIiwiQVUuQU5aX0lOVEVSTkFMLlZJU0lPTl9NRVJDSEFOVC5SRUFEIiwiQVUuQU5aX0lOVEVSTkFMLk9UTC5SRUFEX0RJU0FCTEVEIiwiQVUuQU5aX0lOVEVSTkFMLk1JREFOWi5SRUFEIiwiQVUuQU5aX0lOVEVSTkFMLk9DVi5NTUxPLkFDQ0VTUy5SRUFEIiwiQVUuQU5aX0lOVEVSTkFMLkJCRC5WSUVXIl0sImFtciI6WyJwb3AiXSwiYWNyIjoiSUFMMi5BQUwxLkZBTDEifQ.lsr8KRmjAY8NF2GRRDiUKfkbiETNnX6x-PlLDBoCtFW34rgJbsGjfPLVr9WjzRBFVhigG9vNR0ZmtEXFbmulyWgUt6SyWIwe2Jkpa2EBgO87iopXpS_ss3nISBQJuHsxa-KjGmaQy10MbMIAbIcBVUt8RyYrugFNz7nEljdw37uK8zQoH8TlUKjbFYmSx_BjLIvuM6olTYqrQiIK2j4MaO7PnRdOwb5ktVxJ9AYsSWX3wq_2UUA4JOGmF9lH3k9zSxpjhS9Ls0jGa2_kUFCLJEhdFZzWBCrizRzTJozGuAy33PnXrm2ol4A3NT6-Ugj0sEb9pRSINqz99cf8qGkdaw");

        headers.put(OCVConstants.ACCEPT_HEADER, "application/json");
        headers.put(OCVConstants.CHANNEL, "MMLO");
        headers.put(OCVConstants.APPLICATION, "OCV");

        String jsonString = "{\r\n" + "\"partyType\" : \"O\",\r\n" + "\"status\" : \"active\",\r\n"
                + "\"organisationType\" : \"CZ\",\r\n" + "\"identifiers\" : [\r\n" + "{\r\n"
                + "\"identifierUsageType\" : \"Drivers Licence\",\r\n" + "\"identifier\" : \"221321312\"\r\n" + "},\r\n"
                + "{\r\n" + "\"identifierUsageType\" : \"CACHE Key\",\r\n" + "\"identifier\" : \"2-CMPRINTER-1\"\r\n"
                + "}\r\n" + "],\r\n" + "\"names\":[\r\n" + "{\r\n" + "\"firstName\":\"CMFR PROPTY LTD\",\r\n"
                + "\"lastName\" : \"CMFR PROPTY LTD\"\r\n" + "}\r\n" + "],\r\n" + "\"addresses\" : [\r\n" + "{\r\n"
                + "\"addressLineOne\" : \"35 GEDDES STREET\"}\r\n" + "]\r\n" + "} ";
        Party party = new ObjectMapper().readValue(jsonString, Party.class);
        Map<String, String> queryParameters = new HashMap<String, String>();
        APIRequest<Party> apiRequest = new APIRequest<Party>(headers, queryParameters, party);

        try {
            jwtInterceptor.validateJWT(apiRequest);
        } catch (Exception e) {
            String exceptionMsg = e.getMessage();
            assertTrue(exceptionMsg.contains("no matching key(s) found"));
        }
    }

    private Map<String, String> prepareIssuerPropertiesMap() {
        Map<String, String> issuerList = new HashMap<>();
        issuerList.put("ISSUERLIST",
                "https://datapower-sts.anz.com=https://apisittoken.corp.dev.anz:8448/auth/.well-known/jwks.json|https://datapower-b2b.anz.com=https://apisittoken.corp.dev.anz:8448/auth/.well-known/jwks.json|https://auth.service.dev/oidc=https://auth.service.dev/oidc/.well-known/jwks.json|https://datapower-vdpunauthecom.anz.com=https://apisittoken.corp.dev.anz:8448/auth/.well-known/jwks.json|NextSingTokenGenerator.service.dev=https://apisittoken.corp.dev.anz:8448/auth/.well-known/jwks.json|https://amsit1.service.dev:443/openam/oauth2/anz=https://gwiamauthcorpsit1.service.dev:443/token/jwk_uri|https://amsit2.service.dev:443/openam/oauth2/anz=https://gwiamauthcorpsit2.service.dev:443/token/jwk_uri|https://amsit4.service.dev:443/openam/oauth2/anz=https://gwiamauthcorpsit4.service.dev:443/token/jwk_uri|https://amict1.service.dev:443/openam/oauth2/anz=https://gwiamauthcorpict1.service.dev:443/token/jwk_uri|https://amict2.service.dev:443/openam/oauth2/anz=https://gwiamauthcorpict2.service.dev:443/token/jwk_uri|https://amst1.service.dev:443/openam/oauth2/anz=https://gwiamauthcorpst1.service.dev/token/jwk_uri|https://amst2.service.dev:443/openam/oauth2/anz=https://gwiamauthcorpst2.service.dev/token/jwk_uri|https://amst4.service.dev:443/openam/oauth2/anz=https://gwiamauthcorpst4.service.dev/token/jwk_uri|https://amqa.service.dev:443/openam/oauth2/anz=https://iamauthcorpqa.service.dev:443/token/jwk_uri|https://ampp.service.dev:443/openam/oauth2/anz=https://iamauthcorppp.service.dev:443/token/jwk_uri|https://amps.service.dev:443/openam/oauth2/anz=https://iamauthcorpps.service.dev:443/token/jwk_uri|https://identity-services-sit-int-gw.apps-int.x.gcpnp.anz/am/oauth2/system=https://identity-services-sit-int-gw.apps-int.x.gcpnp.anz/am/oauth2/system/connect/jwk_uri|https://identity-services-sit-int-gw.apps-int.x.gcpnp.anz/am/oauth2/customer=https://identity-services-sit-int-gw.apps-int.x.gcpnp.anz/am/oauth2/customer/connect/jwk_uri|https://identity-services-sit2-int-gw.apps-int.x.gcpnp.anz/am/oauth2/system=https://identity-services-sit2-int-gw.apps-int.x.gcpnp.anz/am/oauth2/system/connect/jwk_uri|https://identity-services-sit2-int-gw.apps-int.x.gcpnp.anz/am/oauth2/customer=https://identity-services-sit2-int-gw.apps-int.x.gcpnp.anz/am/oauth2/customer/connect/jwk_uri|https://identity-services-np-int-gw.apps-int.x.gcpnp.anz/am/oauth2/system=https://identity-services-np-int-gw.apps-int.x.gcpnp.anz/am/oauth2/system/connect/jwk_uri|https://identity-services-np-int-gw.apps-int.x.gcpnp.anz/am/oauth2/customer=https://identity-services-np-int-gw.apps-int.x.gcpnp.anz/am/oauth2/customer/connect/jwk_uri|https://datapower-sts.anz.com=https://apisittoken.corp.dev.anz:8448/auth/.well-known/jwks.json|https://datapower-b2b.anz.com=https://apisittoken.corp.dev.anz:8448/auth/.well-known/jwks.json|https://auth.service.dev/oidc=https://auth.service.dev/oidc/.well-known/jwks.json|https://datapower-vdpunauthecom.anz.com=https://apisittoken.corp.dev.anz:8448/auth/.well-known/jwks.json|NextSingTokenGenerator.service.dev=https://apisittoken.corp.dev.anz:8448/auth/.well-known/jwks.json|https://amsit1.service.dev:443/openam/oauth2/anz=https://gwiamauthcorpsit1.service.dev:443/token/jwk_uri|https://amsit2.service.dev:443/openam/oauth2/anz=https://gwiamauthcorpsit2.service.dev:443/token/jwk_uri|https://amsit4.service.dev:443/openam/oauth2/anz=https://gwiamauthcorpsit4.service.dev:443/token/jwk_uri|https://amict1.service.dev:443/openam/oauth2/anz=https://gwiamauthcorpict1.service.dev:443/token/jwk_uri|https://amict2.service.dev:443/openam/oauth2/anz=https://gwiamauthcorpict2.service.dev:443/token/jwk_uri|https://amst1.service.dev:443/openam/oauth2/anz=https://gwiamauthcorpst1.service.dev/token/jwk_uri|https://amst2.service.dev:443/openam/oauth2/anz=https://gwiamauthcorpst2.service.dev/token/jwk_uri|https://amst4.service.dev:443/openam/oauth2/anz=https://gwiamauthcorpst4.service.dev/token/jwk_uri|https://amqa.service.dev:443/openam/oauth2/anz=https://iamauthcorpqa.service.dev:443/token/jwk_uri|https://ampp.service.dev:443/openam/oauth2/anz=https://iamauthcorppp.service.dev:443/token/jwk_uri|https://amps.service.dev:443/openam/oauth2/anz=https://iamauthcorpps.service.dev:443/token/jwk_uri|https://identity-services-sit-int-gw.apps-int.x.gcpnp.anz/am/oauth2/system=https://identity-services-sit-int-gw.apps-int.x.gcpnp.anz/am/oauth2/system/connect/jwk_uri|https://identity-services-sit-int-gw.apps-int.x.gcpnp.anz/am/oauth2/customer=https://identity-services-sit-int-gw.apps-int.x.gcpnp.anz/am/oauth2/customer/connect/jwk_uri|https://identity-services-sit2-int-gw.apps-int.x.gcpnp.anz/am/oauth2/system=https://identity-services-sit2-int-gw.apps-int.x.gcpnp.anz/am/oauth2/system/connect/jwk_uri|https://identity-services-sit2-int-gw.apps-int.x.gcpnp.anz/am/oauth2/customer=https://identity-services-sit2-int-gw.apps-int.x.gcpnp.anz/am/oauth2/customer/connect/jwk_uri|https://identity-services-np-int-gw.apps-int.x.gcpnp.anz/am/oauth2/system=https://identity-services-np-int-gw.apps-int.x.gcpnp.anz/am/oauth2/system/connect/jwk_uri|https://identity-services-np-int-gw.apps-int.x.gcpnp.anz/am/oauth2/customer=https://identity-services-np-int-gw.apps-int.x.gcpnp.anz/am/oauth2/customer/connect/jwk_uri\r\n");

        return issuerList;
    }

    private Map<String, String> prepareChannelPropertiesMap() {
        Map<String, String> channelList = new HashMap<>();
        channelList.put("EXCLUDECHANNELSLIST", "XYZ|Customer Hub|Digital Banking");

        return channelList;
    }
}
