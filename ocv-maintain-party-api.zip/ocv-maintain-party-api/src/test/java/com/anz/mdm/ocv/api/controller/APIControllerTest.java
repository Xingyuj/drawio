package com.anz.mdm.ocv.api.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.spy;

import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.lang3.ObjectUtils;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.ResourceUtils;

import com.anz.mdm.ocv.api.UAMAccessConfiguration;
import com.anz.mdm.ocv.api.constants.OCVConstants;
import com.anz.mdm.ocv.api.converter.OrganizationObjectConverter;
import com.anz.mdm.ocv.api.converter.PartyIdentifierConverter;
import com.anz.mdm.ocv.api.converter.PartySourceSystemConverter;
import com.anz.mdm.ocv.api.converter.PersonObjectConverter;
import com.anz.mdm.ocv.api.downsteamservices.AbstractFuzzyService;
import com.anz.mdm.ocv.api.downsteamservices.CapTransformationService;
import com.anz.mdm.ocv.api.downsteamservices.DataStandardisationService;
import com.anz.mdm.ocv.api.downsteamservices.DataValidationService;
import com.anz.mdm.ocv.api.downsteamservices.DeletePartyService;
import com.anz.mdm.ocv.api.downsteamservices.JWTService;
import com.anz.mdm.ocv.api.downsteamservices.MaintainPartyService;
import com.anz.mdm.ocv.api.downsteamservices.RetrievePartyService;
import com.anz.mdm.ocv.api.downsteamservices.StandardisedParty;
import com.anz.mdm.ocv.api.downsteamservices.TokenServiceImpl;
import com.anz.mdm.ocv.api.downsteamservices.ValidatedParty;
import com.anz.mdm.ocv.api.dto.APIResponse;
import com.anz.mdm.ocv.api.exception.ErrorResponse;
import com.anz.mdm.ocv.api.exception.GlobalExceptionHandler;
import com.anz.mdm.ocv.api.exception.ServiceUnavailableException;
import com.anz.mdm.ocv.api.interceptor.JWTInterceptor;
import com.anz.mdm.ocv.api.interceptor.UAMInterceptor;
import com.anz.mdm.ocv.api.model.CAPParty;
import com.anz.mdm.ocv.api.util.IdempotencyConfigUtil;
import com.anz.mdm.ocv.api.util.LogRequestModel;
import com.anz.mdm.ocv.api.util.StreetSuffixConfig;
import com.anz.mdm.ocv.api.validator.APIRequest;
import com.anz.mdm.ocv.api.validator.MaintainCapPartyValidator;
import com.anz.mdm.ocv.api.validator.MaintainPartyValidator;
import com.anz.mdm.ocv.common.v1.SourceSystem;
import com.anz.mdm.ocv.party.v1.Party;
import com.anz.mdm.ocv.party.v1.SearchPartyResultWrapper;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.mdm.schema.CommonBObjType;
import com.ibm.mdm.schema.ResponseObject;
import com.ibm.mdm.schema.TCRMAdminContEquivBObjType;
import com.ibm.mdm.schema.TCRMExtension;
import com.ibm.mdm.schema.TCRMPartyIdentificationBObjType;
import com.ibm.mdm.schema.TCRMPersonBObjType;
import com.ibm.mdm.schema.TCRMPersonNameBObjType;
import com.ibm.mdm.schema.TCRMService;
import com.ibm.mdm.schema.TxResponse;
import com.ibm.mdm.schema.TxResult;
import com.ibm.mdm.schema.XPartyIdentificationBObjExtType;
import com.ibm.mdm.schema.XPersonBObjExtType;

@SpringBootTest
@AutoConfigureMockMvc
public class APIControllerTest {

    @InjectMocks
    private APIController apiController;

    private DataStandardisationService dataStandardisationService;

    private DataValidationService dataValidationService;

    @InjectMocks
    @Spy
    private MaintainPartyService maintainPartyService;

    private MaintainCapPartyValidator maintainCapPartyValidator;

    private DeletePartyService deletePartyService;

    private MaintainPartyValidator maintainPartyValidator;

    private LogRequestModel logAttributes;

    @Mock
    private RetrievePartyService retrievePartyService;

    @Mock
    private IdempotencyConfigUtil idempotencyConfigUtil;

    private TokenServiceImpl tokenService;

    @Mock
    private AbstractFuzzyService abstractFuzzyService;

    @Mock
    private SearchPartyResultWrapper searchPartyResultWrapper;

    private CapTransformationService capTransformationService;
    
    @Autowired
    private MockMvc mockMvc;

    private JWTInterceptor jwtInterceptor;

    private JWTService theJWTService;

    private UAMAccessConfiguration uamConfiguration;

    @Mock StreetSuffixConfig streetSuffixCfg;
    
    private UAMInterceptor uamInterceptor;
    
    private UAMAccessConfiguration uamAccessConfiguration;
    
    private Map<String, String> accessList;
    
    @Before
    public void setUp() throws IOException {

        Mockito.spy(PersonObjectConverter.class);
        Mockito.spy(OrganizationObjectConverter.class);
        Mockito.spy(PartySourceSystemConverter.class);
        Mockito.spy(PartyIdentifierConverter.class);

        dataStandardisationService = new DataStandardisationService();
        dataStandardisationService = spy(dataStandardisationService);

        maintainPartyService = new MaintainPartyService();
        maintainPartyService = spy(maintainPartyService);

        idempotencyConfigUtil = new IdempotencyConfigUtil();
        idempotencyConfigUtil = spy(idempotencyConfigUtil);

        deletePartyService = new DeletePartyService();
        deletePartyService = spy(deletePartyService);

        maintainPartyValidator = new MaintainPartyValidator();
        maintainPartyValidator = spy(maintainPartyValidator);

        maintainCapPartyValidator = new MaintainCapPartyValidator();
        maintainCapPartyValidator = spy(maintainCapPartyValidator);

        dataValidationService = new DataValidationService();
        dataValidationService = spy(dataValidationService);

        retrievePartyService = new RetrievePartyService();
        retrievePartyService = spy(retrievePartyService);

        capTransformationService = new CapTransformationService();
        capTransformationService = spy(capTransformationService);

        tokenService = new TokenServiceImpl();
        tokenService = spy(tokenService);
        
        // OCT-23700 - for validating JWT Token Scope - Start
        uamAccessConfiguration = new UAMAccessConfiguration();
        uamAccessConfiguration = spy(uamAccessConfiguration);
               
        uamInterceptor = new UAMInterceptor(uamAccessConfiguration);
        uamInterceptor = spy(uamInterceptor);
        
        maintainPartyValidator.setUamInterceptor(uamInterceptor);
        maintainCapPartyValidator.setUamInterceptor(uamInterceptor);
        
        accessList = new HashMap<String, String>();
        accessList.put("VALID_OCV_SCOPES_MAINTAIN_PARTY_API", "AU.RETAIL.CUSTOMERPROFILE.UPDATE|AU.ANZ_INTERNAL.OCV.CUSTOMERHUB.ACCESS.UPDATE|AU.ANZ_INTERNAL.OCV.ANZX.ACCESS.UPDATE|AU.ANZ_INTERNAL.OCV.COMMBROKER.ACCESS.UPDATE");
        //OCT-23700 - for validating JWT Token Scope - End

        //
        // theJWTService = new JWTService(null);
        // theJWTService = spy(theJWTService);
        //
        // uamConfiguration = new UAMAccessConfiguration();
        // uamConfiguration = spy(uamConfiguration);

        jwtInterceptor = new JWTInterceptor(theJWTService, uamConfiguration);
        jwtInterceptor = spy(jwtInterceptor);
        streetSuffixCfg = new StreetSuffixConfig();
        streetSuffixCfg = spy(streetSuffixCfg);

        apiController = new APIController(dataStandardisationService, maintainPartyService, deletePartyService,
                new LogRequestModel(), dataValidationService, retrievePartyService, capTransformationService,
                jwtInterceptor, idempotencyConfigUtil);
        apiController = spy(apiController);

        MockitoAnnotations.initMocks(this);
        Mockito.when(streetSuffixCfg.getPropertyValue("street")).thenReturn("ST");
        Mockito.when(streetSuffixCfg.getPropertyValue("street highway")).thenReturn("sthwy");
        apiController.setTokenService(tokenService);
        mockMvc = MockMvcBuilders.standaloneSetup(new GlobalExceptionHandler(), apiController).build();
    }

    @Test
    public void maintainPartyTest() throws Exception {
        Map<String, String> headers = prepareRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();
        Party person = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:SamplePersonInput.json"),
                Party.class);
        File responseXml = ResourceUtils.getFile("classpath:MaintainPartyIndResponse.xml");
        StreamSource xmlsource = new StreamSource(responseXml);
        StringWriter writer = new StringWriter();
        StreamResult result = new StreamResult(writer);
        TransformerFactory tFactory = TransformerFactory.newInstance();
        Transformer transformer = tFactory.newTransformer();
        transformer.transform(xmlsource, result);
        String strResult = writer.toString();
        HttpEntity<String> response = new HttpEntity<String>(strResult);

        doReturn(new StandardisedParty(setParameterisedBody(), true)).when(dataStandardisationService)
                .standardiseParty(Mockito.any(APIRequest.class));
        doReturn(new ValidatedParty(setParameterisedBody(), true)).when(dataValidationService)
                .validateParty(Mockito.any(APIRequest.class));
        doReturn(response).when(maintainPartyService).invokeBackend(Mockito.any(String.class),
                Mockito.any(String.class));
        doReturn(true).when(jwtInterceptor).validateJWT(any(APIRequest.class));
        String jsonResponse = new String(
                Files.readAllBytes(ResourceUtils.getFile("classpath:SamplePersonInput.json").toPath()));
        doReturn(jsonResponse).when(maintainPartyService).transformMDMResponse((HttpEntity<String>) any(Object.class),
                any(String.class));
        doReturn(new StandardisedParty(setParameterisedBody(), true)).when(dataStandardisationService)
                .invokeRedHatRuleEngine(Mockito.any(APIRequest.class));
        
        System.out.println("Here"+idempotencyConfigUtil);
        
        doReturn(idempotencyConfigUtil).when(maintainPartyService).getIdempotencyUtil();

        doReturn(false).when(idempotencyConfigUtil).isChannelIncluded(Mockito.anyString(),Mockito.anyString());
        
        doReturn(accessList).when(uamAccessConfiguration).getAccessMap(any(String.class));
        
        ResponseEntity<Object> result1 = apiController.maintainParty(headers, queryParameters, person);
        String output = (String) result1.getBody();

        assertEquals("Comparison", output, jsonResponse);
    }

    @Test
    public void maintainV2PartyTest() throws Exception {
        SearchPartyResultWrapper searchPartyResultWrapper = new SearchPartyResultWrapper();
        ReflectionTestUtils.setField(retrievePartyService, "goodStatuses",
                "OK,NOT_FOUND,BAD_REQUEST,INTERNAL_SERVER_ERROR");
        ReflectionTestUtils.setField(retrievePartyService, "url", "https://localhost:8080/parties/retrieve");
        Map<String, String> headers = prepareANZXRequestHeaders();
        headers.put("idempotency-key", "3432434324-sadsad-23213-2313213213-70");
        headers.put("idempotency-first-sent", new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date()));
        Map<String, String> queryParameters = new HashMap<String, String>();
        Party person = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:SamplePersonInputANZX.json"),
                Party.class);

        ResponseEntity<TCRMService> mdmResponse = setMDMResponse_Person();
        String response = "{ \"partyType\": \"P\", \"source\": \"FENERGOANZX\", \"sourceEstablishedDate\": \"2005-11-10\", \"sourceClosedDate\": \"2015-11-10\", \"status\": \"Active\", \"dateOfBirth\": \"1969-11-06\", \"gender\": \"N\", \"maritalStatus\": \"Married/De Facto\", \"deceasedDate\": \"2000-01-01\", \"bankruptDate\": \"2019-03-15\", \"employeeIndicator\": \"Y\", \"employerName\": \"ANZ\", \"kycDetails\": { \"status\": \"CO\", \"verificationLevel\": \"NM\" }, \"occupation\": { \"code\": \"111200\" }, \"addresses\": [ { \"addressUsageType\": \"Primary Residential\", \"addressLineOne\": \"(LOT) YORK RD\", \"city\": \"POPANYINNING\", \"postalCode\": \"6309\", \"state\": \"SA\", \"country\": \"AUS\", \"region\": \"\", \"deliveryId\": \"80941156\", \"source\": \"FENERGOANZX\", \"startDate\": \"1901-01-01\", \"endDate\": \"9999-12-31\" }, { \"addressUsageType\": \"Primary Mailing\", \"addressLineOne\": \"PO BOX 147\", \"city\": \"CAMBERWELL\", \"postalCode\": \"3124\", \"state\": \"VIC\", \"country\": \"DZA\", \"region\": \"VIC\", \"deliveryId\": \"69775498\", \"source\": \"FENERGOANZX\", \"startDate\": \"2014-05-29\", \"endDate\": \"9999-12-31\" } ], \"phones\": [ { \"phoneUsageType\": \"Mobile Telephone\", \"phone\": \"+610422591580\", \"preferred\": \"\", \"source\": \"FENERGOANZX\", \"sequence\": \"3\", \"startDate\": \"1901-01-01\", \"endDate\": \"9999-12-31\" }, { \"phoneUsageType\": \"Primary Home Telephone\", \"phone\": \"+61386549523\", \"preferred\": \"Y\", \"source\": \"FENERGOANZX\", \"sequence\": \"1\", \"startDate\": \"1901-01-01\", \"endDate\": \"9999-12-31\" }, { \"phoneUsageType\": \"Secondary Home Telephone\", \"phone\": \"+613865675234\", \"preferred\": \"Y\", \"source\": \"FENERGOANZX\", \"sequence\": \"2\", \"startDate\": \"1901-01-01\", \"endDate\": \"2019-12-31\" } ], \"emails\": [ { \"emailUsageType\": \"Email\", \"email\": \"damian@trecose.com\", \"preferred\": \"\", \"source\": \"FENERGOANZX\", \"startDate\": \"1901-01-01\", \"endDate\": \"\" } ], \"identifiers\": [ { \"identifierUsageType\": \"Drivers License\", \"identifier\": \"5642341\", \"identificationIssueLocation\": \"VIC\", \"source\": \"FENERGOANZX\", \"sequence\": \"1\", \"startDate\": \"1901-01-01\", \"expiryDate\": \"9999-12-31\" } ], \"preferences\": [ { \"preferenceType\": \"Disclosure Indicator\", \"preferenceValue\": \"N\", \"preferenceReason\": \"Not Allowed\", \"source\": \"FENERGOANZX\", \"startDate\": \"1901-01-01\", \"endDate\": \"\" }, { \"preferenceType\": \"Primary Preferred Contact Day and Time\", \"preferenceValue\": \"000000000000NNNNNNN\", \"preferenceReason\": \"Not Interested\", \"source\": \"FENERGOANZX\", \"startDate\": \"2018-08-31\", \"endDate\": \"9999-12-31\" }, { \"preferenceType\": \"Secondary Preferred Contact Day and Time\", \"preferenceValue\": \"000000000000YYYYYYY\", \"preferenceReason\": \"Interested\", \"source\": \"CAP-CIS\", \"startDate\": \"2018-08-31\", \"endDate\": \"9999-12-31\" }, { \"preferenceType\": \"Advertising Indicator\", \"preferenceValue\": \"Y\", \"preferenceReason\": \"Allowed\", \"source\": \"FENERGOANZX\", \"startDate\": \"9999-12-01\", \"endDate\": \"9999-12-31\" } ], \"bankingServices\": [ { \"key\": \"DNC\", \"value\": \"Y\" }, { \"key\": \"NVE\", \"value\": \"Y\" } ], \"names\": [ { \"firstName\": \"Abhishek\", \"lastName\": \"DAMIAN M PHELAN\" }, { \"nameUsageType\": \"Mailing Name\", \"lastName\": \"MR D PHELAN\", \"startDate\": \"1901-01-01\", \"source\": \"FENERGOANZX\" } ], \"sourceSystems\": [ { \"sourceSystemId\": \"4012977562\", \"sourceSystemName\": \"FENERGOANZX\" } ] }";
        Party responseParty = new ObjectMapper().readValue(response, Party.class);
        ArrayList<Party> parties = new ArrayList<Party>();
        parties.add(responseParty);
        searchPartyResultWrapper.getCertifiedResults().addAll(parties);
        ResponseEntity<Object> apiresponse = new ResponseEntity<Object>(parties, HttpStatus.OK);
        doReturn(new StandardisedParty(setParameterisedBodyANZX(), true)).when(dataStandardisationService)
                .standardiseParty(Mockito.any(APIRequest.class));
        doReturn(new StandardisedParty(setParameterisedBody(), true)).when(dataStandardisationService)
                .invokeRedHatRuleEngine(Mockito.any(APIRequest.class));
        doReturn(new ValidatedParty(setParameterisedBodyANZX(), true)).when(dataValidationService)
                .validateParty(Mockito.any(APIRequest.class));
        doReturn(mdmResponse).when(maintainPartyService).invokeMdmBackend((Mockito.any(String.class)),
                Mockito.any(String.class));
        APIResponse apiResponse = getApiResponse();
        doReturn(apiResponse).when(maintainPartyService).transformMdmResponse(Mockito.any(String.class), Mockito.any(),
                Mockito.any());
        doReturn(apiresponse).when(retrievePartyService).invokeDownStreamService(Mockito.any(),
                Mockito.any(String.class));
        doReturn(searchPartyResultWrapper).when(retrievePartyService).getResponse(Mockito.any(),
                Mockito.any(String.class));

        Party capResponseParty = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:CapParty.json"),
                Party.class);
        APIRequest<Party> capParty = new APIRequest<Party>(headers, queryParameters, capResponseParty);
        CAPParty capPratyObj = new CAPParty(capParty, true);
        doReturn(capPratyObj).when(capTransformationService).createCapProfileV2(Mockito.any(), Mockito.any(),
                Mockito.anyString());
        doReturn(true).when(jwtInterceptor).validateJWT(any(APIRequest.class));

        doNothing().when(idempotencyConfigUtil).validate(Mockito.any(), Mockito.any(), Mockito.any());
        doReturn(idempotencyConfigUtil).when(maintainPartyService).getIdempotencyUtil();
        doReturn(true).when(idempotencyConfigUtil).isChannelIncluded(Mockito.anyString(), Mockito.anyString());
        doReturn(true).when(idempotencyConfigUtil).isRequestModeIncluded(Mockito.anyBoolean(), Mockito.anyString(),
                Mockito.anyString(), Mockito.anyString());
        doReturn(accessList).when(uamAccessConfiguration).getAccessMap(any(String.class));
        ResponseEntity<Object> result = apiController.maintainPartyV2(headers, queryParameters, person);
        assertTrue(ObjectUtils.isNotEmpty(result.getBody()));
    }

    @Test
    public void maintainV2PartyTestInt3() throws Exception {
        SearchPartyResultWrapper searchPartyResultWrapper = new SearchPartyResultWrapper();
        ReflectionTestUtils.setField(retrievePartyService, "goodStatuses",
                "OK,NOT_FOUND,BAD_REQUEST,INTERNAL_SERVER_ERROR");
        ReflectionTestUtils.setField(retrievePartyService, "url", "https://localhost:8080/parties/retrieve");
        Map<String, String> headers = prepareANZXRequestHeadersForInt3();
        Map<String, String> queryParameters = new HashMap<String, String>();
        Party person = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:SamplePersonInputANZXInt3.json"),
                Party.class);

        ResponseEntity<TCRMService> mdmResponse = setMDMResponse_Person();
        String response = "{ \"partyType\": \"P\", \"source\": \"FENERGOANZX\", \"sourceEstablishedDate\": \"2005-11-10\", \"sourceClosedDate\": \"2015-11-10\", \"status\": \"Active\", \"dateOfBirth\": \"1969-11-06\", \"gender\": \"N\", \"maritalStatus\": \"Married/De Facto\", \"deceasedDate\": \"2000-01-01\", \"bankruptDate\": \"2019-03-15\", \"employeeIndicator\": \"Y\", \"employerName\": \"ANZ\", \"kycDetails\": { \"status\": \"CO\", \"verificationLevel\": \"NM\" }, \"occupation\": { \"code\": \"111200\" }, \"addresses\": [ { \"addressUsageType\": \"Primary Residential\", \"addressLineOne\": \"(LOT) YORK RD\", \"city\": \"POPANYINNING\", \"postalCode\": \"6309\", \"state\": \"SA\", \"country\": \"AUS\", \"region\": \"\", \"deliveryId\": \"80941156\", \"source\": \"FENERGOANZX\", \"startDate\": \"1901-01-01\", \"endDate\": \"9999-12-31\" }, { \"addressUsageType\": \"Primary Mailing\", \"addressLineOne\": \"PO BOX 147\", \"city\": \"CAMBERWELL\", \"postalCode\": \"3124\", \"state\": \"VIC\", \"country\": \"DZA\", \"region\": \"VIC\", \"deliveryId\": \"69775498\", \"source\": \"FENERGOANZX\", \"startDate\": \"2014-05-29\", \"endDate\": \"9999-12-31\" } ], \"phones\": [ { \"phoneUsageType\": \"Mobile Telephone\", \"phone\": \"+610422591580\", \"preferred\": \"\", \"source\": \"FENERGOANZX\", \"sequence\": \"3\", \"startDate\": \"1901-01-01\", \"endDate\": \"9999-12-31\" }, { \"phoneUsageType\": \"Primary Home Telephone\", \"phone\": \"+61386549523\", \"preferred\": \"Y\", \"source\": \"FENERGOANZX\", \"sequence\": \"1\", \"startDate\": \"1901-01-01\", \"endDate\": \"9999-12-31\" }, { \"phoneUsageType\": \"Secondary Home Telephone\", \"phone\": \"+613865675234\", \"preferred\": \"Y\", \"source\": \"FENERGOANZX\", \"sequence\": \"2\", \"startDate\": \"1901-01-01\", \"endDate\": \"2019-12-31\" } ], \"emails\": [ { \"emailUsageType\": \"Email\", \"email\": \"damian@trecose.com\", \"preferred\": \"\", \"source\": \"FENERGOANZX\", \"startDate\": \"1901-01-01\", \"endDate\": \"\" } ], \"identifiers\": [ { \"identifierUsageType\": \"Drivers License\", \"identifier\": \"5642341\", \"identificationIssueLocation\": \"VIC\", \"source\": \"FENERGOANZX\", \"sequence\": \"1\", \"startDate\": \"1901-01-01\", \"expiryDate\": \"9999-12-31\" } ], \"preferences\": [ { \"preferenceType\": \"Disclosure Indicator\", \"preferenceValue\": \"N\", \"preferenceReason\": \"Not Allowed\", \"source\": \"FENERGOANZX\", \"startDate\": \"1901-01-01\", \"endDate\": \"\" }, { \"preferenceType\": \"Primary Preferred Contact Day and Time\", \"preferenceValue\": \"000000000000NNNNNNN\", \"preferenceReason\": \"Not Interested\", \"source\": \"FENERGOANZX\", \"startDate\": \"2018-08-31\", \"endDate\": \"9999-12-31\" }, { \"preferenceType\": \"Secondary Preferred Contact Day and Time\", \"preferenceValue\": \"000000000000YYYYYYY\", \"preferenceReason\": \"Interested\", \"source\": \"CAP-CIS\", \"startDate\": \"2018-08-31\", \"endDate\": \"9999-12-31\" }, { \"preferenceType\": \"Advertising Indicator\", \"preferenceValue\": \"Y\", \"preferenceReason\": \"Allowed\", \"source\": \"FENERGOANZX\", \"startDate\": \"9999-12-01\", \"endDate\": \"9999-12-31\" } ], \"bankingServices\": [ { \"key\": \"DNC\", \"value\": \"Y\" }, { \"key\": \"NVE\", \"value\": \"Y\" } ], \"names\": [ { \"firstName\": \"Abhishek\", \"lastName\": \"DAMIAN M PHELAN\" }, { \"nameUsageType\": \"Mailing Name\", \"lastName\": \"MR D PHELAN\", \"startDate\": \"1901-01-01\", \"source\": \"FENERGOANZX\" } ], \"sourceSystems\": [ { \"sourceSystemId\": \"4012977562\", \"sourceSystemName\": \"CAP-CIS\" } ] }";
        Party responseParty = new ObjectMapper().readValue(response, Party.class);
        ArrayList<Party> parties = new ArrayList<Party>();
        parties.add(responseParty);
        searchPartyResultWrapper.getCertifiedResults().addAll(parties);
        ResponseEntity<Object> apiresponse = new ResponseEntity<Object>(parties, HttpStatus.OK);
        doReturn(new StandardisedParty(setParameterisedBodyANZX(), true)).when(dataStandardisationService)
                .standardiseParty(Mockito.any(APIRequest.class));
        doReturn(new ValidatedParty(setParameterisedBodyANZX(), true)).when(dataValidationService)
                .validateParty(Mockito.any(APIRequest.class));
        doReturn(mdmResponse).when(maintainPartyService).invokeMdmBackend((Mockito.any(String.class)),
                Mockito.any(String.class));
        APIResponse apiResponse = getApiResponse();
        doReturn(apiResponse).when(maintainPartyService).transformMdmResponse(Mockito.any(String.class), Mockito.any(),
                Mockito.any());
        doReturn(apiresponse).when(retrievePartyService).invokeDownStreamService(Mockito.any(),
                Mockito.any(String.class));
        doReturn(searchPartyResultWrapper).when(retrievePartyService).getResponse(Mockito.any(),
                Mockito.any(String.class));
        doReturn(new StandardisedParty(setParameterisedBody(), true)).when(dataStandardisationService)
        .invokeRedHatRuleEngine(Mockito.any(APIRequest.class));

        Party capResponseParty = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:CapParty.json"),
                Party.class);
        APIRequest<Party> capParty = new APIRequest<Party>(headers, queryParameters, capResponseParty);
        CAPParty capPratyObj = new CAPParty(capParty, true);
        doReturn(capPratyObj).when(capTransformationService).createCapProfile(Mockito.any(), Mockito.any(),
                Mockito.anyString());
        doReturn(true).when(jwtInterceptor).validateJWT(any(APIRequest.class));
        doNothing().when(idempotencyConfigUtil).validate(Mockito.any(), Mockito.any(), Mockito.any());
        doReturn(idempotencyConfigUtil).when(maintainPartyService).getIdempotencyUtil();
        doReturn(false).when(idempotencyConfigUtil).isChannelIncluded(Mockito.any(), Mockito.any());
        doReturn(accessList).when(uamAccessConfiguration).getAccessMap(any(String.class));
        ResponseEntity<Object> result = apiController.maintainPartyV2(headers, queryParameters, person);
        assertTrue(ObjectUtils.isNotEmpty(result.getBody()));
    }

    @Test
    public void maintainV2PartyTestInt3CTTwithTIN() throws Exception {
        SearchPartyResultWrapper searchPartyResultWrapper = new SearchPartyResultWrapper();
        ReflectionTestUtils.setField(retrievePartyService, "goodStatuses",
                "OK,NOT_FOUND,BAD_REQUEST,INTERNAL_SERVER_ERROR");
        ReflectionTestUtils.setField(retrievePartyService, "url", "https://localhost:8080/parties/retrieve");
        Map<String, String> headers = prepareANZXRequestHeadersForInt3();
        Map<String, String> queryParameters = new HashMap<String, String>();
        Party person = new ObjectMapper()
                .readValue(ResourceUtils.getFile("classpath:SamplePersonInputANZXInt3CTTwithTIN.json"), Party.class);

        ResponseEntity<TCRMService> mdmResponse = setMDMResponse_Person();
        String response = "{ \"partyType\": \"P\", \"source\": \"FENERGOANZX\", \"sourceEstablishedDate\": \"2005-11-10\", \"sourceClosedDate\": \"2015-11-10\", \"status\": \"Active\", \"dateOfBirth\": \"1969-11-06\", \"gender\": \"N\", \"maritalStatus\": \"Married/De Facto\", \"deceasedDate\": \"2000-01-01\", \"bankruptDate\": \"2019-03-15\", \"employeeIndicator\": \"Y\", \"employerName\": \"ANZ\", \"kycDetails\": { \"status\": \"CO\", \"verificationLevel\": \"NM\" }, \"occupation\": { \"code\": \"111200\" }, \"addresses\": [ { \"addressUsageType\": \"Primary Residential\", \"addressLineOne\": \"(LOT) YORK RD\", \"city\": \"POPANYINNING\", \"postalCode\": \"6309\", \"state\": \"SA\", \"country\": \"AUS\", \"region\": \"\", \"deliveryId\": \"80941156\", \"source\": \"FENERGOANZX\", \"startDate\": \"1901-01-01\", \"endDate\": \"9999-12-31\" }, { \"addressUsageType\": \"Primary Mailing\", \"addressLineOne\": \"PO BOX 147\", \"city\": \"CAMBERWELL\", \"postalCode\": \"3124\", \"state\": \"VIC\", \"country\": \"DZA\", \"region\": \"VIC\", \"deliveryId\": \"69775498\", \"source\": \"FENERGOANZX\", \"startDate\": \"2014-05-29\", \"endDate\": \"9999-12-31\" } ], \"phones\": [ { \"phoneUsageType\": \"Mobile Telephone\", \"phone\": \"+610422591580\", \"preferred\": \"\", \"source\": \"FENERGOANZX\", \"sequence\": \"3\", \"startDate\": \"1901-01-01\", \"endDate\": \"9999-12-31\" }, { \"phoneUsageType\": \"Primary Home Telephone\", \"phone\": \"+61386549523\", \"preferred\": \"Y\", \"source\": \"FENERGOANZX\", \"sequence\": \"1\", \"startDate\": \"1901-01-01\", \"endDate\": \"9999-12-31\" }, { \"phoneUsageType\": \"Secondary Home Telephone\", \"phone\": \"+613865675234\", \"preferred\": \"Y\", \"source\": \"FENERGOANZX\", \"sequence\": \"2\", \"startDate\": \"1901-01-01\", \"endDate\": \"2019-12-31\" } ], \"emails\": [ { \"emailUsageType\": \"Email\", \"email\": \"damian@trecose.com\", \"preferred\": \"\", \"source\": \"FENERGOANZX\", \"startDate\": \"1901-01-01\", \"endDate\": \"\" } ], \"identifiers\": [ { \"identifierUsageType\": \"Drivers License\", \"identifier\": \"5642341\", \"identificationIssueLocation\": \"VIC\", \"source\": \"FENERGOANZX\", \"sequence\": \"1\", \"startDate\": \"1901-01-01\", \"expiryDate\": \"9999-12-31\" } ], \"preferences\": [ { \"preferenceType\": \"Disclosure Indicator\", \"preferenceValue\": \"N\", \"preferenceReason\": \"Not Allowed\", \"source\": \"FENERGOANZX\", \"startDate\": \"1901-01-01\", \"endDate\": \"\" }, { \"preferenceType\": \"Primary Preferred Contact Day and Time\", \"preferenceValue\": \"000000000000NNNNNNN\", \"preferenceReason\": \"Not Interested\", \"source\": \"FENERGOANZX\", \"startDate\": \"2018-08-31\", \"endDate\": \"9999-12-31\" }, { \"preferenceType\": \"Secondary Preferred Contact Day and Time\", \"preferenceValue\": \"000000000000YYYYYYY\", \"preferenceReason\": \"Interested\", \"source\": \"CAP-CIS\", \"startDate\": \"2018-08-31\", \"endDate\": \"9999-12-31\" }, { \"preferenceType\": \"Advertising Indicator\", \"preferenceValue\": \"Y\", \"preferenceReason\": \"Allowed\", \"source\": \"FENERGOANZX\", \"startDate\": \"9999-12-01\", \"endDate\": \"9999-12-31\" } ], \"bankingServices\": [ { \"key\": \"DNC\", \"value\": \"Y\" }, { \"key\": \"NVE\", \"value\": \"Y\" } ], \"names\": [ { \"firstName\": \"Abhishek\", \"lastName\": \"DAMIAN M PHELAN\" }, { \"nameUsageType\": \"Mailing Name\", \"lastName\": \"MR D PHELAN\", \"startDate\": \"1901-01-01\", \"source\": \"FENERGOANZX\" } ], \"sourceSystems\": [ { \"sourceSystemId\": \"4012977562\", \"sourceSystemName\": \"CAP-CIS\" } ] }";
        Party responseParty = new ObjectMapper().readValue(response, Party.class);
        ArrayList<Party> parties = new ArrayList<Party>();
        parties.add(responseParty);
        searchPartyResultWrapper.getCertifiedResults().addAll(parties);
        ResponseEntity<Object> apiresponse = new ResponseEntity<Object>(parties, HttpStatus.OK);
        doReturn(new StandardisedParty(setParameterisedBodyANZX(), true)).when(dataStandardisationService)
                .standardiseParty(Mockito.any(APIRequest.class));
        doReturn(new ValidatedParty(setParameterisedBodyANZX(), true)).when(dataValidationService)
                .validateParty(Mockito.any(APIRequest.class));
        doReturn(mdmResponse).when(maintainPartyService).invokeMdmBackend((Mockito.any(String.class)),
                Mockito.any(String.class));
        APIResponse apiResponse = getApiResponse();
        doReturn(apiResponse).when(maintainPartyService).transformMdmResponse(Mockito.any(String.class), Mockito.any(),
                Mockito.any());
        doReturn(apiresponse).when(retrievePartyService).invokeDownStreamService(Mockito.any(),
                Mockito.any(String.class));
        doReturn(searchPartyResultWrapper).when(retrievePartyService).getResponse(Mockito.any(),
                Mockito.any(String.class));
        doReturn(new StandardisedParty(setParameterisedBody(), true)).when(dataStandardisationService)
        .invokeRedHatRuleEngine(Mockito.any(APIRequest.class));

        Party capResponseParty = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:CapParty.json"),
                Party.class);
        APIRequest<Party> capParty = new APIRequest<Party>(headers, queryParameters, capResponseParty);
        CAPParty capPratyObj = new CAPParty(capParty, true);
        doReturn(capPratyObj).when(capTransformationService).createCapProfile(Mockito.any(), Mockito.any(),
                Mockito.anyString());
        doReturn(true).when(jwtInterceptor).validateJWT(any(APIRequest.class));

        doNothing().when(idempotencyConfigUtil).validate(Mockito.any(), Mockito.any(), Mockito.any());
        doReturn(idempotencyConfigUtil).when(maintainPartyService).getIdempotencyUtil();
        doReturn(false).when(idempotencyConfigUtil).isChannelIncluded(Mockito.anyString(), Mockito.anyString());
        doReturn(accessList).when(uamAccessConfiguration).getAccessMap(any(String.class));
        ResponseEntity<Object> result = apiController.maintainPartyV2(headers, queryParameters, person);
        assertTrue(ObjectUtils.isNotEmpty(result.getBody()));
    }

    @Test
    public void maintainV2PartyTestInt3CTTwithNoTinReason() throws Exception {
        SearchPartyResultWrapper searchPartyResultWrapper = new SearchPartyResultWrapper();
        ReflectionTestUtils.setField(retrievePartyService, "goodStatuses",
                "OK,NOT_FOUND,BAD_REQUEST,INTERNAL_SERVER_ERROR");
        ReflectionTestUtils.setField(retrievePartyService, "url", "https://localhost:8080/parties/retrieve");
        Map<String, String> headers = prepareANZXRequestHeadersForInt3();
        Map<String, String> queryParameters = new HashMap<String, String>();
        Party person = new ObjectMapper().readValue(
                ResourceUtils.getFile("classpath:SamplePersonInputANZXInt3CTTwithNoTinReason.json"), Party.class);

        ResponseEntity<TCRMService> mdmResponse = setMDMResponse_Person();
        String response = "{ \"partyType\": \"P\", \"source\": \"FENERGOANZX\", \"sourceEstablishedDate\": \"2005-11-10\", \"sourceClosedDate\": \"2015-11-10\", \"status\": \"Active\", \"dateOfBirth\": \"1969-11-06\", \"gender\": \"N\", \"maritalStatus\": \"Married/De Facto\", \"deceasedDate\": \"2000-01-01\", \"bankruptDate\": \"2019-03-15\", \"employeeIndicator\": \"Y\", \"employerName\": \"ANZ\", \"kycDetails\": { \"status\": \"CO\", \"verificationLevel\": \"NM\" }, \"occupation\": { \"code\": \"111200\" }, \"addresses\": [ { \"addressUsageType\": \"Primary Residential\", \"addressLineOne\": \"(LOT) YORK RD\", \"city\": \"POPANYINNING\", \"postalCode\": \"6309\", \"state\": \"SA\", \"country\": \"AUS\", \"region\": \"\", \"deliveryId\": \"80941156\", \"source\": \"FENERGOANZX\", \"startDate\": \"1901-01-01\", \"endDate\": \"9999-12-31\" }, { \"addressUsageType\": \"Primary Mailing\", \"addressLineOne\": \"PO BOX 147\", \"city\": \"CAMBERWELL\", \"postalCode\": \"3124\", \"state\": \"VIC\", \"country\": \"DZA\", \"region\": \"VIC\", \"deliveryId\": \"69775498\", \"source\": \"FENERGOANZX\", \"startDate\": \"2014-05-29\", \"endDate\": \"9999-12-31\" } ], \"phones\": [ { \"phoneUsageType\": \"Mobile Telephone\", \"phone\": \"+610422591580\", \"preferred\": \"\", \"source\": \"FENERGOANZX\", \"sequence\": \"3\", \"startDate\": \"1901-01-01\", \"endDate\": \"9999-12-31\" }, { \"phoneUsageType\": \"Primary Home Telephone\", \"phone\": \"+61386549523\", \"preferred\": \"Y\", \"source\": \"FENERGOANZX\", \"sequence\": \"1\", \"startDate\": \"1901-01-01\", \"endDate\": \"9999-12-31\" }, { \"phoneUsageType\": \"Secondary Home Telephone\", \"phone\": \"+613865675234\", \"preferred\": \"Y\", \"source\": \"FENERGOANZX\", \"sequence\": \"2\", \"startDate\": \"1901-01-01\", \"endDate\": \"2019-12-31\" } ], \"emails\": [ { \"emailUsageType\": \"Email\", \"email\": \"damian@trecose.com\", \"preferred\": \"\", \"source\": \"FENERGOANZX\", \"startDate\": \"1901-01-01\", \"endDate\": \"\" } ], \"identifiers\": [ { \"identifierUsageType\": \"Drivers License\", \"identifier\": \"5642341\", \"identificationIssueLocation\": \"VIC\", \"source\": \"FENERGOANZX\", \"sequence\": \"1\", \"startDate\": \"1901-01-01\", \"expiryDate\": \"9999-12-31\" } ], \"preferences\": [ { \"preferenceType\": \"Disclosure Indicator\", \"preferenceValue\": \"N\", \"preferenceReason\": \"Not Allowed\", \"source\": \"FENERGOANZX\", \"startDate\": \"1901-01-01\", \"endDate\": \"\" }, { \"preferenceType\": \"Primary Preferred Contact Day and Time\", \"preferenceValue\": \"000000000000NNNNNNN\", \"preferenceReason\": \"Not Interested\", \"source\": \"FENERGOANZX\", \"startDate\": \"2018-08-31\", \"endDate\": \"9999-12-31\" }, { \"preferenceType\": \"Secondary Preferred Contact Day and Time\", \"preferenceValue\": \"000000000000YYYYYYY\", \"preferenceReason\": \"Interested\", \"source\": \"CAP-CIS\", \"startDate\": \"2018-08-31\", \"endDate\": \"9999-12-31\" }, { \"preferenceType\": \"Advertising Indicator\", \"preferenceValue\": \"Y\", \"preferenceReason\": \"Allowed\", \"source\": \"FENERGOANZX\", \"startDate\": \"9999-12-01\", \"endDate\": \"9999-12-31\" } ], \"bankingServices\": [ { \"key\": \"DNC\", \"value\": \"Y\" }, { \"key\": \"NVE\", \"value\": \"Y\" } ], \"names\": [ { \"firstName\": \"Abhishek\", \"lastName\": \"DAMIAN M PHELAN\" }, { \"nameUsageType\": \"Mailing Name\", \"lastName\": \"MR D PHELAN\", \"startDate\": \"1901-01-01\", \"source\": \"FENERGOANZX\" } ], \"sourceSystems\": [ { \"sourceSystemId\": \"4012977562\", \"sourceSystemName\": \"CAP-CIS\" } ] }";
        Party responseParty = new ObjectMapper().readValue(response, Party.class);
        ArrayList<Party> parties = new ArrayList<Party>();
        parties.add(responseParty);
        searchPartyResultWrapper.getCertifiedResults().addAll(parties);
        ResponseEntity<Object> apiresponse = new ResponseEntity<Object>(parties, HttpStatus.OK);
        doReturn(new StandardisedParty(setParameterisedBodyANZX(), true)).when(dataStandardisationService)
                .standardiseParty(Mockito.any(APIRequest.class));
        doReturn(new ValidatedParty(setParameterisedBodyANZX(), true)).when(dataValidationService)
                .validateParty(Mockito.any(APIRequest.class));
        doReturn(mdmResponse).when(maintainPartyService).invokeMdmBackend((Mockito.any(String.class)),
                Mockito.any(String.class));
        APIResponse apiResponse = getApiResponse();
        doReturn(apiResponse).when(maintainPartyService).transformMdmResponse(Mockito.any(String.class), Mockito.any(),
                Mockito.any());
        doReturn(apiresponse).when(retrievePartyService).invokeDownStreamService(Mockito.any(),
                Mockito.any(String.class));
        doReturn(searchPartyResultWrapper).when(retrievePartyService).getResponse(Mockito.any(),
                Mockito.any(String.class));
        doReturn(new StandardisedParty(setParameterisedBody(), true)).when(dataStandardisationService)
        .invokeRedHatRuleEngine(Mockito.any(APIRequest.class));

        Party capResponseParty = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:CapParty.json"),
                Party.class);
        APIRequest<Party> capParty = new APIRequest<Party>(headers, queryParameters, capResponseParty);
        CAPParty capPratyObj = new CAPParty(capParty, true);
        doReturn(capPratyObj).when(capTransformationService).createCapProfile(Mockito.any(), Mockito.any(),
                Mockito.anyString());
        doReturn(true).when(jwtInterceptor).validateJWT(any(APIRequest.class));

        doNothing().when(idempotencyConfigUtil).validate(Mockito.any(), Mockito.any(), Mockito.any());
        doReturn(idempotencyConfigUtil).when(maintainPartyService).getIdempotencyUtil();
        doReturn(false).when(idempotencyConfigUtil).isChannelIncluded(Mockito.anyString(), Mockito.anyString());
        doReturn(accessList).when(uamAccessConfiguration).getAccessMap(any(String.class));
        ResponseEntity<Object> result = apiController.maintainPartyV2(headers, queryParameters, person);
        assertTrue(ObjectUtils.isNotEmpty(result.getBody()));
    }

    @Test
    public void maintainV2PartyTestInt3TFN() throws Exception {
        SearchPartyResultWrapper searchPartyResultWrapper = new SearchPartyResultWrapper();
        ReflectionTestUtils.setField(retrievePartyService, "goodStatuses",
                "OK,NOT_FOUND,BAD_REQUEST,INTERNAL_SERVER_ERROR");
        ReflectionTestUtils.setField(retrievePartyService, "url", "https://localhost:8080/parties/retrieve");
        Map<String, String> headers = prepareANZXRequestHeadersForInt3();
        Map<String, String> queryParameters = new HashMap<String, String>();
        Party person = new ObjectMapper()
                .readValue(ResourceUtils.getFile("classpath:SamplePersonInputANZXInt3TFN.json"), Party.class);

        ResponseEntity<TCRMService> mdmResponse = setMDMResponse_Person();
        String response = "{ \"partyType\": \"P\", \"source\": \"FENERGOANZX\", \"sourceEstablishedDate\": \"2005-11-10\", \"sourceClosedDate\": \"2015-11-10\", \"status\": \"Active\", \"dateOfBirth\": \"1969-11-06\", \"gender\": \"N\", \"maritalStatus\": \"Married/De Facto\", \"deceasedDate\": \"2000-01-01\", \"bankruptDate\": \"2019-03-15\", \"employeeIndicator\": \"Y\", \"employerName\": \"ANZ\", \"kycDetails\": { \"status\": \"CO\", \"verificationLevel\": \"NM\" }, \"occupation\": { \"code\": \"111200\" }, \"addresses\": [ { \"addressUsageType\": \"Primary Residential\", \"addressLineOne\": \"(LOT) YORK RD\", \"city\": \"POPANYINNING\", \"postalCode\": \"6309\", \"state\": \"SA\", \"country\": \"AUS\", \"region\": \"\", \"deliveryId\": \"80941156\", \"source\": \"FENERGOANZX\", \"startDate\": \"1901-01-01\", \"endDate\": \"9999-12-31\" }, { \"addressUsageType\": \"Primary Mailing\", \"addressLineOne\": \"PO BOX 147\", \"city\": \"CAMBERWELL\", \"postalCode\": \"3124\", \"state\": \"VIC\", \"country\": \"DZA\", \"region\": \"VIC\", \"deliveryId\": \"69775498\", \"source\": \"FENERGOANZX\", \"startDate\": \"2014-05-29\", \"endDate\": \"9999-12-31\" } ], \"phones\": [ { \"phoneUsageType\": \"Mobile Telephone\", \"phone\": \"+610422591580\", \"preferred\": \"\", \"source\": \"FENERGOANZX\", \"sequence\": \"3\", \"startDate\": \"1901-01-01\", \"endDate\": \"9999-12-31\" }, { \"phoneUsageType\": \"Primary Home Telephone\", \"phone\": \"+61386549523\", \"preferred\": \"Y\", \"source\": \"FENERGOANZX\", \"sequence\": \"1\", \"startDate\": \"1901-01-01\", \"endDate\": \"9999-12-31\" }, { \"phoneUsageType\": \"Secondary Home Telephone\", \"phone\": \"+613865675234\", \"preferred\": \"Y\", \"source\": \"FENERGOANZX\", \"sequence\": \"2\", \"startDate\": \"1901-01-01\", \"endDate\": \"2019-12-31\" } ], \"emails\": [ { \"emailUsageType\": \"Email\", \"email\": \"damian@trecose.com\", \"preferred\": \"\", \"source\": \"FENERGOANZX\", \"startDate\": \"1901-01-01\", \"endDate\": \"\" } ], \"identifiers\": [ { \"identifierUsageType\": \"Drivers License\", \"identifier\": \"5642341\", \"identificationIssueLocation\": \"VIC\", \"source\": \"FENERGOANZX\", \"sequence\": \"1\", \"startDate\": \"1901-01-01\", \"expiryDate\": \"9999-12-31\" } ], \"preferences\": [ { \"preferenceType\": \"Disclosure Indicator\", \"preferenceValue\": \"N\", \"preferenceReason\": \"Not Allowed\", \"source\": \"FENERGOANZX\", \"startDate\": \"1901-01-01\", \"endDate\": \"\" }, { \"preferenceType\": \"Primary Preferred Contact Day and Time\", \"preferenceValue\": \"000000000000NNNNNNN\", \"preferenceReason\": \"Not Interested\", \"source\": \"FENERGOANZX\", \"startDate\": \"2018-08-31\", \"endDate\": \"9999-12-31\" }, { \"preferenceType\": \"Secondary Preferred Contact Day and Time\", \"preferenceValue\": \"000000000000YYYYYYY\", \"preferenceReason\": \"Interested\", \"source\": \"CAP-CIS\", \"startDate\": \"2018-08-31\", \"endDate\": \"9999-12-31\" }, { \"preferenceType\": \"Advertising Indicator\", \"preferenceValue\": \"Y\", \"preferenceReason\": \"Allowed\", \"source\": \"FENERGOANZX\", \"startDate\": \"9999-12-01\", \"endDate\": \"9999-12-31\" } ], \"bankingServices\": [ { \"key\": \"DNC\", \"value\": \"Y\" }, { \"key\": \"NVE\", \"value\": \"Y\" } ], \"names\": [ { \"firstName\": \"Abhishek\", \"lastName\": \"DAMIAN M PHELAN\" }, { \"nameUsageType\": \"Mailing Name\", \"lastName\": \"MR D PHELAN\", \"startDate\": \"1901-01-01\", \"source\": \"FENERGOANZX\" } ], \"sourceSystems\": [ { \"sourceSystemId\": \"4012977562\", \"sourceSystemName\": \"CAP-CIS\" } ] }";
        Party responseParty = new ObjectMapper().readValue(response, Party.class);
        ArrayList<Party> parties = new ArrayList<Party>();
        parties.add(responseParty);
        searchPartyResultWrapper.getCertifiedResults().addAll(parties);
        ResponseEntity<Object> apiresponse = new ResponseEntity<Object>(parties, HttpStatus.OK);
        doReturn(new StandardisedParty(setParameterisedBodyANZX(), true)).when(dataStandardisationService)
                .standardiseParty(Mockito.any(APIRequest.class));
        doReturn(new ValidatedParty(setParameterisedBodyANZX(), true)).when(dataValidationService)
                .validateParty(Mockito.any(APIRequest.class));
        doReturn(mdmResponse).when(maintainPartyService).invokeMdmBackend((Mockito.any(String.class)),
                Mockito.any(String.class));
        APIResponse apiResponse = getApiResponse();
        doReturn(apiResponse).when(maintainPartyService).transformMdmResponse(Mockito.any(String.class), Mockito.any(),
                Mockito.any());
        doReturn(apiresponse).when(retrievePartyService).invokeDownStreamService(Mockito.any(),
                Mockito.any(String.class));
        doReturn(searchPartyResultWrapper).when(retrievePartyService).getResponse(Mockito.any(),
                Mockito.any(String.class));
        doReturn(new StandardisedParty(setParameterisedBody(), true)).when(dataStandardisationService)
        .invokeRedHatRuleEngine(Mockito.any(APIRequest.class));

        Party capResponseParty = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:CapParty.json"),
                Party.class);
        APIRequest<Party> capParty = new APIRequest<Party>(headers, queryParameters, capResponseParty);
        CAPParty capPratyObj = new CAPParty(capParty, true);
        doReturn(capPratyObj).when(capTransformationService).createCapProfile(Mockito.any(), Mockito.any(),
                Mockito.anyString());
        doReturn(true).when(jwtInterceptor).validateJWT(any(APIRequest.class));

        doNothing().when(idempotencyConfigUtil).validate(Mockito.any(), Mockito.any(), Mockito.any());
        doReturn(idempotencyConfigUtil).when(maintainPartyService).getIdempotencyUtil();
        doReturn(false).when(idempotencyConfigUtil).isChannelIncluded(Mockito.anyString(), Mockito.anyString());
        doReturn(accessList).when(uamAccessConfiguration).getAccessMap(any(String.class));
        ResponseEntity<Object> result = apiController.maintainPartyV2(headers, queryParameters, person);
        assertTrue(ObjectUtils.isNotEmpty(result.getBody()));
    }

    @Test
    public void maintainV2PartyTestInt3TFNwithNoTinReason() throws Exception {
        SearchPartyResultWrapper searchPartyResultWrapper = new SearchPartyResultWrapper();
        ReflectionTestUtils.setField(retrievePartyService, "goodStatuses",
                "OK,NOT_FOUND,BAD_REQUEST,INTERNAL_SERVER_ERROR");
        ReflectionTestUtils.setField(retrievePartyService, "url", "https://localhost:8080/parties/retrieve");
        Map<String, String> headers = prepareANZXRequestHeadersForInt3();
        Map<String, String> queryParameters = new HashMap<String, String>();
        Party person = new ObjectMapper().readValue(
                ResourceUtils.getFile("classpath:SamplePersonInputANZXInt3TFNwithNoTinReason.json"), Party.class);

        ResponseEntity<TCRMService> mdmResponse = setMDMResponse_Person();
        String response = "{ \"partyType\": \"P\", \"source\": \"FENERGOANZX\", \"sourceEstablishedDate\": \"2005-11-10\", \"sourceClosedDate\": \"2015-11-10\", \"status\": \"Active\", \"dateOfBirth\": \"1969-11-06\", \"gender\": \"N\", \"maritalStatus\": \"Married/De Facto\", \"deceasedDate\": \"2000-01-01\", \"bankruptDate\": \"2019-03-15\", \"employeeIndicator\": \"Y\", \"employerName\": \"ANZ\", \"kycDetails\": { \"status\": \"CO\", \"verificationLevel\": \"NM\" }, \"occupation\": { \"code\": \"111200\" }, \"addresses\": [ { \"addressUsageType\": \"Primary Residential\", \"addressLineOne\": \"(LOT) YORK RD\", \"city\": \"POPANYINNING\", \"postalCode\": \"6309\", \"state\": \"SA\", \"country\": \"AUS\", \"region\": \"\", \"deliveryId\": \"80941156\", \"source\": \"FENERGOANZX\", \"startDate\": \"1901-01-01\", \"endDate\": \"9999-12-31\" }, { \"addressUsageType\": \"Primary Mailing\", \"addressLineOne\": \"PO BOX 147\", \"city\": \"CAMBERWELL\", \"postalCode\": \"3124\", \"state\": \"VIC\", \"country\": \"DZA\", \"region\": \"VIC\", \"deliveryId\": \"69775498\", \"source\": \"FENERGOANZX\", \"startDate\": \"2014-05-29\", \"endDate\": \"9999-12-31\" } ], \"phones\": [ { \"phoneUsageType\": \"Mobile Telephone\", \"phone\": \"+610422591580\", \"preferred\": \"\", \"source\": \"FENERGOANZX\", \"sequence\": \"3\", \"startDate\": \"1901-01-01\", \"endDate\": \"9999-12-31\" }, { \"phoneUsageType\": \"Primary Home Telephone\", \"phone\": \"+61386549523\", \"preferred\": \"Y\", \"source\": \"FENERGOANZX\", \"sequence\": \"1\", \"startDate\": \"1901-01-01\", \"endDate\": \"9999-12-31\" }, { \"phoneUsageType\": \"Secondary Home Telephone\", \"phone\": \"+613865675234\", \"preferred\": \"Y\", \"source\": \"FENERGOANZX\", \"sequence\": \"2\", \"startDate\": \"1901-01-01\", \"endDate\": \"2019-12-31\" } ], \"emails\": [ { \"emailUsageType\": \"Email\", \"email\": \"damian@trecose.com\", \"preferred\": \"\", \"source\": \"FENERGOANZX\", \"startDate\": \"1901-01-01\", \"endDate\": \"\" } ], \"identifiers\": [ { \"identifierUsageType\": \"Drivers License\", \"identifier\": \"5642341\", \"identificationIssueLocation\": \"VIC\", \"source\": \"FENERGOANZX\", \"sequence\": \"1\", \"startDate\": \"1901-01-01\", \"expiryDate\": \"9999-12-31\" } ], \"preferences\": [ { \"preferenceType\": \"Disclosure Indicator\", \"preferenceValue\": \"N\", \"preferenceReason\": \"Not Allowed\", \"source\": \"FENERGOANZX\", \"startDate\": \"1901-01-01\", \"endDate\": \"\" }, { \"preferenceType\": \"Primary Preferred Contact Day and Time\", \"preferenceValue\": \"000000000000NNNNNNN\", \"preferenceReason\": \"Not Interested\", \"source\": \"FENERGOANZX\", \"startDate\": \"2018-08-31\", \"endDate\": \"9999-12-31\" }, { \"preferenceType\": \"Secondary Preferred Contact Day and Time\", \"preferenceValue\": \"000000000000YYYYYYY\", \"preferenceReason\": \"Interested\", \"source\": \"CAP-CIS\", \"startDate\": \"2018-08-31\", \"endDate\": \"9999-12-31\" }, { \"preferenceType\": \"Advertising Indicator\", \"preferenceValue\": \"Y\", \"preferenceReason\": \"Allowed\", \"source\": \"FENERGOANZX\", \"startDate\": \"9999-12-01\", \"endDate\": \"9999-12-31\" } ], \"bankingServices\": [ { \"key\": \"DNC\", \"value\": \"Y\" }, { \"key\": \"NVE\", \"value\": \"Y\" } ], \"names\": [ { \"firstName\": \"Abhishek\", \"lastName\": \"DAMIAN M PHELAN\" }, { \"nameUsageType\": \"Mailing Name\", \"lastName\": \"MR D PHELAN\", \"startDate\": \"1901-01-01\", \"source\": \"FENERGOANZX\" } ], \"sourceSystems\": [ { \"sourceSystemId\": \"4012977562\", \"sourceSystemName\": \"CAP-CIS\" } ] }";
        Party responseParty = new ObjectMapper().readValue(response, Party.class);
        ArrayList<Party> parties = new ArrayList<Party>();
        parties.add(responseParty);
        searchPartyResultWrapper.getCertifiedResults().addAll(parties);
        ResponseEntity<Object> apiresponse = new ResponseEntity<Object>(parties, HttpStatus.OK);
        doReturn(new StandardisedParty(setParameterisedBodyANZX(), true)).when(dataStandardisationService)
                .standardiseParty(Mockito.any(APIRequest.class));
        doReturn(new ValidatedParty(setParameterisedBodyANZX(), true)).when(dataValidationService)
                .validateParty(Mockito.any(APIRequest.class));
        doReturn(mdmResponse).when(maintainPartyService).invokeMdmBackend((Mockito.any(String.class)),
                Mockito.any(String.class));
        APIResponse apiResponse = getApiResponse();
        doReturn(apiResponse).when(maintainPartyService).transformMdmResponse(Mockito.any(String.class), Mockito.any(),
                Mockito.any());
        doReturn(apiresponse).when(retrievePartyService).invokeDownStreamService(Mockito.any(),
                Mockito.any(String.class));
        doReturn(searchPartyResultWrapper).when(retrievePartyService).getResponse(Mockito.any(),
                Mockito.any(String.class));
        doReturn(new StandardisedParty(setParameterisedBody(), true)).when(dataStandardisationService)
        .invokeRedHatRuleEngine(Mockito.any(APIRequest.class));

        Party capResponseParty = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:CapParty.json"),
                Party.class);

        doNothing().when(idempotencyConfigUtil).validate(Mockito.any(), Mockito.any(), Mockito.any());
        doReturn(idempotencyConfigUtil).when(maintainPartyService).getIdempotencyUtil();
        doReturn(false).when(idempotencyConfigUtil).isChannelIncluded(Mockito.anyString(), Mockito.anyString());

        APIRequest<Party> capParty = new APIRequest<Party>(headers, queryParameters, capResponseParty);
        CAPParty capPratyObj = new CAPParty(capParty, true);
        doReturn(capPratyObj).when(capTransformationService).createCapProfile(Mockito.any(), Mockito.any(),
                Mockito.anyString());
        doReturn(true).when(jwtInterceptor).validateJWT(any(APIRequest.class));
        doReturn(accessList).when(uamAccessConfiguration).getAccessMap(any(String.class));
        ResponseEntity<Object> result = apiController.maintainPartyV2(headers, queryParameters, person);
        assertTrue(ObjectUtils.isNotEmpty(result.getBody()));
    }

    private APIResponse getApiResponse() {
        APIResponse apiResponse = new APIResponse();
        apiResponse.setOcvId("7666565");
        List<SourceSystem> sourceSystems = new ArrayList<>();
        SourceSystem sourceSystem = new SourceSystem();
        sourceSystem.setSourceSystemId("898989889");
        sourceSystem.setSourceSystemName("CAP-CIS");
        sourceSystems.add(sourceSystem);
        apiResponse.setSourceSystems(sourceSystems);
        return apiResponse;
    }

    private ResponseEntity<TCRMService> setMDMResponse_Person() {

        TCRMService tcrmService = new TCRMService();
        TxResult txResult = new TxResult();
        txResult.setResultCode("SUCCESS");
        TxResponse txResponse = new TxResponse();
        txResponse.setTxResult(txResult);
        ResponseObject resObject = new ResponseObject();
        TCRMAdminContEquivBObjType adminContequiv = new TCRMAdminContEquivBObjType();
        adminContequiv.setAdminPartyId("11111");
        adminContequiv.setAdminSystemValue("CAP-CIS");
        TCRMPersonBObjType person = populatePersonBObj();
        person.getTCRMAdminContEquivBObj().add(adminContequiv);

        populatePersonName(person);
        populateIdentifiers(person);

        person.setPartyId("222222");

        CommonBObjType common = (CommonBObjType) person;
        JAXBElement<TCRMPersonBObjType> jaxbElement = new JAXBElement(
                new QName(TCRMPersonBObjType.class.getSimpleName()), TCRMPersonBObjType.class, common);
        resObject.getCommonBObj().add(jaxbElement);
        txResponse.setResponseObject(resObject);
        tcrmService.setTxResponse(txResponse);
        ResponseEntity<TCRMService> mdmResponse = new ResponseEntity<TCRMService>(tcrmService, HttpStatus.OK);

        return mdmResponse;
    }

    private TCRMPersonBObjType populatePersonBObj() {

        TCRMPersonBObjType person = new TCRMPersonBObjType();
        person.setPartyType("P");
        person.setPartyId("11111111");
        person.setBirthDate("1986-06-29");
        person.setSinceDate("1986-06-29");
        person.setClientStatusValue("Active");
        person.setMaritalStatusValue("Single");
        person.setGenderValue("M");
        person.setDeceasedDate("2019-06-29");
        person.setInactivatedDate("2019-06-29");
        XPersonBObjExtType xperson = new XPersonBObjExtType();
        xperson.setXKycStatusValue("NO STATUS ISSUED");
        xperson.setXKycVerificationLevelValue("NO VERIFICATION LEVEL ISSUED");
        xperson.setXEmployerName("ANZ BANK");
        xperson.setXEmployeeIndicator("Employee");
        xperson.setXBankruptDate("1944-08-29");
        xperson.setXOccupationType("Occ type");
        xperson.setXOccupationValue("Occ value");
        TCRMExtension personext = new TCRMExtension();
        JAXBElement<XPersonBObjExtType> xpersonjaxbElement = new JAXBElement(
                new QName(XPersonBObjExtType.class.getSimpleName()), XPersonBObjExtType.class, xperson);
        personext.getCommonExtensionBObj().add(xpersonjaxbElement);
        person.setTCRMExtension(personext);
        return person;
    }

    private void populatePersonName(TCRMPersonBObjType person) {

        TCRMPersonNameBObjType name = new TCRMPersonNameBObjType();
        name.setNameUsageValue("Legal name");
        name.setGivenNameOne("First name");
        name.setGivenNameTwo("Middle name");
        name.setLastName("Last name");
        name.setStartDate("2020-01-01");
        name.setEndDate("2020-01-01");
        name.setPrefixDescription("Mr.");
        name.setSuffix("Test");
        name.setSourceIdentifierValue("CAP-CIS");

        person.getTCRMPersonNameBObj().add(name);

    }

    private void populateIdentifiers(TCRMPersonBObjType person) {

        TCRMPartyIdentificationBObjType identifierDL = new TCRMPartyIdentificationBObjType();
        identifierDL.setIdentificationNumber("enc(R1zSZ0H)");
        identifierDL.setIdentificationValue("Drivers License");
        identifierDL.setStartDate("2020-01-01");

        TCRMPartyIdentificationBObjType identifierOCVID = new TCRMPartyIdentificationBObjType();
        identifierOCVID.setIdentificationNumber("33333");
        identifierOCVID.setIdentificationValue("One Customer ID");
        identifierOCVID.setStartDate("2020-01-01");

        XPartyIdentificationBObjExtType xIdentifier = new XPartyIdentificationBObjExtType();
        xIdentifier.setXOccurenceNum("1");

        JAXBElement<XPartyIdentificationBObjExtType> XidentifierJaxbElement = new JAXBElement<XPartyIdentificationBObjExtType>(
                new QName(XPartyIdentificationBObjExtType.class.getSimpleName()), XPartyIdentificationBObjExtType.class,
                xIdentifier);

        TCRMExtension tcrmExtension = new TCRMExtension();
        tcrmExtension.getCommonExtensionBObj().add(XidentifierJaxbElement);

        identifierOCVID.setTCRMExtension(tcrmExtension);

        person.getTCRMPartyIdentificationBObj().add(identifierDL);
        person.getTCRMPartyIdentificationBObj().add(identifierOCVID);
    }

    @Test
    public void validateBadRequestException() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.add(OCVConstants.TRACE_ID_HEADER, "abc123");

        headers.add(OCVConstants.AUTHORIZATION_HEADER,
                "Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImFwaWRldnRva2VuLmNvcnAuZGV2LmFueiJ9.eyJpc3MiOiJodHRwczovL2RhdGFwb3dlci1zdHMuYW56LmNvbSIsImF1ZCI6IlRlc3RVc2VyIiwic3ViIjoiVGVzdFVzZXIiLCJpYXQiOjE1ODgwNTAwMjMzODQsImV4cCI6MTU4ODA1MDkyMy4zODQsInNjb3BlcyI6WyJBVS5BTlpfSU5URVJOQUwuT0NWLk1NTE8uQUNDRVNTLlJFQUQiXSwiYW1yIjpbInBvcCJdLCJhY3IiOiJJQUwyLkFBTDEuRkFMMSJ9.MVN9DXoByov2ln4znQXmYk6IVIk1k7Gd3e3eqIJTfB0hgGs2xdAD2q73xMLjr22BgeylsrFdMV5PTFBhte8Wetgdyzyj7a1AuD4CJXFQ3dA0johCxS90g9qddhJhfJALVWsKtrVm86yMyvDT9mreIgVWnshiaD7ZLwrO9DxYQlqDdeJyH_RZWdFHMUMsECysF1psUDEZ8k3juEKeVNE0cM2QUBYxkvchU3hJUnrt2IpFmnf1d30Ksdyt1aqZIcN6y00qSm4LGI5OPVIm5ltF3TO2B9puZxSrBvn7NIjH6Xe2ocSzFagPctL_opzCwO0PnyOpeykmdReKfUNX8VkjaQ");
        headers.add(OCVConstants.CHANNEL, "CAP");
        headers.add(OCVConstants.REQUEST_TIMESTAMP, "Test time");
        headers.add(OCVConstants.USER_ID, "Test user");
        
        doReturn(accessList).when(uamAccessConfiguration).getAccessMap(any(String.class));

        MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
        String jsonReq = new String(
                Files.readAllBytes(ResourceUtils.getFile("classpath:OrgResponseJurisdiction.json").toPath()));
        RequestBuilder request = MockMvcRequestBuilders.post("/parties").contentType("application/json")
                .content(jsonReq).headers(headers).params(params);

        try {
            MvcResult rs = mockMvc.perform(request).andReturn();
        } catch (Exception ex) {
            String message = ex.getMessage();
            assertTrue(message.contains("BadRequestException: 4001"));
        }

    }

    @Test
    public void validateServiceUnavailableExceptionMaintainParty() throws Exception {
        Map<String, String> headers = prepareRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();
        Party person = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:SamplePersonInput.json"),
                Party.class);
        File responseXml = ResourceUtils.getFile("classpath:MaintainPartyIndResponse.xml");
        StreamSource xmlsource = new StreamSource(responseXml);
        StringWriter writer = new StringWriter();
        StreamResult result = new StreamResult(writer);
        TransformerFactory tFactory = TransformerFactory.newInstance();
        Transformer transformer = tFactory.newTransformer();
        transformer.transform(xmlsource, result);
        String strResult = writer.toString();
        HttpEntity<String> response = new HttpEntity<String>(strResult);

        doReturn(new StandardisedParty(setParameterisedBody(), true)).when(dataStandardisationService)
                .standardiseParty(Mockito.any(APIRequest.class));
        doReturn(new StandardisedParty(setParameterisedBody(), true)).when(dataStandardisationService)
        .invokeRedHatRuleEngine(Mockito.any(APIRequest.class));
        doReturn(new ValidatedParty(setParameterisedBody(), true)).when(dataValidationService)
                .validateParty(Mockito.any(APIRequest.class));

        doNothing().when(idempotencyConfigUtil).validate(Mockito.any(), Mockito.any(), Mockito.any());
        doReturn(idempotencyConfigUtil).when(maintainPartyService).getIdempotencyUtil();
        doReturn(false).when(idempotencyConfigUtil).isChannelIncluded(Mockito.anyString(), Mockito.anyString());
        doThrow(new ServiceUnavailableException("ServiceUnavailableException: 5005")).when(maintainPartyService)
                .invokeBackend(Mockito.any(String.class), Mockito.any(String.class));
        doReturn(true).when(jwtInterceptor).validateJWT(any(APIRequest.class));
        String jsonResponse = new String(
                Files.readAllBytes(ResourceUtils.getFile("classpath:SamplePersonInput.json").toPath()));
        doReturn(jsonResponse).when(maintainPartyService).transformMDMResponse((HttpEntity<String>) any(Object.class),
                any(String.class));
        doReturn(accessList).when(uamAccessConfiguration).getAccessMap(any(String.class));
        try {
            ResponseEntity<Object> result1 = apiController.maintainParty(headers, queryParameters, person);
        } catch (Exception ex) {
            String message = ex.getMessage();
            assertTrue(message.contains("ServiceUnavailableException: 5005"));
        }

    }

    public void validateunAuthorisedMDMExceptionMaintainParty() throws Exception {
        Map<String, String> headers = prepareRequestHeaders();
        Map<String, String> queryParameters = new HashMap<String, String>();
        Party person = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:SamplePersonInput.json"),
                Party.class);
        File responseXml = ResourceUtils.getFile("classpath:MaintainPartyIndResponse.xml");
        StreamSource xmlsource = new StreamSource(responseXml);
        StringWriter writer = new StringWriter();
        StreamResult result = new StreamResult(writer);
        TransformerFactory tFactory = TransformerFactory.newInstance();
        Transformer transformer = tFactory.newTransformer();
        transformer.transform(xmlsource, result);
        String strResult = writer.toString();
        HttpEntity<String> response = new HttpEntity<String>(strResult);

        doReturn(new StandardisedParty(setParameterisedBody(), true)).when(dataStandardisationService)
                .standardiseParty(Mockito.any(APIRequest.class));
        doReturn(new ValidatedParty(setParameterisedBody(), true)).when(dataValidationService)
                .validateParty(Mockito.any(APIRequest.class));
        doThrow(new ServiceUnavailableException("UnAuthorizedMDMException: 5006")).when(maintainPartyService)
                .invokeBackend(Mockito.any(String.class), Mockito.any(String.class));

        String jsonResponse = new String(
                Files.readAllBytes(ResourceUtils.getFile("classpath:SamplePersonInput.json").toPath()));
        doReturn(jsonResponse).when(maintainPartyService).transformMDMResponse((HttpEntity<String>) any(Object.class),
                any(String.class));
        try {
            ResponseEntity<Object> result1 = apiController.maintainParty(headers, queryParameters, person);
        } catch (Exception ex) {
            String message = ex.getMessage();
            assertTrue(message.contains("UnAuthorizedMDMException: 5006"));
        }

    }

    @Test
    public void validateBadRequestExceptionDeletepartyService() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.add(OCVConstants.TRACE_ID_HEADER, "abc123");

        headers.add(OCVConstants.AUTHORIZATION_HEADER,
                "Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImFwaWRldnRva2VuLmNvcnAuZGV2LmFueiJ9.eyJpc3MiOiJodHRwczovL2RhdGFwb3dlci1zdHMuYW56LmNvbSIsImF1ZCI6IlRlc3RVc2VyIiwic3ViIjoiVGVzdFVzZXIiLCJpYXQiOjE1ODgwNTAwMjMzODQsImV4cCI6MTU4ODA1MDkyMy4zODQsInNjb3BlcyI6WyJBVS5BTlpfSU5URVJOQUwuT0NWLk1NTE8uQUNDRVNTLlJFQUQiXSwiYW1yIjpbInBvcCJdLCJhY3IiOiJJQUwyLkFBTDEuRkFMMSJ9.MVN9DXoByov2ln4znQXmYk6IVIk1k7Gd3e3eqIJTfB0hgGs2xdAD2q73xMLjr22BgeylsrFdMV5PTFBhte8Wetgdyzyj7a1AuD4CJXFQ3dA0johCxS90g9qddhJhfJALVWsKtrVm86yMyvDT9mreIgVWnshiaD7ZLwrO9DxYQlqDdeJyH_RZWdFHMUMsECysF1psUDEZ8k3juEKeVNE0cM2QUBYxkvchU3hJUnrt2IpFmnf1d30Ksdyt1aqZIcN6y00qSm4LGI5OPVIm5ltF3TO2B9puZxSrBvn7NIjH6Xe2ocSzFagPctL_opzCwO0PnyOpeykmdReKfUNX8VkjaQ");
        headers.add(OCVConstants.CHANNEL, "CAP");
        headers.add(OCVConstants.REQUEST_TIMESTAMP, "Test time");
        headers.add(OCVConstants.USER_ID, "Test user");

        MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
        String jsonReq = new String(
                Files.readAllBytes(ResourceUtils.getFile("classpath:OrgResponseJurisdiction.json").toPath()));
        RequestBuilder request = MockMvcRequestBuilders.post("/parties/1234").contentType("application/json")
                .content(jsonReq).headers(headers).params(params);

        try {
            MvcResult rs = mockMvc.perform(request).andReturn();
        } catch (Exception ex) {
            String message = ex.getMessage();
            assertTrue(message.contains("BadRequestException: 4001"));
        }

    }

    private Party setParameterisedBody() throws JsonParseException, JsonMappingException, IOException {

        Party person = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:SamplePersonInput.json"),
                Party.class);
        return person;
    }

    private Party setParameterisedBodyANZX() throws JsonParseException, JsonMappingException, IOException {

        Party person = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:SamplePersonInputANZX.json"),
                Party.class);
        return person;
    }

    private HttpEntity<String> getXMLFromFile(String path) {
        String mdmResponse = "";
        try {
            File resource = ResourceUtils.getFile(path);
            mdmResponse = new String(Files.readAllBytes(resource.toPath()));
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        HttpEntity<String> response = new HttpEntity<String>(mdmResponse);
        return response;
    }

    private Map<String, String> prepareRequestHeaders() {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put(OCVConstants.ACCEPT_HEADER, "application/json");
        headers.put(OCVConstants.TRACE_ID_HEADER, "6846gjfj-fgdjg-afas");
        headers.put(OCVConstants.AUTHORIZATION_HEADER,
                "Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImFwaWRldnRva2VuLmNvcnAuZGV2LmFueiJ9.eyJpc3MiOiJodHRwczovL2RhdGFwb3dlci1zdHMuYW56LmNvbSIsImF1ZCI6IlRlc3RVc2VyIiwic3ViIjoiVGVzdFVzZXIiLCJpYXQiOjE1ODgwNTAwMjMzODQsImV4cCI6MTU4ODA1MDkyMy4zODQsInNjb3BlcyI6WyJBVS5BTlpfSU5URVJOQUwuT0NWLk1NTE8uQUNDRVNTLlJFQUQiXSwiYW1yIjpbInBvcCJdLCJhY3IiOiJJQUwyLkFBTDEuRkFMMSJ9.MVN9DXoByov2ln4znQXmYk6IVIk1k7Gd3e3eqIJTfB0hgGs2xdAD2q73xMLjr22BgeylsrFdMV5PTFBhte8Wetgdyzyj7a1AuD4CJXFQ3dA0johCxS90g9qddhJhfJALVWsKtrVm86yMyvDT9mreIgVWnshiaD7ZLwrO9DxYQlqDdeJyH_RZWdFHMUMsECysF1psUDEZ8k3juEKeVNE0cM2QUBYxkvchU3hJUnrt2IpFmnf1d30Ksdyt1aqZIcN6y00qSm4LGI5OPVIm5ltF3TO2B9puZxSrBvn7NIjH6Xe2ocSzFagPctL_opzCwO0PnyOpeykmdReKfUNX8VkjaQ");
        headers.put(OCVConstants.CHANNEL, "MMLO");
        headers.put(OCVConstants.USER_ID_HEADER, "shgfjsf");
        headers.put(OCVConstants.REQUEST_TIMESTAMP, "shgfjsf");
        headers.put(OCVConstants.USER_ID, "5465465464");
        headers.put(OCVConstants.APPLICATION, "OCV");
        return headers;
    }

    private Map<String, String> prepareANZXRequestHeaders() {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put(OCVConstants.ACCEPT_HEADER, "application/json");
        headers.put(OCVConstants.TRACE_ID_HEADER, "6846gjfj-fgdjg-afas");
        headers.put(OCVConstants.AUTHORIZATION_HEADER,
                "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6InN0aSJ9.eyJwdWJsaXNoZXIiOiJPbmUgQ3VzdG9tZXIgVmlldyIsImF1ZCI6IjU4NjRkMzZkLTA5YWMtNDMzYS05ODcxLTAyNDQ4MTQxZThiOCIsImFjciI6IklBTDEuQUFMMS5GQUwxIiwiaWF0IjoxNjUzMDA3MTAyLCJzdWIiOiJyYW1lc2giLCJhbXIiOlsicG9wIl0sImlzcyI6Ik9VT1NfU3R1YiIsInNjb3BlcyI6WyJBVS5BTlpfSU5URVJOQUwuT0NWLkFOWlguQUNDRVNTLlVQREFURSJdLCJleHAiOjE2NTMwMDgwMDJ9.L42kqgckcEEv6CUU7DIhSCqqilqktztzqRDb8CFokpegyz66TkRj5r6ZvDlBYVHwp978j4ejgbQjlyHVL4ckqX3zFK55fuvuNoxAolK94k8UWnjKz9JeuJNY_A6RH7uKjgXuNnkClPRSbKg-GDLH6uG7NoKCn4DWz4BcfvrwY9v4F6NvftddDVpnCHdA-t3PEQk12HuC59wtcj1vPToupzhdbSYVJrSYmrKhxAYvqSHWdWjrQoZ6mXXHmx_QqdaBIPna0VBIVFoVdR01440VEgEZ-NiyZM036F-cI-RkhZoLY52HRDgndILZksssI2nqZSO66ETJGBtsVLxk7s8-xw");
        headers.put(OCVConstants.CHANNEL, "FENERGOANZX");
        headers.put(OCVConstants.USER_ID_HEADER, "shgfjsf");
        headers.put(OCVConstants.REQUEST_TIMESTAMP, "2021-03-10 16:05:00.29");
        headers.put(OCVConstants.USER_ID, "5465465464");
        headers.put(OCVConstants.REQUEST_MODE_HEADER, "updateCustomerKYC");
        return headers;
    }

    private Map<String, String> prepareANZXRequestHeadersForInt3() {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put(OCVConstants.ACCEPT_HEADER, "application/json");
        headers.put(OCVConstants.TRACE_ID_HEADER, "6846gjfj-fgdjg-afas");
        headers.put(OCVConstants.AUTHORIZATION_HEADER,
                "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6InN0aSJ9.eyJwdWJsaXNoZXIiOiJPbmUgQ3VzdG9tZXIgVmlldyIsImF1ZCI6IjU4NjRkMzZkLTA5YWMtNDMzYS05ODcxLTAyNDQ4MTQxZThiOCIsImFjciI6IklBTDEuQUFMMS5GQUwxIiwiaWF0IjoxNjUzMDA3MTAyLCJzdWIiOiJyYW1lc2giLCJhbXIiOlsicG9wIl0sImlzcyI6Ik9VT1NfU3R1YiIsInNjb3BlcyI6WyJBVS5BTlpfSU5URVJOQUwuT0NWLkFOWlguQUNDRVNTLlVQREFURSJdLCJleHAiOjE2NTMwMDgwMDJ9.L42kqgckcEEv6CUU7DIhSCqqilqktztzqRDb8CFokpegyz66TkRj5r6ZvDlBYVHwp978j4ejgbQjlyHVL4ckqX3zFK55fuvuNoxAolK94k8UWnjKz9JeuJNY_A6RH7uKjgXuNnkClPRSbKg-GDLH6uG7NoKCn4DWz4BcfvrwY9v4F6NvftddDVpnCHdA-t3PEQk12HuC59wtcj1vPToupzhdbSYVJrSYmrKhxAYvqSHWdWjrQoZ6mXXHmx_QqdaBIPna0VBIVFoVdR01440VEgEZ-NiyZM036F-cI-RkhZoLY52HRDgndILZksssI2nqZSO66ETJGBtsVLxk7s8-xw");
        headers.put(OCVConstants.CHANNEL, "FENERGOANZX");
        headers.put(OCVConstants.USER_ID_HEADER, "shgfjsf");
        headers.put(OCVConstants.REQUEST_TIMESTAMP, "2021-03-10 16:05:00.29");
        headers.put(OCVConstants.USER_ID, "5465465464");
        headers.put(OCVConstants.REQUEST_MODE_HEADER, "updateCustomer");
        return headers;
    }

    private HttpHeaders prepareHttpHeaders() {
        HttpHeaders headers = new HttpHeaders();

        headers.add(OCVConstants.TRACE_ID_HEADER, "abc123");
        headers.add(OCVConstants.ACCEPT_HEADER, "application/json");
        headers.add(OCVConstants.AUTHORIZATION_HEADER,
                "Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImFwaWRldnRva2VuLmNvcnAuZGV2LmFueiJ9.eyJpc3MiOiJodHRwczovL2RhdGFwb3dlci1zdHMuYW56LmNvbSIsImF1ZCI6IlRlc3RVc2VyIiwic3ViIjoiVGVzdFVzZXIiLCJpYXQiOjE1ODgwNTAwMjMzODQsImV4cCI6MTU4ODA1MDkyMy4zODQsInNjb3BlcyI6WyJBVS5BTlpfSU5URVJOQUwuT0NWLk1NTE8uQUNDRVNTLlJFQUQiXSwiYW1yIjpbInBvcCJdLCJhY3IiOiJJQUwyLkFBTDEuRkFMMSJ9.MVN9DXoByov2ln4znQXmYk6IVIk1k7Gd3e3eqIJTfB0hgGs2xdAD2q73xMLjr22BgeylsrFdMV5PTFBhte8Wetgdyzyj7a1AuD4CJXFQ3dA0johCxS90g9qddhJhfJALVWsKtrVm86yMyvDT9mreIgVWnshiaD7ZLwrO9DxYQlqDdeJyH_RZWdFHMUMsECysF1psUDEZ8k3juEKeVNE0cM2QUBYxkvchU3hJUnrt2IpFmnf1d30Ksdyt1aqZIcN6y00qSm4LGI5OPVIm5ltF3TO2B9puZxSrBvn7NIjH6Xe2ocSzFagPctL_opzCwO0PnyOpeykmdReKfUNX8VkjaQ");
        headers.add(OCVConstants.CHANNEL, "CAP");
        headers.add(OCVConstants.REQUEST_TIMESTAMP, "Test time");
        headers.add(OCVConstants.USER_ID, "Test user");
        return headers;
    }

    private Map<String, String> prepareRequestHeadersDelete() {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put(OCVConstants.AUTHORIZATION_HEADER,
                "Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImFwaWRldnRva2VuLmNvcnAuZGV2LmFueiJ9.eyJpc3MiOiJodHRwczovL2RhdGFwb3dlci1zdHMuYW56LmNvbSIsImF1ZCI6IlRlc3RVc2VyIiwic3ViIjoiVGVzdFVzZXIiLCJpYXQiOjE1ODgwNTAwMjMzODQsImV4cCI6MTU4ODA1MDkyMy4zODQsInNjb3BlcyI6WyJBVS5BTlpfSU5URVJOQUwuT0NWLk1NTE8uQUNDRVNTLlJFQUQiXSwiYW1yIjpbInBvcCJdLCJhY3IiOiJJQUwyLkFBTDEuRkFMMSJ9.MVN9DXoByov2ln4znQXmYk6IVIk1k7Gd3e3eqIJTfB0hgGs2xdAD2q73xMLjr22BgeylsrFdMV5PTFBhte8Wetgdyzyj7a1AuD4CJXFQ3dA0johCxS90g9qddhJhfJALVWsKtrVm86yMyvDT9mreIgVWnshiaD7ZLwrO9DxYQlqDdeJyH_RZWdFHMUMsECysF1psUDEZ8k3juEKeVNE0cM2QUBYxkvchU3hJUnrt2IpFmnf1d30Ksdyt1aqZIcN6y00qSm4LGI5OPVIm5ltF3TO2B9puZxSrBvn7NIjH6Xe2ocSzFagPctL_opzCwO0PnyOpeykmdReKfUNX8VkjaQ");
        headers.put(OCVConstants.CHANNEL, "CAP");
        // headers.put(OCVConstants.ACCEPT_HEADER, "application/json");
        headers.put(OCVConstants.TRACE_ID_HEADER, "6846gjfj-fgdjg-afas");
        headers.put(OCVConstants.DELETE_IDTYPE, "CAP-CIS");
        headers.put(OCVConstants.CHANNEL, "MMLO");
        headers.put(OCVConstants.USER_ID_HEADER, "shgfjsf");
        headers.put(OCVConstants.REQUEST_TIMESTAMP, "shgfjsf");
        headers.put(OCVConstants.USER_ID, "5465465464");
        return headers;
    }

    @Test
    public void deletePartyV2Test() throws IOException, Exception {
        Map<String, String> headers = prepareRequestHeadersDelete();
        headers.put(OCVConstants.ACCEPT_HEADER, "application/json");
        String deletePartyId = "12345";
        Map<String, String> queryParameters = new HashMap<String, String>();
        queryParameters.put(OCVConstants.DELETE_IDTYPE, "CAP-CIS");
        String idType = queryParameters.get(OCVConstants.DELETE_IDTYPE);

        // APIRequest<Party> apiRequest = new APIRequest<>(headers, queryParameters,
        // party);
        APIResponse apiResponse = new APIResponse();

        doReturn(apiResponse).when(deletePartyService).deleteParty(Mockito.any(), Mockito.any(), Mockito.any());
        doReturn(true).when(jwtInterceptor).validateJWT(any(APIRequest.class));
        apiController.deletePartyV2(headers, queryParameters, "12345");
    }

    @Test
    public void maintainV2PartyOCVIDUnderReviewTest() throws Exception {
        SearchPartyResultWrapper searchPartyResultWrapper = new SearchPartyResultWrapper();
        ReflectionTestUtils.setField(retrievePartyService, "goodStatuses",
                "OK,NOT_FOUND,BAD_REQUEST,INTERNAL_SERVER_ERROR");
        ReflectionTestUtils.setField(retrievePartyService, "url", "https://localhost:8080/parties/retrieve");
        Map<String, String> headers = prepareANZXRequestHeaders();
        headers.put("idempotency-key", "3432434324-sadsad-23213-2313213213-70");
        headers.put("idempotency-first-sent", new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date()));
        Map<String, String> queryParameters = new HashMap<String, String>();
        Party person = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:SamplePersonInputANZX.json"),
                Party.class);

        ResponseEntity<TCRMService> mdmResponse = setMDMResponse_Person();
        String response = "{ \"partyType\": \"P\", \"source\": \"FENERGOANZX\", \"sourceEstablishedDate\": \"2005-11-10\", \"sourceClosedDate\": \"2015-11-10\", \"status\": \"Active\", \"dateOfBirth\": \"1969-11-06\", \"gender\": \"N\", \"maritalStatus\": \"Married/De Facto\", \"deceasedDate\": \"2000-01-01\", \"bankruptDate\": \"2019-03-15\", \"employeeIndicator\": \"Y\", \"employerName\": \"ANZ\", \"kycDetails\": { \"status\": \"CO\", \"verificationLevel\": \"NM\" }, \"occupation\": { \"code\": \"111200\" }, \"addresses\": [ { \"addressUsageType\": \"Primary Residential\", \"addressLineOne\": \"(LOT) YORK RD\", \"city\": \"POPANYINNING\", \"postalCode\": \"6309\", \"state\": \"SA\", \"country\": \"AUS\", \"region\": \"\", \"deliveryId\": \"80941156\", \"source\": \"FENERGOANZX\", \"startDate\": \"1901-01-01\", \"endDate\": \"9999-12-31\" }, { \"addressUsageType\": \"Primary Mailing\", \"addressLineOne\": \"PO BOX 147\", \"city\": \"CAMBERWELL\", \"postalCode\": \"3124\", \"state\": \"VIC\", \"country\": \"DZA\", \"region\": \"VIC\", \"deliveryId\": \"69775498\", \"source\": \"FENERGOANZX\", \"startDate\": \"2014-05-29\", \"endDate\": \"9999-12-31\" } ], \"phones\": [ { \"phoneUsageType\": \"Mobile Telephone\", \"phone\": \"+610422591580\", \"preferred\": \"\", \"source\": \"FENERGOANZX\", \"sequence\": \"3\", \"startDate\": \"1901-01-01\", \"endDate\": \"9999-12-31\" }, { \"phoneUsageType\": \"Primary Home Telephone\", \"phone\": \"+61386549523\", \"preferred\": \"Y\", \"source\": \"FENERGOANZX\", \"sequence\": \"1\", \"startDate\": \"1901-01-01\", \"endDate\": \"9999-12-31\" }, { \"phoneUsageType\": \"Secondary Home Telephone\", \"phone\": \"+613865675234\", \"preferred\": \"Y\", \"source\": \"FENERGOANZX\", \"sequence\": \"2\", \"startDate\": \"1901-01-01\", \"endDate\": \"2019-12-31\" } ], \"emails\": [ { \"emailUsageType\": \"Email\", \"email\": \"damian@trecose.com\", \"preferred\": \"\", \"source\": \"FENERGOANZX\", \"startDate\": \"1901-01-01\", \"endDate\": \"\" } ], \"identifiers\": [ { \"identifierUsageType\": \"Drivers License\", \"identifier\": \"5642341\", \"identificationIssueLocation\": \"VIC\", \"source\": \"FENERGOANZX\", \"sequence\": \"1\", \"startDate\": \"1901-01-01\", \"expiryDate\": \"9999-12-31\" } ], \"preferences\": [ { \"preferenceType\": \"Disclosure Indicator\", \"preferenceValue\": \"N\", \"preferenceReason\": \"Not Allowed\", \"source\": \"FENERGOANZX\", \"startDate\": \"1901-01-01\", \"endDate\": \"\" }, { \"preferenceType\": \"Primary Preferred Contact Day and Time\", \"preferenceValue\": \"000000000000NNNNNNN\", \"preferenceReason\": \"Not Interested\", \"source\": \"FENERGOANZX\", \"startDate\": \"2018-08-31\", \"endDate\": \"9999-12-31\" }, { \"preferenceType\": \"Secondary Preferred Contact Day and Time\", \"preferenceValue\": \"000000000000YYYYYYY\", \"preferenceReason\": \"Interested\", \"source\": \"CAP-CIS\", \"startDate\": \"2018-08-31\", \"endDate\": \"9999-12-31\" }, { \"preferenceType\": \"Advertising Indicator\", \"preferenceValue\": \"Y\", \"preferenceReason\": \"Allowed\", \"source\": \"FENERGOANZX\", \"startDate\": \"9999-12-01\", \"endDate\": \"9999-12-31\" } ], \"bankingServices\": [ { \"key\": \"DNC\", \"value\": \"Y\" }, { \"key\": \"NVE\", \"value\": \"Y\" } ], \"names\": [ { \"firstName\": \"Abhishek\", \"lastName\": \"DAMIAN M PHELAN\" }, { \"nameUsageType\": \"Mailing Name\", \"lastName\": \"MR D PHELAN\", \"startDate\": \"1901-01-01\", \"source\": \"FENERGOANZX\" } ], \"sourceSystems\": [ { \"sourceSystemId\": \"4012977562\", \"sourceSystemName\": \"FENERGOANZX\" } ] }";
        Party responseParty = new ObjectMapper().readValue(response, Party.class);
        ArrayList<Party> emptyParties = new ArrayList<Party>();
        searchPartyResultWrapper.getCertifiedResults().addAll(emptyParties);
        searchPartyResultWrapper.getProbableResults().addAll(emptyParties);
        doReturn(new StandardisedParty(setParameterisedBodyANZX(), true)).when(dataStandardisationService)
                .standardiseParty(Mockito.any(APIRequest.class));
        doReturn(new ValidatedParty(setParameterisedBodyANZX(), true)).when(dataValidationService)
                .validateParty(Mockito.any(APIRequest.class));
        doReturn(mdmResponse).when(maintainPartyService).invokeMdmBackend((Mockito.any(String.class)),
                Mockito.any(String.class));
        APIResponse apiResponse = getApiResponse();
        doReturn(apiResponse).when(maintainPartyService).transformMdmResponse(Mockito.any(String.class), Mockito.any(),
                Mockito.any());

        /* OCV ID under review error response */
        ErrorResponse errResp = new ErrorResponse();
        errResp.setHttpCode(409);
        errResp.setHttpMessage("Conflict Record");
        com.anz.mdm.ocv.api.exception.Error error = new com.anz.mdm.ocv.api.exception.Error();
        error.setStatusCode("4091");
        error.setStatusMessage("One of more parties in the OCV Id group is under review");
        List<com.anz.mdm.ocv.api.exception.Error> errors = new ArrayList<com.anz.mdm.ocv.api.exception.Error>();
        errors.add(error);
        errResp.setErrors(errors);

        ResponseEntity<ErrorResponse> apiErrorResponse = new ResponseEntity<ErrorResponse>(errResp,
                HttpStatus.CONFLICT);
        doReturn(apiErrorResponse).when(retrievePartyService).invokeDownStreamService(Mockito.any(),
                Mockito.any(String.class));
        doReturn(searchPartyResultWrapper).when(retrievePartyService).getResponse(Mockito.any(),
                Mockito.any(String.class));

        Party capResponseParty = new ObjectMapper().readValue(ResourceUtils.getFile("classpath:CapParty.json"),
                Party.class);
        APIRequest<Party> capParty = new APIRequest<Party>(headers, queryParameters, capResponseParty);
        CAPParty capPratyObj = new CAPParty(capParty, true);
        doReturn(capPratyObj).when(capTransformationService).createCapProfileV2(Mockito.any(), Mockito.any(),
                Mockito.anyString());
        doReturn(true).when(jwtInterceptor).validateJWT(any(APIRequest.class));

        doNothing().when(idempotencyConfigUtil).validate(Mockito.any(), Mockito.any(), Mockito.any());
        doReturn(idempotencyConfigUtil).when(maintainPartyService).getIdempotencyUtil();
        doReturn(true).when(idempotencyConfigUtil).isChannelIncluded(Mockito.anyString(), Mockito.anyString());
        doReturn(true).when(idempotencyConfigUtil).isRequestModeIncluded(Mockito.anyBoolean(), Mockito.anyString(),
                Mockito.anyString(), Mockito.anyString());
        doReturn(accessList).when(uamAccessConfiguration).getAccessMap(any(String.class));
        ResponseEntity<Object> result = apiController.maintainPartyV2(headers, queryParameters, person);
        assertTrue(ObjectUtils.isNotEmpty(result.getBody()));
    }
}