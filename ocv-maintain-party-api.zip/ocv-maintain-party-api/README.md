# OCV Maintain Party API

## Operation enabled


### POST /parties
Create a new party

### DELETE /parties/{partId}?idType={idType}
Delete a party for a given party Id
