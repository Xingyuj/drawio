# Building and running images locally

1. Build the docker images using
docker build -t ocv/ocv-party-api:0.1 -f Dockerfile.local . 

2. Update the environment variables in below command and execute (assuming you have docker installed locally)

3. Run the container
docker run -e OCV_ENVIRONTMENT=DEV -e MDM_URL=https://gcrdev6.service.dev/com.ibm.mdm.server.ws.restful/resources/MDMWSRESTful -e MDM_USER=augcrmdmadmindsa -e MDM_USER_PASS=Ev*luti*n04 -e KEYSTORE_LOCATION=/opt/OCVPartyAPI/TrustStore.jks -e KEYSTORE_PASSWORD=lethal -p 8080:8080 ocv/ocv-party-api:0.1